#!/usr/bin/perl
########################################################################################################################
#  Creater        :
#  Creation Time  :
#  Description    :
#  Modify By      :
#  Modify Time    :
#  Modify Content :
#  Script Version :1.0.3
########################################################################################################################
use strict;
use jrjtcommon;
use Common::Hive;
use zjcommon;

##############################################
#默认STINGER运行，失败后HIVE运行，可更改Runner和Retry_Runner
#修改最终生成表库名和表名
##############################################

my $Runner = "STINGER";
my $Retry_Runner = "HIVE";
my $DB = "";
my $TABLE = "";
#########################################################################################
#############################日期变量区##################################################
#########################################################################################

if ( $#ARGV < 0 ) { exit(1); }
my $CONTROL_FILE = $ARGV[0];

###########################################
#运行参数
my $RUN_PARAM = $ARGV[1];
my $JOB = substr(${CONTROL_FILE}, 4, length(${CONTROL_FILE})-17);#作业名称

#数据日期，格式 yyyy-mm-dd
my $TX_DATE = substr(${CONTROL_FILE},length(${CONTROL_FILE})-12, 4).'-'.substr(${CONTROL_FILE},length(${CONTROL_FILE})-8, 2).'-'.substr(${CONTROL_FILE},length(${CONTROL_FILE})-6, 2);
#数据日期，格式 yyyymmdd
my $TXDATE = substr($TX_DATE, 0, 4).substr($TX_DATE, 5, 2).substr($TX_DATE, 8, 2);
my $TX_MONTH = substr($TX_DATE, 0, 4).'-'.substr($TX_DATE, 5, 2);                                          #数据日期所在月，格式： yyyy-mm
my $TXMONTH = substr($TX_DATE, 0, 4).substr($TX_DATE, 5, 2);                                               #数据日期所在月，格式： yyyymm
my $TX_PREV_DATE = getPreviousDate($TX_DATE);                                                               #前一天，格式：yyyy-mm-dd
my $TX_NEXT_DATE = getNextDate($TX_DATE);                                                                   #下一天，格式： yyyy-mm-dd
my $TXPDATE = substr(${TX_PREV_DATE},0,4).substr(${TX_PREV_DATE},5,2).substr(${TX_PREV_DATE},8,2);        #前一天，格式： yyyymmdd
my $TXNDATE = substr(${TX_NEXT_DATE},0,4).substr(${TX_NEXT_DATE},5,2).substr(${TX_NEXT_DATE},8,2);        #下一天，格式： yyyymmdd
my $CURRENT_TIME = getNowTime();
my $TX_YEAR = substr($TX_DATE, 0, 4);#当年 yyyy

########################################################################################################################
# Write SQL For Your APP
sub getsql
{
    my @SQL_BUFF=();
    #########################################################################################
    ####################################以下为SQL编辑区######################################
    #sql编写区，多个sql按 $SQL_BUFF[0],$SQL_BUFF[1],$SQL_BUFF[2]...新建，按数字下标顺序运行,需要几个sql就使用几个$SQL_BUFF[x]变量
    #在sql中可以使用大量的日期变量，例如：
    #select * from app.a_01_pop_info_basic  where dt='$TX_DATE'
    #日期变量的所有日期都是根据当前任务数据日期计算而来，如果当前的数据日期为：2017-10-09
    #则上述语句程序解析后，实际运行语句为： select * from app.a_01_pop_info_basic where dt='2017-10-09'
    #日期变量列表见日期变量区
    #########################################################################################
    #示例sql:使用了数据日期内置变量：$TX_DATE
    $SQL_BUFF[0]=qq(

    set mapred.job.name=sql1;
     select
      case when count(1)<>0 then "check_ok"
      else 'check_failed'
      end pop_info_flag
 from app.a_01_pop_info_basic where dt='$TX_DATE';
);;;

    $SQL_BUFF[1]=qq(

    set mapred.job.name=sql3;
     select
      case when count(1)<>0 then "check_ok"
      else 'check_failed'
      end pop_info_flag
 from app.a_01_pop_info_basic where dt='$TX_DATE';
);;;

    #############################################################################################
    ########################################以上为SQL编辑区######################################
    #############################################################################################

    return @SQL_BUFF;
}

########################################################################################################################

sub main
{
    my $ret;

    my @sql_buff = getsql();

    for (my $i = 0; $i <= $#sql_buff; $i++) {
        $ret = Common::Hive::run_hive_sql($sql_buff[$i], ${Runner}, ${Retry_Runner});

        if ($ret != 0) {
            print getCurrentDateTime("SQL_BUFF[$i] Execute Failed");
            return $ret;
        }
        else {
            print getCurrentDateTime("SQL_BUFF[$i] Execute Success");
        }
    }

    return $ret;
}

########################################################################################################################
# program section
# To see if there is one parameter,
print getCurrentDateTime(" Startup Success ..");
print "JOB          : $JOB\n";
print "TX_DATE      : $TX_DATE\n";
print "TXDATE       : $TXDATE\n";
print "Target TABLE : $TABLE\n";

my $rc = main();
if ( $rc != 0 ) {
    print getCurrentDateTime("Task Execution Failed"),"\n";
} else{
    print getCurrentDateTime("Task Execution Success"),"\n";
}
exit($rc);

