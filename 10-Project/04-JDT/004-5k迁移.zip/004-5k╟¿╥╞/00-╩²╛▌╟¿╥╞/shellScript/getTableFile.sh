#!/bin/bash

hdfs dfs -ls hdfs://ns2/apps/hive/warehouse/stage.db/cwmart_sdm_gj_sdm_gj_general_s_db_journal_i/*/*/* >> ./tableFile.txt

startDate=20190101
endDate=20190630
nowDate=20200901
fileName=./tableFile.txt

echo "开始查询"
while ( [ $nowDate -le $endDate ] && [ $nowDate -ge $startDate ] )
do
  echo "开始处理 $nowDate"
  for bizType in `cat ./bizType.txt`
  do
    grep "$nowDate" $fileName | grep "$bizType" >> ./getTableFile.txt
  done
  nowDate=`date -d "$nowDate +1 day" "+%Y%m%d"`
done
echo "查询完成"