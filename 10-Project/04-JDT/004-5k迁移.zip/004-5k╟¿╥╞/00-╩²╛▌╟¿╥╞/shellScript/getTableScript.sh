#!/bin/bash

#请输入erp编码作为分区字段
if [ $# -lt 1 ];then
  echo "请输入erp作为导入数据分区；存储表名的文件的全路径；两个参数！";
  exit;
elif [ $# -eq 1 ];then
  echo "输入参数过少，请输入erp作为导入数据分区；存储表名的文件的全路径；两个参数！";
  exit;
elif [ $# -gt 2 ];then
  echo "输入参数个数过多，只需要输入erp作为导入数据分区；存储表名的文件的全路径；两个参数即可！";
  exit;
elif [ $# -eq 2 ];then
  if [ ! -f $2 ];then
    echo "输入参数个数正确，但是输入的存储表名的文件的全路径不正确，不存在该文件，请重新输入！";
    exit;
  else
    echo "输入参数个数正确，且文件存在，将开始执行程序！";
    erpCode=$1
    fileName=$2
  fi
fi


#最终导入到数据库的表
inputTab="dmf_dev.dmfdev_getTableStruct_5k_renxiaowei7"
#表名列表文件名
#fileName="./tableList5k.txt"
#最终导入数据库的文件或文件夹
basePath=$PWD
filePath="${basePath}/inputFile"

echo "即将生成${erpCode}的表结构"

#先删除要导入到库表的文件
rm -rf ./inputFile/*
rm -f ./logFile.txt

echo "===========开始获取表结构==========="
echo "===========开始获取表结构===========" >> ./logFile.txt
#上传文件的时候需要转成U8-UNIX，要不文件后面会存在^M的问题
for tabName in `cat ${fileName}`
do
  echo "===========开始处理表${tabName}==========="
  echo "===========开始处理表${tabName}===========" >> ./logFile.txt
  #删除临时存储表结的表
	rm -f ./descTableTmp.txt
	#从数据库查询表结构
  hive -S -e "desc ${tabName}" >> ./descTableTmp.txt
  #加工从数据库查出的表结构
  sh ./getTableStructScript.sh ${tabName}
  #从加工后的数据库表结构获取分区字段标识及最终表结构
  sh ./getTablePartitionScript.sh ${tabName}
  echo "===========处理完成表${tabName}==========="
  echo "===========处理完成表${tabName}===========" >> ./logFile.txt
done

echo "===========获取表结构完成==========="
echo "===========获取表结构完成===========" >> ./logFile.txt
echo "===========导入最终结果到数据库-开始==========="
echo "===========导入最终结果到数据库-开始===========" >> ./logFile.txt
#只新增，不覆盖
#hive -S -e "load data local inpath '${filePath}' overwrite into table ${inputTab} partition(erp='${erpCode}')"
hive -S -e "load data local inpath '${filePath}' into table ${inputTab} partition(erp='${erpCode}')"

echo "===========导入最终结果到数据库-完成==========="
echo "===========导入最终结果到数据库-完成===========" >> ./logFile.txt