#!/bin/bash
IFS_OLD=$IFS
IFS="^"

tabName=$1
#用于判断每个表中的分区字段
num=0
#记录每个表中字段的顺序
serialNum=0
#记录分区键个数
partitionNum=0
#记录分区字段,最多三个
partitionArr[$partitionNum]=""

fileName="./tableStructPartitionFileTmp.txt"

#包含空格的临时文件
rm -f ./tableStructFileSpaceTmp.txt


#获取分区字段
while read colName colType colComm
do
  #num=`grep -c $colName ./tableStructPartitionFileTmp.txt`
  sh grepColScript.sh $colName $fileName
  num=$?
  if [ $num -gt 1 ];then
    partitionArr[$partitionNum]=$colName;
    partitionNum=$(($partitionNum+1));
  fi
done<./tableStructFileTmp.txt

#填充没有放分区的部分。要不导入数据库以后粘贴出来的时候会有问题
if [ $partitionNum -lt 1 ];then
  partitionArr[0]="null";
  partitionArr[1]="null";
  partitionArr[2]="null";
elif [ $partitionNum -eq 1 ];then
  partitionArr[1]="null";
  partitionArr[2]="null";
elif [ $partitionNum -eq 2 ];then
  partitionArr[2]="null";
fi 

#插入 from $tabName 分区 
echo $tabName"^"$serialNum"^from^"$tabName"^"${partitionArr[0]}"^"${partitionArr[1]}"^"${partitionArr[2]} >> ./tableStructFileSpaceTmp.txt

while read colName colType colComm
do
  #num=`grep -c $colName ./tableStructPartitionFileTmp.txt`
  sh grepColScript.sh $colName $fileName
  num=$?
  serialNum=$(($serialNum+1));
  if [ $num -gt 1 ];then
    echo $tabName"^"$serialNum"^"$serialNum"^"$colName"^"$colType"^"$colComm"^Y" >> ./tableStructFileSpaceTmp.txt
  elif [ $num -eq 1 ];then
    echo $tabName"^"$serialNum"^"$serialNum"^"$colName"^"$colType"^"$colComm"^N" >> ./tableStructFileSpaceTmp.txt
  fi
done<./tableStructFileTmp.txt

#插入 TO $tabName 
serialNum=$(($serialNum+1));
echo $tabName"^"$serialNum"^TO^"$tabName"^null^null^null" >> ./tableStructFileSpaceTmp.txt

#去除空格
sed 's/\ //g' ./tableStructFileSpaceTmp.txt >> ./inputFile/tableStructFile.txt

IFS=$IFS_OLD