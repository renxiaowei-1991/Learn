#!/bin/bash

#专门用于导入文件到数据库表
if [ $# -ne 1 ];then
  echo "参数个数不正确！";
  exit;
else
  erp=$1
fi

basePath=$PWD
inputFilePath=$basePath/inputFile
tabName="dmf_dev.dmfdev_getTableMapp_5k_renxiaowei7"

#echo $basePath
#echo $inputFilePath
#echo $erp
#echo "LOAD DATA LOCAL INPATH '${inputFilePath}' INTO TABLE $tabName PARTITION(erp='$erp')"
hive -e "LOAD DATA LOCAL INPATH '${inputFilePath}' INTO TABLE $tabName PARTITION(erp='$erp')"