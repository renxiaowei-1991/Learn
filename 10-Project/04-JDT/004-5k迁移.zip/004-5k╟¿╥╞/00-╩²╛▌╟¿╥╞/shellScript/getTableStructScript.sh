#!/bin/bash

rm -f ./tableStructFileTmp.txt
rm -f ./tableStructPartitionFileTmp.txt

#-v用于在awk中引用外部变量
#分隔符用tab，在Linux输入的时候1) ctrl+v 2)按Tab 3)记得用''把tab引起来
#分隔符需要使用tab，否则注释中的内容可能被分割成多份
#输出文件的分隔符不能用","，第二个字段是字段类型，如果为decimal类型的，会被分割。找一个用的比较少的字符
awk -v table_name=$1 -F "	" '{
  colName=$1;
  colType=$2;
  comComm=$3;
  if(colName == "") 
    exit; 
  else 
    print colName"^"colType"^"comComm; 
  fi
}' ./descTableTmp.txt >> ./tableStructFileTmp.txt

awk -v table_name=$1 '{
  colName=$1;
  colType=$2;
  comComm=$3;
  if(colName == "" || colName == "#") 
    next; 
  else 
    print colName; 
  fi
}' ./descTableTmp.txt >> ./tableStructPartitionFileTmp.txt
