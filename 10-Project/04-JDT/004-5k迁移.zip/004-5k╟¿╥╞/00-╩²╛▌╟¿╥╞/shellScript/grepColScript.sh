#!/bin/bash

colName=$1
fileName=$2

#这部分逻辑直接加到上一个脚本会有问题，分隔符有冲突
num=0
for testName in `cat $fileName`
do
  if [ $colName == $testName ];then
    #终端上只有这样才能计算
    num=$(($num+1));
  fi
done
exit $num;
