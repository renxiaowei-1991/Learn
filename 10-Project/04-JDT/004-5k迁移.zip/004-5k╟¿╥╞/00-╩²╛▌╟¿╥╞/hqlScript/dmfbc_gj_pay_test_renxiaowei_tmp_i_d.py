# !/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE
def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_90_DATE = Time.date_sub(date=today, itv=90)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

"sql_01": """
set mapred.job.name=job_dmfbc_gj_pay_test_renxiaowei_tmp_i_d_01;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;

insert into dmf_bc.dmfbc_gj_pay_test_renxiaowei_tmp_i_d partition(dt='{TX_DATE}')
select     '' as def1
          ,'' as def2
          ,'' as def3
          ,'' as def4
          ,'' as def5
          ,'' as def6
          ,'' as def7
          ,'' as def8
          ,'' as def9
          ,'' as def10
          ,'' as def11
          ,'' as def12
          ,'' as def13
          ,'' as def14
          ,'' as def15
          ,'' as def16
          ,'' as def17
          ,'' as def18
          ,'' as def19
          ,'' as def20
from  dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d
;
""",

}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)