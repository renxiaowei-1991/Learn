#!/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE
def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！
      
"sql_01": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_01;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012;
create table if not exists dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012
as
--业务线表 快照转全量
select a.* from (
  select *,row_number() over(distribute by id sort by update_time desc) as rank
  from  odm.odm_fi_tz_dm_busi_type_s_d
  --where dt <= '{TX_DATE}'
) a where rank = 1;
""",
      
"sql_02": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_02;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
--月凭证汇总
--先进行月凭证汇总，后进行轧差
--****只需替换特殊处理部分的逻辑即可****
drop table if exists dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum;
create table dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
as
select     superior_biz_type
          ,biz_type
          ,biz_line
          ,product_no
          ,buss_link_name
          ,company_no
          ,receipt_type
          ,fund_type
          ,substr(trans_dt,0,6) as trans_dt
          ,CAST(round(case when rule_id = '101' then sum(src_trans_amt)-sum(src_trans_amt)/(1+tax)
                           when rule_id = '102' then sum(src_trans_amt)/(1+tax)
                           when rule_id = '100' then sum(src_trans_amt)
                           when rule_id = '201' then sum(src_trans_amt)*tax
                           when rule_id = '202' then sum(src_trans_amt)*(1+tax)
                           when rule_id = '200' then sum(src_trans_amt)
                      end,2) as decimal(30,12)) as trans_amt
          ,subject_no
          ,direction_em
          ,aux_subject_1
          ,aux_subject_2
          ,aux_subject_3
          ,'' as positive_or_negative            --新脚本尾差改造 取''
          ,ysyf_id                               --新脚本尾差改造 改为直接获取
          ,'' as voucher_id                      --新脚本尾差改造 取''
          ,dmf_bc.getmd5(
                           superior_biz_type
                          ,biz_type
                          ,biz_line
                          ,product_no
                          ,buss_link_name
                          ,company_no
                          ,receipt_type
                          ,fund_type
                          ,substr(trans_dt,0,6) -- trans_dt
                          ,CAST(round(case when rule_id = '101' then sum(src_trans_amt)-sum(src_trans_amt)/(1+tax)
                                           when rule_id = '102' then sum(src_trans_amt)/(1+tax)
                                           when rule_id = '100' then sum(src_trans_amt)
                                           when rule_id = '201' then sum(src_trans_amt)*tax
                                           when rule_id = '202' then sum(src_trans_amt)*(1+tax)
                                           when rule_id = '200' then sum(src_trans_amt)
                                      end,2) as decimal(30,12)) -- trans_amt
                          ,subject_no
                          ,direction_em
                          ,aux_subject_1
                          ,aux_subject_2
                          ,aux_subject_3
                          ,'' -- positive_or_negative
                          ,ysyf_id
                          ,'' -- voucher_id          
                          ,''  -- trans_id
                          ,bank_code
                          ,bank_name
                          ,buss_link_code
                          ,substr(nvl(manual_dt,trans_dt),0,6) -- manual_dt
                          ,currency
                          ,nvl(voucher_type,'0') -- voucher_type
                          ,rule_id
                          ,CAST(round(sum(src_trans_amt),10) as decimal(30,12)) --src_trans_amt   20220808精度修改
                          ,tax
                          ,CAST(round(sum(trans_amt),10) as decimal(30,12)) --old_trans_amt  20220808精度修改
                          ,voucher_state                       
                        ) as md5                --新脚本尾差改造 md5重新生成
          ,FROM_UNIXTIME(UNIX_TIMESTAMP(),'yyyy-MM-dd HH:mm:ss') AS create_dt
          ,''  as trans_id                       --新脚本尾差改造取''
          ,bank_code
          ,bank_name
          ,buss_link_code                        --新脚本示例为空 需要校验摘要和凭证号是否一致，这里需要取值，有其它作业会使用到这个字段做关联
          ,substr(nvl(manual_dt,trans_dt),0,6) as manual_dt  --新脚本尾差改造新增
          ,currency
          ,nvl(voucher_type,'0') as voucher_type --新脚本尾差改造新增
          ,rule_id                               --新脚本尾差改造新增 这里不能取''
          ,CAST(round(sum(src_trans_amt),10) as decimal(30,12)) as src_trans_amt   --新脚本尾差改造新增 这里不能取0   20220808精度修改
          ,tax                                   --新脚本尾差改造新增 这里不能取''
          ,CAST(round(sum(trans_amt),10) as decimal(30,12)) as old_trans_amt       --新脚本尾差改造新增 这里不能取0  20220808精度修改
          ,voucher_state    -- add by fanpengwei 异常凭证改造新增字段
          ,concat(case when voucher_state = '1' then 'normal_' else 'abnormal_' end --add by wanglixin@20210311 异常凭证改造
                  ,dmf_bc.getmd5(superior_biz_type,biz_type,biz_line,product_no,receipt_type,fund_type,company_no,buss_link_name
                         ,substr(trans_dt,0,6) -- trans_dt
                         ,currency
                         ,substr(nvl(manual_dt,trans_dt),0,6) --manual_dt
                         ,nvl(voucher_type,'0')
                         )) as data_key           --新脚本尾差改造新增 标识一对分录的key
          ,dmf_bc.getmd5(concat_ws(',',superior_biz_type,biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,substr(trans_dt,0,6),subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,ysyf_id,bank_code,bank_name,buss_link_code,substr(nvl(manual_dt,trans_dt),0,6),currency,nvl(voucher_type,'0'),rule_id,tax,voucher_state)  -- 增加金额字段
           ) as union_id       -- add by qf 20210309  唯一id 本次异常凭证改造点
          ,cast(null as string) as day_union_ids                -- add by qf 20210309  日凭证id 本次异常凭证改造点
from (
  --两张表字段一样，但是字段顺序不一样，需要全部展示
  select superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,trans_amt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,voucher_id,md5,create_dt,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,src_trans_amt,tax,manual_dt
         ,voucher_type,union_id,detail_union_ids,dt,biz_type
         ,'1' as voucher_state  
  from  dmf_gj.dmfgj_gj_sf_fi_hs_voucher_000012_i_d
  where  superior_biz_type='000012'
    and  biz_type in (select node_id from dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012 where parent_node_id='000012')
    --记账日期&交易日期
    and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}' and nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
    --dt的条件相当于初始化限定，20200901分区之前的未来期数据从飞哥的未来期数据表出，20200901分区之后的未来期数据正常从日大凭证出
    and  dt >= '2020-09-01'
    --这个交易日期的限定是飞哥的表中只有20200901之前分区的trans_dt大于等于20200901的数据。没处理trans_dt是8月的数据，所以本月不取8月的交易日期数据，否则还可能出现过去分区，交易日期是8月的数据，新增的用于处理凭证尾差改造的字段为空，会有问题
    and  nvl(manual_dt,trans_dt)>='20200901'
    and  trans_amt <> 0
  union all
  select superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,trans_amt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,voucher_id,md5,create_dt,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,src_trans_amt,tax,manual_dt
         ,voucher_type,'' as union_id,'' as detail_union_ids,dt,biz_type
         ,'1' as voucher_state
  from  sodm.cwmart_gudle_sdm_gj_general_g_db_journal_voucher_busbigtype_i  --20200901之前分区的20200831交易日期及之后的未来期数据
  where  superior_biz_type='000012'
    and  biz_type in (select node_id from dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012 where parent_node_id='000012')
    --记账日期&交易日期
    and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}' and nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
    --这个交易日期的限定是飞哥的表中只有20200901之前分区的trans_dt大于等于20200901的数据。没处理trans_dt是8月的数据，所以本月不取8月的交易日期数据，否则还可能出现过去分区，交易日期是8月的数据，新增的用于处理凭证尾差改造的字段为空，会有问题
    and  nvl(manual_dt,trans_dt)>='20200901'
    and  trans_amt <> 0
    union all
 -------------------------- begin 这段逻辑不需修改直接复制即可-------------------------
     select 
     superior_biz_type
    ,biz_line
    ,product_no
    ,buss_link_name
    ,company_no
    ,receipt_type
    ,fund_type
    ,trans_dt
    ,case when positive_or_negative = '0' then abs(trans_amt) 
          when positive_or_negative = '1' then abs(trans_amt)*-1
          when positive_or_negative = '2' then trans_amt
          when positive_or_negative = '3' then trans_amt*-1
          else trans_amt end as trans_amt
    ,subject_no
    ,direction_em
    ,aux_subject_1
    ,aux_subject_2
    ,aux_subject_3
    ,positive_or_negative
    ,ysyf_id
    ,md5 as voucher_id 
    ,md5
    ,FROM_UNIXTIME(UNIX_TIMESTAMP()) as create_dt
    ,trans_id
    ,bank_code
    ,bank_name
    ,buss_link_code
    ,currency
    ,rule_id -- add by xiaojia 凭证轧差使用
    ,case when positive_or_negative = '0' then abs(src_trans_amt)            
          when positive_or_negative = '1' then -abs(src_trans_amt)         
          when positive_or_negative = '2' then src_trans_amt
          when positive_or_negative = '3' then -src_trans_amt              
          else src_trans_amt end as src_trans_amt -- add by xiaojia 凭证轧差使用
    ,tax
    ,manual_dt    --add
    ,voucher_type --add
    ,union_id as union_id 
    ,union_id as detail_union_ids
    ,dt
    ,biz_type
    ,'0' as voucher_state    
 -------------------------- end 这段逻辑不需修改直接复制即可-------------------------
    from dmf_gj.dmfgj_ex_check_sf_detail_voucher_ex_000012_i_d
    where  superior_biz_type='000012'
    and  biz_type in (select node_id from dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012 where parent_node_id='000012')
    --记账日期&交易日期
    and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}' and nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
    --dt的条件相当于初始化限定，20200901分区之前的未来期数据从飞哥的未来期数据表出，20200901分区之后的未来期数据正常从日大凭证出
    and  dt >= '2020-09-01'
    --这个交易日期的限定是飞哥的表中只有20200901之前分区的trans_dt大于等于20200901的数据。没处理trans_dt是8月的数据，所以本月不取8月的交易日期数据，否则还可能出现过去分区，交易日期是8月的数据，新增的用于处理凭证尾差改造的字段为空，会有问题
    and  nvl(manual_dt,trans_dt)>='20200901'
    and  trans_amt <> 0
) a
group by   superior_biz_type
          ,biz_type
          ,biz_line
          ,product_no
          ,buss_link_name
          ,company_no
          ,receipt_type
          ,fund_type
          ,substr(trans_dt,0,6)
          ,subject_no
          ,direction_em
          ,aux_subject_1
          ,aux_subject_2
          ,aux_subject_3
          ,ysyf_id
          ,bank_code
          ,bank_name
          ,buss_link_code
          ,substr(nvl(manual_dt,trans_dt),0,6)
          ,currency
          ,nvl(voucher_type,'0')
          ,rule_id
          ,tax
          ,voucher_state
;
""",

#修改之前的逻辑，将手工操作后的异常凭证与手工打标不处理、挂接平衡的日凭证合并
#where 条件一定要参考改前sql3里面注释为【业财对账手工操作打标不处理和挂接平衡后生成凭证汇总】的条件,直接复制过来即可
#改动点只需替换里面的where条件即可
"sql_03": """   
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
    
-- 手工打标不处理和挂接平衡后日凭证 union all 手工操作后异常日凭证
drop table if exists dmf_tmp.tmp_dmfgj_gj_ycdz_fi_voucher_manual_ycdz_000012_sum;
create table         dmf_tmp.tmp_dmfgj_gj_ycdz_fi_voucher_manual_ycdz_000012_sum as
    select 
    superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,trans_amt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,voucher_id 
    ,md5,create_dt,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,src_trans_amt,tax,manual_dt,voucher_type,union_id ,detail_union_ids,dt,biz_type
    ,'1' as voucher_state
    from dmf_gj.dmfgj_gj_ycdz_fi_voucher_manual_ycdz_i_d
    where  superior_biz_type='000012'
      and  biz_type in (select node_id from dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012 where parent_node_id='000012')
      --记账日期&交易日期
      and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}' and nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
      --这个交易日期的限定是飞哥的表中只有20200901之前分区的trans_dt大于等于20200901的数据。没处理trans_dt是8月的数据，所以本月不取8月的交易日期数据，否则还可能出现过去分区，交易日期是8月的数据，新增的用于处理凭证尾差改造的字段为空，会有问题
      and  nvl(manual_dt,trans_dt)>='20200901'
      and  trans_amt <> 0
    union all         -- 下面的逻辑为本次异常凭证改造新增内容 
    select 
     superior_biz_type
    ,biz_line
    ,product_no
    ,buss_link_name
    ,company_no
    ,receipt_type
    ,fund_type
    ,trans_dt
    ,case when positive_or_negative = '0' then abs(trans_amt) 
          when positive_or_negative = '1' then abs(trans_amt)*-1
          when positive_or_negative = '2' then trans_amt
          when positive_or_negative = '3' then trans_amt*-1
          else trans_amt end as trans_amt
    ,subject_no
    ,direction_em
    ,aux_subject_1
    ,aux_subject_2
    ,aux_subject_3
    ,positive_or_negative
    ,ysyf_id
    ,md5 as voucher_id 
    ,md5
    ,FROM_UNIXTIME(UNIX_TIMESTAMP()) as create_dt
    ,trans_id
    ,bank_code
    ,bank_name
    ,buss_link_code
    ,currency
    ,rule_id -- add by xiaojia 凭证轧差使用
    ,case when positive_or_negative = '0' then abs(src_trans_amt)            
          when positive_or_negative = '1' then -abs(src_trans_amt)         
          when positive_or_negative = '2' then src_trans_amt
          when positive_or_negative = '3' then -src_trans_amt            
          else src_trans_amt end as src_trans_amt -- add by xiaojia 凭证轧差使用
    ,tax
    ,manual_dt    --add
    ,voucher_type --add
    ,union_id 
    ,union_id as detail_union_ids
    ,dt
    ,biz_type
    ,'0' as voucher_state    
    from dmf_gj.dmfgj_gj_ycdz_fi_journal_manual_ycdz_excheck_i_d  
    where  superior_biz_type='000012'
      and  biz_type in (select node_id from dmf_tmp.dmftmp_odm_fi_tz_dm_busi_type_s_d_000012 where parent_node_id='000012')
      --记账日期&交易日期
      and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}' and nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
      --这个交易日期的限定是飞哥的表中只有20200901之前分区的trans_dt大于等于20200901的数据。没处理trans_dt是8月的数据，所以本月不取8月的交易日期数据，否则还可能出现过去分区，交易日期是8月的数据，新增的用于处理凭证尾差改造的字段为空，会有问题
      and  nvl(manual_dt,trans_dt)>='20200901'
      and  trans_amt <> 0
--   group by superior_biz_type,biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,md5,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,tax,manual_dt,voucher_type,dt
    ;
""",  
      
"sql_04": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_04;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
      
--业财对账手工操作打标不处理和挂接平衡后生成凭证汇总
--这张表中数据最大的分区为20191029，最大的trans_dt为20191024，不存在20200901之后的未来期数据，不需要处理
--****只需替换特殊处理部分的逻辑即可****
insert into table dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
select     superior_biz_type
          ,biz_type
          ,biz_line
          ,product_no
          ,buss_link_name
          ,company_no
          ,receipt_type
          ,fund_type
          ,substr(trans_dt,0,6) as trans_dt
          ,CAST(round(case when rule_id = '101' then sum(src_trans_amt)-sum(src_trans_amt)/(1+tax)
                           when rule_id = '102' then sum(src_trans_amt)/(1+tax)
                           when rule_id = '100' then sum(src_trans_amt)
                           when rule_id = '201' then sum(src_trans_amt)*tax
                           when rule_id = '202' then sum(src_trans_amt)*(1+tax)
                           when rule_id = '200' then sum(src_trans_amt)
                      end,2) as decimal(30,12)) as trans_amt
          ,subject_no
          ,direction_em
          ,aux_subject_1
          ,aux_subject_2
          ,aux_subject_3
          ,'' as positive_or_negative            --新脚本尾差改造 取''
          ,ysyf_id                               --新脚本尾差改造 改为直接获取
          ,'' as voucher_id                      --新脚本尾差改造 取''
          ,dmf_bc.getmd5(
                           superior_biz_type
                          ,biz_type
                          ,biz_line
                          ,product_no
                          ,buss_link_name
                          ,company_no
                          ,receipt_type
                          ,fund_type
                          ,substr(trans_dt,0,6) -- trans_dt
                          ,CAST(round(case when rule_id = '101' then sum(src_trans_amt)-sum(src_trans_amt)/(1+tax)
                                           when rule_id = '102' then sum(src_trans_amt)/(1+tax)
                                           when rule_id = '100' then sum(src_trans_amt)
                                           when rule_id = '201' then sum(src_trans_amt)*tax
                                           when rule_id = '202' then sum(src_trans_amt)*(1+tax)
                                           when rule_id = '200' then sum(src_trans_amt)
                                      end,2) as decimal(30,12)) -- trans_amt
                          ,subject_no
                          ,direction_em
                          ,aux_subject_1
                          ,aux_subject_2
                          ,aux_subject_3
                          ,'' -- positive_or_negative
                          ,ysyf_id
                          ,'' -- voucher_id          
                          ,''  -- trans_id
                          ,bank_code
                          ,bank_name
                          ,buss_link_code
                          ,substr(nvl(manual_dt,trans_dt),0,6) -- manual_dt
                          ,currency
                          ,nvl(voucher_type,'0') -- voucher_type
                          ,rule_id
                          ,CAST(round(sum(src_trans_amt),10) as decimal(30,12)) --src_trans_amt   20220808精度修改
                          ,tax
                          ,CAST(round(sum(trans_amt),10) as decimal(30,12)) --old_trans_amt  20220808精度修改
                          ,voucher_state          
                         ) as md5                --新脚本尾差改造 md5重新生成
          ,FROM_UNIXTIME(UNIX_TIMESTAMP(),'yyyy-MM-dd HH:mm:ss') AS create_dt
          ,''  as trans_id                       --新脚本尾差改造 取''
          ,bank_code
          ,bank_name
          ,buss_link_code                        --新脚本示例为空 需要校验摘要和凭证号是否一致，这里需要取值，有其它作业会使用到这个字段做关联
          ,substr(nvl(manual_dt,trans_dt),0,6) as manual_dt  -- 新脚本尾差改造新增
          ,currency
          ,nvl(voucher_type,'0') as voucher_type --新脚本尾差改造新增
          ,rule_id                               --新脚本尾差改造新增 这里不能取''
          ,CAST(round(sum(src_trans_amt),10) as decimal(30,12)) as src_trans_amt   --新脚本尾差改造新增 这里不能取0   20220808精度修改
          ,tax                                   --新脚本尾差改造新增 这里不能取''
          ,CAST(round(sum(trans_amt),10) as decimal(30,12)) as old_trans_amt       --新脚本尾差改造新增 这里不能取0  20220808精度修改
          ,voucher_state            -- add by wanglixin@20210311 新增字段，本次异常凭证改造点
          ,concat(case when voucher_state = '1' then 'normal_' else 'abnormal_' end -- add by wanglixin@20210311 新增字段，本次异常凭证改造点 
                  ,dmf_bc.getmd5(superior_biz_type,biz_type,biz_line,product_no,receipt_type,fund_type,company_no,buss_link_name
                         ,substr(trans_dt,0,6) -- trans_dt
                         ,currency
                         ,substr(nvl(manual_dt,trans_dt),0,6)  -- manual_dt
                         ,nvl(voucher_type,'0')
                         )) as data_key           --新脚本尾差改造新增 标识一对分录的key
          ,dmf_bc.getmd5(concat_ws(',',superior_biz_type,biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,substr(trans_dt,0,6),subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,ysyf_id,bank_code,bank_name,buss_link_code,substr(nvl(manual_dt,trans_dt),0,6),currency,nvl(voucher_type,'0'),rule_id,tax,voucher_state)  -- 增加金额字段
           ) as union_id       -- add by qf 20210309  唯一id 本次异常凭证改造点
          ,cast(null as string) as day_union_ids                -- add by qf 20210309  日凭证id 本次异常凭证改造点
from dmf_tmp.tmp_dmfgj_gj_ycdz_fi_voucher_manual_ycdz_000012_sum
group by superior_biz_type
          ,biz_type
          ,biz_line
          ,product_no
          ,buss_link_name
          ,company_no
          ,receipt_type
          ,fund_type
          ,substr(trans_dt,0,6)  -- trans_dt
          ,subject_no
          ,direction_em
          ,aux_subject_1
          ,aux_subject_2
          ,aux_subject_3
          ,ysyf_id
          ,bank_code
          ,bank_name
          ,buss_link_code
          ,substr(nvl(manual_dt,trans_dt),0,6)  -- manual_dt
          ,currency
          ,nvl(voucher_type,'0')
          ,rule_id
          ,tax
          ,voucher_state
;
""",

#新增逻辑，本次异常凭证改造点
#注意修改业务大类编码
"sql_05": """
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;

-- 日凭证与月凭证关联关系表  --mod fanghaifei 20220627  修改日月凭证映射关系
insert overwrite table dmf_gj.dmfgj_ex_check_fi_hs_day_month_voucher_relation_i_d partition (dt = '{TX_DATE}', superior_biz_type='000012')
select dmf_bc.getmd5(concat_ws(',',superior_biz_type,biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,substr(trans_dt,0,6),subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,ysyf_id,bank_code,bank_name,buss_link_code,substr(nvl(manual_dt,trans_dt),0,6),currency,nvl(voucher_type,'0'),rule_id,tax,voucher_state))  as month_voucher_id
 ,union_id as day_voucher_id
from 
(
  --两张表字段一样，但是字段顺序不一样，需要全部展示
  select superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,trans_amt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,voucher_id,md5,create_dt,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,src_trans_amt,tax,manual_dt
        ,voucher_type,union_id,detail_union_ids,dt,biz_type
        ,'1' as voucher_state  
  from  dmf_gj.dmfgj_gj_sf_fi_hs_voucher_000012_i_d
  where  superior_biz_type='000012'
    and  biz_type in (select node_id from odm.odm_fi_tz_dm_busi_type_s_d WHERE dt='{TX_DATE}' AND  parent_node_id='000012' AND type=1 AND status=1 AND effective_date<='{TX_NEXTDATE}' AND (expire_date>'{TX_NEXTDATE}' OR COALESCE(expire_date,'')=''))
    --记账日期&交易日期
    and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}'
    and  nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
    --dt的条件相当于初始化限定，20200901分区之前的未来期数据从飞哥的未来期数据表出，20200901分区之后的未来期数据正常从日大凭证出
    and  dt >= '2020-09-01'
    --这个交易日期的限定是飞哥的表中只有20200901之前分区的trans_dt大于等于20200901的数据。没处理trans_dt是8月的数据，所以本月不取8月的交易日期数据，否则还可能出现过去分区，交易日期是8月的数据，新增的用于处理凭证尾差改造的字段为空，会有问题
    and  nvl(manual_dt,trans_dt)>='20200901'
    and  trans_amt <> 0
    union all
 -------------------------- begin 这段逻辑不需修改直接复制即可-------------------------
     select 
     superior_biz_type
    ,biz_line
    ,product_no
    ,buss_link_name
    ,company_no
    ,receipt_type
    ,fund_type
    ,trans_dt
    ,case when positive_or_negative = '0' then abs(trans_amt) 
          when positive_or_negative = '1' then abs(trans_amt)*-1
          when positive_or_negative = '2' then trans_amt
          when positive_or_negative = '3' then trans_amt*-1
          else trans_amt end as trans_amt
    ,subject_no
    ,direction_em
    ,aux_subject_1
    ,aux_subject_2
    ,aux_subject_3
    ,positive_or_negative
    ,ysyf_id
    ,md5 as voucher_id 
    ,md5
    ,FROM_UNIXTIME(UNIX_TIMESTAMP()) as create_dt
    ,trans_id
    ,bank_code
    ,bank_name
    ,buss_link_code
    ,currency
    ,rule_id -- add by xiaojia 凭证轧差使用
    ,case when positive_or_negative = '0' then abs(src_trans_amt)            
          when positive_or_negative = '1' then -abs(src_trans_amt)         
          when positive_or_negative = '2' then src_trans_amt
          when positive_or_negative = '3' then -src_trans_amt              
          else src_trans_amt end as src_trans_amt -- add by xiaojia 凭证轧差使用
    ,tax
    ,manual_dt    --add
    ,voucher_type --add
    ,union_id as union_id 
    ,union_id as detail_union_ids
    ,dt
    ,biz_type
    ,'0' as voucher_state    
 -------------------------- end 这段逻辑不需修改直接复制即可-------------------------
    from dmf_gj.dmfgj_ex_check_sf_detail_voucher_ex_000012_i_d

    where  superior_biz_type='000012'
      and  biz_type in (select node_id from odm.odm_fi_tz_dm_busi_type_s_d WHERE dt='{TX_DATE}' AND  parent_node_id='000012' AND type=1 AND status=1 AND effective_date<='{TX_NEXTDATE}' AND (expire_date>'{TX_NEXTDATE}' OR COALESCE(expire_date,'')=''))
      --记账日期&交易日期
      and  nvl(manual_dt,trans_dt)>='{TXPREMONTHFIRSTDATE}'
      and  nvl(manual_dt,trans_dt)<= date_format(last_day('{TX_DATE}'),'yyyyMMdd')
      --只处理dt小于20200901的数据
      and  dt >= '2020-09-01'
      and  nvl(manual_dt,trans_dt)>='20200901'
      and  trans_amt <> 0
) a
union all 
select 
dmf_bc.getmd5(concat_ws(',',superior_biz_type,biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,substr(trans_dt,0,6),subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,ysyf_id,bank_code,bank_name,buss_link_code,substr(nvl(manual_dt,trans_dt),0,6),currency,nvl(voucher_type,'0'),rule_id,tax,voucher_state)  -- 增加金额字段
           ) as union_id       -- add by qf 20210309  唯一id 本次异常凭证改造点
    ,union_id as day_voucher_id      
from dmf_tmp.tmp_dmfgj_gj_ycdz_fi_voucher_manual_ycdz_000012_sum
;
        
""",      

"sql_06": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_06;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
-- ******从这里开始的后面部分只需要直接替换业务大类编码即可*****==
-- 轧差值
-- 计算轧差 处理税金科目轧差数据
drop table if exists dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc;
create table dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc
as
select
data_key,
rule_type,
sum(trans_amt) as trans_amt
from (
    select
        data_key,
        case when rule_id in ('100','101','102') then '102'
             when rule_id in ('200','201','202') then '202'
             end as rule_type,
        case when rule_id = '100' then sum(trans_amt)
             when rule_id = '101' then -sum(trans_amt)
             when rule_id = '102' then -sum(trans_amt)
             when rule_id = '200' then sum(trans_amt)
             when rule_id = '201' then sum(trans_amt)
             when rule_id = '202' then -sum(trans_amt)
             end as trans_amt
    from (
        select t2.rule_id,
               t2.trans_amt,
               t2.data_key
        from
----------------------------- begin 用下面的逻辑替换之前的t1表-------------------------------------------
             (
            select data_key 
            from (
                select data_key,rule_id from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
                group by data_key,rule_id
            ) as t
            group by data_key having count(data_key) > 1  -- modify by xiaojia 20210311 修改处理逻辑，税金科目计算尾差，只计算同一个data_key存在的rule_id大于的1的数据
        ) t1  -- 先取需要计算税金轧差的数据
----------------------------- end 用下面的逻辑替换之前的t1表-------------------------------------------        
        inner join dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum t2
        on t1.data_key = t2.data_key
    ) as a
    group by data_key,rule_id
) as t
group by data_key,rule_type;
""",
      
"sql_07": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_07;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
-- 计算轧差 处理全部都是100、200的轧差数据
drop table if exists dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_100;
create table dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_100
as
select     t2.data_key
          ,t2.direction_em
          ,cast(round(sum(t2.src_trans_amt),2) as decimal(30,12)) - sum(t2.trans_amt) as trans_amt
from (select data_key
      from (select distinct data_key,rule_id from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum) a
      group by data_key
      having count(*) <=1
     ) t1  -- 先取需要计算税金轧差的数据
inner join dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum t2
        on t1.data_key = t2.data_key
where t2.rule_id in ('100','200')             -- add by xiaojia 20210311 只处理100,200的数据 本次异常凭证改造点
group by   t2.data_key,t2.direction_em;
""",

"sql_08": """
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;

-- 计算轧差 处理全部都是101、201的轧差数据 add by xiaojia 20210701
drop table if exists dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_101;
create table dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_101
as
select
    data_key,
    rule_type,
    direction_em,
    sum(trans_amt) as trans_amt
from (
    select
        data_key,
        rule_id as rule_type,
        '1' as direction_em,
        case when direction_em = '0' then sum(trans_amt)
             when direction_em = '1' then -sum(trans_amt)
             end as trans_amt
    from (
        select t2.rule_id,
               t2.trans_amt,
               t2.data_key,
               t2.direction_em
        from (
            select data_key 
            from (
                select data_key,rule_id from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
                group by data_key,rule_id
            ) as t
            group by data_key having count(data_key) <= 1  
        ) t1  -- 先取需要计算税金轧差的数据
        inner join dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum t2
        on t1.data_key = t2.data_key and t2.rule_id in ('101','201')
    ) as a
    group by data_key,rule_id,direction_em
) as t
group by data_key,rule_type,direction_em;
""",
      
"sql_09": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_09;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
-- 插入明细  轧差值放入金额最大的一个凭证中
DROP TABLE IF EXISTS dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_data;
CREATE TABLE IF NOT EXISTS dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_data
as
--处理税金科目轧差数据
select
t2.superior_biz_type,
t2.biz_type,
t2.biz_line,
t2.product_no,
t2.buss_link_name,
t2.company_no,
t2.receipt_type,
t2.fund_type,
t2.trans_dt,
t2.manual_dt,
t1.trans_amt,   -- 取轧差金额
t2.subject_no,
t2.direction_em,
t2.aux_subject_1,
t2.aux_subject_2,
t2.aux_subject_3,
t2.positive_or_negative,
t2.ysyf_id,
t2.voucher_id,
--concat('GC_',t2.md5) as md5,
dmf_bc.getmd5('GC_',t2.md5) as md5,  --月凭证推送目标表的md5长度只有32位，所以这里需要把GC_包括进来重新生成一个md5
t2.create_dt,
t2.trans_id,
t2.bank_code,
t2.bank_name,
t2.buss_link_code,
t2.currency,
t2.rule_id,
0 as src_trans_amt,  -- 轧差数据src_trans_amt取0
t2.tax,
0 as old_trans_amt,   -- 轧差数据old_trans_amt取0
t2.union_id,                   -- add by xiaojia 20210311 唯一键 本次异常凭证改造点
t2.voucher_state,               -- add by xiaojia 20210311 凭证状态 本次异常凭证改造点
t2.voucher_type               -- add by xiaojia 20210626 凭证类型
from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc t1
left join
(
select *
from (
    select
        superior_biz_type,
        biz_type,
        biz_line,
        product_no,
        buss_link_name,
        company_no,
        receipt_type,
        fund_type,
        trans_dt,
        manual_dt,
        trans_amt,
        subject_no,
        direction_em,
        aux_subject_1,
        aux_subject_2,
        aux_subject_3,
        positive_or_negative,
        ysyf_id,
        voucher_id,
        md5,
        create_dt,
        trans_id,
        bank_code,
        bank_name,
        buss_link_code,
        currency,
        rule_id,
        src_trans_amt,
        tax,
        old_trans_amt,
        data_key,
        union_id,                   -- add by xiaojia 20210311 唯一键
        voucher_state,               -- add by xiaojia 20210311 凭证状态
        voucher_type,                -- add by xiaojia 20210626 凭证凭证类型
        row_number() over (partition by data_key order by abs(trans_amt) desc ) rn
    from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
    where rule_id in ('102','202')
    ) t
where t.rn = 1
) t2
on t1.data_key = t2.data_key
and t1.rule_type = t2.rule_id
where t1.trans_amt <> 0
--处理全部都是100、200的轧差数据
union
select
t2.superior_biz_type,
t2.biz_type,
t2.biz_line,
t2.product_no,
t2.buss_link_name,
t2.company_no,
t2.receipt_type,
t2.fund_type,
t2.trans_dt,
t2.manual_dt,
t1.trans_amt,   -- 取轧差金额
t2.subject_no,
t2.direction_em,
t2.aux_subject_1,
t2.aux_subject_2,
t2.aux_subject_3,
t2.positive_or_negative,
t2.ysyf_id,
t2.voucher_id,
--concat('GC_',t2.md5) as md5,
dmf_bc.getmd5('GC_',t2.md5) as md5,  --月凭证推送目标表的md5长度只有32位，所以这里需要把GC_包括进来重新生成一个md5
t2.create_dt,
t2.trans_id,
t2.bank_code,
t2.bank_name,
t2.buss_link_code,
t2.currency,
t2.rule_id,
0 as src_trans_amt,  -- 轧差数据src_trans_amt取0
t2.tax,
0 as old_trans_amt,   -- 轧差数据old_trans_amt取0
t2.union_id,                   -- add by xiaojia 20210311 唯一键 本次异常凭证改造点
t2.voucher_state,               -- add by xiaojia 20210311 凭证状态 本次异常凭证改造点
t2.voucher_type               -- add by xiaojia 20210626 凭证类型
from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_100 t1
left join
(
select *
from (
    select
        superior_biz_type,
        biz_type,
        biz_line,
        product_no,
        buss_link_name,
        company_no,
        receipt_type,
        fund_type,
        trans_dt,
        manual_dt,
        trans_amt,
        subject_no,
        direction_em,
        aux_subject_1,
        aux_subject_2,
        aux_subject_3,
        positive_or_negative,
        ysyf_id,
        voucher_id,
        md5,
        create_dt,
        trans_id,
        bank_code,
        bank_name,
        buss_link_code,
        currency,
        rule_id,
        src_trans_amt,
        tax,
        old_trans_amt,
        data_key,
        union_id,                   -- add by xiaojia 20210311 唯一键
        voucher_state,               -- add by xiaojia 20210311 凭证状态
        voucher_type,                -- add by xiaojia 20210626 凭证凭证类型
        row_number() over (partition by data_key,direction_em order by abs(trans_amt) desc ) rn  --这里需要加direction_em分组
    from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
    where rule_id in ('100','200')
    ) t
where t.rn = 1
) t2
on t1.data_key = t2.data_key
and t1.direction_em = t2.direction_em
where t1.trans_amt <> 0
--处理全部都是101、201的轧差数据 add by xiaojia 20210701
union
select
t2.superior_biz_type,
t2.biz_type,
t2.biz_line,
t2.product_no,
t2.buss_link_name,
t2.company_no,
t2.receipt_type,
t2.fund_type,
t2.trans_dt,
t2.manual_dt,
t1.trans_amt,   -- 取轧差金额
t2.subject_no,
t2.direction_em,
t2.aux_subject_1,
t2.aux_subject_2,
t2.aux_subject_3,
t2.positive_or_negative,
t2.ysyf_id,
t2.voucher_id,
--concat('GC_',t2.md5) as md5,
dmf_bc.getmd5('GC_',t2.md5) as md5,  --月凭证推送目标表的md5长度只有32位，所以这里需要把GC_包括进来重新生成一个md5
t2.create_dt,
t2.trans_id,
t2.bank_code,
t2.bank_name,
t2.buss_link_code,
t2.currency,
t2.rule_id,
0 as src_trans_amt,  -- 轧差数据src_trans_amt取0
t2.tax,
0 as old_trans_amt,   -- 轧差数据old_trans_amt取0
t2.union_id,                   -- add by xiaojia 20210311 唯一键 本次异常凭证改造点
t2.voucher_state,               -- add by xiaojia 20210311 凭证状态 本次异常凭证改造点
t2.voucher_type               -- add by xiaojia 20210626 凭证类型
from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_101 t1
left join
(
select *
from (
    select
        superior_biz_type,
        biz_type,
        biz_line,
        product_no,
        buss_link_name,
        company_no,
        receipt_type,
        fund_type,
        trans_dt,
        manual_dt,
        trans_amt,
        subject_no,
        direction_em,
        aux_subject_1,
        aux_subject_2,
        aux_subject_3,
        positive_or_negative,
        ysyf_id,
        voucher_id,
        md5,
        create_dt,
        trans_id,
        bank_code,
        bank_name,
        buss_link_code,
        currency,
        rule_id,
        src_trans_amt,
        tax,
        old_trans_amt,
        data_key,
        union_id,                   -- add by xiaojia 20210311 唯一键
        voucher_state,               -- add by xiaojia 20210311 凭证状态
        voucher_type,               -- add by xiaojia 20210626 凭证类型
        row_number() over (partition by data_key,direction_em order by abs(trans_amt) desc ) rn  --这里需要加direction_em分组
    from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
    where rule_id in ('101','201') 
    ) t
where t.rn = 1
) t2
on t1.data_key = t2.data_key
and t1.direction_em = t2.direction_em
and t1.rule_type = t2.rule_id
where t1.trans_amt <> 0
;
""",
      
"sql_10": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_10;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;
      
-- 插入月凭证表
alter table dmf_gj.dmfgj_gj_sf_fi_hs_voucher_000012_month_i_d drop partition(dt = '{TX_DATE}' );
""",
      
"sql_11": """
set mapred.job.name=job_sdm_gj_general_g_db_journal_voucher_000012_month_i_11;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;
      
alter table dmf_gj.dmfgj_gj_sf_fi_hs_voucher_000012_month_i_d add partition(dt = '{TX_DATE}' );
insert overwrite table dmf_gj.dmfgj_gj_sf_fi_hs_voucher_000012_month_i_d partition(dt = '{TX_DATE}' )
select
superior_biz_type,
biz_type,
biz_line,
product_no,
buss_link_name,
company_no,
receipt_type,
fund_type,
trans_dt,
trans_amt,
subject_no,
direction_em,
aux_subject_1,
aux_subject_2,
aux_subject_3,
positive_or_negative,
ysyf_id,
voucher_id,
md5,
create_dt,
trans_id,
bank_code,
bank_name,
buss_link_code,
manual_dt,
currency,
voucher_type,  -- 月凭证增加凭证类型字段 0：自动凭证 1：跨账期凭证
rule_id,
src_trans_amt,
tax,
old_trans_amt,
union_id,                   -- add by xiaojia 20210311 唯一键 本次异常凭证改造点
voucher_state               -- add by xiaojia 20210311 凭证状态 本次异常凭证改造点
from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_sum
where trans_amt <> 0
union
-- 轧差数据
select
superior_biz_type,
biz_type,
biz_line,
product_no,
buss_link_name,
company_no,
receipt_type,
fund_type,
trans_dt,
trans_amt,
subject_no,
direction_em,
aux_subject_1,
aux_subject_2,
aux_subject_3,
positive_or_negative,
ysyf_id,
voucher_id,
md5,
create_dt,
trans_id,
bank_code,
bank_name,
buss_link_code,
manual_dt,
currency,
case when voucher_type = '0' then '6' else '7' end as voucher_type,   -- 月凭证增加凭证类型字段，6：自动凭证-轧差 7:跨账期-轧差 add by xiaojia 20210626
rule_id,
src_trans_amt,
tax,
old_trans_amt,
concat(union_id,'_',(case when voucher_type = '0' then '6' else '7' end)) as union_id,                   -- add by xiaojia 20220627 唯一键 区分尾差唯一键值
voucher_state               -- add by xiaojia 20210311 凭证状态 本次异常凭证改造点
from dmf_tmp.tmp_sdm_gj_general_g_db_journal_voucher_000012_gc_data
where trans_amt <> 0;
""",
      
}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)