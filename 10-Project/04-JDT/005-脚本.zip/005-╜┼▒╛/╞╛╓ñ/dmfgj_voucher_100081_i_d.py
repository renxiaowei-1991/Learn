#!/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
import os
import copy
import calendar

#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE
def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()

#
# ########################################################################################################################
# 新增函数 用于执行hive sql，execHiveSql
#

def log(msg, type="INFO"):
    print("[%s]%s-%s" % (type, time.strftime("%m-%d %H:%M:%S"), msg))

def execHiveSql(sql):

    lines = os.popen("""
        hive -e "SET hive.cli.print.header=true;
        set hive.exec.parallel=true;
        set hive.exec.parallel.thread.number=5;
        %s" | sed 's/\t/#$#/g'
    """ % sql).readlines()

    res = {"columns": [], "data": [], "type": "", "message": ""}
    cnt = len(lines)
    cols = []
    data = []

    res["type"] = "info"
    if cnt == 0:
        res["message"] = "OK"
        return res
    elif lines[0].strip() == "":
        res["message"] = "".join(lines[1:])
        return res
    elif lines[0].find(" ") > 0:
        msg = lines[0].lower()
        res["message"] = "".join(lines)
        if msg.find("error") >= 0 or msg.find("exception") >= 0:
            res["type"] = "error"
        return res

    res["type"] = "query"
    for i in range(0, cnt):
        line = lines[i]
        fds = line.split("#$#")
        newFds = [fd.strip() for fd in fds]

        if i == 0:
            cols = [c.split(".")[-1] for c in newFds]
        else:
            data.append(newFds)

    res["columns"] = cols
    res["data"] = data

    return res

def add_months(dt,months):
    month = dt.month - 1 + months
    year = dt.year + month / 12
    month = month % 12 + 1
    day = min(dt.day,calendar.monthrange(year,month)[1])
    return dt.replace(year=year, month=month, day=day)


# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())

#
# ########################################################################################################################
# 第1部分语句------START----------，初始化业务小类对应分区变量
#

sql_map_1={
    # 来源系统初始化
    "sql_01": """
        use dmf_tmp;

        drop table dmf_tmp.tmp_gj_transaction_detail_with_datasource_100081_i_d;
        create table dmf_tmp.tmp_gj_transaction_detail_with_datasource_100081_i_d
        as
        select t1.data_source_em from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d t lateral view dmf_bc.dmbiztype('100081') t1 as data_source_em;
    """,

    #add by xiaojia 20210511
    #新增sql段，工单记录账期dt范围表 根据小类取工单记录中的DT范围
    "sql_02": """
        use dmf_tmp;

        drop table dmf_tmp.tmp_biztype_periodcode_dts_100081;
        create table dmf_tmp.tmp_biztype_periodcode_dts_100081
        as
        select t1.biz_type,
        t1.period_code,
        t1.dt,
        t1.rerun_id,
        t1.period_status
        from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d t
        lateral view dmf_bc.dmperioddts('100081') t1 as biz_type,period_code,dt,rerun_id,period_status;
    """,
}
return_code = sql_task.execute_sqls(sql_map_1)
#
# ########################################################################################################################
# 第1部分语句------END----------，初始化业务小类对应分区变量
#


#
# ########################################################################################################################
# 第2部分语句------START----------，初始化变量
#

ret = execHiveSql("select data_source_em from dmf_tmp.tmp_gj_transaction_detail_with_datasource_100081_i_d")
# 来源系统变量
where__data_source_em = "''"
for data_source_em in [col[0] for col in ret["data"]]:
    where__data_source_em = where__data_source_em + ", '%s'" % data_source_em

all_dt_ret = execHiveSql("select dt from dmf_tmp.tmp_biztype_periodcode_dts_100081 group by dt")
if not all_dt_ret["data"]:
    log("当前小类没有分区范围记录，任务结束","ERROR")
    exit(return_code)

# 全部dt
where__all_dt = "''"
for dt in [col[0] for col in all_dt_ret["data"]]:
    where__all_dt = where__all_dt + ", '%s'" % dt

y_ret = execHiveSql("select dt,period_status from dmf_tmp.tmp_biztype_periodcode_dts_100081 where rerun_id is not null")
# 有工单记录，非开账状态的dt   select dt from dmf_tmp.tmp_biztype_periodcode_dts_100081 where rerun_id is not null and period_status = '0' group by dt
where__y_order_n_period_dts = "''"
# 有工单记录，开账状态的dt     select dt from dmf_tmp.tmp_biztype_periodcode_dts_100081 where rerun_id is not null and period_status = '1' group by dt
where__y_order_period_dts = "''"
for col in y_ret["data"]:
    if col[1] == '0':
        where__y_order_n_period_dts = where__y_order_n_period_dts + ", '%s'" % col[0]
    else:
        where__y_order_period_dts = where__y_order_period_dts + ", '%s'" % col[0]

log("where__y_order_n_period_dts:" + str(where__y_order_n_period_dts))
log("where__y_order_period_dts:" + str(where__y_order_period_dts))

# 无工单，全量dt
w_order_ret = execHiveSql("select dt from dmf_tmp.tmp_biztype_periodcode_dts_100081 where rerun_id is null and period_status = '1'")
where__w_order_dts = "''"
for dt in [col[0] for col in w_order_ret["data"]]:
    where__w_order_dts = where__w_order_dts + ", '%s'" % dt

log("where__w_order_dts:" + str(where__w_order_dts))

#
# ########################################################################################################################
# 第2部分语句------END----------，初始化变量
#


#
# ########################################################################################################################
# 第3部分语句------START----------，初始化业务小类对应分区变量及数据备份
#

sql_map_2={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

    #add by xiaojia 20210511
    #新增sql段，自动重跑账期dt范围表 自动重跑加工表-现存凭证账期和dt范围
    "sql_10": """
        use dmf_tmp;
        set hive.stats.autogather=false;
        set hive.execution.engine=mr;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set mapred.max.split.size=64000000;

        drop table dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081;
        create table dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081
        as
        select dt
        ,period_code
        ,case when period_code = dmf_bc.dmperiod('100081') then '1' else '0' end as period_status
        from dmf_gj.dmfgj_gj_hs_journal_back_all_i_d
        where dt in (%s) and biz_type = '100081'
        group by dt,period_code;

    """ % where__w_order_dts,

    #add by xiaojia 20210511
    #新增sql段，自动重跑账期dt范围表 自动重跑加工表-现存凭证账期和dt范围
    "sql_11": """
        use dmf_tmp;

        drop table dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081_n;
        create table dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081_n
        as
        select
        case when d1.dt is not null then d1.dt else d2.dt end dt
        ,case when d1.period_code is not null then d1.period_code else d2.period_code end period_code
        ,case when d1.period_status is not null then d1.period_status else d2.period_status end period_status
        from
        (select * from dmf_tmp.tmp_biztype_periodcode_dts_100081 where rerun_id is null and period_status = '1') d2
        left join dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081 d1
        on d2.dt = d1.dt
        ;

    """,
}

# 数据备份-初始化-第一次运行后不在运行
current_period_code = ""
period_codes = execHiveSql("select dmf_bc.dmperiod('100081')")
# 如果没有账期
if not period_codes["data"]:
    log("当前小类没有开账记录，任务结束","ERROR")
    exit(return_code)

for period_code in [col[0] for col in period_codes["data"]]:
    log("当前开账账期："+str(period_code))
    current_period_code = period_code

if sql_task.get_eq_type() != 'retry' and current_period_code != "":
    start_dt = datetime.datetime.strptime(period_code,'%Y%m').strftime("%Y-%m-01")
    end_dt = datetime.datetime.strptime(period_code,'%Y%m').strftime("%Y-%m-05")
    #查备份表是否为空
    back_cnt = execHiveSql("select count(1) as back_cnt from dmf_gj.dmfgj_gj_hs_journal_back_all_i_d where dt >= '{start_dt}' and dt <= '{end_dt}' and biz_type = '100081'".format(start_dt=start_dt,end_dt=end_dt))
    back_cnt = back_cnt["data"][0][0]
    log("备份数据是否存在："+start_dt+"|"+end_dt+"|"+str(back_cnt))
    if int(back_cnt) == 0:
        dt = copy.copy(start_dt)
        for i in range(1,6):
            sql_map_2["sql_"+str("0"+str(i) if i < 10 else i)] = """
                use dmf_gj;
                alter table dmf_gj.dmfgj_ex_check_detail_transaction_ex_back_all_i_d drop partition(dt='{dt}',biz_type='100081');
                alter table dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
                alter table dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');
                alter table dmf_gj.dmfgj_gj_hs_journal_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
                alter table dmf_gj.dmfgj_gj_hs_journal_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');

            """.format(dt=dt)
            dt = (datetime.datetime.strptime(dt,'%Y-%m-%d') + datetime.timedelta(days=1)).strftime("%Y-%m-%d")

        sql_map_2["sql_08"] = """
            use dmf_gj;
            set mapred.max.split.size=16000000;
            set hive.stats.autogather=false;
            set hive.execution.engine=tez;
            set hive.auto.convert.join = true;

            insert overwrite table dmf_gj.dmfgj_ex_check_detail_transaction_ex_back_all_i_d PARTITION (dt,biz_type)
            select origin_id
            ,serial_no
            ,biz_line
            ,product_no
            ,trans_type
            ,company_no1
            ,company_no2
            ,company_no3
            ,company_no4
            ,company_no5
            ,borrow_bank_acct
            ,loan_bank_acct
            ,trans_dt
            ,trans_amt
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,data_source_em
            ,customer_no
            ,merchant_no
            ,section_no
            ,pay_enum
            ,direction
            ,loan_type
            ,create_dt
            ,order_no
            ,project_no
            ,spare_no
            ,vir_merchant
            ,company_no6
            ,company_no7
            ,company_no8
            ,company_no9
            ,currency
            ,has_tax
            ,tax
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,product_id
            ,sku_id
            ,error_codes
            ,dt
            ,biz_type
            from dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d
            where dt >= '{start_dt}' and dt <= '{end_dt}'
            and biz_type = '100081';

            insert overwrite table dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d PARTITION (dt,biz_type,borrow_loan_status)
            select origin_id
            ,superior_biz_type
            ,biz_line
            ,product_no
            ,buss_link_name
            ,company_no
            ,receipt_type
            ,fund_type
            ,trans_dt
            ,trans_amt
            ,subject_no
            ,direction_em
            ,aux_subject_1
            ,aux_subject_2
            ,aux_subject_3
            ,voucher_id
            ,record_id
            ,serial_no
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,data_source_em
            ,trans_type
            ,positive_or_negative
            ,ysyf_id
            ,md5
            ,subject_type
            ,create_dt
            ,trans_id
            ,bank_code
            ,bank_name
            ,buss_link_code
            ,currency
            ,rule_id
            ,src_trans_amt
            ,tax
            ,manual_dt
            ,voucher_type
            ,aux_subject_1_type
            ,aux_subject_2_type
            ,aux_subject_3_type
            ,cal_trans_amt
            ,union_id
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,period_code
            ,product_id
            ,sku_id
            ,error_codes
            ,dt
            ,biz_type
            ,borrow_loan_status
            from dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d
            where dt >= '{start_dt}' and dt <= '{end_dt}'
            and biz_type = '100081';

            insert overwrite table dmf_gj.dmfgj_gj_hs_journal_back_all_i_d PARTITION (dt,biz_type,borrow_loan_status)
            select origin_id
            ,superior_biz_type
            ,biz_line
            ,product_no
            ,buss_link_name
            ,company_no
            ,receipt_type
            ,fund_type
            ,trans_dt
            ,trans_amt
            ,subject_no
            ,direction_em
            ,aux_subject_1
            ,aux_subject_2
            ,aux_subject_3
            ,voucher_id
            ,record_id
            ,serial_no
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,data_source_em
            ,trans_type
            ,positive_or_negative
            ,ysyf_id
            ,md5
            ,subject_type
            ,create_dt
            ,trans_id
            ,bank_code
            ,bank_name
            ,buss_link_code
            ,currency
            ,rule_id
            ,src_trans_amt
            ,tax
            ,manual_dt
            ,voucher_type
            ,aux_subject_1_type
            ,aux_subject_2_type
            ,aux_subject_3_type
            ,cal_trans_amt
            ,union_id
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,period_code
            ,product_id
            ,sku_id
            ,dt
            ,biz_type
            ,borrow_loan_status
            from dmf_gj.dmfgj_gj_pay_fi_journal_i_d
            where dt >= '{start_dt}' and dt <= '{end_dt}'
            and biz_type = '100081';
        """.format(start_dt=start_dt,end_dt=end_dt)
    
return_code = sql_task.execute_sqls(sql_map_2)
#
# ########################################################################################################################
# 第3部分语句------END----------，初始化业务小类对应分区变量
#


#
# ########################################################################################################################
# 第4部分语句------START----------，初始化业务小类对应分区变量
#

# 无工单记录，非开账状态的dt   select dt from dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081_n where period_status = '0' group by dt
where__w_order_n_period_dts = "''"
# 无工单记录，开账状态的dt     select dt from dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081_n where period_status = '1' group by dt
where__w_order_period_dts = "''"
w_ret = execHiveSql("select dt,period_status from dmf_tmp.tmp_gj_journal_biztype_periodcode_dts_100081_n")
for col in w_ret["data"]:
    if col[1] == '0':
        where__w_order_n_period_dts = where__w_order_n_period_dts + ", '%s'" % col[0]
    else:
        where__w_order_period_dts = where__w_order_period_dts + ", '%s'" % col[0]

log("where__w_order_n_period_dts:" + str(where__w_order_n_period_dts))
log("where__w_order_period_dts:" + str(where__w_order_period_dts))

where__n_period_dts = where__y_order_n_period_dts if where__y_order_n_period_dts != "''" else where__w_order_n_period_dts
where__period_dts = where__y_order_period_dts if where__y_order_period_dts != "''" else where__w_order_period_dts

log("where__n_period_dts:" + str(where__n_period_dts))
log("where__period_dts:" + str(where__period_dts))

#
# ########################################################################################################################
# 第4部分语句------END----------，初始化业务小类对应分区变量
#


#
# ########################################################################################################################
# 第5部分语句------START----------，取非当前账期dt且交易时间小于当前账期1号的数据
#
sql_map_3={
    #add by xiaojia 20210511
    #新增sql段，加工非当前账期dt且交易时间小于当前账期1号的异常交易数据
    "sql_001" : """
        use dmf_tmp;
        set mapred.max.split.size=16000000;
        set hive.execution.engine=tez;
        set hive.auto.convert.join = true;

        drop table dmf_tmp.tmp_dmfgj_ex_check_cf_detail_transaction_ex_000011_100081;
        create table dmf_tmp.tmp_dmfgj_ex_check_cf_detail_transaction_ex_000011_100081
        as
        select origin_id
        ,serial_no
        ,biz_line
        ,product_no
        ,trans_type
        ,company_no1
        ,company_no2
        ,company_no3
        ,company_no4
        ,company_no5
        ,borrow_bank_acct
        ,loan_bank_acct
        ,trans_dt
        ,trans_amt
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,customer_no
        ,merchant_no
        ,section_no
        ,pay_enum
        ,direction
        ,loan_type
        ,create_dt
        ,order_no
        ,project_no
        ,spare_no
        ,vir_merchant
        ,company_no6
        ,company_no7
        ,company_no8
        ,company_no9
        ,currency
        ,has_tax
        ,tax
        ,source_table                                          -- add by xiaojia 20210115 增加字段
        ,source_table_dt                                       -- add by xiaojia 20210115 增加字段
        ,repay_no                                              -- add by xiaojia 20210115 增加字段
        ,refund_no                                             -- add by xiaojia 20210115 增加字段
        ,bill_no                                               -- add by xiaojia 20210115 增加字段
        ,sett_id                                               -- add by xiaojia 20210115 增加字段
        ,fee_id                                                -- add by xiaojia 20210115 增加字段
        ,fee_type                                              -- add by xiaojia 20210115 增加字段
        ,sett_scenes                                           -- add by xiaojia 20210115 增加字段
        ,sett_biz_type                                         -- add by xiaojia 20210115 增加字段
        ,writeoff_status                                       -- add by xiaojia 20210115 增加字段
        ,product_id                                            -- add by xiaojia 20210115 增加字段
        ,sku_id                                                -- add by xiaojia 20210115 增加字段
        ,error_codes                                           -- add by xiaojia 20210115 增加字段
        ,dt
        ,biz_type
        from dmf_gj.dmfgj_ex_check_detail_transaction_ex_back_all_i_d
        where dt in (%s) and (case when length(trans_dt) = 10 then concat(trans_dt,' 00:00:00') else trans_dt end) < from_unixtime(unix_timestamp(dmf_bc.dmperiod('100081'),'yyyyMM'),'yyyy-MM-01 00:00:00') and biz_type = '100081'
        ;
    """ % where__n_period_dts,

    #add by xiaojia 20210511
    #新增sql段，加工非当前账期dt且交易时间小于当前账期1号的异常凭证数据
    "sql_002" : """
        use dmf_tmp;
        set mapred.max.split.size=16000000;
        set hive.execution.engine=tez;
        set hive.auto.convert.join = true;

        drop table dmf_tmp.tmp_dmfgj_ex_check_fi_hs_detail_voucher_ex_000011_100081;
        create table dmf_tmp.tmp_dmfgj_ex_check_fi_hs_detail_voucher_ex_000011_100081
        as
        select origin_id
        ,superior_biz_type
        ,biz_line
        ,product_no
        ,buss_link_name
        ,company_no
        ,receipt_type
        ,fund_type
        ,trans_dt
        ,trans_amt
        ,subject_no
        ,direction_em
        ,aux_subject_1
        ,aux_subject_2
        ,aux_subject_3
        ,voucher_id
        ,record_id
        ,serial_no
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,trans_type
        ,positive_or_negative
        ,ysyf_id
        ,md5
        ,subject_type
        ,create_dt
        ,trans_id
        ,bank_code
        ,bank_name
        ,buss_link_code
        ,currency
        ,rule_id
        ,src_trans_amt
        ,tax
        ,manual_dt
        ,voucher_type
        ,aux_subject_1_type
        ,aux_subject_2_type
        ,aux_subject_3_type
        ,cal_trans_amt
        ,union_id
        ,source_table
        ,source_table_dt
        ,repay_no
        ,refund_no
        ,bill_no
        ,sett_id
        ,fee_id
        ,fee_type
        ,sett_scenes
        ,sett_biz_type
        ,writeoff_status
        ,period_code
        ,product_id
        ,sku_id
        ,error_codes
        ,dt
        ,biz_type
        ,borrow_loan_status
        from dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d
        where dt in (%s) and trans_dt < concat(dmf_bc.dmperiod('100081'),'01') and biz_type = '100081'
        ;

    """ % where__n_period_dts,

    #add by xiaojia 20210511
    #新增sql段，加工非当前账期dt且交易时间小于当前账期1号的正常凭证数据
    "sql_003" : """
        use dmf_tmp;
        set mapred.max.split.size=16000000;
        set hive.execution.engine=tez;
        set hive.auto.convert.join = true;

        drop table dmf_tmp.tmp_dmfgj_gj_cf_fi_hs_voucher_000011_100081;
        create table dmf_tmp.tmp_dmfgj_gj_cf_fi_hs_voucher_000011_100081
        as
        select origin_id
        ,superior_biz_type
        ,biz_line
        ,product_no
        ,buss_link_name
        ,company_no
        ,receipt_type
        ,fund_type
        ,trans_dt
        ,trans_amt
        ,subject_no
        ,direction_em
        ,aux_subject_1
        ,aux_subject_2
        ,aux_subject_3
        ,voucher_id
        ,record_id
        ,serial_no
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,trans_type
        ,positive_or_negative
        ,ysyf_id
        ,md5
        ,subject_type
        ,create_dt
        ,trans_id
        ,bank_code
        ,bank_name
        ,buss_link_code
        ,currency
        ,rule_id
        ,src_trans_amt
        ,tax
        ,manual_dt    --add
        ,voucher_type --add
        ,aux_subject_1_type
        ,aux_subject_2_type
        ,aux_subject_3_type
        ,cal_trans_amt
        ,union_id                       -- 本次新增字段
        ,source_table                   -- 本次新增字段
        ,source_table_dt                -- 本次新增字段
        ,repay_no                       -- 本次新增字段
        ,refund_no                      -- 本次新增字段
        ,bill_no                        -- 本次新增字段
        ,sett_id                        -- 本次新增字段
        ,fee_id                         -- 本次新增字段
        ,fee_type                       -- 本次新增字段
        ,sett_scenes                    -- 本次新增字段
        ,sett_biz_type                  -- 本次新增字段
        ,writeoff_status                -- 本次新增字段
        ,period_code                    -- 本次新增字段
        ,product_id                     -- 本次新增字段
        ,sku_id                         -- 本次新增字段
        ,dt
        ,biz_type
        ,borrow_loan_status
        from dmf_gj.dmfgj_gj_hs_journal_back_all_i_d
        where dt in (%s) and trans_dt < concat(dmf_bc.dmperiod('100081'),'01') and biz_type = '100081'
        ;

    """ % where__n_period_dts,

}

#
# ########################################################################################################################
# 第5部分语句------END----------，取非当前账期dt且交易时间小于当前账期1号的数据
#

#
# ########################################################################################################################
# 第6部分语句------START----------，清理分区
#
sql_drop = ''
for dt in [col[0] for col in y_ret["data"]]:

    sql_drop += """

    --删除明细凭证表T-1分区
    --创建明细凭证表T-1分区
    alter table dmf_gj.dmfgj_gj_pay_fi_journal_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
    alter table dmf_gj.dmfgj_gj_pay_fi_journal_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');

    --删除日汇总凭证表T-1分区
    --创建日汇总凭证表T-1分区
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_i_d drop partition(dt='{dt}',biz_type='100081');
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_i_d add partition(dt='{dt}',biz_type='100081');

    --删除日汇总凭证推送表T-1分区
    --创建日汇总凭证推送表T-1分区
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_100081_i_d drop partition(dt='{dt}');
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_100081_i_d add partition(dt='{dt}');

    --删除异常交易明细表T-1分区
    --创建异常交易明细表T-1分区
    alter table dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d drop partition(dt='{dt}',biz_type='100081');
    alter table dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d add partition(dt='{dt}',biz_type='100081');

    --删除异常明细凭证表T-1分区
    alter table dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
    alter table dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');

    --删除明细凭证与日凭证关系表T-1分区
    alter table dmf_gj.dmfgj_ex_check_fi_hs_detail_day_voucher_relation_i_d drop partition(dt='{dt}',biz_type='100081');
    alter table dmf_gj.dmfgj_ex_check_fi_hs_detail_day_voucher_relation_i_d add partition(dt='{dt}',biz_type='100081');

    """.format(dt=dt)

for dt in [col[0] for col in w_ret["data"]]:
    sql_drop += """

    --删除明细凭证表T-1分区
    --创建明细凭证表T-1分区
    alter table dmf_gj.dmfgj_gj_pay_fi_journal_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
    alter table dmf_gj.dmfgj_gj_pay_fi_journal_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');

    --删除日汇总凭证表T-1分区
    --创建日汇总凭证表T-1分区
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_i_d drop partition(dt='{dt}',biz_type='100081');
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_i_d add partition(dt='{dt}',biz_type='100081');

    --删除日汇总凭证推送表T-1分区
    --创建日汇总凭证推送表T-1分区
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_100081_i_d drop partition(dt='{dt}');
    alter table dmf_gj.dmfgj_gj_pay_fi_voucher_100081_i_d add partition(dt='{dt}');

    --删除异常交易明细表T-1分区
    --创建异常交易明细表T-1分区
    alter table dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d drop partition(dt='{dt}',biz_type='100081');
    alter table dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d add partition(dt='{dt}',biz_type='100081');

    --删除异常明细凭证表T-1分区
    alter table dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
    alter table dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');

    --删除明细凭证与日凭证关系表T-1分区
    alter table dmf_gj.dmfgj_ex_check_fi_hs_detail_day_voucher_relation_i_d drop partition(dt='{dt}',biz_type='100081');
    alter table dmf_gj.dmfgj_ex_check_fi_hs_detail_day_voucher_relation_i_d add partition(dt='{dt}',biz_type='100081');

    """.format(dt=dt)
    
sql_map_3["sql_004"] = sql_drop

#
# ########################################################################################################################
# 第6部分语句------END----------，清理分区
#


sql_map_4={
    #modify by xiaojia 20210511，用于交易明细数据检查，后面注意修改业务小类的编码防止出现相同的临时表
    #交易明细取数范围
    #有工单记录：取sql_02非开账账期dt中trans_dt大于开账账期1号 union 开账账期dt
    #无工单记录（自动跑批）：取sql_02非开账账期dt中trans_dt大于开账账期1号 union 开账账期dt
    "sql_100": """
        use dmf_tmp;
        set hive.stats.column.autogather=false;
        set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles= true;
        set hive.merge.size.per.task = 1024000000;
        set hive.merge.smallfiles.avgsize = 1024000000;
        set hive.exec.reducers.max=2000;
        set hive.exec.reducers.bytes.per.reducer=64000000;
        set mapred.max.split.size=64000000;
        set hive.execution.engine=mr;

        -- 交易明细数据检查，暂存临时表
        DROP TABLE IF EXISTS dmf_tmp.tmp_dmftmp_ex_check_fi_hs_transaction_detail_ex_i_d_100081;
        create table dmf_tmp.tmp_dmftmp_ex_check_fi_hs_transaction_detail_ex_i_d_100081
        as
        select
        t1.*
        ,t2.check_result
        ,t2.error_codes
        from (
           select origin_id
           ,serial_no
           ,biz_line
           ,product_no
           ,trans_type
           ,company_no1
           ,company_no2
           ,company_no3
           ,company_no4
           ,company_no5
           ,borrow_bank_acct
           ,loan_bank_acct
           ,trans_dt
           ,trans_amt
           ,trans_no
           ,pay_no
           ,loan_no
           ,plan_no
           ,data_source_em
           ,customer_no
           ,merchant_no
           ,section_no
           ,pay_enum
           ,direction
           ,loan_type
           ,create_dt
           ,order_no
           ,project_no
           ,spare_no
           ,vir_merchant
           ,company_no6
           ,company_no7
           ,company_no8
           ,company_no9
           ,currency
           ,has_tax
           ,tax
           ,source_table                                          -- add by xiaojia 20210115 增加字段
           ,source_table_dt                                       -- add by xiaojia 20210115 增加字段
           ,repay_no                                              -- add by xiaojia 20210115 增加字段
           ,refund_no                                             -- add by xiaojia 20210115 增加字段
           ,bill_no                                               -- add by xiaojia 20210115 增加字段
           ,sett_id                                               -- add by xiaojia 20210115 增加字段
           ,fee_id                                                -- add by xiaojia 20210115 增加字段
           ,fee_type                                              -- add by xiaojia 20210115 增加字段
           ,sett_scenes                                           -- add by xiaojia 20210115 增加字段
           ,sett_biz_type                                         -- add by xiaojia 20210115 增加字段
           ,writeoff_status                                       -- add by xiaojia 20210115 增加字段
           ,product_id                                            -- add by xiaojia 20210115 增加字段
           ,sku_id                                                -- add by xiaojia 20210115 增加字段
           ,dt
           ,biz_type
           from dmf_gj.dmfgj_gj_pay_fi_hs_transaction_detail_i_d
           where (dt in ({where__n_period_dts}) and (case when length(trans_dt) = 10 then concat(trans_dt,' 00:00:00') else trans_dt end) >= from_unixtime(unix_timestamp(dmf_bc.dmperiod('100081'),'yyyyMM'),'yyyy-MM-01 00:00:00'))
           and data_source_em in ({where__data_source_em})
           and trans_amt != 0
           and biz_type = '100081'
           union all
           select origin_id
           ,serial_no
           ,biz_line
           ,product_no
           ,trans_type
           ,company_no1
           ,company_no2
           ,company_no3
           ,company_no4
           ,company_no5
           ,borrow_bank_acct
           ,loan_bank_acct
           ,trans_dt
           ,trans_amt
           ,trans_no
           ,pay_no
           ,loan_no
           ,plan_no
           ,data_source_em
           ,customer_no
           ,merchant_no
           ,section_no
           ,pay_enum
           ,direction
           ,loan_type
           ,create_dt
           ,order_no
           ,project_no
           ,spare_no
           ,vir_merchant
           ,company_no6
           ,company_no7
           ,company_no8
           ,company_no9
           ,currency
           ,has_tax
           ,tax
           ,source_table                                          -- add by xiaojia 20210115 增加字段
           ,source_table_dt                                       -- add by xiaojia 20210115 增加字段
           ,repay_no                                              -- add by xiaojia 20210115 增加字段
           ,refund_no                                             -- add by xiaojia 20210115 增加字段
           ,bill_no                                               -- add by xiaojia 20210115 增加字段
           ,sett_id                                               -- add by xiaojia 20210115 增加字段
           ,fee_id                                                -- add by xiaojia 20210115 增加字段
           ,fee_type                                              -- add by xiaojia 20210115 增加字段
           ,sett_scenes                                           -- add by xiaojia 20210115 增加字段
           ,sett_biz_type                                         -- add by xiaojia 20210115 增加字段
           ,writeoff_status                                       -- add by xiaojia 20210115 增加字段
           ,product_id                                            -- add by xiaojia 20210115 增加字段
           ,sku_id                                                -- add by xiaojia 20210115 增加字段
           ,dt
           ,biz_type
           from dmf_gj.dmfgj_gj_pay_fi_hs_transaction_detail_i_d
           where (dt in ({where__period_dts}))
           and data_source_em in ({where__data_source_em})
           and trans_amt != 0
           and biz_type = '100081'
        ) t1
        lateral view dmf_bc.dmdetailcheck (biz_type,biz_line,data_source_em,trans_type,origin_id,trans_no,loan_no,plan_no,trans_amt,trans_dt,company_no1,company_no2,company_no3,company_no4,company_no5,company_no6,company_no7,company_no8,company_no9,currency,has_tax,tax,product_no,pay_no,serial_no,merchant_no,borrow_bank_acct,loan_bank_acct,project_no,section_no,spare_no,vir_merchant,dt)
        t2 as data_check, check_result, error_codes;
    """.format(where__n_period_dts=where__n_period_dts,where__period_dts=where__period_dts,where__data_source_em=where__data_source_em),


    #modify by xiaojia 20210511，将交易明细异常数据插入到正式表中
    "sql_101": """
        use dmf_gj;
        set hive.stats.column.autogather=false;
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles= true;
        set hive.merge.size.per.task = 1024000000;
        set hive.merge.smallfiles.avgsize = 1024000000;
        set hive.exec.reducers.max=2000;
        set hive.exec.reducers.bytes.per.reducer=64000000;
        set mapred.max.split.size=64000000;
        set hive.execution.engine=mr;

-- 交易明细异常数据，保存入库
        insert overwrite table dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d partition (dt, biz_type)
        select
        origin_id
        ,serial_no
        ,biz_line
        ,product_no
        ,trans_type
        ,company_no1
        ,company_no2
        ,company_no3
        ,company_no4
        ,company_no5
        ,borrow_bank_acct
        ,loan_bank_acct
        ,trans_dt
        ,trans_amt
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,customer_no
        ,merchant_no
        ,section_no
        ,pay_enum
        ,direction
        ,loan_type
        ,create_dt
        ,order_no
        ,project_no
        ,spare_no
        ,vir_merchant
        ,company_no6
        ,company_no7
        ,company_no8
        ,company_no9
        ,currency
        ,has_tax
        ,tax
        ,source_table                                          -- add by xiaojia 20210115 增加字段
        ,source_table_dt                                       -- add by xiaojia 20210115 增加字段
        ,repay_no                                              -- add by xiaojia 20210115 增加字段
        ,refund_no                                             -- add by xiaojia 20210115 增加字段
        ,bill_no                                               -- add by xiaojia 20210115 增加字段
        ,sett_id                                               -- add by xiaojia 20210115 增加字段
        ,fee_id                                                -- add by xiaojia 20210115 增加字段
        ,fee_type                                              -- add by xiaojia 20210115 增加字段
        ,sett_scenes                                           -- add by xiaojia 20210115 增加字段
        ,sett_biz_type                                         -- add by xiaojia 20210115 增加字段
        ,writeoff_status                                       -- add by xiaojia 20210115 增加字段
        ,product_id                                            -- add by xiaojia 20210115 增加字段
        ,sku_id                                                -- add by xiaojia 20210115 增加字段
        ,error_codes                                           -- add by xiaojia 20210115 增加字段
        ,dt
        ,biz_type
        from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_transaction_detail_ex_i_d_100081
        where check_result = '0'
        -- add by xiaojia 20210511 需要union非当前账期dt且交易时间小于当前账期1号的异常交易数据 --------- start ---------
        union all
        select
        origin_id
        ,serial_no
        ,biz_line
        ,product_no
        ,trans_type
        ,company_no1
        ,company_no2
        ,company_no3
        ,company_no4
        ,company_no5
        ,borrow_bank_acct
        ,loan_bank_acct
        ,trans_dt
        ,trans_amt
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,customer_no
        ,merchant_no
        ,section_no
        ,pay_enum
        ,direction
        ,loan_type
        ,create_dt
        ,order_no
        ,project_no
        ,spare_no
        ,vir_merchant
        ,company_no6
        ,company_no7
        ,company_no8
        ,company_no9
        ,currency
        ,has_tax
        ,tax
        ,source_table                                          -- add by xiaojia 20210115 增加字段
        ,source_table_dt                                       -- add by xiaojia 20210115 增加字段
        ,repay_no                                              -- add by xiaojia 20210115 增加字段
        ,refund_no                                             -- add by xiaojia 20210115 增加字段
        ,bill_no                                               -- add by xiaojia 20210115 增加字段
        ,sett_id                                               -- add by xiaojia 20210115 增加字段
        ,fee_id                                                -- add by xiaojia 20210115 增加字段
        ,fee_type                                              -- add by xiaojia 20210115 增加字段
        ,sett_scenes                                           -- add by xiaojia 20210115 增加字段
        ,sett_biz_type                                         -- add by xiaojia 20210115 增加字段
        ,writeoff_status                                       -- add by xiaojia 20210115 增加字段
        ,product_id                                            -- add by xiaojia 20210115 增加字段
        ,sku_id                                                -- add by xiaojia 20210115 增加字段
        ,error_codes                                           -- add by xiaojia 20210115 增加字段
        ,dt
        ,biz_type
        from dmf_tmp.tmp_dmfgj_ex_check_cf_detail_transaction_ex_000011_100081
        -- add by xiaojia 20210511 需要union非当前账期dt且交易时间小于当前账期1号的异常交易数据 --------- end ---------
        ;

    """,

    #原来的sql段，将正常的交易明细数据生成明细凭证并保存在临时表中
    "sql_102": """
        set hive.stats.column.autogather=false;
        set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 16000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=16000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=16000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles= true;
        set hive.merge.size.per.task = 1024000000;
        set hive.merge.smallfiles.avgsize = 1024000000;
        set hive.exec.reducers.max=2000;
        set hive.exec.reducers.bytes.per.reducer=16000000;
        set mapred.max.split.size=16000000;
        set mapreduce.map.memory.mb=4096;
        set mapreduce.map.java.opts=-Xmx2048m;
        set hive.execution.engine=mr;
        use dmf_tmp;

        -- 生成明细凭证，注意排除金额为0的数据，暂存临时表
        DROP TABLE IF EXISTS dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_00_100081;
        create table         dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_00_100081
        as
        select
             t.origin_id
            ,t.superior_biz_type
            ,t.biz_line
            ,t.product_no
            ,t.buss_link_name
            ,t.company_no
            ,t.receipt_type
            ,t.fund_type
            ,t.trans_dt
            ,t.trans_amt
            ,t.subject_no
            ,t.direction_em
            ,t.aux_subject_1
            ,t.aux_subject_2
            ,t.aux_subject_3
            ,t.voucher_id
            ,t.record_id
            ,t.serial_no
            ,t.trans_no
            ,t.pay_no
            ,t.loan_no
            ,t.plan_no
            ,t.data_source_em
            ,t.trans_type
            ,t.positive_or_negative
            ,t.ysyf_id
            ,t.md5
            ,t.subject_type
            ,t.create_dt
            ,t.trans_id
            ,cast(null as string) as bank_code
            ,cast(null as string) as bank_name
            ,t.buss_link_code
            ,t.currency
            ,t.rule_id
            ,t.src_trans_amt
            ,t.tax
            ,t.manual_dt
            ,t.voucher_type
            ,t.aux_subject_1_type
            ,t.aux_subject_2_type
            ,t.aux_subject_3_type
            ,t.cal_trans_amt
            ,concat(t.origin_id,'_',t.ysyf_id) as union_id    -- add by xiaojia 20210115 增加唯一键
            ,t0.source_table                                   -- add by xiaojia 20210115 增加字段
            ,t0.source_table_dt                                -- add by xiaojia 20210115 增加字段
            ,t0.repay_no                                       -- add by xiaojia 20210115 增加字段
            ,t0.refund_no                                      -- add by xiaojia 20210115 增加字段
            ,t0.bill_no                                        -- add by xiaojia 20210115 增加字段
            ,t0.sett_id                                        -- add by xiaojia 20210115 增加字段
            ,t0.fee_id                                         -- add by xiaojia 20210115 增加字段
            ,t0.fee_type                                       -- add by xiaojia 20210115 增加字段
            ,t0.sett_scenes                                    -- add by xiaojia 20210115 增加字段
            ,t0.sett_biz_type                                  -- add by xiaojia 20210115 增加字段
            ,t0.writeoff_status                                -- add by xiaojia 20210115 增加字段
            ,dmf_bc.dmperiod('100081') as period_code          -- add by xiaojia 20210603 修改账期字段
            ,t0.product_id                                     -- add by xiaojia 20210115 增加字段
            ,t0.sku_id                                         -- add by xiaojia 20210115 增加字段
            ,t.dt
            ,t.biz_type
            ,t.borrow_loan_status
        FROM dmf_tmp.tmp_dmftmp_ex_check_fi_hs_transaction_detail_ex_i_d_100081 t0 --注意修改业务小类编码
        lateral view dmf_bc.dmjournal(biz_type,biz_line,data_source_em,trans_type,origin_id,trans_no,loan_no,plan_no,trans_amt,trans_dt,company_no1,company_no2,company_no3,company_no4,company_no5,company_no6,company_no7,company_no8,company_no9,currency,has_tax,tax,product_no,pay_no,serial_no,merchant_no,borrow_bank_acct,loan_bank_acct,project_no,section_no,spare_no,vir_merchant,dt,'1')
               t as origin_id,superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,trans_amt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,voucher_id,record_id,serial_no,trans_no,pay_no,loan_no,plan_no,data_source_em,trans_type,positive_or_negative,ysyf_id,md5,subject_type,create_dt,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,src_trans_amt,tax,manual_dt,voucher_type,aux_subject_1_type,aux_subject_2_type,aux_subject_3_type,cal_trans_amt,dt,biz_type,borrow_loan_status
        where t0.check_result = '1'
    """,

    #原来的sql段，对明细凭证进行UTDF检查打标，将结果存入临时表中
    "sql_103": """
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 16000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=16000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=16000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles= true;
        set hive.merge.size.per.task = 1024000000;
        set hive.merge.smallfiles.avgsize = 1024000000; 
        set mapred.max.split.size=16000000;
        use dmf_tmp;

        -- 明细凭证UTDF检查，暂存临时表
        DROP TABLE IF EXISTS dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_01_100081;
        create table         dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_01_100081
        as
        select *
        ,case when p.data_check = 1 and p.supplier_id != '' then cast(cast(round(rand()*99,0) as int) as string) 
		      else concat('hvie-', cast(cast(round(rand()*99,0) as int) as string)) end as explode_id  -- update by wanglixin@20210601 将sql_07中的逻辑迁移
        from (
            select
             t.origin_id
            ,t.superior_biz_type
            ,t.biz_line
            ,t.product_no
            ,t.buss_link_name
            ,t.company_no
            ,t.receipt_type
            ,t.fund_type
            ,t.trans_dt
            ,t.trans_amt
            ,t.subject_no
            ,t.direction_em
            ,t.aux_subject_1
            ,t.aux_subject_2
            ,t.aux_subject_3
            ,t.voucher_id
            ,t.record_id
            ,t.serial_no
            ,t.trans_no
            ,t.pay_no
            ,t.loan_no
            ,t.plan_no
            ,t.data_source_em
            ,t.trans_type
            ,t.positive_or_negative
            ,t.ysyf_id
            ,t.md5
            ,t.subject_type
            ,t.create_dt
            ,t.trans_id
            ,t.bank_code
            ,t.bank_name
            ,t.buss_link_code
            ,t.currency
            ,t.rule_id
            ,t.src_trans_amt
            ,t.tax
            ,t.manual_dt
            ,t.voucher_type
            ,t.aux_subject_1_type
            ,t.aux_subject_2_type
            ,t.aux_subject_3_type
            ,t.cal_trans_amt
            ,t.union_id                       -- add by xiaojia 20210115 增加字段
            ,t.source_table                   -- add by xiaojia 20210115 增加字段
            ,t.source_table_dt                -- add by xiaojia 20210115 增加字段
            ,t.repay_no                       -- add by xiaojia 20210115 增加字段
            ,t.refund_no                      -- add by xiaojia 20210115 增加字段
            ,t.bill_no                        -- add by xiaojia 20210115 增加字段
            ,t.sett_id                        -- add by xiaojia 20210115 增加字段
            ,t.fee_id                         -- add by xiaojia 20210115 增加字段
            ,t.fee_type                       -- add by xiaojia 20210115 增加字段
            ,t.sett_scenes                    -- add by xiaojia 20210115 增加字段
            ,t.sett_biz_type                  -- add by xiaojia 20210115 增加字段
            ,t.writeoff_status                -- add by xiaojia 20210115 增加字段
            ,t.period_code                    -- add by xiaojia 20210115 增加字段
            ,t.product_id                     -- add by xiaojia 20210115 增加字段
            ,t.sku_id                         -- add by xiaojia 20210115 增加字段
            ,t.dt
            ,t.biz_type
            ,t.borrow_loan_status
            ,case when (aux_subject_1_type = '2#2' or aux_subject_1_type = '3' or aux_subject_1_type = 'MASTER_CUSTOMER') then aux_subject_1
                  when (aux_subject_2_type = '2#2' or aux_subject_2_type = '3' or aux_subject_2_type = 'MASTER_CUSTOMER') then aux_subject_2
                  when (aux_subject_3_type = '2#2' or aux_subject_3_type = '3' or aux_subject_3_type = 'MASTER_CUSTOMER') then aux_subject_3
                  else ''
                  end as supplier_id
            ,udtf_table.data_check
            ,udtf_table.check_res_codes
            from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_00_100081 t  --注意修改业务大类及业务小类编码
                 lateral view dmf_bc.dmjournalcheck(origin_id,superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,trans_amt,subject_no,direction_em,aux_subject_1,aux_subject_2,aux_subject_3,voucher_id,record_id,serial_no,trans_no,pay_no,loan_no,plan_no,data_source_em,trans_type,positive_or_negative,ysyf_id,md5,subject_type,create_dt,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,src_trans_amt,tax,manual_dt,voucher_type,aux_subject_1_type,aux_subject_2_type,aux_subject_3_type,cal_trans_amt,dt,biz_type,borrow_loan_status)
                 udtf_table as data_check, check_result, check_res_codes
        ) p

        ;
    """,

    #原来的sql段，对明细凭证进行检查，公司主体、供应商字段检查，暂存临时表
    "sql_104": """
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles= true;
        set hive.merge.size.per.task = 1024000000;
        set hive.merge.smallfiles.avgsize = 1024000000; 
        set mapred.max.split.size=64000000;
        set hive.auto.convert.join=true;
        use dmf_tmp;

        -- 凭证明细检查，公司主体、供应商字段检查，暂存临时表
        DROP TABLE IF EXISTS dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_02_100081;
        create table         dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_02_100081
        as
        select
         t.origin_id
        ,t.superior_biz_type
        ,t.biz_line
        ,t.product_no
        ,t.buss_link_name
        ,t.company_no
        ,t.receipt_type
        ,t.fund_type
        ,t.trans_dt
        ,t.trans_amt
        ,t.subject_no
        ,t.direction_em
        ,t.aux_subject_1
        ,t.aux_subject_2
        ,t.aux_subject_3
        ,t.voucher_id
        ,t.record_id
        ,t.serial_no
        ,t.trans_no
        ,t.pay_no
        ,t.loan_no
        ,t.plan_no
        ,t.data_source_em
        ,t.trans_type
        ,t.positive_or_negative
        ,t.ysyf_id
        ,t.md5
        ,t.subject_type
        ,t.create_dt
        ,t.trans_id
        ,t.bank_code
        ,t.bank_name
        ,t.buss_link_code
        ,t.currency
        ,t.rule_id
        ,t.src_trans_amt
        ,t.tax
        ,t.manual_dt
        ,t.voucher_type
        ,t.aux_subject_1_type
        ,t.aux_subject_2_type
        ,t.aux_subject_3_type
        ,t.cal_trans_amt
        ,t.union_id
        ,t.source_table
        ,t.source_table_dt
        ,t.repay_no
        ,t.refund_no
        ,t.bill_no
        ,t.sett_id
        ,t.fee_id
        ,t.fee_type
        ,t.sett_scenes
        ,t.sett_biz_type
        ,t.writeoff_status
        ,t.period_code
        ,t.product_id
        ,t.sku_id
        ,t.dt
        ,t.biz_type
        ,t.borrow_loan_status
        ,t.data_check
        ,case when
                data_check = 1
                then
                    CONCAT_WS (
                        ',',
                        if(check_res_codes = '', null, check_res_codes),
                        if(((t4.id is null) and (t.aux_subject_1_type = '2#2' or t.aux_subject_2_type = '2#2' or t.aux_subject_3_type = '2#2' or t.aux_subject_1_type = '3' or t.aux_subject_2_type = '3' or t.aux_subject_3_type = '3' or t.aux_subject_1_type = 'MASTER_CUSTOMER' or t.aux_subject_2_type = 'MASTER_CUSTOMER' or t.aux_subject_3_type = 'MASTER_CUSTOMER')), '3002', null)
                    )
                else ''
            end as error_codes
        from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_01_100081 t    --注意修改业务大类及业务小类编码
        left join
             (
               select p1.id,p3.rn,p2.dt                     -- update by wanglixin@20210601 新增p2.dt
                from
                  (select id from dmf_dim.dmfdim_dim_fi_subject_merchant_h_d where end_dt = '4712-12-31') p1
                join
                  ( select dt,supplier_id                   -- update by wanglixin@20210601 新增dt
                   from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_01_100081
                   where data_check = 1 and supplier_id != ''
                   group by dt,supplier_id                  -- update by wanglixin@20210601 新增dt
                   ) p2
                 on p1.id= p2.supplier_id
                join
                  (select
                     cast(idx as string) rn
                   from
                    (select split(space(datediff('2020-04-09','2020-01-01')), ' ')  as x) t  --不需要修改
                  lateral view
                  posexplode(x) pe as idx, ele
                  ) p3
                on 1=1
              ) t4
        on concat(t.supplier_id,'_',t.explode_id) = concat(t4.id,'_',rn) and t.dt = t4.dt;

    """,

    #原来的sql段，筛选异常明细凭证，只取origin_id和error_codes
    "sql_105": """
        use dmf_tmp;

        -- 筛选异常凭证明细数据
        DROP TABLE IF EXISTS dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_03_100081;
        create table         dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_03_100081
        as
        select origin_id
        ,buss_link_code
        ,dt
        from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_02_100081    --注意修改业务大类及业务小类编码
        where error_codes != ''
        group by origin_id,buss_link_code,dt;

    """,

    #modify by xiaojia 20210511，需要union非当前账期dt且交易时间小于当前账期1号的异常凭证数据
    "sql_106": """
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set mapred.max.split.size=64000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles = true;
        set hive.merge.size.per.task = 256000000;
        set hive.merge.smallfiles.avgsize=256000000;
        set hive.execution.engine=mr;
        use dmf_gj;

-- 保存异常明细凭证数据
        insert overwrite table dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d partition (dt, biz_type, borrow_loan_status)
        select
         t.origin_id
        ,t.superior_biz_type
        ,t.biz_line
        ,t.product_no
        ,t.buss_link_name
        ,t.company_no
        ,t.receipt_type
        ,t.fund_type
        ,t.trans_dt
        ,t.trans_amt
        ,t.subject_no
        ,t.direction_em
        ,t.aux_subject_1
        ,t.aux_subject_2
        ,t.aux_subject_3
        ,t.voucher_id
        ,t.record_id
        ,t.serial_no
        ,t.trans_no
        ,t.pay_no
        ,t.loan_no
        ,t.plan_no
        ,t.data_source_em
        ,t.trans_type
        ,t.positive_or_negative
        ,t.ysyf_id
        ,t.md5
        ,t.subject_type
        ,t.create_dt
        ,t.trans_id
        ,t.bank_code
        ,t.bank_name
        ,t.buss_link_code
        ,t.currency
        ,t.rule_id
        ,t.src_trans_amt
        ,t.tax
        ,t.manual_dt    --add
        ,t.voucher_type --add
        ,t.aux_subject_1_type
        ,t.aux_subject_2_type
        ,t.aux_subject_3_type
        ,t.cal_trans_amt
        ,t.union_id
        ,t.source_table
        ,t.source_table_dt
        ,t.repay_no
        ,t.refund_no
        ,t.bill_no
        ,t.sett_id
        ,t.fee_id
        ,t.fee_type
        ,t.sett_scenes
        ,t.sett_biz_type
        ,t.writeoff_status
        ,t.period_code
        ,t.product_id
        ,t.sku_id
        ,t.error_codes
        ,t.dt
        ,t.biz_type
        ,t.borrow_loan_status
        from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_02_100081 t
        where exists (select 1 from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_03_100081 where origin_id = t.origin_id and buss_link_code=t.buss_link_code and dt=t.dt)
        -- add by xiaojia 20210511 需要union非当前账期dt且交易时间小于当前账期1号的异常凭证数据 ------ start -------
        union all
        select origin_id
        ,superior_biz_type
        ,biz_line
        ,product_no
        ,buss_link_name
        ,company_no
        ,receipt_type
        ,fund_type
        ,trans_dt
        ,trans_amt
        ,subject_no
        ,direction_em
        ,aux_subject_1
        ,aux_subject_2
        ,aux_subject_3
        ,voucher_id
        ,record_id
        ,serial_no
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,trans_type
        ,positive_or_negative
        ,ysyf_id
        ,md5
        ,subject_type
        ,create_dt
        ,trans_id
        ,bank_code
        ,bank_name
        ,buss_link_code
        ,currency
        ,rule_id
        ,src_trans_amt
        ,tax
        ,manual_dt
        ,voucher_type
        ,aux_subject_1_type
        ,aux_subject_2_type
        ,aux_subject_3_type
        ,cal_trans_amt
        ,union_id
        ,source_table
        ,source_table_dt
        ,repay_no
        ,refund_no
        ,bill_no
        ,sett_id
        ,fee_id
        ,fee_type
        ,sett_scenes
        ,sett_biz_type
        ,writeoff_status
        ,period_code
        ,product_id
        ,sku_id
        ,error_codes
        ,dt
        ,biz_type
        ,borrow_loan_status
        from dmf_tmp.tmp_dmfgj_ex_check_fi_hs_detail_voucher_ex_000011_100081
        -- add by xiaojia 20210511 需要union非当前账期dt且交易时间小于当前账期1号的异常凭证数据 ------ end -------
        ;
    """,

    #modify by xiaojia 20210511，需要union非当前账期dt且交易时间小于当前账期1号的正常凭证数据
    "sql_107": """
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set mapred.max.split.size=64000000;
        set mapreduce.map.memory.mb=4096;
        set mapreduce.map.java.opts=-Xmx2048m;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles = true;
        set hive.merge.size.per.task = 256000000;
        set hive.merge.smallfiles.avgsize=256000000;
        set hive.execution.engine=mr;
        use dmf_gj;

-- 保存正常凭证明细数据
        insert overwrite table dmf_gj.dmfgj_gj_pay_fi_journal_i_d partition (dt, biz_type, borrow_loan_status)
        select
         t.origin_id
        ,t.superior_biz_type
        ,t.biz_line
        ,t.product_no
        ,t.buss_link_name
        ,t.company_no
        ,t.receipt_type
        ,t.fund_type
        ,t.trans_dt
        ,t.trans_amt
        ,t.subject_no
        ,t.direction_em
        ,t.aux_subject_1
        ,t.aux_subject_2
        ,t.aux_subject_3
        ,t.voucher_id
        ,t.record_id
        ,t.serial_no
        ,t.trans_no
        ,t.pay_no
        ,t.loan_no
        ,t.plan_no
        ,t.data_source_em
        ,t.trans_type
        ,t.positive_or_negative
        ,t.ysyf_id
        ,t.md5
        ,t.subject_type
        ,t.create_dt
        ,t.trans_id
        ,t.bank_code
        ,t.bank_name
        ,t.buss_link_code
        ,t.currency
        ,t.rule_id
        ,t.src_trans_amt
        ,t.tax
        ,t.manual_dt    --add
        ,t.voucher_type --add
        ,t.aux_subject_1_type
        ,t.aux_subject_2_type
        ,t.aux_subject_3_type
        ,t.cal_trans_amt
        ,t.union_id                       -- 本次新增字段
        ,t.source_table                   -- 本次新增字段
        ,t.source_table_dt                -- 本次新增字段
        ,t.repay_no                       -- 本次新增字段
        ,t.refund_no                      -- 本次新增字段
        ,t.bill_no                        -- 本次新增字段
        ,t.sett_id                        -- 本次新增字段
        ,t.fee_id                         -- 本次新增字段
        ,t.fee_type                       -- 本次新增字段
        ,t.sett_scenes                    -- 本次新增字段
        ,t.sett_biz_type                  -- 本次新增字段
        ,t.writeoff_status                -- 本次新增字段
        ,t.period_code                    -- 本次新增字段
        ,t.product_id                     -- 本次新增字段
        ,t.sku_id                         -- 本次新增字段
        ,t.dt
        ,t.biz_type
        ,t.borrow_loan_status
        from dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_02_100081 t
        left join dmf_tmp.tmp_dmftmp_ex_check_fi_hs_journal_000011_i_d_03_100081 t1
        on t.origin_id = t1.origin_id and t.buss_link_code=t1.buss_link_code and t.dt=t1.dt
        where t1.origin_id is null
        -- add by xiaojia 20210511 需要union非当前账期dt且交易时间小于当前账期1号的正常凭证数据 ------ start -------
        union all
        select origin_id
        ,superior_biz_type
        ,biz_line
        ,product_no
        ,buss_link_name
        ,company_no
        ,receipt_type
        ,fund_type
        ,trans_dt
        ,trans_amt
        ,subject_no
        ,direction_em
        ,aux_subject_1
        ,aux_subject_2
        ,aux_subject_3
        ,voucher_id
        ,record_id
        ,serial_no
        ,trans_no
        ,pay_no
        ,loan_no
        ,plan_no
        ,data_source_em
        ,trans_type
        ,positive_or_negative
        ,ysyf_id
        ,md5
        ,subject_type
        ,create_dt
        ,trans_id
        ,bank_code
        ,bank_name
        ,buss_link_code
        ,currency
        ,rule_id
        ,src_trans_amt
        ,tax
        ,manual_dt    --add
        ,voucher_type --add
        ,aux_subject_1_type
        ,aux_subject_2_type
        ,aux_subject_3_type
        ,cal_trans_amt
        ,union_id                       -- 本次新增字段
        ,source_table                   -- 本次新增字段
        ,source_table_dt                -- 本次新增字段
        ,repay_no                       -- 本次新增字段
        ,refund_no                      -- 本次新增字段
        ,bill_no                        -- 本次新增字段
        ,sett_id                        -- 本次新增字段
        ,fee_id                         -- 本次新增字段
        ,fee_type                       -- 本次新增字段
        ,sett_scenes                    -- 本次新增字段
        ,sett_biz_type                  -- 本次新增字段
        ,writeoff_status                -- 本次新增字段
        ,period_code                    -- 本次新增字段
        ,product_id                     -- 本次新增字段
        ,sku_id                         -- 本次新增字段
        ,dt
        ,biz_type
        ,borrow_loan_status
        from dmf_tmp.tmp_dmfgj_gj_cf_fi_hs_voucher_000011_100081
        -- add by xiaojia 20210511 需要union非当前账期dt且交易时间小于当前账期1号的正常凭证数据 ------ end -------
        ;
    """,

    #修改前生成汇总凭证的sql段，新增字段union_id、detail_union_ids.注意需要先行新增业务大类汇总凭证的字段！！！
    #modify by xiaojia 20210511
    #修改sql段，修改dt范围
    "sql_108": """
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 256000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
        set mapred.max.split.size=256000000;
        set hive.merge.mapfiles = true;
        set hive.merge.mapredfiles = true;
        set hive.merge.size.per.task = 256000000;
        set hive.merge.smallfiles.avgsize=256000000;
        use dmf_gj;

--将明细凭证汇总
        insert overwrite table dmf_gj.dmfgj_gj_pay_fi_voucher_i_d partition (dt,biz_type)
        select
            superior_biz_type
            ,biz_line
            ,product_no
            ,buss_link_name
            ,company_no
            ,receipt_type
            ,fund_type
            ,trans_dt
            ,case when positive_or_negative = '0' then abs(sum(trans_amt))
                  when positive_or_negative = '1' then abs(sum(trans_amt))*-1
                  when positive_or_negative = '2' then sum(trans_amt)
                  when positive_or_negative = '3' then sum(trans_amt)*-1
                  else sum(trans_amt)
                  end as trans_amt
            ,subject_no
            ,direction_em
            ,aux_subject_1
            ,aux_subject_2
            ,aux_subject_3
            ,positive_or_negative
            ,ysyf_id
            ,md5 as voucher_id
            ,md5
            ,FROM_UNIXTIME(UNIX_TIMESTAMP()) as create_dt
            ,trans_id
            ,bank_code
            ,bank_name
            ,buss_link_code
            ,currency
            ,rule_id -- add by xiaojia 凭证轧差使用
            ,case when positive_or_negative = '0' then abs(sum(src_trans_amt))
                  when positive_or_negative = '1' then -abs(sum(src_trans_amt))
                  when positive_or_negative = '2' then sum(src_trans_amt)
                  when positive_or_negative = '3' then -sum(src_trans_amt)
                  else sum(src_trans_amt)
                  end as src_trans_amt -- add by xiaojia 凭证轧差使用
            ,tax
            ,manual_dt
            ,voucher_type
            ,dmf_bc.getmd5(concat_ws(',',superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,subject_no,direction_em
                     ,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,md5,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,tax,dt,biz_type,manual_dt,voucher_type)  -- 增加金额字段
                           ) as union_id  --异常凭证改造新增字段 20210319改造
            ,cast(null as string) as detail_union_ids --20210319改造
            ,dt
            ,biz_type
        FROM dmf_gj.dmfgj_gj_pay_fi_journal_i_d
        WHERE dt in (%s) and biz_type = '100081' and borrow_loan_status='1'
        GROUP BY superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,subject_no,direction_em
                     ,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,md5,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,tax,dt,biz_type,manual_dt,voucher_type;

    """ % where__all_dt,

    #新增的sql段，将结果插入到明细凭证与日凭证关系表。
    #modify by xiaojia 20210511
    #修改sql段，修改dt范围
    "sql_109": """
        set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
        set mapreduce.input.fileinputformat.split.maxsize = 64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.node=64000000;
        set mapreduce.input.fileinputformat.split.minsize.per.rack=64000000;
        set mapred.max.split.size=64000000;
        set hive.exec.reducers.bytes.per.reducer=64000000;
        use dmf_gj;

--建立明细凭证与日凭证关系表
        insert overwrite table dmf_gj.dmfgj_ex_check_fi_hs_detail_day_voucher_relation_i_d partition (dt,biz_type)
        select
            dmf_bc.getmd5(concat_ws(',',superior_biz_type,biz_line,product_no,buss_link_name,company_no,receipt_type,fund_type,trans_dt,subject_no,direction_em
                     ,aux_subject_1,aux_subject_2,aux_subject_3,positive_or_negative,ysyf_id,md5,trans_id,bank_code,bank_name,buss_link_code,currency,rule_id,tax,dt,biz_type,manual_dt,voucher_type)  -- 增加金额字段
                           ) as day_voucher_id,
            union_id as detail_voucher_id,
            dt,
            biz_type
        from dmf_gj.dmfgj_gj_pay_fi_journal_i_d
        where dt in (%s) and biz_type = '100081' ;
    """ % where__all_dt,

    #将汇总凭证拆分，按业务小类存储。新增字段union_id。注意需要先行新增拆分业务小类后的汇总凭证模型的字段！！！
    "sql_110": """
        use dmf_gj;
        set hive.stats.autogather = false;

--将日汇总凭证表数据按照业务小类拆分存储，后续分别创建推送作业，将数据推送至核算系统，避免个别业务线数据延迟导致核算全量业务无数据可用的情况
        INSERT OVERWRITE TABLE dmf_gj.dmfgj_gj_pay_fi_voucher_100081_i_d PARTITION (dt)
        SELECT
             superior_biz_type  AS superior_biz_type
            ,biz_type           AS biz_type
            ,biz_line           AS biz_line
            ,product_no         AS product_no
            ,buss_link_name     AS buss_link_name
            ,company_no         AS company_no
            ,receipt_type       AS receipt_type
            ,fund_type          AS fund_type
            ,trans_dt           AS trans_dt
            ,trans_amt          AS trans_amt
            ,subject_no         AS subject_no
            ,direction_em       AS direction_em
            ,aux_subject_1      AS aux_subject_1
            ,aux_subject_2      AS aux_subject_2
            ,aux_subject_3      AS aux_subject_3
            ,positive_or_negative AS positive_or_negative
            ,ysyf_id            AS ysyf_id
            ,voucher_id         AS voucher_id
            ,md5                AS md5
            ,create_dt          AS create_dt
            ,trans_id           AS trans_id
            ,bank_code          AS bank_code
            ,bank_name          AS bank_name
            ,buss_link_code     AS buss_link_code
            ,currency           AS currency
            ,manual_dt          AS manual_dt
            ,voucher_type       AS voucher_type
            ,union_id           AS union_id        -- 异常凭证改造新增字段
            ,dt
        FROM dmf_gj.dmfgj_gj_pay_fi_voucher_i_d
        WHERE dt in (%s) and biz_type='100081';

    """ % where__all_dt,
}

#判断临时表数据是否存在需要刷新备份分区数据
if current_period_code != "":
    #判断当前账期所属分区段是否包含下月（自然月）1号及以后的数据，需要进行重新备份
    next_period_start_dt = add_months(datetime.datetime.strptime(current_period_code,'%Y%m'),1)
    log("当前账期-下个月："+next_period_start_dt.strftime("%Y-%m-%d"))
    i = 0
    for dt in [col[0] for col in all_dt_ret["data"]]:
        if datetime.datetime.strptime(dt, '%Y-%m-%d') >= next_period_start_dt:
            sql_map_4["sql_"+str(111+i)] = """
                    use dmf_gj;
                    alter table dmf_gj.dmfgj_ex_check_detail_transaction_ex_back_all_i_d drop partition(dt='{dt}',biz_type='100081');
                    alter table dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
                    alter table dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');
                    alter table dmf_gj.dmfgj_gj_hs_journal_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='1');
                    alter table dmf_gj.dmfgj_gj_hs_journal_back_all_i_d drop partition(dt='{dt}',biz_type='100081',borrow_loan_status='0');
            """.format(dt=dt)
            i+=1
    if i > 0:
        next_period_end_dt = (next_period_start_dt + datetime.timedelta(days=(i-1))).strftime("%Y-%m-%d")
        sql_map_4["sql_"+str(111+i)] = """
            use dmf_gj;
            set mapred.max.split.size=16000000;
            set hive.stats.autogather=false;
            set hive.execution.engine=tez;
            set hive.auto.convert.join = true;

            insert overwrite table dmf_gj.dmfgj_ex_check_detail_transaction_ex_back_all_i_d PARTITION (dt,biz_type)
            select origin_id
            ,serial_no
            ,biz_line
            ,product_no
            ,trans_type
            ,company_no1
            ,company_no2
            ,company_no3
            ,company_no4
            ,company_no5
            ,borrow_bank_acct
            ,loan_bank_acct
            ,trans_dt
            ,trans_amt
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,data_source_em
            ,customer_no
            ,merchant_no
            ,section_no
            ,pay_enum
            ,direction
            ,loan_type
            ,create_dt
            ,order_no
            ,project_no
            ,spare_no
            ,vir_merchant
            ,company_no6
            ,company_no7
            ,company_no8
            ,company_no9
            ,currency
            ,has_tax
            ,tax
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,product_id
            ,sku_id
            ,error_codes
            ,dt
            ,biz_type
            from dmf_gj.dmfgj_ex_check_pay_detail_transaction_ex_000011_i_d
            where dt >= '{next_period_start_dt}' and dt <= '{next_period_end_dt}'
            and biz_type = '100081';

            insert overwrite table dmf_gj.dmfgj_ex_check_detail_voucher_ex_back_all_i_d PARTITION (dt,biz_type,borrow_loan_status)
            select origin_id
            ,superior_biz_type
            ,biz_line
            ,product_no
            ,buss_link_name
            ,company_no
            ,receipt_type
            ,fund_type
            ,trans_dt
            ,trans_amt
            ,subject_no
            ,direction_em
            ,aux_subject_1
            ,aux_subject_2
            ,aux_subject_3
            ,voucher_id
            ,record_id
            ,serial_no
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,data_source_em
            ,trans_type
            ,positive_or_negative
            ,ysyf_id
            ,md5
            ,subject_type
            ,create_dt
            ,trans_id
            ,bank_code
            ,bank_name
            ,buss_link_code
            ,currency
            ,rule_id
            ,src_trans_amt
            ,tax
            ,manual_dt
            ,voucher_type
            ,aux_subject_1_type
            ,aux_subject_2_type
            ,aux_subject_3_type
            ,cal_trans_amt
            ,union_id
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,period_code
            ,product_id
            ,sku_id
            ,error_codes
            ,dt
            ,biz_type
            ,borrow_loan_status
            from dmf_gj.dmfgj_ex_check_pay_detail_voucher_ex_000011_i_d
            where dt >= '{next_period_start_dt}' and dt <= '{next_period_end_dt}'
            and biz_type = '100081';

            insert overwrite table dmf_gj.dmfgj_gj_hs_journal_back_all_i_d PARTITION (dt,biz_type,borrow_loan_status)
            select origin_id
            ,superior_biz_type
            ,biz_line
            ,product_no
            ,buss_link_name
            ,company_no
            ,receipt_type
            ,fund_type
            ,trans_dt
            ,trans_amt
            ,subject_no
            ,direction_em
            ,aux_subject_1
            ,aux_subject_2
            ,aux_subject_3
            ,voucher_id
            ,record_id
            ,serial_no
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,data_source_em
            ,trans_type
            ,positive_or_negative
            ,ysyf_id
            ,md5
            ,subject_type
            ,create_dt
            ,trans_id
            ,bank_code
            ,bank_name
            ,buss_link_code
            ,currency
            ,rule_id
            ,src_trans_amt
            ,tax
            ,manual_dt
            ,voucher_type
            ,aux_subject_1_type
            ,aux_subject_2_type
            ,aux_subject_3_type
            ,cal_trans_amt
            ,union_id
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,period_code
            ,product_id
            ,sku_id
            ,dt
            ,biz_type
            ,borrow_loan_status
            from dmf_gj.dmfgj_gj_pay_fi_journal_i_d
            where dt >= '{next_period_start_dt}' and dt <= '{next_period_end_dt}'
            and biz_type = '100081';
        """.format(next_period_start_dt=next_period_start_dt.strftime("%Y-%m-%d"),next_period_end_dt=next_period_end_dt)

sql_map = dict(sql_map_3 , **sql_map_4)
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)
