# !/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *

#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
#sql_runner=RUNNER_STINGER
sql_runner=RUNNER_HIVE
#sql_runner=RUNNER_SPARK_SQL

def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = sql_task._tx_date
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()

sql_map={

# ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

#校验一：
#  计提明细表&上一天计提明细表-借方发生额校验

"sql_01": """
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
set hive.mapjoin.smalltable.filesize=209715200;
set hive.exec.reducers.bytes.per.reducer=64000000;
set mapred.reduce.tasks = 1000;
set hive.exec.reducers.max=1009;
use dmf_chk;

alter table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_fee_detail_s_d drop partition(recvbl_dt='{TX_DATE}');
alter table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_fee_detail_s_d add partition(recvbl_dt='{TX_DATE}');
insert into table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_fee_detail_s_d partition(recvbl_dt='{TX_DATE}')
--备份变更差异
select     case when t1.joinkey is null then 'fee_detail_backup_MORE'
                when t2.joinkey is null then 'fee_detail_MORE'
                else 'oth' 
           end as match_rslt
          ,if(t1.joinkey is null,t2.source_em,t1.source_em) as source_em
          ,if(t1.joinkey is null,t2.trans_no,t1.trans_no) as trans_no
          ,if(t1.joinkey is null,t2.superior_biz_type,t1.superior_biz_type) as superior_biz_type
          ,if(t1.joinkey is null,t2.biz_type,t1.biz_type) as biz_type
          ,if(t1.joinkey is null,t2.biz_line,t1.biz_line) as biz_line
          ,if(t1.joinkey is null,t2.jdfin_code,t1.jdfin_code) as jdfin_code
          ,if(t1.joinkey is null,t2.buss_link_code,t1.buss_link_code) as buss_link_code
          ,if(t1.joinkey is null,t2.subject_no,t1.subject_no) as subject_no
          ,if(t1.joinkey is null,t2.fee_customer_name_merchant_id,t1.fee_customer_name_merchant_id) as fee_customer_name_merchant_id
          ,if(t1.joinkey is null,t2.fee_customer_name_merchant_name,t1.fee_customer_name_merchant_name) as fee_customer_name_merchant_name
          ,if(t1.joinkey is null,t2.company_no,t1.company_no) as company_no
          ,if(t1.joinkey is null,t2.trans_dt,t1.trans_dt) as trans_dt
          ,if(t1.joinkey is null,t2.trans_amt,t1.trans_amt) as trans_amt
          ,if(t1.joinkey is null,t2.source_id,t1.source_id) as source_id
          ,if(t1.joinkey is null,t2.manual_dt,t1.manual_dt) as manual_dt
          ,if(t1.joinkey is null,t2.voucher_type,t1.voucher_type) as voucher_type
          ,if(t1.joinkey is null,t2.sett_sum_period,t1.sett_sum_period) as sett_sum_period
          ,if(t1.joinkey is null,t2.sett_acc_period,t1.sett_acc_period) as sett_acc_period
          ,if(t1.joinkey is null,t2.receive_sett_dt,t1.receive_sett_dt) as receive_sett_dt
          ,if(t1.joinkey is null,t2.fee_biz_type,t1.fee_biz_type) as fee_biz_type
          ,if(t1.joinkey is null,t2.fee_type,t1.fee_type) as fee_type
          ,if(t1.joinkey is null,t2.match_mode,t1.match_mode) as match_mode
          ,if(t1.joinkey is null,t2.status,t1.status) as status
          ,if(t1.joinkey is null,t2.amount,t1.amount) as amount
          ,if(t1.joinkey is null,t2.sett_amount,t1.sett_amount) as sett_amount
          ,if(t1.joinkey is null,t2.currency,t1.currency) as currency
          ,if(t1.joinkey is null,t2.peride_type,t1.peride_type) as peride_type
          ,if(t1.joinkey is null,t2.peride_date,t1.peride_date) as peride_date
          ,if(t1.joinkey is null,t2.biz_line_name,t1.biz_line_name) as biz_line_name
          ,if(t1.joinkey is null,t2.jdfin_name,t1.jdfin_name) as jdfin_name
          ,if(t1.joinkey is null,t2.company_name,t1.company_name) as company_name
          ,if(t1.joinkey is null,t2.dt,t1.dt) as dt
from (
    select *,dmf_bc.getmd5(source_em,trans_no,superior_biz_type,biz_type,biz_line,jdfin_code,buss_link_code,subject_no,fee_customer_name_merchant_id,fee_customer_name_merchant_name,company_no,trans_dt,trans_amt,source_id,manual_dt,voucher_type,sett_sum_period,sett_acc_period,receive_sett_dt,fee_biz_type,fee_type,match_mode,status,amount,sett_amount,currency,peride_type,peride_date,biz_line_name,jdfin_name,company_name,dt) as joinkey 
    from dmf_bc.dmfbc_rpt_recvbl_fee_detail_i_d 
    where dt <= date_sub('{TX_DATE}',1)  
    --and dt >= if(substr('{TX_DATE}',9,2) < 8,trunc(add_months('{TX_DATE}',-1),'MM'),trunc('{TX_DATE}','MM')) 
	and dt >= '2020-10-01' --从应收期初日期开始校验(非变量)
	and substr(manual_dt,1,6) >= '202010'  --从应收期初日期开始校验(非变量)
    and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
) t1
full join (
    select *,dmf_bc.getmd5(source_em,trans_no,superior_biz_type,biz_type,biz_line,jdfin_code,buss_link_code,subject_no,fee_customer_name_merchant_id,fee_customer_name_merchant_name,company_no,trans_dt,trans_amt,source_id,manual_dt,voucher_type,sett_sum_period,sett_acc_period,receive_sett_dt,fee_biz_type,fee_type,match_mode,status,amount,sett_amount,currency,peride_type,peride_date,biz_line_name,jdfin_name,company_name,dt) as joinkey 
    from dmf_rpt.dmfrpt_rpt_recvbl_fee_detail_backup_s_d 
    where recvbl_dt = date_sub('{TX_DATE}',1) 
    --and dt >= if(substr('{TX_DATE}',9,2) < 8,trunc(add_months('{TX_DATE}',-1),'MM'),trunc('{TX_DATE}','MM')) 
	and dt >= '2020-10-01' --从应收期初日期开始校验(非变量)
	and substr(manual_dt,1,6) >= '202010'  --从应收期初日期开始校验(非变量)
    and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
) t2
   on t1.joinkey = t2.joinkey
where t1.joinkey is null or t2.joinkey is null
--union all
----增量差异
--select 'oth' as match_rslt,*
--from dmf_bc.dmfbc_rpt_recvbl_fee_detail_i_d 
--where dt = '{TX_DATE}'
--  and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
;
""",

#校验二：
#  回款明细表&上一天回款明细表-贷方发生额校验

"sql_02": """
set hive.exec.reducers.bytes.per.reducer=64000000;
set mapred.reduce.tasks = 1000;
set hive.exec.reducers.max=1009;
set hive.merge.mapfiles= true;
set hive.merge.mapredfiles= true;
set hive.merge.size.per.task= 256000000;
set hive.merge.smallfiles.avgsize=16000000;
set mapreduce.map.memory.mb=8192;
set mapreduce.map.java.opts=-Xmx7144M;
set mapreduce.reduce.memory.mb=8192;
use dmf_chk;

alter table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_return_detail_s_d drop partition(recvbl_dt='{TX_DATE}');
alter table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_return_detail_s_d add partition(recvbl_dt='{TX_DATE}');
insert into table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_return_detail_s_d partition(recvbl_dt='{TX_DATE}')
--备份变更差异
select     case when t1.jdfin_name is null then 'return_detail_backup_MORE'
                when t2.jdfin_name is null then 'return_detail_MORE'
                else 'oth'
           end as match_rslt
          ,if(t1.joinkey is null,t2.source_em,t1.source_em) as source_em
          ,if(t1.joinkey is null,t2.fee_id,t1.fee_id) as fee_id
          ,if(t1.joinkey is null,t2.superior_biz_type,t1.superior_biz_type) as superior_biz_type
          ,if(t1.joinkey is null,t2.biz_type,t1.biz_type) as biz_type
          ,if(t1.joinkey is null,t2.biz_line,t1.biz_line) as biz_line
          ,if(t1.joinkey is null,t2.jdfin_code,t1.jdfin_code) as jdfin_code
          ,if(t1.joinkey is null,t2.buss_link_code,t1.buss_link_code) as buss_link_code
          ,if(t1.joinkey is null,t2.subject_no,t1.subject_no) as subject_no
          ,if(t1.joinkey is null,t2.sett_customer_name_merchant_id,t1.sett_customer_name_merchant_id) as sett_customer_name_merchant_id
          ,if(t1.joinkey is null,t2.sett_customer_name_merchant_name,t1.sett_customer_name_merchant_name) as sett_customer_name_merchant_name
          ,if(t1.joinkey is null,t2.company_no,t1.company_no) as company_no
          ,if(t1.joinkey is null,t2.trans_dt,t1.trans_dt) as trans_dt
          ,if(t1.joinkey is null,t2.trans_amt,t1.trans_amt) as trans_amt
          ,if(t1.joinkey is null,t2.sett_id,t1.sett_id) as sett_id
          ,if(t1.joinkey is null,t2.manual_dt,t1.manual_dt) as manual_dt
          ,if(t1.joinkey is null,t2.voucher_type,t1.voucher_type) as voucher_type
          ,if(t1.joinkey is null,t2.audit_dt,t1.audit_dt) as audit_dt
          ,if(t1.joinkey is null,t2.complete_dt,t1.complete_dt) as complete_dt
          ,if(t1.joinkey is null,t2.match_mode,t1.match_mode) as match_mode
          ,if(t1.joinkey is null,t2.sett_biz_type,t1.sett_biz_type) as sett_biz_type
          ,if(t1.joinkey is null,t2.fee_type,t1.fee_type) as fee_type
          ,if(t1.joinkey is null,t2.fee_trans_dt,t1.fee_trans_dt) as fee_trans_dt
          ,if(t1.joinkey is null,t2.currency,t1.currency) as currency
          ,if(t1.joinkey is null,t2.peride_date,t1.peride_date) as peride_date
          ,if(t1.joinkey is null,t2.biz_line_name,t1.biz_line_name) as biz_line_name
          ,if(t1.joinkey is null,t2.jdfin_name,t1.jdfin_name) as jdfin_name
          ,if(t1.joinkey is null,t2.company_name,t1.company_name) as company_name
          ,if(t1.joinkey is null,t2.dt,t1.dt) as dt

from (
    select *,dmf_bc.getmd5(source_em,fee_id,superior_biz_type,biz_type,biz_line,jdfin_code,buss_link_code,subject_no,sett_customer_name_merchant_id,sett_customer_name_merchant_name,company_no,trans_dt,trans_amt,sett_id,manual_dt,voucher_type,audit_dt,complete_dt,match_mode,sett_biz_type,fee_type,fee_trans_dt,currency,peride_date,biz_line_name,jdfin_name,company_name,dt) as joinkey
    from dmf_bc.dmfbc_rpt_recvbl_return_detail_i_d
    where dt <= date_sub('{TX_DATE}',1)
    --and dt >= if(substr('{TX_DATE}',9,2) < 8,trunc(add_months('{TX_DATE}',-1),'MM'),trunc('{TX_DATE}','MM')) 
	and dt >= '2020-10-01' --从应收期初日期开始校验(非变量)
	and substr(manual_dt,1,6) >= '202010'  --从应收期初日期开始校验(非变量)
    and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
) t1
full join (
    select *,dmf_bc.getmd5(source_em,fee_id,superior_biz_type,biz_type,biz_line,jdfin_code,buss_link_code,subject_no,sett_customer_name_merchant_id,sett_customer_name_merchant_name,company_no,trans_dt,trans_amt,sett_id,manual_dt,voucher_type,audit_dt,complete_dt,match_mode,sett_biz_type,fee_type,fee_trans_dt,currency,peride_date,biz_line_name,jdfin_name,company_name,dt) as joinkey
    from dmf_rpt.dmfrpt_rpt_recvbl_return_detail_backup_s_d
    where recvbl_dt = date_sub('{TX_DATE}',1) 
    --and dt >= if(substr('{TX_DATE}',9,2) < 8,trunc(add_months('{TX_DATE}',-1),'MM'),trunc('{TX_DATE}','MM')) 
	and dt >= '2020-10-01' --从应收期初日期开始校验(非变量)
	and substr(manual_dt,1,6) >= '202010'  --从应收期初日期开始校验(非变量)
    and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
) t2
   on t1.joinkey = t2.joinkey
where t1.joinkey is null or t2.joinkey is null
--union all
--select 'oth' as match_rslt,*
--from dmf_bc.dmfbc_rpt_recvbl_return_detail_i_d 
--where dt = '{TX_DATE}'
--  and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
;
""",

#校验三：
#  跟进表应收余额负数统计

"sql_03": """
use dmf_chk;

alter table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_receive_follow_up_s_d drop partition(recvbl_dt='{TX_DATE}');
alter table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_receive_follow_up_s_d add partition(recvbl_dt='{TX_DATE}');
insert into table dmf_chk.dmfchk_rpt_recvbl_rpt_detail_chk_receive_follow_up_s_d partition(recvbl_dt='{TX_DATE}')
select tt1.*
from (
    select * 
    from dmf_bc.dmfbc_rpt_recvbl_return_detail_i_d
    where dt <= '{TX_DATE}'
    and substr(manual_dt,1,6) <= if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
) tt1
inner join (
    select     t1.dt
              ,t1.fee_trans_ym
              ,t1.jdfin_name
              ,t1.company_name
              ,t1.fin_merchant_name
              ,t1.currency
              ,t1.month_receive_balance
              ,t2.period_end_balance
    from (select dt,fee_trans_ym,jdfin_name,company_name,fin_merchant_name,currency,month_receive_balance
          from dmf_rpt.dmfrpt_rpt_recvbl_receive_follow_up_m_i_d
          where dt = '{TX_DATE}'
            and fee_trans_ym < if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))
            and month_receive_balance < 0
    ) t1
    inner join (
        select dt,jdfin_code,jdfin_name,fin_merchant_code,fin_merchant_name,company_id,company_code,company_name,currency,statis_ym,period_end_balance
        from dmf_rpt.dmfrpt_rpt_recvbl_receive_statis_receive_m_i_d
        where dt = '{TX_DATE}'
          and statis_ym = if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6),substr(replace('{TX_DATE}','-',''),1,6))  --本月取上月应收余额  last_period_balance
          and period_end_balance > 0
    ) t2
     on t1.jdfin_name = t2.jdfin_name
    and t1.company_name = t2.company_name
    and t1.fin_merchant_name = t2.fin_merchant_name
    and t1.currency = t2.currency
) tt2
 on tt1.jdfin_name = tt2.jdfin_name
and tt1.company_name = tt2.company_name
and tt1.sett_customer_name_merchant_name = tt2.fin_merchant_name
and tt1.currency = tt2.currency
;
""",
}

parallel_keys = [
    ['sql_01','sql_02','sql_03'],
]

# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
#return_code = sql_task.execute_sqls(sql_map)
return_code = sql_task.execute_sqls_parallel(sql_map, parallel_keys)
exit(return_code)