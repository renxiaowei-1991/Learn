# coding=utf-8
import os
import datetime
from template.base_sql_task import *
from multiprocessing import Pool

# 通用变量定义
sql_runner = RUNNER_HIVE
return_code = None
sql_task = SqlTask()
today = Time.today()
yestoday = sql_task._tx_date
#yestoday =(datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
TX_MONTH_START=str(yestoday[:-3])+"-01"
# 执行文件中用配置并行执行的全局参数
py_file_name = "JCW_DMFCHK_RPT_RECVBL_BETW_TAB_CHK_S_D.py"
parallel_sql = 'sql_00'
parallel_fctr_sql1 = ""
parallel_fctr_sql2 = ""
parallel_rel_sql1 = ""
parallel_rel_sql2 = ""
parallel_fctr_sql_list1 = []
parallel_fctr_sql_list2 = []
parallel_rel_sql_list1 = []
parallel_rel_sql_list2 = []
parallel_keys = ""

#执行sql语句
def execHiveSql(sql):
    lines = os.popen("""
        hive -e "SET hive.cli.print.header=true;
        set hive.exec.parallel=true; 
        set hive.exec.parallel.thread.number=5;
        %s" | sed 's/\t/#$#/g'
    """ % sql).readlines()

    # log(lines)

    res = {"columns": [], "data": [], "type": "", "message": ""}
    cnt = len(lines)
    cols = []
    data = []

    res["type"] = "info"
    if cnt == 0:
        res["message"] = "OK"
        return res
    elif lines[0].strip() == "":
        res["message"] = "".join(lines[1:])
        return res
    elif lines[0].find(" ") > 0:
        msg = lines[0].lower()
        res["message"] = "".join(lines)
        if msg.find("error") >= 0 or msg.find("exception") >= 0:
            res["type"] = "error"
        return res

    res["type"] = "query"
    for i in range(0, cnt):
        line = lines[i]
        fds = line.split("#$#")
        newFds = [fd.strip() for fd in fds]

        if i == 0:
            cols = [c.split(".")[-1] for c in newFds]
        else:
            data.append(newFds)

    res["columns"] = cols
    res["data"] = data
    return res

# 获取校验因子配置信息
def get_fctr_config_sql():
    #此add表结构有较大变化，暂不使用
    #sql = "select * from dmf_add.dmfadd_add_recvbl_betw_tab_chk_fctr_a_d"

    #此临时表建表以及配置信息初始化在临时脚本【表间校验模型初始化脚本.py】中进行，表结构数据可随时修改，方便测试，正式上线时可根据此临时表【dmf_add.dmfadd_rpt_recvbl_betw_tab_chk_fctr_cnfg_a_d】创建add实体
    #过滤生效的配置信息
    sql = "select * " \
          "from dmf_add.dmfadd_rpt_recvbl_betw_tab_chk_fctr_cnfg_a_d " \
          "where if(trim(coalesce(valid_start_dt,''))='','2021-01-01',valid_start_dt) < '"+yestoday+"' " \
          "and if(trim(coalesce(valid_end_dt,''))='','2099-12-31',valid_end_dt) > '"+yestoday+"'"
    return sql

# 获取勾稽关系配置信息
def get_rel_config_sql():
    #此add表结构有较大变化，暂不使用
    #sql = "select * from dmf_add.dmfadd_add_recvbl_betw_tab_chk_rel_a_d"

    #此临时表建表以及配置信息初始化在临时脚本【表间校验模型初始化脚本.py】中进行，表结构数据可随时修改，方便测试，正式上线时可根据此临时表【dmf_add.dmfadd_rpt_recvbl_betw_tab_chk_fctr_cnfg_a_d】创建add实体
    #过滤生效的配置信息
    sql = "select * " \
          "from dmf_add.dmfadd_rpt_recvbl_betw_tab_chk_rel_cnfg_a_d " \
          "where if(trim(coalesce(valid_start_dt,''))='','2021-01-01',valid_start_dt) < '"+yestoday+"' " \
          "and if(trim(coalesce(valid_end_dt,''))='','2099-12-31',valid_end_dt) > '"+yestoday+"'"
    return sql

# 获取校验因子配置信息执行结果
def get_fctr_rslt():
    rst = execHiveSql(get_fctr_config_sql())
    # 校验因子维度list
    fctrdim_list = []
    # 校验因子维度str
    fctrdim_str = ''
    # 汇总相同【表名+维度】字段的校验因子map
    fctr_map = {}
    fctr_map2 = {}
    # fctr_map.key
    fctr_map_key_str = ''
    # fctr_map.value
    fctr_map_value_str = ''
    fctr_map_value_str2 = ''
    # chk_indx_en_nm_map.key
    chk_indx_en_nm_map_key_str = ''
    # chk_indx_en_nm_map.value
    chk_indx_en_nm_map_value_str = ''
    global yestoday
    global TX_MONTH_START
    global py_file_name
    global parallel_sql
    global parallel_fctr_sql1
    global parallel_fctr_sql2
    global parallel_rel_sql1
    global parallel_rel_sql2
    global parallel_fctr_sql_list1
    global parallel_fctr_sql_list2
    global parallel_rel_sql_list1
    global parallel_rel_sql_list2
    global parallel_keys
    global return_code
    fctr_sql = ""

    #判断返回结果中data是否为空
    if len(rst["data"]) > 0:
        #循环次数标志变量，如果是第一次循环，清空校验因子结果表当天分区
        for_time_flag = 0
        #date2 = [c.replace("`","'") for c in rst["data"]]
        for res in rst["data"]:
            # 校验因子英文名map
            chk_indx_en_nm_map = {}

            tab_cn_nm = res[0].strip().replace("`","'")
            tab_en_nm = res[1].strip().replace("`","'")
            chk_indx_cn_nm = res[2].strip().replace("`","'")
            chk_indx_en_nm = res[3].strip().replace("`","'")
            valid_start_dt = res[4].strip().replace("`","'")
            valid_end_dt = res[5].strip().replace("`","'")
            fctr_dim01 = res[6].strip().replace("`","'")
            fctr_dim02 = res[7].strip().replace("`","'")
            fctr_dim03 = res[8].strip().replace("`","'")
            fctr_dim04 = res[9].strip().replace("`","'")
            fctr_dim05 = res[10].strip().replace("`","'")
            fctr_dim06 = res[11].strip().replace("`","'")
            fctr_dim07 = res[12].strip().replace("`","'")
            fctr_dim08 = res[13].strip().replace("`","'")
            chk_indx_val = res[14].strip().replace("`","'")
            co_filter = res[15].strip().replace("`","'")
            feat_filter = res[16].strip().replace("`", "'")

            # 过滤条件不能为空 如果过滤条件为空则赋值 1 = 1
            if len(co_filter) == 0 : co_filter = "1 = 1"
            if len(feat_filter) == 0 :  feat_filter = "1 = 1"

            # 维度信息拼接list
            fctrdim_list = [fctr_dim01, fctr_dim02, fctr_dim03, fctr_dim04, fctr_dim05, fctr_dim06, fctr_dim07, fctr_dim08]
            # 维度信息list升序排序，为了后续在map中使key唯一
            # fctrdim_list.sort(reverse=True)  # 这里不能排序，因为勾稽关系会根据校验因子的配置顺序选取维度字段名
            # 排序后的维度list转字符串，map的key不能为list
            fctrdim_str = '`'.join(fctrdim_list)
            fctr_map_key_str = tab_en_nm + '|' + co_filter + '|' + fctrdim_str
            fctr_map_value_str2 = tab_cn_nm + '`' + valid_start_dt + '`' + valid_end_dt
            chk_indx_en_nm_map_value_str = chk_indx_cn_nm + '`' + chk_indx_val + '`' + feat_filter
            # 判断 fctr_map_key_str 在map中是否已经存在，已存在则在原来基础上拼接新校验因子，不存在则新增map
            if fctr_map_key_str in fctr_map:
                # 获取已存在的校验因子编码map
                chk_indx_en_nm_map = fctr_map[fctr_map_key_str]
                chk_indx_en_nm_map[chk_indx_en_nm] = chk_indx_en_nm_map_value_str
            else:
                chk_indx_en_nm_map[chk_indx_en_nm] = chk_indx_en_nm_map_value_str
            # 写入校验因子map,第一个map的value存放的是校验因子特有的字段map,第二个map的value存放的是校验因子公用的字段str
            fctr_map[fctr_map_key_str] = chk_indx_en_nm_map
            fctr_map2[fctr_map_key_str] = fctr_map_value_str2

        # 拼接sql的where条件
        select_where_str = ''
        # 校验因子维度str
        fctr_dim_str = ""
        # 拼接sql的map字段
        select_fctr_map_str = ''
        select_fctr_dim_str2 = ''
        # 拼接sql的维度字段
        select_fctr_dim_list = []
        select_fctr_dim_str = ""
        # 拼接sql的group by
        select_group_by_str = ""
        i = 0

        # 删除当天分区;测试时用重建临时表的方式清空临时表
        fctr_sql = """
        # 表间校验-校验因子结果表
        "{parallel_sql}": \"""
        set hive.stats.column.autogather=false;
        use dmf_chk;
        
        alter table dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_fctr_rslt_s_d drop partition(dt='{TX_DATE}');
        alter table dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_fctr_rslt_s_d add  partition(dt='{TX_DATE}');
        ;
        \n\t\t\t\""",
        """
        parallel_sql = parallel_sql[0:4] + str(int(parallel_sql[4:6])+1).rjust(2,'0')
        parallel_fctr_sql1 = parallel_sql
        parallel_fctr_sql_list1.append(parallel_sql)
        args = dict()
        args['parallel_sql'] = parallel_sql
        args['TX_DATE'] = yestoday
        fctr_sql = fctr_sql.format(**args)

        # 拼接SQL
        for key in fctr_map.keys():
            # sql变量初始化
            # 校验因子维度str
            fctr_dim_str = ""
            # 校验因子参数列表 置空
            tab_cn_nm = ""
            tab_en_nm = ""
            # chk_indx_cn_nm = chk_indx_en_nm_map_value_str.split("`")[0]
            # chk_indx_en_nm = key2
            valid_start_dt = ""
            valid_end_dt = ""
            # chk_indx_val = chk_indx_en_nm_map_value_str.split("`")[1]
            co_filter = ""
            # feat_filter = chk_indx_en_nm_map_value_str.split("`")[2]
            # 拼接sql的维度字段
            select_fctr_dim_list = []
            select_fctr_dim_str = ""
            # 拼接sql的map字段
            select_fctr_map_str = ''
            select_fctr_dim_str2 = ''
            # 拼接sql的where条件
            select_where_str = ''
            # 拼接sql的group by
            select_group_by_str = ""
            # dim 编号
            i = 0

            for_time_flag = for_time_flag + 1
            chk_indx_en_nm_map = fctr_map[key]
            fctr_map_value_str2 = fctr_map2[key]
            select_where_str = key.split("|")[1]
            select_fctr_dim_list = key.split("|")[2].split("`")

            # 获取校验因子维度字段
            for fctr_dim_str in select_fctr_dim_list:
                i += 1
                if len(fctr_dim_str) > 0 and fctr_dim_str[0] == '#' :
                    select_fctr_dim_str += "\n" + " "*25 + ", '" + fctr_dim_str[1:] + "' AS " + "fctr_dim0" + str(i)
                    select_group_by_str += "\n" + " " * 20 + ", " + "fctr_dim0" + str(i)
                elif len(fctr_dim_str) > 0 and fctr_dim_str[0] != '#' :
                    select_fctr_dim_str += "\n" + " "*25 + ", " + fctr_dim_str + " AS " + "fctr_dim0" + str(i)
                    select_group_by_str += "\n" + " "*20 + ", " + "fctr_dim0" + str(i)
                elif len(fctr_dim_str) == 0 :
                    select_fctr_dim_str += "\n" + " "*25 + ", '' AS " + "fctr_dim0" + str(i)
                    select_group_by_str += "\n" + " " * 20 + ", " + "fctr_dim0" + str(i)
                else :
                    select_fctr_dim_str += "\n" + " "*25 + ", '' AS " + "fctr_dim0" + str(i)
                    select_group_by_str += "\n" + " " * 20 + ", " + "fctr_dim0" + str(i)

                select_fctr_dim_str2 += "\n" + " "*17 + ", " + "fctr_dim0" + str(i)

            # 获取 拼接sql的map字段
            for key2 in chk_indx_en_nm_map:
                chk_indx_en_nm_map_value_str = chk_indx_en_nm_map[key2]

                if select_fctr_map_str == "" :
                    select_fctr_map_str  = "\n" + " "*32 + " \'" + key2 + "#" + chk_indx_en_nm_map_value_str.split("`")[0] + "#" + chk_indx_en_nm_map_value_str.split("`")[2].replace("'","`") +\
                                           "\' , IF(" + chk_indx_en_nm_map_value_str.split("`")[2] + " , " +\
                                           chk_indx_en_nm_map_value_str.split("`")[1] + " , " + "0)"
                else:
                    select_fctr_map_str += "\n" + " "*32 + ", \'" + key2 + "#" + chk_indx_en_nm_map_value_str.split("`")[0] + "#" + chk_indx_en_nm_map_value_str.split("`")[2].replace("'","`") +\
                                           "\' , IF(" + chk_indx_en_nm_map_value_str.split("`")[2] + " , " +\
                                           chk_indx_en_nm_map_value_str.split("`")[1] + " , " + "0)"

            # 校验因子参数列表
            tab_cn_nm = fctr_map2[key].split("`")[0]
            tab_en_nm = key.split("|")[0]
            # chk_indx_cn_nm = chk_indx_en_nm_map_value_str.split("`")[0]
            # chk_indx_en_nm = key2
            valid_start_dt = fctr_map2[key].split("`")[1]
            valid_end_dt = fctr_map2[key].split("`")[2]
            # chk_indx_val = chk_indx_en_nm_map_value_str.split("`")[1]
            co_filter = "'" + key.split("|")[1].replace("'","`") + "'"
            # feat_filter = chk_indx_en_nm_map_value_str.split("`")[2]
            # select_fctr_dim_str
            select_fctr_map_str = select_fctr_map_str[1:]
            # select_where_str
            # select_group_by_str

            # 直接调用执行方式
            #sql=sqlMap.get_fctr_map(yestoday, for_time_flag, tab_cn_nm, tab_en_nm, valid_start_dt, valid_end_dt, co_filter, select_fctr_dim_str, select_fctr_dim_str2, select_fctr_map_str, select_where_str, select_group_by_str)
            #sql_task.set_sql_runner(sql_runner)
            #sql_task.set_customized_items(sqlMap.get_customized_items())
            #return_code = sql_task.execute_sqls(sql)

            # 校验因子SQL
            fctr_sql += """
            \n"{parallel_sql}": \"""
            set hive.stats.autogather = false;
            use dmf_chk;
            
            INSERT INTO TABLE dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_fctr_rslt_s_d partition(dt='{TX_DATE}')
            SELECT
                   '{tab_cn_nm}' AS tab_cn_nm  --表中文名
                 , '{tab_en_nm}' AS tab_en_nm  --表英文名
                 , split(subview.key,'#')[1] AS chk_indx_cn_nm  --校验因子中文名
                 , split(subview.key,'#')[0] AS chk_indx_en_nm  --校验因子英文名
                 , '{valid_start_dt}' AS valid_start_dt  --有效开始日期
                 , '{valid_end_dt}' AS valid_end_dt  --有效结束日期
{select_fctr_dim_str2}
                 , sum(subview.value) AS chk_indx_val  --校验因子值
                 , {co_filter} AS co_filter   --公共过滤条件
                 , split(subview.key,'#')[2] AS feat_filter  --特征过滤条件
              FROM (
                    SELECT 
                           map(
{select_fctr_map_str}
                           ) AS amt
{select_fctr_dim_str}
                      FROM {tab_en_nm}  --{tab_cn_nm}
                     WHERE {select_where_str}
                    ) t1
           LATERAL VIEW EXPLODE(amt) SUBVIEW
             GROUP BY subview.key
{select_group_by_str}
            ;
            \n\t\t\t\""",
            """

            parallel_sql = parallel_sql[0:4] + str(int(parallel_sql[4:6])+1).rjust(2,'0')
            parallel_fctr_sql2 = parallel_sql
            parallel_fctr_sql_list2.append(parallel_sql)
            args = dict()
            args['parallel_sql'] = parallel_sql
            args['TX_DATE'] = yestoday
            args['tab_cn_nm'] = tab_cn_nm
            args['tab_en_nm'] = tab_en_nm
            # args['chk_indx_cn_nm'] = chk_indx_cn_nm
            # args['chk_indx_en_nm'] = chk_indx_en_nm
            args['valid_start_dt'] = valid_start_dt
            args['valid_end_dt'] = valid_end_dt
            args['select_fctr_dim_str'] = select_fctr_dim_str
            args['select_fctr_dim_str2'] = select_fctr_dim_str2
            args['select_fctr_map_str'] = select_fctr_map_str
            # args['chk_indx_val'] = chk_indx_val
            args['co_filter'] = co_filter
            # args['feat_filter'] = feat_filter
            args['select_where_str'] = select_where_str
            args['select_group_by_str'] = select_group_by_str
            fctr_sql = fctr_sql.format(**args)

        # 写入脚本文件
        # r 以只读方式打开文件。文件的指针将会放在文件的开头。这是默认模式
        # a 打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾
        # w 打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除
        fo = open(py_file_name, "a")
        fo.write(fctr_sql)
        fo.flush()
        fo.close()
    else:
        return_code = "ERR:查询校验因子配置表返回值为空！"
    return return_code

# 获取校验因子配置信息执行结果
def get_rel_rslt():
    rst = execHiveSql(get_rel_config_sql())
    # 勾稽关系维度列表
    reldim_list = []
    # 勾稽关系编码list
    chk_rel_en_nm_map = {}
    # 勾稽关系维度与勾稽关系map
    reldim_rel_map = {}
    # 拼接sql的维度字段
    select_fctr_dim_str = ""
    # 拼接sql的group by
    select_group_by_str = ""
    # 判断返回结果中data是否为空
    global yestoday
    global TX_MONTH_START
    global py_file_name
    global parallel_sql
    global parallel_fctr_sql1
    global parallel_fctr_sql2
    global parallel_rel_sql1
    global parallel_rel_sql2
    global parallel_fctr_sql_list1
    global parallel_fctr_sql_list2
    global parallel_rel_sql_list1
    global parallel_rel_sql_list2
    global parallel_keys
    global return_code
    # 勾稽关系拼接SQL
    rel_sql = ""

    if len(rst["data"]) > 0:
        # 循环次数标志变量，如果是第一次循环，清空校验因子结果表当天分区
        for_time_flag = 0
        for res in rst["data"]:
            chk_rel_en_nm = res[1].strip().replace("`","'")
            rel_dim01 = res[7].strip().lower().replace("`","'")
            rel_dim02 = res[8].strip().lower().replace("`","'")
            rel_dim03 = res[9].strip().lower().replace("`","'")
            rel_dim04 = res[10].strip().lower().replace("`","'")
            rel_dim05 = res[11].strip().lower().replace("`","'")
            rel_dim06 = res[12].strip().lower().replace("`","'")
            rel_dim07 = res[13].strip().lower().replace("`","'")
            rel_dim08 = res[14].strip().lower().replace("`","'")
            # 维度信息拼接list
            reldim_list = [rel_dim01,rel_dim02,rel_dim03,rel_dim04,rel_dim05,rel_dim06,rel_dim07,rel_dim08]
            # 维度信息list排序，为了后续在map中使key唯一
            reldim_list.sort()
            # 排序后的维度list转字符串，map的key不能为list
            reldim_str = '`'.join(reldim_list)
            # 判断维度list在map中是否已经存在，已存在则在原来基础上拼接新勾稽关系，不存在则新增map
            if reldim_str in reldim_rel_map:
                # 获取已存在的勾稽关系编码map
                chk_rel_en_nm_map = reldim_rel_map[reldim_str]
                chk_rel_en_nm_map[chk_rel_en_nm] = chk_rel_en_nm
            else:
                chk_rel_en_nm_map[chk_rel_en_nm] = chk_rel_en_nm
            # 写入勾稽关系map
            reldim_rel_map[reldim_str] = chk_rel_en_nm_map

        # 删除当天分区;测试时用重建临时表的方式清空临时表
        rel_sql = """
        # 表间校验-校验因子结果表
        "{parallel_sql}": \"""
        set hive.stats.column.autogather=false;
        use dmf_chk;

        alter table dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_rel_rslt_s_d drop partition(dt='{TX_DATE}');
        alter table dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_rel_rslt_s_d add  partition(dt='{TX_DATE}');
        ;
        \n\t\t\t\""",
        """
        parallel_sql = parallel_sql[0:4] + str(int(parallel_sql[4:6])+1).rjust(2,'0')
        parallel_rel_sql1 = parallel_sql
        parallel_rel_sql_list1.append(parallel_sql)
        args = dict()
        args['parallel_sql'] = parallel_sql
        args['TX_DATE'] = yestoday
        rel_sql = rel_sql.format(**args)

        # 循环 reldim_rel_map
        for key in reldim_rel_map.keys():
            # sql变量初始化
            select_fctr_dim_str = ""
            select_group_by_str = ""
            chk_rel_en_nm_str = ""

            for_time_flag = for_time_flag + 1
            reldim_list = key.replace("*", "`").split("`")
            # 获取校验因子维度字段
            for j in range(1,9,1):
                i = str(j)
                if "fctr_dim0"+i in reldim_list:
                    select_fctr_dim_str += "\n" + " "*17 + ", coalesce(r."+"fctr_dim0"+i+",'') AS "+"rel_dim0"+i
                    select_group_by_str += "\n" + " "*17 + ", r.fctr_dim0"+i
                else:
                    select_fctr_dim_str += "\n" + " "*17 + ", '' AS "+"rel_dim0"+i
            chk_rel_en_nm_str = str(tuple(reldim_rel_map[key].keys()))

            # 勾稽关系编码
            #sql=sqlMap.get_rel_map(for_time_flag,yestoday, select_fctr_dim_str, select_group_by_str, chk_rel_en_nm_str)
            #sql_task.set_sql_runner(sql_runner)
            #sql_task.set_customized_items(sqlMap.get_customized_items())
            #return_code = sql_task.execute_sqls(sql)

            # 校验因子SQL
            rel_sql += """
            \n"{parallel_sql}": \"""
            set mapred.job.name=job_tmp_betw_tab_chk_rel_rslt_s_d;
            set hive.stats.autogather = false;
            use dmf_chk;
            
            insert overwrite table dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_rel_rslt_s_d PARTITION(dt='{TX_DATE}')
            select
                  coalesce(a.chk_rel_cn_nm,'') AS chk_rel_cn_nm  --勾稽关系中文名
                , coalesce(a.chk_rel_en_nm,'') AS chk_rel_en_nm  --勾稽关系英文名
                , coalesce(a.chk_rel,'') AS chk_rel  --勾稽关系
                , coalesce(a.valid_start_dt,'') AS valid_start_dt  --有效开始日期
                , coalesce(a.valid_end_dt,'') AS valid_end_dt  --有效结束日期
                {select_fctr_dim_str}
                , coalesce(a.math_opt,'') AS math_opt  --勾稽比较方式
                , coalesce(a.prosp_diff_val,'') AS prosp_diff_val  --预期勾稽差额
                , coalesce(a.cmp_typ,'') AS cmp_typ  --比较类型
                , SUM(if(a.wght = '1', COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0), 0)) AS pstv_val
                , SUM(if(a.wght = '-1', COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0), 0)) AS ngtv_val
                , sum(coalesce(r.chk_indx_val,0)*coalesce(a.wght,0)) diff_val
                , case when max(a.chk_indx_en_nm) is null then 'CHK_REL_NOT_FOUND'   --勾稽关系未找到
                       when max(r.chk_indx_en_nm) is null then 'CHK_FCTR_NOT_FOUND'  --校验因子未找到
                       --when upper(cast(cast(concat(cast(sum(coalesce(r.chk_indx_val,0)*coalesce(a.wght,0)) as string),coalesce(a.math_opt,''),coalesce(a.prosp_diff_val,'')) as boolean) as string)) = 'TRUE' then 'CHK_MATCH'   --勾稽通过
                        WHEN TRIM(a.math_opt) = '=' THEN IF(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0)) = COALESCE(a.prosp_diff_val,0),'CHK_MATCH','CHK_NOT_MATCH')
						WHEN TRIM(a.math_opt) = '<>' AND UPPER(TRIM(a.cmp_typ)) = 'ABS' THEN IF(ABS(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))) <> ABS(COALESCE(a.prosp_diff_val,0)),'CHK_MATCH','CHK_NOT_MATCH')
						WHEN TRIM(a.math_opt) = '<>'                                    THEN IF(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))      <> COALESCE(a.prosp_diff_val,0),'CHK_MATCH','CHK_NOT_MATCH')
                        WHEN TRIM(a.math_opt) = '>'  AND UPPER(TRIM(a.cmp_typ)) = 'ABS' THEN IF(ABS(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))) > ABS(COALESCE(a.prosp_diff_val,0)),'CHK_MATCH','CHK_NOT_MATCH')
                        WHEN TRIM(a.math_opt) = '>'                                     THEN IF(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))      > COALESCE(a.prosp_diff_val,0),'CHK_MATCH','CHK_NOT_MATCH')
						WHEN TRIM(a.math_opt) = '>=' AND UPPER(TRIM(a.cmp_typ)) = 'ABS' THEN IF(ABS(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))) >= ABS(COALESCE(a.prosp_diff_val,0)),'CHK_MATCH','CHK_NOT_MATCH')
						WHEN TRIM(a.math_opt) = '>='                                    THEN IF(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))      >= COALESCE(a.prosp_diff_val,0),'CHK_MATCH','CHK_NOT_MATCH')
						WHEN TRIM(a.math_opt) = '<'  AND UPPER(TRIM(a.cmp_typ)) = 'ABS' THEN IF(ABS(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))) < ABS(COALESCE(a.prosp_diff_val,0)),'CHK_MATCH','CHK_NOT_MATCH')
                        WHEN TRIM(a.math_opt) = '<'                                     THEN IF(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))      < COALESCE(a.prosp_diff_val,0),'CHK_MATCH','CHK_NOT_MATCH')
                        WHEN TRIM(a.math_opt) = '<=' AND UPPER(TRIM(a.cmp_typ)) = 'ABS' THEN IF(ABS(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))) <= ABS(COALESCE(a.prosp_diff_val,0)),'CHK_MATCH','CHK_NOT_MATCH')
                        WHEN TRIM(a.math_opt) = '<='                                    THEN IF(SUM(COALESCE(r.chk_indx_val,0)*COALESCE(a.wght,0))      <= COALESCE(a.prosp_diff_val,0),'CHK_MATCH','CHK_NOT_MATCH')
                       ELSE 'UNKNOW_RSLT'
                  END AS chk_rslt
              FROM (SELECt * FROM dmf_add.dmfadd_rpt_recvbl_betw_tab_chk_rel_cnfg_a_d
                     where if(trim(coalesce(valid_start_dt,''))='','2021-01-01',valid_start_dt) < '{TX_DATE}'
                       and if(trim(coalesce(valid_end_dt,''))='','2099-12-31',valid_start_dt) > '{TX_DATE}'
                       and chk_rel_en_nm in {chk_rel_en_nm_str}
                   ) a -- 勾稽关系配置表
             full join
                   dmf_chk.dmfchk_rpt_recvbl_betw_tab_chk_fctr_rslt_s_d r -- 结果表
                on a.chk_indx_en_nm = r.chk_indx_en_nm
            --   and r.dt = '{TX_DATE}'
            group by
                  a.chk_rel_cn_nm  --勾稽关系中文名
                , a.chk_rel_en_nm  --勾稽关系英文名
                , a.chk_rel  --勾稽关系
                , a.valid_start_dt  --有效开始日期
                , a.valid_end_dt  --有效结束日期
                , a.math_opt  --勾稽结果匹配方式
                , a.prosp_diff_val  --勾稽结果匹配差额
                , a.cmp_typ  --比较类型
{select_group_by_str}
            ;
            \n\t\t\t\""",
            """
            parallel_sql = parallel_sql[0:4] + str(int(parallel_sql[4:6])+1).rjust(2,'0')
            parallel_rel_sql2 = parallel_sql
            parallel_rel_sql_list2.append(parallel_sql)
            args = dict()
            args['parallel_sql'] = parallel_sql
            args['TX_DATE'] = yestoday
            args['select_fctr_dim_str'] = select_fctr_dim_str
            args['select_group_by_str'] = select_group_by_str
            args['chk_rel_en_nm_str'] = chk_rel_en_nm_str
            rel_sql = rel_sql.format(**args)

        # 写入脚本文件
        # r 以只读方式打开文件。文件的指针将会放在文件的开头。这是默认模式
        # a 打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾
        # w 打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除
        fo = open(py_file_name, "a")
        fo.write(rel_sql)
        fo.flush()
        fo.close()
    else:
        return_code = "ERR:查询勾稽关系配置表返回值为空！"
    return return_code

def file_write_head():
    head = """
#coding=utf-8
# !/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import datetime

from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE
def get_customized_items():
    \"""
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    \"""
    today = Time.today()
    today2 = sql_task._tx_date
    TX_MONTH_START=str(today2[:-3])+"-01"
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！
    """

    # r 以只读方式打开文件。文件的指针将会放在文件的开头。这是默认模式
    # a 打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾
    # w 打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除
    fo = open(py_file_name, "w")
    fo.write(head)
    fo.flush()
    fo.close()

def file_write_tail():
    tail = """    
# 银河限制最多并行3个SQL同时执行
parallel_keys = [
{parallel_keys}
]

# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
# 非并行调用sql_map
# return_code = sql_task.execute_sqls(sql_map)
# 非并行调用sql_map,第二个参数为并行sql_keys配置
return_code = sql_task.execute_sqls_parallel(sql_map, parallel_keys)
exit(return_code)
    """
    args = dict()
    args['parallel_keys'] = parallel_keys
    tail = tail.format(**args)

    tail = "}\n" + tail

    # r 以只读方式打开文件。文件的指针将会放在文件的开头。这是默认模式
    # a 打开一个文件用于追加。如果该文件已存在，文件指针将会放在文件的结尾
    # w 打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除
    fo = open(py_file_name, "a")
    fo.write(tail)
    fo.flush()
    fo.close()

def get_parallel_keys():
    global parallel_fctr_sql1
    global parallel_fctr_sql2
    global parallel_rel_sql1
    global parallel_rel_sql2
    global parallel_fctr_sql_list1
    global parallel_fctr_sql_list2
    global parallel_rel_sql_list1
    global parallel_rel_sql_list2
    global parallel_keys

    x = 0
    for key in parallel_fctr_sql_list1:
        x += 1
        if x % 3 == 1 and key != parallel_fctr_sql1: parallel_keys += "    ['" + key + "'"
        if x % 3 == 1 and key == parallel_fctr_sql1: parallel_keys += "    ['" + key + "'],\n"
        if x % 3 == 2 and key != parallel_fctr_sql1: parallel_keys += ",'" + key + "'"
        if x % 3 == 2 and key == parallel_fctr_sql1: parallel_keys += ",'" + key + "'],\n"
        if x % 3 == 0: parallel_keys += ",'" + key + "'],\n"

    x = 0
    for key in parallel_fctr_sql_list2:
        x += 1
        if x % 3 == 1 and key != parallel_fctr_sql2: parallel_keys += "    ['" + key + "'"
        if x % 3 == 1 and key == parallel_fctr_sql2: parallel_keys += "    ['" + key + "'],\n"
        if x % 3 == 2 and key != parallel_fctr_sql2: parallel_keys += ",'" + key + "'"
        if x % 3 == 2 and key == parallel_fctr_sql2: parallel_keys += ",'" + key + "'],\n"
        if x % 3 == 0: parallel_keys += ",'" + key + "'],\n"

    x = 0
    for key in parallel_rel_sql_list1:
        x += 1
        if x % 3 == 1 and key != parallel_rel_sql1: parallel_keys += "    ['" + key + "'"
        if x % 3 == 1 and key == parallel_rel_sql1: parallel_keys += "    ['" + key + "'],\n"
        if x % 3 == 2 and key != parallel_rel_sql1: parallel_keys += ",'" + key + "'"
        if x % 3 == 2 and key == parallel_rel_sql1: parallel_keys += ",'" + key + "'],\n"
        if x % 3 == 0: parallel_keys += ",'" + key + "'],\n"

    x = 0
    for key in parallel_rel_sql_list2:
        x += 1
        if x % 3 == 1 and key != parallel_rel_sql2: parallel_keys += "    ['" + key + "'"
        if x % 3 == 1 and key == parallel_rel_sql2: parallel_keys += "    ['" + key + "'],\n"
        if x % 3 == 2 and key != parallel_rel_sql2: parallel_keys += ",'" + key + "'"
        if x % 3 == 2 and key == parallel_rel_sql2: parallel_keys += ",'" + key + "'],\n"
        if x % 3 == 0: parallel_keys += ",'" + key + "'],\n"

def get_py_file():
    # 写入文件头
    file_write_head()

    # 写入校验因子配置信息拼接SQL
    return_code = get_fctr_rslt()
    # 判断校验因子是否正常执行，如果没有正常执行，则终止程序
    if return_code is not None and return_code.split(":")[0] == "ERR": exit()
    # 写入校验因子与校验关系关联拼接SQL
    return_code = get_rel_rslt()
    # 判断勾稽关系是否正常执行，如果没有正常执行，则终止程序
    if return_code is not None and return_code.split(":")[0] == "ERR": exit()
    # 生成并行参数
    get_parallel_keys()

    # 写入文件尾
    file_write_tail()
    return return_code

if __name__ == '__main__':
    print('==============================================mainfactor log begin==============================================')
    # 获取执行文件
    get_py_file()

    fo = open(py_file_name, "r")
    print(fo.read())
    fo.close()

    # 执行脚本文件
    #os.system('chmod u+x ' + py_file_name)
    os.system('python ' + py_file_name + ' XXX_' + py_file_name + '.dir')
    print('==============================================mainfactor log end==============================================')

