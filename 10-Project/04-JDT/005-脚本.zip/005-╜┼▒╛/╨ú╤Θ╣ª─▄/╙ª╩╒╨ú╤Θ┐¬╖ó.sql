select 
     t1.dt
    ,t1.jdfin_code
    ,t1.jdfin_name
    ,t1.fin_merchant_code
    ,t1.fin_merchant_name
    ,t1.company_id
    ,t1.company_code
    ,t1.company_name
    ,t1.currency
    ,t2.statis_ym
    ,t1.last_period_balance    --本月取上月应收余额
    ,t2.month_receive_balance  --上个月取本月应收余额
    ,t1.last_period_balance - t2.month_receive_balance as diff_val
from (
    select 
     dt
    ,jdfin_code
    ,jdfin_name
    ,fin_merchant_code
    ,fin_merchant_name
    ,company_id
    ,company_code
    ,company_name
    ,currency
    ,statis_ym
    ,period_end_balance
    ,last_period_balance
    from dmf_rpt.dmfrpt_rpt_recvbl_receive_statis_receive_m_i_d
    where dt = '{TX_DATE}'
    and statis_ym = if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6),SUBSTR('{TXDATE}',1,6))  --本月取上月应收余额  last_period_balance
    --and jdfin_name = '京东科技-保险业务-保险频道-寿险'
    --and company_name = '天津津投保险经纪有限公司'
    --and fin_merchant_name = '泰康养老保险股份有限公司北京分公司'
    --and currency = 'CNY'
) t1
left join (
    select 
     dt
    ,jdfin_code
    ,jdfin_name
    ,fin_merchant_code
    ,fin_merchant_name
    ,company_id
    ,company_code
    ,company_name
    ,currency
    ,statis_ym
    ,period_end_balance
    , month_receive_balance
    from dmf_rpt.dmfrpt_rpt_recvbl_receive_statis_receive_m_i_d
    where dt = '{TX_DATE}'
    and statis_ym = if(substr('{TX_DATE}',9,2) < 9,substr(replace(add_months('{TX_DATE}',-2),'-',''),1,6),substr(replace(add_months('{TX_DATE}',-1),'-',''),1,6))  --上个月取本月应收余额  month_receive_balance
    --and jdfin_name = '京东科技-保险业务-保险频道-寿险'
    --and company_name = '天津津投保险经纪有限公司'
    --and fin_merchant_name = '泰康养老保险股份有限公司北京分公司'
    --and currency = 'CNY'
) t2
    on t1.jdfin_name = t2.jdfin_name
    and t1.company_name = t2.company_name
    and t1.fin_merchant_name = t2.fin_merchant_name
    and t1.currency = t2.currency
 where abs(t1.last_period_balance - t2.month_receive_balance) > 0.001

