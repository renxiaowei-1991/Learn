#!/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *


#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE


def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()


sql_map={

# ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

##交易明细增量数据，关联分录配置，获取固定值-银行账户参数
"sql_05": """
use dmf_tmp;

drop TABLE if exists dmf_tmp.dmftmp_gj_sf_transaction_detail_000012_i_d;
create table dmf_tmp.dmftmp_gj_sf_transaction_detail_000012_i_d
as
select t1.origin_id
      ,t1.serial_no
      ,t1.biz_type
      ,t1.biz_line
      ,t1.product_no
      ,t1.trans_type
      ,t1.company_no1
      ,t1.company_no2
      ,t1.company_no3
      ,t1.company_no4
      ,t1.company_no5
      ,coalesce(t1.borrow_bank_acct,t2.borrow_bank_id) as borrow_bank_acct
      ,coalesce(t1.loan_bank_acct,t2.loan_bank_id) as loan_bank_acct
      ,t1.trans_dt
      ,t1.trans_amt
      ,t1.trans_no
      ,t1.pay_no
      ,t1.loan_no
      ,t1.plan_no
      ,t1.customer_no
      ,t1.merchant_no
      ,t1.section_no
      ,t1.pay_enum
      ,t1.direction
      ,t1.loan_type
      ,t1.create_dt
      ,t1.order_no
      ,t1.project_no
      ,t1.spare_no
      ,t1.vir_merchant
      ,t1.company_no6
      ,t1.company_no7
      ,t1.company_no8
      ,t1.company_no9
      ,t1.currency
      ,t1.has_tax
      ,t1.tax
      ,t1.source_table
      ,t1.source_table_dt
      ,t1.repay_no
      ,t1.refund_no
      ,t1.bill_no
      ,t1.sett_id
      ,t1.fee_id
      ,t1.fee_type
      ,t1.sett_scenes
      ,t1.sett_biz_type
      ,t1.writeoff_status
      ,t1.product_id
      ,t1.sku_id
      ,t1.dt
      ,t1.data_source_em
FROM (select origin_id
            ,serial_no
            ,biz_type
            ,biz_line
            ,product_no
            ,trans_type
            ,company_no1
            ,company_no2
            ,company_no3
            ,company_no4
            ,company_no5
            ,borrow_bank_acct
            ,loan_bank_acct
            ,trans_dt
            ,trans_amt
            ,trans_no
            ,pay_no
            ,loan_no
            ,plan_no
            ,customer_no
            ,merchant_no
            ,section_no
            ,pay_enum
            ,direction
            ,loan_type
            ,create_dt
            ,order_no
            ,project_no
            ,spare_no
            ,vir_merchant
            ,company_no6
            ,company_no7
            ,company_no8
            ,company_no9
            ,currency
            ,has_tax
            ,tax
            ,source_table
            ,source_table_dt
            ,repay_no
            ,refund_no
            ,bill_no
            ,sett_id
            ,fee_id
            ,fee_type
            ,sett_scenes
            ,sett_biz_type
            ,writeoff_status
            ,product_id
            ,sku_id
            ,dt
            ,data_source_em
       from dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_000012_i_d
       where dt='{TX_DATE}' and trans_amt != 0 and trans_dt!=''
                       and data_source_em in (select data_source_em from dmf_dim.dmfdim_gj_hs_fi_hs_busbigtype_datasourceem_a_d where bus_big_type='000012')
) t1
left join (select * from dmf_bc.dmfbc_gj_hs_ac_journal_spec_rule_fixed_bank_s_d where dt='{TX_DATE}') t2
on t1.data_source_em = t2.data_source_em and t1.trans_type = t2.trans_type
----------取固定值银行账号数据
--(select source_sys,trans_type,borrow_bank_id,loan_bank_id
--                     from dmf_dim.dmfdim_gj_hs_fi_hs_dm_subject_config_bank_s_d
--                     where dt = '{TX_DATE}'  --add by renxiaowei7
--                     group by source_sys,trans_type,borrow_bank_id,loan_bank_id
--) t2
--on t1.data_source_em = t2.source_sys and t1.trans_type = t2.trans_type

;

""",

##财务账数据写入数据模型
"sql_06": """
use dmf_tmp;

--初始化数据模型财务账分区
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='ydz',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_DATE}',sys='ydz',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_DATE}',sys='ydz',biz_type='000012');
--初始化数据模型不参与对账分区
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='nom',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_DATE}',sys='nom',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_DATE}',sys='nom',biz_type='000012');
--初始化数据模型资金帐分区
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='cdz',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_DATE}',sys='cdz',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_DATE}',sys='cdz',biz_type='000012');


insert overwrite table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d partition(dt='{TX_DATE}',sys,biz_type)
select t1.db_nm
      ,t1.tab_nm
      ,t1.col_nm
      ,t1.data_dt
      ,t1.amt_typ
      ,t1.amt_modfr1
      ,t1.amt_modfr2
      ,t1.amt_modfr3
      ,t1.amt_modfr4
      ,t1.dat_key1
      ,t1.dat_key2
      ,t1.dat_key3
      ,t1.dat_key4
      ,t1.dat_key5
      ,t1.sval
      ,t1.nval
      ,t.trans_amt as dval
      ,t1.rule_nm
      ,t1.rule_cd
      ,t1.dt as origin_dt
      ,array(t.origin_id,t.company_no1,t.company_no2,t.company_no3,t.company_no4,t.company_no5,
             t.borrow_bank_acct,t.loan_bank_acct,t.trans_dt,t.trans_no,
             t.loan_no,t.plan_no,t.customer_no,t.merchant_no,t.pay_enum,t.loan_type,t.create_dt,
             t.order_no,t.project_no,t.spare_no,t.vir_merchant,t.company_no6,t.company_no7,
             t.company_no8,t.company_no9,t.currency,t.has_tax,t.tax,
             t.source_table,t.source_table_dt,t.repay_no,t.refund_no,t.bill_no,t.sett_id,
             t.fee_id,t.fee_type,t.sett_scenes,t.sett_biz_type,t.writeoff_status,t.product_id,t.sku_id
	         ) as data -- qf 20210309 增加来源表,来源表分区,还款单号,退款单号,账单号,结算单号,费用单号,费用类型,结算场景,业务类型,冲销标识，0正常，1被冲销,账期,产品id,品类id
     ,t1.sys
     ,'000012' as biz_type
from dmf_tmp.dmftmp_gj_sf_transaction_detail_000012_i_d t
lateral view dmf_bc.dmyinput('000012',origin_id,serial_no,biz_type,biz_line,product_no,trans_type,company_no1,company_no2,company_no3,company_no4,company_no5,borrow_bank_acct,loan_bank_acct,trans_dt,trans_amt,trans_no,
                              --pay_no,  alter by lxn at 20230315,原因：对账单号为空会导致sql_10关联时匹配不成功导致这部分数据丢失。处理方案：如果对账单号为空，则将赋值贷款单号
                              COALESCE(pay_no, concat('pay_noIsNull,loan_no:',loan_no)),
                              loan_no,plan_no,customer_no,merchant_no,section_no,pay_enum,direction,loan_type,create_dt,order_no,project_no,spare_no,vir_merchant,company_no6,company_no7,company_no8,company_no9,dt,data_source_em) t1 
as db_nm,tab_nm,col_nm,data_dt,amt_typ,amt_modfr1,amt_modfr2,amt_modfr3,amt_modfr4,dat_key1,dat_key2,dat_key3,dat_key4,dat_key5,sval,nval,dval,rule_nm,rule_cd,dt,sys,biz_type
;

""",
##资金帐数据写入数据模型
"sql_07": """
use dmf_tmp;

insert overwrite table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d partition(dt='{TX_DATE}',sys,biz_type)
select t1.db_nm
      ,t1.tab_nm
      ,t1.col_nm
      ,t1.data_dt
      ,t1.amt_typ
      ,t1.amt_modfr1
      ,t1.amt_modfr2
      ,t1.amt_modfr3
      ,t1.amt_modfr4
      ,regexp_replace(t1.dat_key1,concat_ws('|',decode(unhex('0A'),'UTF-8'),decode(unhex('0D'),'UTF-8'),decode(unhex('09'),'UTF-8')),'') as dat_key1
      ,t1.dat_key2
      ,t1.dat_key3
      ,t1.dat_key4
      ,t1.dat_key5
      ,t1.sval
      ,t1.nval
      ,t.pay_amount as dval
      ,t1.rule_nm
      ,t1.rule_cd
      ,t1.dt as origin_dt
      ,array(t.origin_id,t.data_source_em,t.pay_no,t.pay_amount,t.currency_code,t.relation_type
                ,t.supplier_name,t.member_no,t.op_name,t.status_em,t.biz_rule,t.remark,t.create_dt
                ,t.update_dt,t.sys_em,t.id,t.inputtype,t.bankemum,t.receiptstatus,t.bankcheckstatus
                ,t.bankcheckdate,t.confirmdate,t.payername,t.balance,t.opstatus,t.opnum,t.shortpaidid
                ,t.routerdate,t.productId,t.productName,t.businessTypeName,t.settWayName,t.realCustomerName
                ,t.projectName,t.startDate,t.endDate,t.underAssetName,t.merchantNo,t.customerId,t.busfincheckno
                ,t.bankname,t.categoryname,t.pay_status,t.modiref_id,t.create_dt_new,t.update_dt_new,t.config_key
                ,t.config_topic,t.settbilltype,t.settfeetype,t.settfeeprop,t.voucherid,t.superiorbiztype,t.biztype
                ,t.busslinkname,t.companycode,t.perioddate) as data
      ,t1.sys
      ,'000012' as biz_type
from (select * from dmf_bc.dmfbc_gj_hs_fi_hs_m07_cap_data_ycdz_i_d where dt='{TX_DATE}' and !( nvl(businesstypename,'')='445供应链金融ABS' and remark like '%projectId:BL%')) t
lateral view dmf_bc.dmcinput('000012',origin_id,data_source_em,bank_id,pay_no,pay_type,pay_amount,currency_code,bank_confirm_dt,direction_em,relation_no,relation_type,supplier_name,member_no,op_name,op_code,status_em,biz_rule,biz_catg,biz_system,remark,create_dt,update_dt,sys_em,valid,id,inputtype,bankemum,receiptstatus,bankcheckstatus,bankcheckdate,confirmdate,payername,balance,opstatus,opnum,shortpaidid,routerdate,extendsvo,productId,productName,businessTypeName,settWayName,realCustomerName,projectName,startDate,endDate,underAssetName,merchantNo,customerId,busfincheckno,bankname,categoryname,dt) t1
as db_nm,tab_nm,col_nm,data_dt,amt_typ,amt_modfr1,amt_modfr2,amt_modfr3,amt_modfr4,dat_key1,dat_key2,dat_key3,dat_key4,dat_key5,sval,nval,dval,rule_nm,rule_cd,dt,sys,biz_type
;
""",
###暂存规则和数据关联结果
"sql_08": """
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_gj_sf_all_data_collect_ycdz_000012_i_d;
create table dmf_tmp.dmftmp_gj_sf_all_data_collect_ycdz_000012_i_d
as
select d.db_nm
      ,d.tab_nm
      ,d.col_nm
      ,d.data_dt
      ,d.amt_typ
      ,d.amt_modfr1
      ,d.amt_modfr2
      ,d.amt_modfr3
      ,d.amt_modfr4
      ,d.dat_key1
      ,d.dat_key2
      ,d.dat_key3
      ,d.dat_key4
      ,d.dat_key5
      ,d.sval
      ,d.nval
      ,d.dval
      ,d.rule_nm
      ,d.rule_cd
      ,d.origin_dt
      ,case when tab_nm='sdm_gj_transaction_detail_i' then 1   
	        else -1 end as para_key
      ,'chk' as data_tag
      ,'' as para_cond
      ,d.data
from dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d d
-- qf 20210719 增加差异类型
where d.dt = '{TX_DATE}' and d.sys in( 'ydz', 'cdz','ycdz_diff', 'ycdz_diff_1', 'ycdz_diff_2', 'ycdz_diff_3') and  d.biz_type='000012'
;
""",
##合并关联键进行汇总对账，存储汇总业财对账结果
"sql_09": """
use dmf_tmp;
-- qf 20210715 临时表不使用分区表
drop table if exists dmf_tmp.dmftmp_gj_sf_ycdz_data_collect_result_000012_i_d;
create table dmf_tmp.dmftmp_gj_sf_ycdz_data_collect_result_000012_i_d
as

select rule_cd, dat_key as data_key, amt_typ,
       collect_list(concat(amt_typ, '-', amt_modfr1, '-', amt_modfr2, '-', amt_modfr3, '-', amt_modfr4, ':', cast(nval as string))) as chk_data,
       -- array(null) as chk_data,
       sum(nval * para_key) as chk_rslt,
       max(rule_nm) as rule_nm,
       concat_ws(',',collect_set(origin_dt)) as key_type,
       -- qf 20210716 汇总的时候统计差异类型
       case size(collect_set(db_nm)) when 2 then 3 else case collect_set(db_nm)[0] when 'cwmart_sdm_gj' then 1 else 2 end end as diff_status_em
from (select db_nm -- qf 20210716 汇总的时候统计差异类型
            ,rule_cd
            ,rule_nm
            ,amt_typ
            ,amt_modfr1
            ,amt_modfr2
            ,amt_modfr3
            ,amt_modfr4
            ,nval, dval
            ,sval
            ,para_key
            ,data_tag
            ,para_cond
            ,dat_key1 as dat_key
            ,origin_dt
       from dmf_tmp.dmftmp_gj_sf_all_data_collect_ycdz_000012_i_d
) t
group by dat_key, rule_cd, amt_typ
having sum(case when data_tag = 'cond' and nval = para_cond then 1 else 0 end)=sum(case when data_tag = 'cond' then 1 else 0 end)
;
""",

###根据汇总对账结果从对账数据模型中获取明细差异数据，关联并排除核算系统人工处理业财差异结果，其余数据存为差异
"sql_10": """
use dmf_tmp;
--存储差异数据
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='ycdz_diff',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_NEXTDATE}',sys='ycdz_diff',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_NEXTDATE}',sys='ycdz_diff',biz_type='000012');
-- qf 20210719 增加对账差异类型
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='ycdz_diff_1',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_NEXTDATE}',sys='ycdz_diff_1',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_NEXTDATE}',sys='ycdz_diff_1',biz_type='000012');

alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='ycdz_diff_2',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_NEXTDATE}',sys='ycdz_diff_2',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_NEXTDATE}',sys='ycdz_diff_2',biz_type='000012');

alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt <= '{TX_PREMONTHFIRSTDATE}',sys='ycdz_diff_3',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_NEXTDATE}',sys='ycdz_diff_3',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_NEXTDATE}',sys='ycdz_diff_3',biz_type='000012');  


insert into table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d partition(dt = '{TX_NEXTDATE}', sys, biz_type)
select t1.db_nm
      ,t1.tab_nm
      ,t1.col_nm
      ,t1.data_dt
      ,t1.amt_typ
      ,t1.amt_modfr1
      ,t1.amt_modfr2
      ,t1.amt_modfr3
      ,t1.amt_modfr4
      ,t1.dat_key1
      ,t1.dat_key2
      ,t1.dat_key3
      ,t1.dat_key4
      ,t1.dat_key5
      ,t1.sval
      ,t1.nval
      ,t1.dval
      ,t1.rule_nm
      ,t1.rule_cd
      ,t1.origin_dt
      ,t1.data
      ,concat('ycdz_diff_',t1.diff_status_em) as sys -- qf 20210716 增加差异类型
      ,'000012' as biz_type
from ( select *,concat(tab_nm,'&',rule_cd,'&',dat_key1) as join_key,data[0] as origin_id 
       from ( select d.db_nm
                    ,d.tab_nm
                    ,d.col_nm
                    ,d.data_dt
                    ,d.amt_typ
                    ,d.amt_modfr1
                    ,d.amt_modfr2
                    ,d.amt_modfr3
                    ,d.amt_modfr4
                    ,d.dat_key1
                    ,d.dat_key2
                    ,d.dat_key3
                    ,d.dat_key4
                    ,d.dat_key5
                    ,d.sval
                    ,d.nval
                    ,d.dval
                    ,d.rule_nm
                    ,d.rule_cd
                    ,d.origin_dt
                    ,d.data
                    -- qf 20210719去掉t.dt,
                    -- qf 20210719去掉t.biz_type,
                    ,t.diff_status_em -- qf 20210716 增加差异类型
               from ( select rule_cd, db_nm, tab_nm, col_nm, data_dt, amt_typ, amt_modfr1, amt_modfr2, amt_modfr3, amt_modfr4,dat_key1, dat_key2, dat_key3, dat_key4, dat_key5, sval, nval, dval, rule_nm,dat_key1 as dat_key,origin_dt,data
                      from dmf_tmp.dmftmp_gj_sf_all_data_collect_ycdz_000012_i_d
               ) d
               inner join (select * 
			               from dmf_tmp.dmftmp_gj_sf_ycdz_data_collect_result_000012_i_d r
                           where cast(abs(chk_rslt) as double) > 0
               ) t
               on d.rule_cd = t.rule_cd and d.dat_key = t.data_key
        ) k1
) t1
left join (select * from dmf_bc.dmfbc_bc_fi_acct_chk_diff_new_trt_i_d
           where dt='{TX_DATE}' -- qf 20211012 判断日期从TX_NEXTDATE调整为TX_DATE
) t2
on t1.join_key = t2.join_key AND  t1.origin_id=t2.origin_id
WHERE t2.join_key is null
;
""",
##关联差异数据和回抽的手工操作数据，如果关联上则保存到manual分区。否则依然为差异
"sql_11": """
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_gj_sf_busi_bankaccount_ycdz_fail_000012_i_d;
create table dmf_tmp.dmftmp_gj_sf_busi_bankaccount_ycdz_fail_000012_i_d
as
select case db_nm when 'cwmart_sdm_gj' then NULL else data[0] end capital_origin_id
      ,amt_typ as bank_id
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[2] end capital_no
      ,case db_nm when 'cwmart_sdm_gj' then NULL else dat_key3 end capital_bus_no
      ,case db_nm when 'cwmart_sdm_gj' then NULL else dat_key4 end capital_bus_time
      ,case db_nm when 'cwmart_sdm_gj' then 0 else nval end capital_amount
      ,case db_nm when 'cwmart_sdm_gj' then NULL else amt_modfr3 end capital_biz_system
      ,case db_nm when 'cwmart_sdm_gj' then NULL else amt_modfr1 end capital_biz_catg
      ,case db_nm when 'cwmart_sdm_gj' then NULL else dat_key2 end capital_pay_type
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[11] end capital_remark
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[4] end capital_currency_code
      ,case db_nm when 'cwmart_sdm_gj' then NULL else amt_modfr2 end capital_direction_em
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[13] end capital_create_dt
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[1] end capital_data_source_em
      ,case db_nm when 'cwmart_sdm_gj' then NULL else dat_key5 end capital_valid
      ,case db_nm when 'cwmart_sdm_gj' then NULL else amt_modfr4 end capital_op_code
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[30] end capital_businessTypeName     -- qf 20210717 资金账费用类型
      ,case db_nm when 'cwmart_sdm_gj' then NULL else data[31] end capital_settWayName          -- qf 20210717 资金账结算场景
      ,case db_nm when 'cwmart_sdm_gj' then data[8] else NULL end ledger_bus_time
      ,case db_nm when 'cwmart_sdm_gj' then amt_modfr4 else NULL end ledger_data_source_em
      ,case db_nm when 'cwmart_sdm_gj' then data[0] else NULL end ledger_origin_id
      ,case db_nm when 'cwmart_sdm_gj' then dat_key2 else NULL end ledger_serial_no
      ,case db_nm when 'cwmart_sdm_gj' then amt_modfr2 else NULL end ledger_biz_type
      ,case db_nm when 'cwmart_sdm_gj' then amt_modfr1 else NULL end ledger_biz_line
      ,case db_nm when 'cwmart_sdm_gj' then dat_key5 else NULL end ledger_product_no
      ,case db_nm when 'cwmart_sdm_gj' then amt_modfr3 else NULL end ledger_trans_type
      ,case db_nm when 'cwmart_sdm_gj' then data[1] else NULL end ledger_company_no1
      ,case db_nm when 'cwmart_sdm_gj' then data[2] else NULL end ledger_company_no2
      ,case db_nm when 'cwmart_sdm_gj' then data[3] else NULL end ledger_company_no3
      ,case db_nm when 'cwmart_sdm_gj' then data[4] else NULL end ledger_company_no4
      ,case db_nm when 'cwmart_sdm_gj' then data[5] else NULL end ledger_company_no5
      ,case db_nm when 'cwmart_sdm_gj' then data[6] else NULL end ledger_borrow_bank_acct
      ,case db_nm when 'cwmart_sdm_gj' then data[7] else NULL end ledger_loan_bank_acct
      ,case db_nm when 'cwmart_sdm_gj' then data[8] else NULL end ledger_trans_dt
      ,case db_nm when 'cwmart_sdm_gj' then dval else 0 end ledger_trans_amt
      ,case db_nm when 'cwmart_sdm_gj' then data[9] else NULL end ledger_trans_no
      ,case db_nm when 'cwmart_sdm_gj' then dat_key4 else NULL end ledger_pay_no
      ,case db_nm when 'cwmart_sdm_gj' then data[10] else NULL end ledger_loan_no
      ,case db_nm when 'cwmart_sdm_gj' then data[11] else NULL end ledger_plan_no
      ,case db_nm when 'cwmart_sdm_gj' then data[12] else NULL end ledger_customer_no
      ,case db_nm when 'cwmart_sdm_gj' then data[13] else NULL end ledger_merchant_no
      ,case db_nm when 'cwmart_sdm_gj' then dat_key2 else NULL end ledger_section_no
      ,case db_nm when 'cwmart_sdm_gj' then data[14] else NULL end ledger_pay_enum
      ,case db_nm when 'cwmart_sdm_gj' then dat_key3 else NULL end ledger_direction
      ,case db_nm when 'cwmart_sdm_gj' then data[15] else NULL end ledger_loan_type
      ,case db_nm when 'cwmart_sdm_gj' then data[16] else NULL end ledger_create_dt
      ,case db_nm when 'cwmart_sdm_gj' then data[17] else NULL end ledger_order_no
      ,case db_nm when 'cwmart_sdm_gj' then data[18] else NULL end ledger_project_no
      ,case db_nm when 'cwmart_sdm_gj' then data[19] else NULL end ledger_spare_no
      ,case db_nm when 'cwmart_sdm_gj' then data[20] else NULL end ledger_vir_merchant
      ,case db_nm when 'cwmart_sdm_gj' then data[35] else NULL end ledger_fee_type   -- qf 20210715 增加台账费用类型
      ,case db_nm when 'cwmart_sdm_gj' then data[36] else NULL end ledger_sett_scenes-- qf 20210715 增加台账结算场景
      ,substr(sys,11) as diff_status_em                                              -- qf 20210715 增加差异类型
      ,db_nm
      ,tab_nm
      ,dat_key1
      ,rule_cd
      ,origin_dt
from dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d
where dt='{TX_NEXTDATE}' and biz_type='000012' and sys in ('ycdz_diff','ycdz_diff_1','ycdz_diff_2','ycdz_diff_3')
;

""",
##业财核对成功的明细数据，写入数据模型
"sql_12": """
use dmf_tmp;
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d drop partition (dt='{TX_DATE}',sys='ycdz',biz_type='000012');
alter table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d add partition (dt='{TX_DATE}',sys='ycdz',biz_type='000012');
insert into table dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d partition(dt = '{TX_DATE}', sys='ycdz', biz_type='000012')
select t.db_nm
      ,t.tab_nm
      ,t.col_nm
      ,t.data_dt
      ,t.amt_typ
      ,t.amt_modfr1
      ,t.amt_modfr2
      ,t.amt_modfr3
      ,t.amt_modfr4
      ,t.dat_key1
      ,t.dat_key2
      ,t.dat_key3
      ,t.dat_key4
      ,t.dat_key5
      ,t.sval
      ,t.nval
      ,t.dval
      ,t.rule_nm
      ,t.rule_cd
      ,t.origin_dt
      ,t.data
from (select data_key,rule_cd,amt_typ,rule_nm
      from dmf_tmp.dmftmp_gj_sf_ycdz_data_collect_result_000012_i_d d
      where cast(abs(chk_rslt) as double)=0
) d
inner join dmf_tmp.dmftmp_gj_sf_all_data_collect_ycdz_000012_i_d t
on nvl(t.dat_key1,'')=nvl(d.data_key,'') and nvl(t.rule_cd,'')=nvl(d.rule_cd,'') and nvl(t.amt_typ,'')=nvl(d.amt_typ,'')
;
""",
##qf 20210716 差异不再做汇总，改成同步以后再调度平台进行多维度汇总
##写入业财差异明细数据
"sql_13": """
use dmf_gj;
alter table dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d drop partition (dt='{TX_DATE}');
alter table dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d add partition (dt='{TX_DATE}');
insert overwrite table dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d partition(dt='{TX_DATE}')
select COALESCE(ledger_origin_id,capital_origin_id) as origin_id         
      ,bank_id
      ,COALESCE(ledger_data_source_em,capital_data_source_em) as data_source_em
      ,capital_no
      ,capital_bus_no
      ,capital_bus_time
      ,capital_amount
      ,capital_biz_system
      ,capital_biz_catg
      ,capital_pay_type
      ,capital_remark
      ,capital_currency_code
      ,capital_direction_em
      ,capital_create_dt
      ,capital_data_source_em
      ,capital_valid
      ,capital_op_code
      ,ledger_bus_time
      ,ledger_data_source_em
      ,ledger_origin_id
      ,ledger_serial_no
      ,ledger_biz_type
      ,ledger_biz_line
      ,ledger_product_no
      ,ledger_trans_type
      ,ledger_company_no1
      ,ledger_company_no2
      ,ledger_company_no3
      ,ledger_company_no4
      ,ledger_company_no5
      ,ledger_borrow_bank_acct
      ,ledger_loan_bank_acct
      ,ledger_trans_dt
      ,ledger_trans_amt
      ,ledger_trans_no
      ,ledger_pay_no
      ,ledger_loan_no
      ,ledger_plan_no
      ,ledger_customer_no
      ,ledger_merchant_no
      ,ledger_section_no
      ,ledger_pay_enum
      ,ledger_direction
      ,ledger_loan_type
      ,ledger_create_dt
      ,ledger_order_no
      ,ledger_project_no
      ,ledger_spare_no
      ,ledger_vir_merchant
      ,'' as ledger_fund_type
      ,'' as oper_user
      ,'' as confirm_user
      ,'' as oper_id
      ,'' as oper_time
      ,FROM_UNIXTIME(UNIX_TIMESTAMP()) as create_dt
      ,FROM_UNIXTIME(UNIX_TIMESTAMP()) as update_dt
      ,concat(tab_nm,'&',rule_cd,'&',dat_key1) as join_key
      ,'0' as handle_status_em
      ,origin_dt
      ,diff_status_em
      ,capital_businessTypeName       -- qf 20210717 资金账费用类型
      ,capital_settWayName            -- qf 20210717 资金账结算场景
      ,ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
      ,ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
      ,substr(rule_cd,5) as rule_id                                                   -- qf 0210716 增加规则id
from dmf_tmp.dmftmp_gj_sf_busi_bankaccount_ycdz_fail_000012_i_d
;
""",
##获取业财对账后全量交易明细数据

"sql_14": """
use dmf_gj;
insert overwrite table dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_ycdz_000012_i_d partition(dt,data_source_em)
--不参与对账的交易明细数据
select data[0] as origin_id
      ,dat_key2 as serial_no
      ,amt_modfr2 as biz_type
      ,amt_modfr1 as biz_line
      ,dat_key5 as product_no
      ,amt_modfr3 as trans_type
      ,data[1] as company_no1
      ,data[2] as company_no2
      ,data[3] as company_no3
      ,data[4] as company_no4
      ,data[5] as company_no5
      ,data[6] as borrow_bank_acct
      ,data[7] as loan_bank_acct
      ,data[8] as trans_dt
      ,dval as trans_amt
      ,data[9] as trans_no
      ,dat_key4 as pay_no
      ,data[10] as loan_no
      ,data[11] as plan_no
      ,data[12] as customer_no
      ,data[13] as merchant_no
      ,dat_key2 as section_no
      ,data[14] as pay_enum
      ,dat_key3 as direction
      ,data[15] as loan_type
      ,data[16] as create_dt
      ,data[17] as order_no
      ,data[18] as project_no
      ,data[19] as spare_no
      ,data[20] as vir_merchant
      ,data[21] as company_no6
      ,data[22] as company_no7
      ,data[23] as company_no8
      ,data[24] as company_no9
      ,'' as oper_user
      ,'' as confirm_user
      ,'' as oper_id
      ,'' as oper_time
      ,origin_dt as run_dt
      ,data[25] as currency
      ,data[26] as has_tax
      ,data[27] as tax
      ,'nom' as sys
      ,data[28] as source_table
      ,data[29] as source_table_dt
      ,data[30] as repay_no
      ,data[31] as refund_no
      ,data[32] as bill_no
      ,data[33] as sett_id
      ,data[34] as fee_id
      ,data[35] as fee_type
      ,data[36] as sett_scenes
      ,data[37] as sett_biz_type
      ,data[38] as writeoff_status
      ,data[39] as product_id
      ,data[40] as sku_id
      ,'{TX_DATE}' as dt
      ,amt_modfr4 as data_source_em
from dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d
where dt='{TX_DATE}' and sys='nom' and biz_type='000012' and rule_nm='1' and tab_nm='sdm_gj_transaction_detail_i'
UNION ALL
-- 业财对账成功交易明细数据
select data[0] as origin_id
      ,dat_key2 as serial_no
      ,amt_modfr2 as biz_type
      ,amt_modfr1 as biz_line
      ,dat_key5 as product_no
      ,amt_modfr3 as trans_type
      ,data[1] as company_no1
      ,data[2] as company_no2
      ,data[3] as company_no3
      ,data[4] as company_no4
      ,data[5] as company_no5
      ,data[6] as borrow_bank_acct
      ,data[7] as loan_bank_acct
      ,data[8] as trans_dt
      ,dval as trans_amt
      ,data[9] as trans_no
      ,dat_key4 as pay_no
      ,data[10] as loan_no
      ,data[11] as plan_no
      ,data[12] as customer_no
      ,data[13] as merchant_no
      ,dat_key2 as section_no
      ,data[14] as pay_enum
      ,dat_key3 as direction
      ,data[15] as loan_type
      ,data[16] as create_dt
      ,data[17] as order_no
      ,data[18] as project_no
      ,data[19] as spare_no
      ,data[20] as vir_merchant
      ,data[21] as company_no6
      ,data[22] as company_no7
      ,data[23] as company_no8
      ,data[24] as company_no9
      ,'' as oper_user
      ,'' as confirm_user
      ,'' as oper_id
      ,'' as oper_time
      ,origin_dt as run_dt
      ,data[25] as currency
      ,data[26] as has_tax
      ,data[27] as tax
      ,'ycdz' as sys
      ,data[28] as source_table
      ,data[29] as source_table_dt
      ,data[30] as repay_no
      ,data[31] as refund_no
      ,data[32] as bill_no
      ,data[33] as sett_id
      ,data[34] as fee_id
      ,data[35] as fee_type
      ,data[36] as sett_scenes
      ,data[37] as sett_biz_type
      ,data[38] as writeoff_status
      ,data[39] as product_id
      ,data[40] as sku_id
      ,'{TX_DATE}' as dt
      ,amt_modfr4 as data_source_em
from (select * from dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d where dt = '{TX_DATE}' and sys='ycdz' and biz_type='000012'
) k1
where rule_nm='1' and tab_nm='sdm_gj_transaction_detail_i'
;
""",


}


# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)
