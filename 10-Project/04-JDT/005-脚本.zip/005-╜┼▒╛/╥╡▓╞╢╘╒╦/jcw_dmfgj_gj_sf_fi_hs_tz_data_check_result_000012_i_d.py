# !/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *


#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE


def get_customized_items():
    """
     if you need some special values in your sql, please define AND calculate THEN here
     to refer it AS {YOUR_VAR} in your sql
    """
    today = Time.today()
    ##TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    ##TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()


sql_map={

     # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

    "sql_01": """
    set mapred.job.name=job_dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d_01;
    set hive.merge.mapfiles = true;
    set hive.merge.mapredfiles= true;
    set hive.merge.size.per.task = 1024000000;
    set hive.merge.smallfiles.avgsize =1024000000;
        
    use dmf_tmp;
         
    drop table if exists dmf_tmp.dmftmp_gj_cf_fi_transaction_detail_config_000012;
    create table dmf_tmp.dmftmp_gj_cf_fi_transaction_detail_config_000012 AS 
    SELECT dtl.pay_no,
        concat_ws(',',collect_set(dtl.biz_type)) AS biz_type, --业务小类
        concat_ws(',',collect_set(dtl.biz_line)) AS biz_line, --业务线
        sum(case WHEN coalesce(dtl.biz_line,'')='' THEN 1 ELSE 0 END ) AS isnull_biz_line, --业务线是否为空
        concat_ws(',',collect_set(dtl.trans_type)) AS trans_type,--交易类型
        sum(case WHEN coalesce(dtl.trans_type,'')='' THEN 1 ELSE 0 END ) AS isnull_trans_type, --交易类型是否为空
        concat_ws(',',collect_set(dtl.borrow_bank_acct)) AS borrow_bank_acct, --借银行账户
        concat_ws(',',collect_set(dtl.loan_bank_acct)) AS loan_bank_acct, --贷银行账户
        concat_ws(',',collect_set(case WHEN con.borrow_or_loan=0 THEN con.bank_account end))  AS con_borrow_bank_acct, ---配置表借银行账户
        concat_ws(',',collect_set(case WHEN con.borrow_or_loan=1 THEN con.bank_account end)) AS con_loan_bank_acct, --配置表贷银行账户
        concat_ws(',',collect_set(con.account_type_capital)) AS account_type_capital, --资金分类
        concat_ws(',',collect_set(con.account_biz_system)) AS  account_biz_system,--资金帐来源系统
		concat_ws(',',collect_set(case when fee_id !='' and fee_id is not null then   dtl.pay_no else dtl.trans_no end )) AS  trans_no,--台账单号1
		concat_ws(',',collect_set(case when fee_id !='' and fee_id is not null then   dtl.pay_no else dtl.loan_no end)) AS  loan_no,--台账单号2
		concat_ws(',',collect_set(case when fee_id !='' and fee_id is not null then   dtl.pay_no else dtl.plan_no end)) AS  plan_no,--台账单号3
		concat_ws(',',collect_set(case when fee_id !='' and fee_id is not null then   dtl.pay_no else dtl.order_no end)) AS  order_no--台账单号4		
    FROM (
            SELECT * from dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_000012_i_d
            WHERE dt <= '{TX_DATE}'
            AND dt >= '{TX_PRE_60_DATE}'
			AND replace(nvl(pay_no,''),' ','')<>'' and pay_no<>'NULL'
         )dtl
    LEFT JOIN 
         (  SELECT *
            FROM dmf_dim.dmfdim_gj_hs_dm_busi_bankaccount_config_s_d con
            WHERE dt = '{TX_DATE}'
         ) con
        ON coalesce(dtl.biz_type, '') = coalesce(con.bus_small_type, '')
            AND coalesce(dtl.biz_line, '') = coalesce(con.biz_line, '')
            AND coalesce(dtl.trans_type, '') = coalesce(con.trans_type, '')
			--20210924@lina285 添加
            AND coalesce(dtl.data_source_em, '') = coalesce(con.source_sys, '')
    GROUP BY dtl.pay_no;




    """,
    
    "sql_02": """
	set mapred.job.name=job_dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d_02;
	use dmf_gj;
	 --财务账未达差异(财务账无资金帐有)打标结果表，清理历史数据
	 alter table dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d drop partition (dt <= '{TX_PRE_60_DATE}');
	 --清理T-1日数据
	 alter table dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d drop partition (dt = '{TX_DATE}');
	 --创建T-1日分区
	 alter table dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d  add partition (dt = '{TX_DATE}');
    """,
    
    "sql_03": """
    set mapred.job.name=job_dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d_03;
    use dmf_gj;
    insert into dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d partition (dt = '{TX_DATE}')
	select  t1.origin_id                  
		   ,t1.data_source_em             
		   ,t1.bank_id                    
		   ,t1.capital_no                 
		   ,t1.capital_bus_no             
		   ,t1.capital_bus_time           
		   ,t1.capital_amount             
		   ,t1.capital_biz_system         
		   ,t1.capital_biz_catg           
		   ,t1.capital_pay_type           
		   ,t1.capital_remark             
		   ,t1.capital_currency_code      
		   ,t1.capital_direction_em 
		   ,t1.capital_create_dt      
		   ,t1.capital_data_source_em     
		   ,t1.ledger_bus_time            
		   ,t1.ledger_fund_type           
		   ,t1.ledger_data_source_em      
		   ,t1.ledger_origin_id           
		   ,t1.ledger_serial_no           
		   ,t1.ledger_biz_type            
		   ,t1.ledger_biz_line            
		   ,t1.ledger_product_no          
		   ,t1.ledger_trans_type          
		   ,t1.ledger_company_no1         
		   ,t1.ledger_company_no2         
		   ,t1.ledger_company_no3         
		   ,t1.ledger_company_no4         
		   ,t1.ledger_company_no5         
		   ,t1.ledger_borrow_bank_acct    
		   ,t1.ledger_loan_bank_acct      
		   ,t1.ledger_trans_dt            
		   ,t1.ledger_trans_amt           
		   ,t1.ledger_trans_no            
		   ,t1.ledger_pay_no              
		   ,t1.ledger_loan_no             
		   ,t1.ledger_plan_no             
		   ,t1.ledger_customer_no         
		   ,t1.ledger_merchant_no         
		   ,t1.ledger_section_no          
		   ,t1.ledger_pay_enum            
		   ,t1.ledger_direction           
		   ,t1.ledger_loan_type           
		   ,t1.ledger_create_dt           
		   ,t1.ledger_order_no            
		   ,t1.ledger_project_no          
		   ,t1.join_key                   
		   ,t1.handle_status_em           
		   ,t1.create_dt                  
		   ,t1.update_dt                  
		   ,t1.origin_dt AS capital_dt                 
		   ,t1.capital_valid              
		   ,t1.capital_op_code        
		   ,t1.oper_user                  
		   ,t1.confirm_user               
		   ,t1.oper_id                    
		   ,t1.oper_time                  
		   ,t1.ledger_spare_no            
		   ,t1.ledger_vir_merchant                                 
		   ,'000012' AS bus_big_type  
		   ,t1.diff_status_em
		   ,t1.origin_dt AS rematch_dt           
		   ,(case   WHEN coalesce(t1.is_jdmall_biz,'')='1' THEN '110'   --非集团数据
					WHEN t6.origin_id is not null  THEN '111' --数据问题-资金系统-退票数据
				    WHEN t4.is_tuipiao = 1 then '111' --数据问题-资金系统-退票数据
					WHEN coalesce(capital_valid,'') = '0' THEN '13'                                              --资金帐冲销数据
					WHEN coalesce(capital_valid,'') <> '0' AND capital_biz_system in ('177','176') THEN '14'     --线下处理数据
					WHEN coalesce(capital_valid,'') <> '0' 
					   AND coalesce(capital_biz_system,'') not in ('177','176') 
					   AND UPPER(coalesce(trim(capital_op_code),''))<>'SYSTEM'   THEN '15'                     --线下处理数据
					WHEN (coalesce(t2.capital_biz_catg_new,'') <>'' OR t1.capital_biz_system  ='178') THEN '16'  --业务线无需要集成 
					--20210924@lina285	添加 37 对账需求问题-收支方向问题
					when coalesce(t5.ledger_pay_no,'')<> '' and abs(capital_amount) =abs(t5.ledger_trans_amt) then '37'					
					WHEN coalesce(t5.ledger_pay_no,'')<> '' THEN '109'              --财务帐有资金帐无中能匹配
					WHEN t3.pay_no IS NOT NULL
						THEN (CASE  WHEN coalesce(t3.biz_line, '') = '' OR t3.isnull_biz_line>0 THEN '003' --'运营问题-核算业务线映射问题'
									WHEN coalesce(t3.trans_type, '') = '' OR t3.isnull_trans_type>0 THEN '004' --'开发问题-核算交易环节映射为空'
									WHEN (array_contains(split(t3.borrow_bank_acct, ','), t1.bank_id) 
													OR array_contains(split(t3.loan_bank_acct, ','), t1.bank_id))
											  AND array_contains(split(t3.account_type_capital, ','), t1.capital_biz_catg)
											  AND NOT array_contains(split(t3.account_biz_system, ','), t1.capital_biz_system)
										THEN '101' -- 对账需求问题-核算侧-缺少场景配置 --来源系统问题
									WHEN (array_contains(split(t3.borrow_bank_acct, ','), t1.bank_id)
													OR array_contains(split(t3.loan_bank_acct, ','), t1.bank_id))
											  AND NOT array_contains(split(t3.account_type_capital, ','), t1.capital_biz_catg)
											  AND array_contains(split(t3.account_biz_system, ','), t1.capital_biz_system)
										THEN '102' -- 对账需求问题-核算侧-缺少场景配置  --资金分类一样										    --20210924@lina285 缺少场景配置 ，本身是有资金帐无台账，资金帐侧肯定是配置了，应该是台账侧对应的业务线摘要未配置
									WHEN not array_contains(split(t3.borrow_bank_acct, ','), t1.bank_id)
											  AND not array_contains(split(t3.loan_bank_acct, ','), t1.bank_id)
										THEN '005' --'数据问题-资金帐和财务账银行账号不一致'
									WHEN NOT array_contains(split(t3.con_borrow_bank_acct, ','), t1.bank_id)
											   AND not array_contains(split(t3.con_loan_bank_acct, ','), t1.bank_id)   
											   AND array_contains(split(t3.account_type_capital, ','), t1.capital_biz_catg)
											   AND array_contains(split(t3.account_biz_system, ','), t1.capital_biz_system)
										THEN '103' -- 对账需求问题-核算侧-缺少场景配置--银行账号
									WHEN coalesce(t3.account_type_capital, '') = ''
											   OR coalesce(t3.account_biz_system, '') = ''
										THEN '010' --对账需求问题-核算侧-缺少场景配置  --摘要未配置即配置表中未查到来源系统和资金分类
									WHEN (coalesce(t3.borrow_bank_acct, '') = '' AND coalesce(t3.con_borrow_bank_acct, '') <> '' )
											   OR ( coalesce(t3.loan_bank_acct, '') = '' AND coalesce(t3.con_loan_bank_acct, '') <> '' )
										THEN '002' -- 数据问题-银行账号为空
									WHEN (array_contains(split(t3.trans_no, ','), t1.capital_no) or array_contains(split(t3.loan_no, ','), t1.capital_no) or array_contains(split(t3.plan_no, ','), t1.capital_no) or array_contains(split(t3.order_no, ','), t1.capital_no))
										THEN '113' -- 数据问题-对账单号不一致
									ELSE '17' 
								END )
					WHEN t4.pay_id IS NOT NULL AND abs(t1.capital_amount)  = abs(t4.amount)
						THEN '006' --核算会计账需求问题-结算系统数据未集成
					WHEN t4.pay_id IS NOT NULL AND abs(t1.capital_amount) > abs(t4.amount)
						THEN '007'--核算会计账需求问题-结算系统数据未集成-结算场景需要拆分集成
					WHEN coalesce(t3.pay_no,'') = ''
								 AND (unix_timestamp(substr(capital_bus_time,1,19),'yyyy-MM-dd hh:mm:ss') - unix_timestamp('{TX_DATE}','yyyy-MM-dd'))<86400
								 AND (unix_timestamp(substr(capital_bus_time,1,19),'yyyy-MM-dd hh:mm:ss') - unix_timestamp('{TX_DATE}','yyyy-MM-dd'))>82800
						THEN '8'                                            --'资金帐与财务数据时间差'
					ELSE ''            --无匹配数据 -从业务系统匹配数据（先输出到一张结果表）   
				END ) AS result_flag
		   ,t1.capital_businessTypeName                                                      -- qf 20210717 资金账费用类型
		   ,t1.capital_settWayName                                                            -- qf 20210717 资金账结算场景   
		   ,t1.ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
		   ,t1.ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
		   ,t1.rule_id                                                                        -- qf 0210716 增加规则id 
	FROM (SELECT *,dmf_bc.dmdictDesc('sett_scenes_is_jdmall_biz',capital_businesstypename) as is_jdmall_biz  
			FROM dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d 
			WHERE dt= '{TX_DATE}'
				  AND handle_status_em='0'
				  AND diff_status_em ='2') t1 --有资金帐无台账
	LEFT JOIN dmf_add.dmfadd_add_fi_zjz_no_compare_a_d t2         
		ON t1.capital_biz_catg = t2.capital_biz_catg_new
	LEFT JOIN dmf_tmp.dmftmp_gj_cf_fi_transaction_detail_config_000012 t3      --交易明细直接通过trans_type关联对账配置
		ON trim(t1.capital_no) = trim(t3.pay_no)
	LEFT JOIN (SELECT pay_id,sum(amount) as amount,max(case when status='9' then 1 else 0 end ) as is_tuipiao  FROM dmf_bc.dmfbc_bc_fi_fst_sett_i_d       --TODO 表
				  WHERE dt >= '{TX_PRE_60_DATE}'
					  AND dt <= '{TX_DATE}' 
					  and yn_flag='1' 
					  AND amount<>0
				  GROUP BY pay_id) t4                                                                                
		ON trim(t1.capital_no) = trim(t4.pay_id)
	left join (SELECT ledger_pay_no, sum(ledger_trans_amt) as ledger_trans_amt ,ledger_direction  
	FROM dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d
				  WHERE dt= '{TX_DATE}'
					 AND handle_status_em='0'
					 AND diff_status_em = 1 AND COALESCE(ledger_pay_no,'') <> '' AND COALESCE(ledger_trans_amt,0) <> 0 AND COALESCE(ledger_trans_dt,'') <> '' 
				  group by ledger_pay_no ,ledger_direction
			  ) t5 
	 ON trim(t1.capital_no) = trim(t5.ledger_pay_no)
	left join ( select * from dmf_bc.dmfbc_gj_hs_fi_hs_m07_cap_data_ycdz_i_d 
				  where dt>='{TX_PRE_60_DATE}' 
					and dt< '{TX_DATE}'
					and pay_status='10'
	) t6  --资金帐退票数据
	ON  t1.origin_id=t6.origin_id  ;
    """,
}

# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)