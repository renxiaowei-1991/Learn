# !/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE
def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

"sql_01": """
set mapred.job.name=job_sdm_gj_cw_zjz_tz_data_check_result_collect_000012_01;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;

--1-2-2-2-2-2-1
--目前要处理的是所有需要到业务系统进行匹配的数据，但是目前只有个别业务大类开发了
--从业务系统进行匹配的程序，所以需要把还没有进行从业务系统进行匹配的数据汇总到结果表，使数据完整；
--传数据进结果表
alter table dmf_gj.dmfgj_gj_sf_fi_hs_acct_rslt_tab_push_000012_i_d drop partition (r_dt <= '{TX_PRE_29_DATE}' );
alter table dmf_gj.dmfgj_gj_sf_fi_hs_acct_rslt_tab_push_000012_i_d drop partition (r_dt = '{TX_DATE}' );
alter table dmf_gj.dmfgj_gj_sf_fi_hs_acct_rslt_tab_push_000012_i_d add partition (r_dt = '{TX_DATE}' );
""",

"sql_02": """
set mapred.job.name=job_sdm_gj_cw_zjz_tz_data_check_result_collect_000012_02;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;

insert into dmf_gj.dmfgj_gj_sf_fi_hs_acct_rslt_tab_push_000012_i_d partition (r_dt = '{TX_DATE}' )
--资金帐有台账无数据
select     origin_id
          ,data_source_em
          ,bank_id
          ,capital_no
          ,capital_bus_no
          ,capital_bus_time
          ,capital_amount
          ,capital_biz_system
          ,capital_biz_catg
          ,capital_pay_type
          ,capital_remark
          ,capital_currency_code
          ,capital_direction_em
          ,capital_create_dt
          ,capital_data_source_em
          ,ledger_fund_type
          ,ledger_data_source_em
          ,ledger_origin_id
          ,ledger_serial_no
          ,ledger_biz_type
          ,ledger_biz_line
          ,ledger_product_no
          ,ledger_trans_type
          ,ledger_company_no1
          ,ledger_company_no2
          ,ledger_company_no3
          ,ledger_company_no4
          ,ledger_company_no5
          ,ledger_borrow_bank_acct
          ,ledger_loan_bank_acct
          ,ledger_trans_dt
          ,ledger_trans_amt
          ,ledger_trans_no
          ,ledger_pay_no
          ,ledger_loan_no
          ,ledger_plan_no
          ,ledger_customer_no
          ,ledger_merchant_no
          ,ledger_section_no
          ,ledger_pay_enum
          ,ledger_direction
          ,ledger_loan_type
          ,ledger_create_dt
          ,ledger_order_no
          ,ledger_project_no
          ,t1.join_key
          ,handle_status_em
          ,create_dt
          ,update_dt
          ,capital_valid
          ,bus_big_type
          ,diff_status_em
          ,rematch_dt  as dt
          ,case when t2.result_flag is not null then t2.result_flag
                when t1.result_flag='' then '33' 
                else t1.result_flag 
           end as result_flag
          ,'' as data_source_flag
        ,capital_businessTypeName                                                       -- qf 20210717 资金账费用类型
        ,capital_settWayName                                                            -- qf 20210717 资金账结算场景   
        ,ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
        ,ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
        ,rule_id                                                                        -- qf 0210716 增加规则id           
from     (select *     from dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d where dt = '{TX_DATE}')t1
           
left join  
  
        (select distinct join_key,result_flag 
         from dmf_bc.dmfbc_gj_sf_zjz_tz_data_check_result_collect_gyl_i_d t2 
         where dt = '{TX_DATE}' and  nvl(result_flag,'')<>''
        )t2 on t1.join_key=t2.join_key  


 
;
""",

"sql_03": """
set mapred.job.name=job_sdm_gj_cw_zjz_tz_data_check_result_collect_000012_03;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;

insert into dmf_gj.dmfgj_gj_sf_fi_hs_acct_rslt_tab_push_000012_i_d partition (r_dt = '{TX_DATE}' )
--台账有资金帐无数据
--传数据进结果表
select     origin_id
          ,data_source_em
          ,bank_id
          ,capital_no
          ,capital_bus_no
          ,capital_bus_time
          ,capital_amount
          ,capital_biz_system
          ,capital_biz_catg
          ,capital_pay_type
          ,capital_remark
          ,capital_currency_code
          ,capital_direction_em
          ,capital_create_dt
          ,capital_data_source_em
          ,ledger_fund_type
          ,ledger_data_source_em
          ,ledger_origin_id
          ,ledger_serial_no
          ,ledger_biz_type
          ,ledger_biz_line
          ,ledger_product_no
          ,ledger_trans_type
          ,ledger_company_no1
          ,ledger_company_no2
          ,ledger_company_no3
          ,ledger_company_no4
          ,ledger_company_no5
          ,ledger_borrow_bank_acct
          ,ledger_loan_bank_acct
          ,ledger_trans_dt
          ,ledger_trans_amt
          ,ledger_trans_no
          ,ledger_pay_no
          ,ledger_loan_no
          ,ledger_plan_no
          ,ledger_customer_no
          ,ledger_merchant_no
          ,ledger_section_no
          ,ledger_pay_enum
          ,ledger_direction
          ,ledger_loan_type
          ,ledger_create_dt
          ,ledger_order_no
          ,ledger_project_no
          ,t1.join_key
          ,handle_status_em
          ,create_dt
          ,update_dt
          ,capital_valid
          ,bus_big_type
          ,diff_status_em
          ,rematch_dt  as dt
          ,case when t2.result_flag is not null then t2.result_flag
                when t1.result_flag='' then '33' 
                else t1.result_flag 
          end as result_flag
          ,'' as data_source_flag
          ,capital_businessTypeName                                                       -- qf 20210717 资金账费用类型
          ,capital_settWayName                                                            -- qf 20210717 资金账结算场景   
          ,ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
          ,ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
          ,rule_id   
from                                                                      -- qf 0210716 增加规则id           
        ( select * from dmf_gj.dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d where dt = '{TX_DATE}' )t1
left join  
  
        (select distinct join_key,result_flag 
         from dmf_bc.dmfbc_gj_sf_zjz_tz_data_check_result_collect_gyl_i_d t2 
         where dt = '{TX_DATE}' and  nvl(result_flag,'')<>''
        )t2 on t1.join_key=t2.join_key               
;
""",

"sql_04": """
set mapred.job.name=job_sdm_gj_cw_zjz_tz_data_check_result_collect_000012_04;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_gj;

insert into dmf_gj.dmfgj_gj_sf_fi_hs_acct_rslt_tab_push_000012_i_d partition (r_dt = '{TX_DATE}' )
--插入金额不匹配数据
select 
          origin_id
          ,a.data_source_em
          ,a.bank_id
          ,capital_no
          ,capital_bus_no
          ,capital_bus_time
          ,a.capital_amount
          ,a.capital_biz_system
          ,a.capital_biz_catg
          ,capital_pay_type
          ,capital_remark
          ,capital_currency_code
          ,a.capital_direction_em       
          ,capital_create_dt
          ,capital_data_source_em     
          ,ledger_fund_type
          ,a.ledger_data_source_em      
          ,ledger_origin_id
          ,ledger_serial_no
          ,a.ledger_biz_type
          ,ledger_biz_line
          ,ledger_product_no
          ,a.ledger_trans_type
          ,ledger_company_no1
          ,ledger_company_no2
          ,ledger_company_no3
          ,ledger_company_no4
          ,ledger_company_no5
          ,ledger_borrow_bank_acct
          ,ledger_loan_bank_acct
          ,ledger_trans_dt
          ,a.ledger_trans_amt
          ,ledger_trans_no
          ,ledger_pay_no
          ,ledger_loan_no
          ,ledger_plan_no
          ,ledger_customer_no
          ,ledger_merchant_no
          ,ledger_section_no
          ,ledger_pay_enum
          ,ledger_direction
          ,ledger_loan_type
          ,ledger_create_dt
          ,ledger_order_no
          ,ledger_project_no
          ,join_key
          ,handle_status_em       
          ,create_dt              
          ,update_dt              
          ,capital_valid
  		  ,'000012' as bus_big_type
  		  ,diff_status_em         
  		  ,origin_dt  as dt
  		  ,case 
  			when b.is_sett >0 and b.ledger_trans_amt/b.capital_amount=1 then '108'--核算会计账需求问题-结算系统-结算场景集成金额反了
  			when b.sett_direc= 2 then '105' --需求问题-结算系统-双向结算场景
  			when b.is_sett >0 and pmod(b.ledger_trans_amt,b.capital_amount)=0 then '106'--需求问题-结算系统-结算场景集成重复（财务金额>资金金额，且财务金额整除资金金额）
  			when b.is_sett >0 and b.ledger_trans_amt>b.capital_amount then '107' --资金帐漏记（财务金额>资金金额）
  			when b.is_sett >0 and b.ledger_trans_amt<b.capital_amount then '006' --结算场景漏集成（资金金额<财务金额）
  			--when b.bank_id='1278' and b.ledger_data_source_em ='a01_zdhk' and b.ledger_trans_type='7' and b.ledger_biz_type='100021'   then '1000010016' 
  		   else '3' end as result_flag
                ,'' as data_source_flag
                ,capital_businessTypeName                                                       -- qf 20210717 资金账费用类型
                ,capital_settWayName                                                            -- qf 20210717 资金账结算场景   
                ,ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
                ,ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
                ,rule_id                                                                        -- qf 0210716 增加规则id 
        from (select * ,split(join_key ,'&')[2] as join_key_no,case when coalesce(capital_settWayName, '') !='' then coalesce(capital_settWayName, '') else coalesce(ledger_sett_scenes, '')  end as sett_code 			   
						from dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d 
						  WHERE dt= '{TX_DATE}'
						  and   handle_status_em='0'
						  and   diff_status_em ='3') a 
  	    left join (
  				select split(join_key ,'&')[2] as join_key_no , 
  					   case when sum(coalesce(capital_amount,0)) >0 then sum(coalesce(capital_amount,0)) else sum(coalesce(capital_amount,0))*-1 end as capital_amount, 
					   case when sum(coalesce(ledger_trans_amt,0))>0 then sum(coalesce(ledger_trans_amt,0)) else sum(coalesce(ledger_trans_amt,0))*-1 end  as ledger_trans_amt, 
  					   sum(case when coalesce(capital_settWayName, '') !='' then 1  when coalesce(ledger_sett_scenes, '') !='' then 1 else 0 end ) as is_sett,
  					   max(case when b2.sett_direc is not null then b2.sett_direc else 0 end ) as sett_direc,
  					   concat_ws(',',collect_set(b1.bank_id)) AS bank_id,--银行id
  					   concat_ws(',',collect_set(b1.ledger_data_source_em)) AS ledger_data_source_em,--台账来源系统
  					   concat_ws(',',collect_set(b1.capital_biz_system)) AS capital_biz_system,--资金帐来源系统
  					   concat_ws(',',collect_set(b1.capital_biz_catg)) AS capital_biz_catg,--资金帐资金分类
  					   concat_ws(',',collect_set(b1.capital_direction_em)) AS capital_direction_em,--资金帐借贷方向
  					   concat_ws(',',collect_set(b1.ledger_trans_type)) AS ledger_trans_type,--台账交易环节
  					   concat_ws(',',collect_set(b1.ledger_biz_type)) AS ledger_biz_type--台账业务小类
  				from (select * 
  						from dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d 
  						WHERE dt= '{TX_DATE}'
  							  and   handle_status_em='0'
  							  and   diff_status_em ='3'
  				  ) b1 
  				left join 
  					 (select sett_code, -- 结算场景
  							case when mark & 2 =2 then 1  --单向
  							when mark & 4 =4 then 2 end  as sett_direc  --双项
  						from odm.odm_fi_js_fin_sett_settway_s_d
  					    where dt = '{TX_DATE}' 
  				)b2 on b1.ledger_sett_scenes=b2.sett_code 
  				group by split(join_key ,'&')[2] 
	) b on a.join_key_no = b.join_key_no;
 """,         

}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)