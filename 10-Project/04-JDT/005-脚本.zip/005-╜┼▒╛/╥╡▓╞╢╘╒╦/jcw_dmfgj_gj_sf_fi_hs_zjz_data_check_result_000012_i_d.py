# !/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *


#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE


def get_customized_items():
    """
     if you need some special values in your sql, please define AND calculate THEN here
     to refer it as {YOUR_VAR} in your sql
    """
    #today = sql_task._tx_date
    #TX_PRE_60_DATE = sql_task._tx_date.date_sub(date=today, itv=60)
    #TX_PRE_365_DATE = sql_task._tx_date.date_sub(date=today, itv=365)
    return locals()


sql_map={

     # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！
    "sql_01": """
	set mapred.job.name=job_dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d_01;
	use dmf_gj;
	--资金帐未达差异(财务账有资金帐无)打标结果表，清理历史数据
	alter table dmf_gj.dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d drop partition (dt <= '{TX_PRE_60_DATE}');
	--资金帐未达差异(财务账有资金帐无)打标结果表，清理T-1日数据
	alter table dmf_gj.dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d drop partition (dt = '{TX_DATE}');
	--资金帐未达差异(财务账有资金帐无)打标结果表，创建T-1日分区
	alter table dmf_gj.dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d  add partition (dt = '{TX_DATE}');
    """,
    "sql_02": """    
	set mapred.job.name=job_dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d_02;
	use dmf_gj;

	insert into dmf_gj.dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d partition (dt = '{TX_DATE}')
	  select 
	        origin_id                  
	        ,data_source_em             
	        ,bank_id                    
	        ,capital_no                 
	        ,capital_bus_no             
	        ,capital_bus_time           
	        ,capital_amount             
	        ,capital_biz_system         
	        ,capital_biz_catg           
	        ,capital_pay_type           
	        ,capital_remark             
	        ,capital_currency_code      
	        ,capital_direction_em
	        ,capital_create_dt       
	        ,capital_data_source_em     
	        ,ledger_bus_time            
	        ,ledger_fund_type           
	        ,ledger_data_source_em      
	        ,ledger_origin_id           
	        ,ledger_serial_no           
	        ,ledger_biz_type            
	        ,ledger_biz_line            
	        ,ledger_product_no          
	        ,ledger_trans_type          
	        ,ledger_company_no1         
	        ,ledger_company_no2         
	        ,ledger_company_no3         
	        ,ledger_company_no4         
	        ,ledger_company_no5         
	        ,ledger_borrow_bank_acct    
	        ,ledger_loan_bank_acct      
	        ,ledger_trans_dt            
	        ,ledger_trans_amt           
	        ,ledger_trans_no            
	        ,ledger_pay_no              
	        ,ledger_loan_no             
	        ,ledger_plan_no             
	        ,ledger_customer_no         
	        ,ledger_merchant_no         
	        ,ledger_section_no          
	        ,ledger_pay_enum            
	        ,ledger_direction           
	        ,ledger_loan_type           
	        ,ledger_create_dt           
	        ,ledger_order_no            
	        ,ledger_project_no          
	        ,join_key                   
	        ,handle_status_em           
	        ,create_dt                  
	        ,update_dt                  
	        ,origin_dt as capital_dt                  
	        ,capital_valid              
	        ,capital_op_code            
	        ,oper_user                  
	        ,confirm_user               
	        ,oper_id                    
	        ,oper_time                  
	        ,ledger_spare_no            
	        ,ledger_vir_merchant                                 
	        ,'000012' as bus_big_type   
	        ,diff_status_em  
	        ,origin_dt as rematch_dt              
	        ,'9'              --支付单号或金额为空
	        ,capital_businessTypeName                                                       -- qf 20210717 资金账费用类型
	       ,capital_settWayName                                                            -- qf 20210717 资金账结算场景   
	       ,ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
	       ,ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
	       ,rule_id                                                                        -- qf 0210716 增加规则id   
		from dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d
		WHERE dt= '{TX_DATE}'
		  AND handle_status_em='0'
		  AND diff_status_em = '1'
		  AND (COALESCE(ledger_pay_no,'') = '' OR COALESCE(ledger_trans_amt,0) = 0 OR COALESCE(ledger_trans_dt,'') = '');


    """,
    "sql_03": """
	set mapred.job.name=job_dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d_03;
	use dmf_gj;
	insert into dmf_gj.dmfgj_gj_sf_fi_hs_zjz_data_check_result_000012_i_d partition (dt = '{TX_DATE}')
	   select 
			 t1.origin_id                  
			,t1.data_source_em             
			,t1.bank_id                    
			,t1.capital_no                 
			,t1.capital_bus_no             
			,t1.capital_bus_time           
			,t1.capital_amount             
			,t1.capital_biz_system         
			,t1.capital_biz_catg           
			,t1.capital_pay_type           
			,t1.capital_remark             
			,t1.capital_currency_code      
			,t1.capital_direction_em
			,t1.capital_create_dt       
			,t1.capital_data_source_em     
			,t1.ledger_bus_time            
			,t1.ledger_fund_type           
			,t1.ledger_data_source_em      
			,t1.ledger_origin_id           
			,t1.ledger_serial_no           
			,t1.ledger_biz_type            
			,t1.ledger_biz_line            
			,t1.ledger_product_no          
			,t1.ledger_trans_type          
			,t1.ledger_company_no1         
			,t1.ledger_company_no2         
			,t1.ledger_company_no3         
			,t1.ledger_company_no4         
			,t1.ledger_company_no5         
			,t1.ledger_borrow_bank_acct    
			,t1.ledger_loan_bank_acct      
			,t1.ledger_trans_dt            
			,t1.ledger_trans_amt           
			,t1.ledger_trans_no            
			,t1.ledger_pay_no              
			,t1.ledger_loan_no             
			,t1.ledger_plan_no             
			,t1.ledger_customer_no         
			,t1.ledger_merchant_no         
			,t1.ledger_section_no          
			,t1.ledger_pay_enum            
			,t1.ledger_direction           
			,t1.ledger_loan_type           
			,t1.ledger_create_dt           
			,t1.ledger_order_no            
			,t1.ledger_project_no          
			,t1.join_key                   
			,t1.handle_status_em           
			,t1.create_dt                  
			,t1.update_dt                  
			,t1.origin_dt as capital_dt                 
			,t1.capital_valid              
			,t1.capital_op_code            
			,t1.oper_user                  
			,t1.confirm_user               
			,t1.oper_id                    
			,t1.oper_time                  
			,t1.ledger_spare_no            
			,t1.ledger_vir_merchant                                 
			,'000012' as bus_big_type   
			,t1.diff_status_em  
			,t1.origin_dt as rematch_dt              
			,CASE WHEN COALESCE(t1.ledger_sett_scenes,'') != ''  and T5.status in ('5','8','9') and COALESCE(t2.capital_no,'')!='' then '112' --数据问题-结算系统-退票数据，将退票台账和资金帐保持一致，目前未与资金帐paystatus=10直接匹配,结算状态 5-已驳回 8-付款失败 9-退票
				  WHEN COALESCE(t1.ledger_sett_scenes,'') != ''  and T5.status in ('5','8','9') and COALESCE(t2.capital_no,'')='' then '104' --无差异-结算单数据冲销（资金帐中不存在该单据）
				  WHEN COALESCE(t1.ledger_sett_scenes,'') != ''  and COALESCE(t4.capital_no,'')!='' then '37' --无差异-资金与财务账收支方向不一致（资金帐（如果对账配置未收入，则判断支出类资金帐）中存在该单据）
				  WHEN (COALESCE(t1.ledger_pay_no,'') = '' OR COALESCE(t1.ledger_trans_amt,0) = 0) THEN '9'    --支付单号或金额为空
				  WHEN nvl(t4.capital_no,'') != '' THEN '37'       --收支方向问题
				  WHEN COALESCE(t2.capital_no,'') <> ''
					  THEN ( CASE WHEN not ARRAY_CONTAINS(split(t2.biz_catg, ','), t1.biz_catg) AND ARRAY_CONTAINS(split(t1.biz_system, ','), t2.biz_system)  AND ARRAY_CONTAINS(split(t2.bank_id, ','), t1.bank_id) THEN '102'
								  WHEN ARRAY_CONTAINS(split(t2.biz_catg, ','), t1.biz_catg) AND not ARRAY_CONTAINS(split(t1.biz_system, ','), t2.biz_system) AND ARRAY_CONTAINS(split(t2.bank_id, ','), t1.bank_id) THEN '101'
								  WHEN ARRAY_CONTAINS(split(t2.biz_catg, ','), t1.biz_catg) AND ARRAY_CONTAINS(split(t1.biz_system, ','), t2.biz_system)  AND not ARRAY_CONTAINS(split(t2.bank_id, ','), t1.bank_id) THEN '103'
								  ELSE '10' 
							 END ) --业财对账配置问题  --fhf add
				  WHEN COALESCE(t3.judge_flag2,'') <> '' THEN '11'                                             --银行流水和资金帐时间差
				  WHEN COALESCE(t3.judge_flag2,'')='' 
					  AND (unix_timestamp(substr(concat(ledger_trans_dt,' 00:00:00'),1,19),'yyyy-MM-dd hh:mm:ss') - unix_timestamp('{TX_DATE}','yyyy-MM-dd'))<86400
					  AND (unix_timestamp(substr(concat(ledger_trans_dt,' 00:00:00'),1,19),'yyyy-MM-dd hh:mm:ss') - unix_timestamp('{TX_DATE}','yyyy-MM-dd'))>82800
					  THEN '8'              --资金帐与财务数据时间差
				  WHEN COALESCE(t3.judge_flag2,'')='' 
					  AND ((unix_timestamp(substr(concat(ledger_trans_dt,' 00:00:00'),1,19),'yyyy-MM-dd hh:mm:ss') - unix_timestamp('{TX_DATE}','yyyy-MM-dd'))>=86400
					  OR (unix_timestamp(substr(concat(ledger_trans_dt,' 00:00:00'),1,19),'yyyy-MM-dd hh:mm:ss') - unix_timestamp('{TX_DATE}','yyyy-MM-dd'))<=82800)
					  THEN '12'             --资金帐无数据
				  ELSE '33' END         --其他未知原因 
			,t1.capital_businessTypeName                                                       -- qf 20210717 资金账费用类型
			,t1.capital_settWayName                                                            -- qf 20210717 资金账结算场景   
			,t1.ledger_fee_type                                                                -- qf 20210715 增加台账费用类型
			,t1.ledger_sett_scenes                                                             -- qf 20210715 增加台账结算场景
			,t1.rule_id                                                                        -- qf 0210716 增加规则id        
		FROM (  
				SELECT x1.*,x2.account_type_capital as biz_catg, x2.account_biz_system as biz_system,x2.account_payments as capital_direction 
				FROM 
					(SELECT * FROM dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d
						WHERE dt= '{TX_DATE}'
						AND handle_status_em='0'
						AND diff_status_em = 1 AND COALESCE(ledger_pay_no,'') <> '' AND COALESCE(ledger_trans_amt,0) <> 0 AND COALESCE(ledger_trans_dt,'') <> '' 
					) x1
				LEFT JOIN (SELECT * FROM dmf_dim.dmfdim_gj_hs_fi_hs_dm_busi_bankaccount_zndb_a_d where bus_big_type='000012') x2      
					ON x1.ledger_biz_type = x2.bus_small_type
					   AND nvl(x1.ledger_biz_line,'1') = nvl(x2.biz_line,'1')
					   AND x1.ledger_trans_type = x2.trans_type
					   AND x1.bank_id = x2.bank_account
					   AND nvl(x1.ledger_data_source_em,'1') =nvl(x2.source_sys,'1')
			) t1
		LEFT JOIN dmf_dim.dmfdim_gj_hs_fi_hs_zjz_zndb_detail_a_d t2 --资金帐汇总数据：支付单号 ，银行（concat_ws），资金分类（concat_ws），来源系统 （concat_ws）  
			ON trim(T1.ledger_pay_no) = trim(T2.capital_no)
		LEFT JOIN dmf_dim.dmfdim_gj_hs_fi_hs_bankaccount_fss_new_zndb_a_d t4    --资金帐汇总数据：银行账号，支付单号 ，收支方向，资金分类，金额，来源系统（concat_ws）
			ON T1.ledger_pay_no = T4.capital_no
				AND abs(T1.ledger_trans_amt) = abs(T4.capital_amount)
				AND T1.bank_id = T4.bank_id
				AND T1.biz_catg = T4.biz_catg
				AND T1.capital_direction = cast(int(direction_em)*-1 as string)
		LEFT JOIN dmf_dim.dmfdim_gj_hs_fi_hs_jr_reference_ref_accounts_zndb_a_d t3  --备查系统 
			ON T1.ledger_pay_no = T3.serial_number
			   AND T1.ledger_trans_amt = T3.add_ledger_trans_amt
		LEFT JOIN (SELECT pay_id,change_flag, status,row_number() over(partition by pay_id order by update_dt desc ) rn 
					  FROM dmf_bc.dmfbc_bc_fi_fst_sett_i_d       --TODO 表
					  WHERE dt >= '{TX_PRE_60_DATE}'
						  AND dt <= '{TX_DATE}'
						  --AND status ='1' 
						  and yn_flag='1' 
						  --AND sett_final_time is not null 
						  --AND NVL(sett_final_time,'') !=''
						  AND amount<>0
						  and change_flag !='6'
					  ) t5 
			ON T1.ledger_pay_no =t5.pay_id  AND t5.rn=1;
    """,

}


# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)