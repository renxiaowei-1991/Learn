#!/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner = RUNNER_HIVE


def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()


sql_map = {
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！
    "sql_02":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_02;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
--1.将有资金帐无台账剩余未打标数据进行判断
drop table if exists dmf_tmp.tmp_cw_zjz_tz_data_check_result_collect_i_gyl;
create table dmf_tmp.tmp_cw_zjz_tz_data_check_result_collect_i_gyl as
select  z.origin_id
	 , z.data_source_em
	 , z.bank_id
	 , z.capital_no
	 , z.capital_bus_no
	 , z.capital_bus_time
	 , z.capital_amount
	 , z.capital_biz_system
	 , z.capital_biz_catg
	 , z.capital_pay_type
	 , z.capital_remark
	 , z.capital_currency_code
	 , z.capital_direction_em
	 , z.capital_create_dt
	 , z.capital_data_source_em
	 , z.ledger_bus_time
	 , z.ledger_fund_type
	 , z.ledger_data_source_em
	 , z.ledger_origin_id
	 , z.ledger_serial_no
	 , z.ledger_biz_type
	 , z.ledger_biz_line
	 , z.ledger_product_no
	 , z.ledger_trans_type
	 , z.ledger_company_no1
	 , z.ledger_company_no2
	 , z.ledger_company_no3
	 , z.ledger_company_no4
	 , z.ledger_company_no5
	 , z.ledger_borrow_bank_acct
	 , z.ledger_loan_bank_acct
	 , z.ledger_trans_dt
	 , z.ledger_trans_amt
	 , z.ledger_trans_no
	 , z.ledger_pay_no
	 , z.ledger_loan_no
	 , z.ledger_plan_no
	 , z.ledger_customer_no
	 , z.ledger_merchant_no
	 , z.ledger_section_no
	 , z.ledger_pay_enum
	 , z.ledger_direction
	 , z.ledger_loan_type
	 , z.ledger_create_dt
	 , z.ledger_order_no
	 , z.ledger_project_no
	 , z.join_key
	 , z.handle_status_em
	 , z.create_dt
	 , z.update_dt
	 , z.capital_dt
	 , z.capital_valid
	 , z.capital_op_code
	 , z.oper_user
	 , z.confirm_user
	 , z.oper_id
	 , z.oper_time
	 , z.ledger_spare_no
	 , z.ledger_vir_merchant
	 , z.bus_big_type
	 , z.diff_status_em
	 , z.rematch_dt 
--取支付FG号，因为直接用capital_no不能作为关联条件，需要用资金表中的busfincheckno字段，若busfincheckno为空，则使用capital_no
,case when nvl(split(join_key, '&')[2],'') ='' then capital_no else split(join_key, '&')[2] end as pay_no_fg
from  dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000012_i_d z -- dmf_gj.dmfgj_gj_sf_zjz_tz_no_match_result_000012_i_d z
where  dt = '{TX_DATE}'  -- and result_flag is null 
union all
select  z.origin_id
	 , z.data_source_em
	 , z.bank_id
	 , z.capital_no
	 , z.capital_bus_no
	 , z.capital_bus_time
	 , z.capital_amount
	 , z.capital_biz_system
	 , z.capital_biz_catg
	 , z.capital_pay_type
	 , z.capital_remark
	 , z.capital_currency_code
	 , z.capital_direction_em
	 , z.capital_create_dt
	 , z.capital_data_source_em
	 , z.ledger_bus_time
	 , z.ledger_fund_type
	 , z.ledger_data_source_em
	 , z.ledger_origin_id
	 , z.ledger_serial_no
	 , z.ledger_biz_type
	 , z.ledger_biz_line
	 , z.ledger_product_no
	 , z.ledger_trans_type
	 , z.ledger_company_no1
	 , z.ledger_company_no2
	 , z.ledger_company_no3
	 , z.ledger_company_no4
	 , z.ledger_company_no5
	 , z.ledger_borrow_bank_acct
	 , z.ledger_loan_bank_acct
	 , z.ledger_trans_dt
	 , z.ledger_trans_amt
	 , z.ledger_trans_no
	 , z.ledger_pay_no
	 , z.ledger_loan_no
	 , z.ledger_plan_no
	 , z.ledger_customer_no
	 , z.ledger_merchant_no
	 , z.ledger_section_no
	 , z.ledger_pay_enum
	 , z.ledger_direction
	 , z.ledger_loan_type
	 , z.ledger_create_dt
	 , z.ledger_order_no
	 , z.ledger_project_no
	 , z.join_key
	 , z.handle_status_em
	 , z.create_dt
	 , z.update_dt
	 , z.capital_dt
	 , z.capital_valid
	 , z.capital_op_code
	 , z.oper_user
	 , z.confirm_user
	 , z.oper_id
	 , z.oper_time
	 , z.ledger_spare_no
	 , z.ledger_vir_merchant
	 , z.bus_big_type
	 , z.diff_status_em
	 , z.rematch_dt 
--取支付FG号，因为直接用capital_no不能作为关联条件，需要用资金表中的busfincheckno字段，若busfincheckno为空，则使用capital_no
  ,capital_no as pay_no_fg
from  -- dmf_gj.dmfgj_gj_sf_zjz_tz_no_match_result_000004_i_d z
dmf_gj.dmfgj_gj_sf_fi_hs_tz_data_check_result_000004_i_d z
where  dt = '{TX_DATE}' -- and result_flag is null 
;
""",
    "sql_03":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_03;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
--2创建临时表
--2.1 业财对账未配置数据
drop table if exists dmf_tmp.tmp_cw_zjz_tz_data_nomatch_nobank;
create table dmf_tmp.tmp_cw_zjz_tz_data_nomatch_nobank as
SELECT
	--a1.origin_id,
	a1.ledger_data_source_em,
	a1.ledger_biz_type,
--	a1.ledger_borrow_bank_acct,
	--a1.ledger_loan_bank_acct,
    a1.ledger_bank_acct, 
	a1.ledger_trans_dt,
	--对于同一还款单号还多个贷款单的数据，汇总为一条
	sum(a1.ledger_trans_amt) as ledger_trans_amt,
	a1.ledger_pay_no,
	a2.buss_link_code,
	a3.buss_link_name
	--a3.type
 from 
 ( SELECT 
  amt_modfr2 as ledger_biz_type,
  amt_modfr3  as ledger_trans_type,
  amt_modfr4 as ledger_data_source_em,
  data_dt as ledger_trans_dt,
  amt_typ as ledger_bank_acct,
  dat_key4 as ledger_pay_no,
  nval as ledger_trans_amt
  FROM 
       (
        select * from dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000012_i_d WHERE dt >= '{TX_PRE_30_DATE}'   AND  biz_type in ('000012','000004') and sys='nom' 
           union all
        select * from dmf_tmp.dmftmp_gj_sf_fi_hs_ycdz_data_collect_000004_i_d WHERE dt >= '{TX_PRE_30_DATE}'   AND  biz_type in ('000012','000004') and sys='nom' 
        ) x
		
 ) a1 --不参与业财对账的数据
INNER JOIN (
            SELECT data_source_em AS source_sys
                  ,trans_type_enum_code AS code
                  ,trans_type
                  ,bus_big_type
                  ,bus_small_type
                  ,biz_line
                  ,buss_link_code
                  ,buss_link_name 
            FROM dmf_bc.dmfbc_gj_hs_ac_trans_rules_filter_detail_s_d
            WHERE dt='{TX_DATE}'
--20220513 chengsong7 切换至原有的维表模型
--SELECT
--	t1.source_sys,
--	t1.CODE,
--	t1.trans_type,
--	t1.bus_big_type,
--	t1.bus_small_type,
--	t1.biz_line,
--	t1.BUSS_LINK_CODE,
--	t2.codeName AS BUSS_LINK_NAME 
--FROM
--	-- caiwu_orig.a_recpayable1_dm_bus_enum_config t1
--	(
--	select *
--    from (select *, row_number() over(partition by id order by update_time desc) as rn
--          from odm.odm_fi_tz_dm_bus_enum_config_i_d
--         where dt <= '{TX_DATE}'
--		) x
--   where x.rn = 1
--	) t1
--	LEFT JOIN ( SELECT 
--	            codeName,CODE
--	            FROM odm.odm_fi_dm_ysyf_enums_s_d -- caiwu_orig.a_recpayable1_dm_ysyf_enums 
--                WHERE type = 170 and dt='{TX_DATE}') t2 
--                ON t1.BUSS_LINK_CODE = t2.CODE 
--WHERE
--	bus_big_type in( '000012' ,'000004' )
--	AND STATUS = 1 
) a2  --利用交易环节和来源系统，关联了match表中数据的摘要信息
ON a1.ledger_trans_type = a2.trans_type 
   AND a1.ledger_data_source_em = a2.source_sys
   and a1.ledger_biz_type=a2.bus_small_type
inner JOIN (
             SELECT distinct bus_small_type,buss_link_name 
             from dmf_dim.dmfdim_gj_hs_dm_busi_bankaccount_config_s_d  
             where dt='{TX_DATE}' and bus_big_type in('000012' ,'000004' )
--20220513 chengsong7 切换至原有的维表模型
--SELECT
----	t1.bank_account,
----	t1.account_type_capital,
----	t1.account_payments,
--	t2.bus_small_type,
--	t2.buss_link_name,
--	t2.type 
--FROM
--	( SELECT id,STATUS 
--	  FROM -- dmf_bc.dmfbc_mix_odm_fi_hs_dm_busi_bankaccount_h_d 
--	     (select *
--          from (select *, row_number() over(partition by id order by update_time desc) as rn
--                  from odm.odm_fi_hs_dm_busi_bankaccount_i_d 
--                 where dt <= '{TX_DATE}'
--		            ) x
--         where x.rn = 1
--       ) y
--	) t1
--	LEFT JOIN ( SELECT 
--	            fid,
--	            STATUS,
--	            bus_small_type,
--	            buss_link_name,
--	            type,
--	            bus_big_type
--	             FROM  (select *, row_number() over(partition by fid order by update_time desc) as rn
--                  from odm.odm_fi_tz_dm_busi_bankaccount_detail_i_d
--                 where dt <= '{TX_DATE}'
--		            ) t
--                    where rn =1
--              
-- ) t2 
--WHERE
--	t1.id = t2.fid 
--	AND t1.STATUS = 0 
--	AND t2.STATUS = 0 
--	AND t2.bus_big_type in('000012' ,'000004' )
--group by 
--	t2.bus_small_type,
--	t2.buss_link_name,
--	t2.type 
) a3  --a3为业财配置表中已配置摘要信息， 关联得出摘要配置过业财对账信息的match表中不参与对账的数据，则这部分数据，就是银行账户未配置业财对账
ON a2.BUSS_LINK_name = a3.buss_link_name
group by --a1.origin_id,
	a1.ledger_data_source_em,
	a1.ledger_biz_type,
	--a1.ledger_borrow_bank_acct,
	--a1.ledger_loan_bank_acct,
	a1.ledger_bank_acct,
	a1.ledger_trans_dt,
	a1.ledger_pay_no,
    a2.buss_link_code,
	a3.buss_link_name
	--a3.type
;
""",
    "sql_04":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_04;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
 
--2.2 包含两部分数据：保理结算单还款 和 其它银行不一致的数据(具体原因待查询后确认)
--目前对于结算单还款和主动还款场景的主体简码及FG流水号没有落库，集市取数源自于产品配置信息，因此在途或产品配置变更无法取到；
drop table if exists dmf_tmp.tmp_cw_zjz_tz_data_nomatch_diffbank;
create table dmf_tmp.tmp_cw_zjz_tz_data_nomatch_diffbank as
SELECT distinct 
	a1.data_source_em,
	a1.ledger_biz_type,
	a1.ledger_bank_acct, 
	a1.ledger_trans_amt,
	a1.ledger_pay_no,
	a1.ledger_trans_type,
	concat(a2.busi_type,'_',a2.money_type) as money_type
FROM
	( select 
	   data_source_em,
	   ledger_biz_type,
	   bank_id as ledger_bank_acct,
	   ledger_trans_amt,
	   ledger_pay_no,
	   ledger_trans_type	   
	  from dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000012_i_d -- dmf_chk.dmfchk_gj_sf_gj_busi_bankaccount_ycdz_fail_000012_i_d 
          WHERE dt >= '{TX_PRE_30_DATE}'   --限制这个时间是为了避免已手工处理过的数据
          and diff_status_em = '1'
 union all 
    select 
	   data_source_em,
	   ledger_biz_type,
	   bank_id as ledger_bank_acct,
	   ledger_trans_amt,
	   ledger_pay_no,
	   ledger_trans_type	   
	  from -- dmf_chk.dmfchk_gj_sf_gj_busi_bankaccount_ycdz_fail_000004_i_d 
	      dmf_gj.dmfgj_gj_sf_fi_hs_busi_bankaccount_ycdz_fail_000004_i_d
          WHERE dt >= '{TX_PRE_30_DATE}' 
          and diff_status_em = '1'
            ) a1 --有台账无资金账数据
	LEFT JOIN 
	( 	select distinct
	    pay_no,
	    busi_type,
	    money_type
	    from dmf_bc.dmfbc_gj_sf_fi_hs_m02_transaction_cl_finl_i_d --dmf_bc.dmfbc_gj_sf_fi_hs_m02_transaction_cl_i_d -- dmf_gj.dmfgj_gj_sf_gyl_m02_transaction_cl_i_d 	
	WHERE dt >= '{TX_PRE_30_DATE}'   and busi_type='repay' and  money_type='balance' 
	) a2
	on a1.ledger_pay_no=a2.pay_no ;
""",
    "sql_05":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_05;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
--2.3 退票的数据	
--资金账退票数据汇总，取数条件：同一个银行流言号，有2条以上的数据，金额相同且收支方向相反
drop table if exists dmf_tmp.tmp_cw_zjz_tz_data_nomatch_tp;
create table dmf_tmp.tmp_cw_zjz_tz_data_nomatch_tp as
select 
pay_no
,pay_amount
,relation_no
,count(1) as cnt
,sum(direction_em) as direction_em
from (
    SELECT * 
    FROM 
    (
    select * ,row_number() over (partition by origin_id order by update_dt desc) as rn
    from dmf_bc.dmfbc_bc_fi_m07_cap_data_i_d WHERE dt>='{TX_PRE_35_DATE}' 
    ) t 
    WHERE rn = 1 and COALESCE(valid,'1')='1' --正常资金帐
) m
group by pay_no,pay_amount,relation_no	
having count(1)>=2 and sum(direction_em)=0;
""",
    "sql_06":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_06;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
  
	
--2.4 交易流水表中取近30天所有数据
DROP TABLE IF EXISTS dmf_tmp.tmp_gyl_cl_data_source_em_list_ycdz;
CREATE TABLE IF NOT EXISTS dmf_tmp.tmp_gyl_cl_data_source_em_list_ycdz 
AS
SELECT t1.data_source_em 
FROM dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d t 
LATERAL VIEW dmf_bc.dmbiztype('000012') t1 AS data_source_em
union  
SELECT t1.data_source_em 
FROM dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d t 
LATERAL VIEW dmf_bc.dmbiztype('000004') t1 AS data_source_em;
""",
    "sql_07":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_07;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
drop table if exists dmf_tmp.tmp_cw_zjz_tz_data_nomatch_payno_all;
create table dmf_tmp.tmp_cw_zjz_tz_data_nomatch_payno_all as	
select 	pay_no,trans_dt,sum(trans_amt) as trans_amt from (
  --核心台账
	select pay_no,to_date(trans_dt) as trans_dt ,trans_amt from dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_000012_i_d -- dmf_gj.dmfgj_gj_hs_gj_transaction_detail_i_d  
	where  dt >= '{TX_PRE_30_DATE}'  
	and  data_source_em in  (select data_source_em  from dmf_tmp.tmp_gyl_cl_data_source_em_list_ycdz)
)m
group by pay_no,trans_dt;
""",
    "sql_08":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_08;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
set hive.execution.engine=tez;
use dmf_tmp;
      
--3 汇总临时表并关联有资金账无台账的数据
drop table if exists dmf_tmp.tmp_zjz_gyl_payno_list;
create table  dmf_tmp.tmp_zjz_gyl_payno_list as  
select 
 t1.origin_id                  
,t1.data_source_em             
,t1.bank_id                    
,t1.capital_no                 
,t1.capital_bus_no             
,t1.capital_bus_time           
,t1.capital_amount             
,t1.capital_biz_system         
,t1.capital_biz_catg           
,t1.capital_pay_type           
,t1.capital_remark             
,t1.capital_currency_code      
,t1.capital_direction_em 
,t1.capital_create_dt      
,t1.capital_data_source_em     
,t1.ledger_bus_time            
,t1.ledger_fund_type           
,t1.ledger_data_source_em      
,t1.ledger_origin_id           
,t1.ledger_serial_no           
,t1.ledger_biz_type            
,t1.ledger_biz_line            
,t1.ledger_product_no          
,t1.ledger_trans_type          
,t1.ledger_company_no1         
,t1.ledger_company_no2         
,t1.ledger_company_no3         
,t1.ledger_company_no4         
,t1.ledger_company_no5         
,t1.ledger_borrow_bank_acct    
,t1.ledger_loan_bank_acct      
,t1.ledger_trans_dt            
,t1.ledger_trans_amt           
,t1.ledger_trans_no            
,t1.ledger_pay_no              
,t1.ledger_loan_no             
,t1.ledger_plan_no             
,t1.ledger_customer_no         
,t1.ledger_merchant_no         
,t1.ledger_section_no          
,t1.ledger_pay_enum            
,t1.ledger_direction           
,t1.ledger_loan_type           
,t1.ledger_create_dt           
,t1.ledger_order_no            
,t1.ledger_project_no          
,t1.join_key                   
,t1.handle_status_em           
,t1.create_dt                  
,t1.update_dt                  
,t1.capital_dt                 
,t1.capital_valid              
,t1.capital_op_code            
,t1.oper_user                  
,t1.confirm_user               
,t1.oper_id                    
,t1.oper_time                  
,t1.ledger_spare_no            
,t1.ledger_vir_merchant                                 
,t1.bus_big_type  
,t1.diff_status_em  
--取支付FG号
,t1.rematch_dt
,t1.pay_no_fg
,t2.ledger_bank_acct as ledger_bank_acct_nobank
,t2.ledger_trans_amt as ledger_trans_amt_nobank
,t2.ledger_trans_dt as ledger_trans_dt_nobank
,t3.ledger_bank_acct as ledger_bank_acct_diffbank
,t3.ledger_trans_amt as ledger_trans_amt_diffbank
,t3.money_type 
,t4.pay_no as pay_no_tp
,t4.pay_amount as pay_amount_tp
,t5.pay_no as pay_no_ywxt
,t5.trans_amt as trans_amt_ywxt
,t5.trans_dt as trans_dt_ywxt
from  dmf_tmp.tmp_cw_zjz_tz_data_check_result_collect_i_gyl t1
--t2表中为未配置业财对账的数据
left join  dmf_tmp.tmp_cw_zjz_tz_data_nomatch_nobank  t2
on t1.pay_no_fg = t2.ledger_pay_no and t1.capital_amount =t2.ledger_trans_amt
--t3表为保理结算单还款中银行账户不准确的数据
left join dmf_tmp.tmp_cw_zjz_tz_data_nomatch_diffbank t3
on t1.pay_no_fg= t3.ledger_pay_no and t1.capital_amount =t3.ledger_trans_amt
--t4表为退票的数据
left join  dmf_tmp.tmp_cw_zjz_tz_data_nomatch_tp t4
on  t1.capital_no=t4.pay_no
--t5表为所有业务数据的汇总表，用于判断这条数据是否从业务数据取到了
left join dmf_tmp.tmp_cw_zjz_tz_data_nomatch_payno_all	 t5 
on t1.pay_no_fg = t5.pay_no ;
""",
    "sql_09":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_09;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_tmp;
      
--4 判断
drop table if exists dmf_tmp.tmp_zjz_gyl_payno_list_flag;
create table  dmf_tmp.tmp_zjz_gyl_payno_list_flag as  
select 
 origin_id                  
,data_source_em             
,bank_id                    
,capital_no                 
,capital_bus_no             
,capital_bus_time           
,capital_amount             
,capital_biz_system         
,capital_biz_catg           
,capital_pay_type           
,capital_remark             
,capital_currency_code      
,capital_direction_em 
,capital_create_dt      
,capital_data_source_em     
,ledger_bus_time            
,ledger_fund_type           
,ledger_data_source_em      
,ledger_origin_id           
,ledger_serial_no           
,ledger_biz_type            
,ledger_biz_line            
,ledger_product_no          
,ledger_trans_type          
,ledger_company_no1         
,ledger_company_no2         
,ledger_company_no3         
,ledger_company_no4         
,ledger_company_no5         
,ledger_borrow_bank_acct    
,ledger_loan_bank_acct      
,ledger_trans_dt            
,ledger_trans_amt           
,ledger_trans_no            
,ledger_pay_no              
,ledger_loan_no             
,ledger_plan_no             
,ledger_customer_no         
,ledger_merchant_no         
,ledger_section_no          
,ledger_pay_enum            
,ledger_direction           
,ledger_loan_type           
,ledger_create_dt           
,ledger_order_no            
,ledger_project_no          
,join_key                   
,handle_status_em           
,create_dt                  
,update_dt                  
,capital_dt                 
,capital_valid              
,capital_op_code            
,oper_user                  
,confirm_user               
,oper_id                    
,oper_time                  
,ledger_spare_no            
,ledger_vir_merchant                                 
,bus_big_type  
,diff_status_em
,rematch_dt   
--银行账号未配置业财对账
,case 
when capital_biz_catg in ('4838','4775') and  
           (
            instr(capital_remark,'1000036')>0  
        or  instr(capital_remark,'1000040')>0  
        or  instr(capital_remark,'1000041')>0 
        or  instr(capital_remark,'1000043')>0 ) then '0000120009'
when bank_id=ledger_bank_acct_nobank then '0000120001'
--保理结算单还款按产品和客户取到的银行账号不准确
when bank_id<>ledger_bank_acct_diffbank and  money_type='repay_balance' then '0000120002'
--银行账号不一致-其它原因
when bank_id<>ledger_bank_acct_diffbank and  money_type is NULL  then '0000120003'
--业财对账配置错误
when bank_id=ledger_bank_acct_diffbank   then'0000120004'
--订单池业务系统-华为小米没有切入新台账
when  capital_biz_system='79'	and ( capital_remark like '%华为终端有限公司%' or  capital_remark like  '%小米通讯技术有限公司%') then '0000120005'
--退票
when pay_no_tp is not null  and  capital_remark not like '%02055%'  then '0000120006'
--业务系统有，但未集成
when pay_no_ywxt is not null and capital_remark  like '%02055%' then '0000120011'
--业务系统有，但未集成
when pay_no_ywxt is not null then '0000120008'
--业务系统无数据
when pay_no_ywxt is null then '0000120007'
else '0000120010'   end 
as result_flag
from  dmf_tmp.tmp_zjz_gyl_payno_list ;
""",
    "sql_10":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_10;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_bc;
      
alter table dmf_bc.dmfbc_gj_sf_zjz_tz_data_check_result_collect_gyl_i_d drop  partition (dt = '{TX_DATE}' ,data_source='zjz_tz_money_no_gyl');
""",
    "sql_11":
    """
set mapred.job.name=job_sdm_gj_tz_data_check_match_i_gyl_11;
set mapred.max.split.size=64000000;
set hive.stats.column.autogather=false;
use dmf_bc;
      


alter table dmf_bc.dmfbc_gj_sf_zjz_tz_data_check_result_collect_gyl_i_d drop  partition (dt <= '{TX_PRE_40_DATE}' ,data_source='zjz_tz_money_no_gyl');
insert into dmf_bc.dmfbc_gj_sf_zjz_tz_data_check_result_collect_gyl_i_d partition (dt = '{TX_DATE}' ,data_source='zjz_tz_money_no_gyl') 
select 
 origin_id                  
,data_source_em             
,bank_id                    
,capital_no                 
,capital_bus_no             
,capital_bus_time           
,capital_amount             
,capital_biz_system         
,capital_biz_catg           
,capital_pay_type           
,capital_remark             
,capital_currency_code      
,capital_direction_em 
,capital_create_dt      
,capital_data_source_em     
,ledger_bus_time            
,ledger_fund_type           
,ledger_data_source_em      
,ledger_origin_id           
,ledger_serial_no           
,ledger_biz_type            
,ledger_biz_line            
,ledger_product_no          
,ledger_trans_type          
,ledger_company_no1         
,ledger_company_no2         
,ledger_company_no3         
,ledger_company_no4         
,ledger_company_no5         
,ledger_borrow_bank_acct    
,ledger_loan_bank_acct      
,ledger_trans_dt            
,ledger_trans_amt           
,ledger_trans_no            
,ledger_pay_no              
,ledger_loan_no             
,ledger_plan_no             
,ledger_customer_no         
,ledger_merchant_no         
,ledger_section_no          
,ledger_pay_enum            
,ledger_direction           
,ledger_loan_type   
,ledger_create_dt
,ledger_order_no            
,ledger_project_no          
,join_key                   
,handle_status_em           
,create_dt                  
,update_dt                  
,capital_dt                 
,capital_valid              
,capital_op_code            
,oper_user                  
,confirm_user               
,oper_id                    
,oper_time                  
,ledger_spare_no            
,ledger_vir_merchant                                 
,bus_big_type  
,diff_status_em 
,result_flag
,rematch_dt
from   dmf_tmp.tmp_zjz_gyl_payno_list_flag ;
""",
}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)
