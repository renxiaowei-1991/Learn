#!/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
from datetime import datetime
import os
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE

#=====================================================自定义 start===========================================#
#获取月初日期
def get_month_start(in_date):
    in_year,in_month,in_day = str(in_date).split('-')
    
    out_year = in_year
    out_month = in_month
    out_day = "01"
    
    list_date = [out_year,out_month,out_day]
    #split_str = "-"
    out_date = "-".join(list_date)

    return out_date
    
    
#当前日期加减n月
def get_add_months(in_date,num):
    in_year,in_month,in_day = str(in_date).split('-')
    
    #print(in_year,in_month,in_day)
    
    if (int(in_month)+num) % 12 == 0 :
        out_year = str(int(in_year) + (int(in_month)+num) / 12 - 1)
        out_month = str("12")
    else :
        out_year = str(int(in_year) + (int(in_month)+num) / 12)
        out_month = str((int(in_month)+num) % 12).zfill(2) #月份补齐两位
        
    out_day = in_day
    
    #print(out_year,out_month,out_day)
    
    list_date = [out_year,out_month,out_day]
    #split_str = "-"
    out_date = "-".join(list_date)
    
    return out_date

#运行时环境
get_run_date = SqlTask()
#获取脚本参数
run_date = get_run_date._tx_date
print("run_date:" + run_date)

#获取系统时间
today = Time.today()
#获取系统自动运行时间
tx_pre_01_date = Time.date_sub(date=today, itv=1)
print("tx_pre_01_date:" + tx_pre_01_date)

#日期判断:获取分区操作开始日期
#如果是1-3号，则刷新上月2号到当前日期
if int(tx_pre_01_date.split('-')[2])<4 :
    start_date = Time.date_sub(date=get_month_start(get_add_months(tx_pre_01_date,-1)), itv=-1)
else :
    start_date = run_date
    
print("start_date:" + start_date)
#=====================================================自定义 end===========================================#

#平台函数
def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_01_DATE = Time.date_sub(date=today, itv=1)
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    
    #按月重跑开始日期，用于删除分区
    START_DATE = start_date
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！


#当月增量
#1、1-3号，支持自动刷上月数据
#2、其它日期，支持每天跑当天数据
#3、支持手工指定日期一次刷之后全部数据
"sql_020": """
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_01;
create table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_01
as
select     id,all_cols,change_code_cols
          ,dmf_bc.getmd5(src_tab,id) as joinkey
          ,dmf_bc.getmd5(change_code_cols) as change_code
          ,dt,src_tab
from (
    select     split(origin_id,'_')[0] as id
              ,concat(decode(unhex('7B'),'UTF-8'),concat_ws(','
                   ,concat('"trade_date"'      ,':"',nvl(trade_date      ,''),'"')
                   ,concat('"trade_category"'  ,':"',nvl(trade_category  ,''),'"')
                   ,concat('"mer_id"'          ,':"',nvl(mer_id          ,''),'"')
                   ,concat('"mer_name"'        ,':"',nvl(mer_name        ,''),'"')
                   ,concat('"trade_type"'      ,':"',nvl(trade_type      ,''),'"')
                   ,concat('"pay_tools"'       ,':"',nvl(pay_tools       ,''),'"')
                   ,concat('"card_type"'       ,':"',nvl(card_type       ,''),'"')
                   ,concat('"bank_mer_id"'     ,':"',nvl(bank_mer_id     ,''),'"')
                   ,concat('"order_amt"'       ,':"',nvl(order_amt       ,0 ),'"')
                   ,concat('"trade_amt"'       ,':"',nvl(trans_amt       ,0 ),'"')
                   ,concat('"mer_fee"'         ,':"',nvl(mer_fee         ,0 ),'"')
                   ,concat('"bank_fee"'        ,':"',nvl(bank_fee        ,0 ),'"')
                   ,concat('"cal_cost"'        ,':"',nvl(cal_cost        ,0 ),'"')
                   ,concat('"real_pay_fee"'    ,':"',nvl(real_pay_fee    ,0 ),'"')
                   ,concat('"chazhi"'          ,':"',nvl(chazhi          ,0 ),'"')
                   ,concat('"product_id"'      ,':"',nvl(product_id      ,''),'"')
                   ,concat('"created_date"'    ,':"',nvl(created_date    ,''),'"')
                   ,concat('"modified_date"'   ,':"',nvl(modified_date   ,''),'"')
                   ,concat('"owner"'           ,':"',nvl(owner           ,''),'"')
                   ,concat('"ou"'              ,':"',nvl(ou              ,''),'"')
                   ,concat('"send_bank_code"'  ,':"',nvl(send_bank_code  ,''),'"')
                   ,concat('"jindie_name"'     ,':"',nvl(jindie_name     ,''),'"')
                   ,concat('"ebs_biz_line_nm"' ,':"',nvl(ebs_biz_line_nm ,''),'"')
                   ,concat('"ebs_biz_line_id"' ,':"',nvl(ebs_biz_line_id ,''),'"')
                   ,concat('"ks_bank_mer_id"'  ,':"',nvl(ks_bank_mer_id  ,''),'"')
                   ,concat('"ks_ou"'           ,':"',nvl(ks_ou           ,''),'"')
                   ,concat('"ks_mer_id"'       ,':"',nvl(ks_mer_id       ,''),'"')
                   ,concat('"ks_jindie_name"'  ,':"',nvl(ks_jindie_name  ,''),'"')
               ),decode(unhex('7D'),'UTF-8')) as all_cols
              ,case when source = 'result'  --入账明细表
                    then concat(decode(unhex('7B'),'UTF-8'),concat_ws(','
                             ,concat('"trade_date"'      ,':"',nvl(trade_date      ,''),'"')
                             ,concat('"trade_category"'  ,':"',nvl(trade_category  ,''),'"')
                             ,concat('"mer_id"'          ,':"',nvl(mer_id          ,''),'"')
                             ,concat('"mer_name"'        ,':"',nvl(mer_name        ,''),'"')
                             ,concat('"trade_type"'      ,':"',nvl(trade_type      ,''),'"')
                             ,concat('"pay_tools"'       ,':"',nvl(pay_tools       ,''),'"')
                             ,concat('"card_type"'       ,':"',nvl(card_type       ,''),'"')
                             ,concat('"bank_mer_id"'     ,':"',nvl(bank_mer_id     ,''),'"')
                             ,concat('"order_amt"'       ,':"',nvl(order_amt       ,0 ),'"')
                             ,concat('"trade_amt"'       ,':"',nvl(trans_amt       ,0 ),'"')
                             ,concat('"mer_fee"'         ,':"',nvl(mer_fee         ,0 ),'"')
                             ,concat('"bank_fee"'        ,':"',nvl(bank_fee        ,0 ),'"')
                             ,concat('"cal_cost"'        ,':"',nvl(cal_cost        ,0 ),'"')
                             ,concat('"product_id"'      ,':"',nvl(product_id      ,''),'"')
                             ,concat('"created_date"'    ,':"',nvl(created_date    ,''),'"')
                             ,concat('"owner"'           ,':"',nvl(owner           ,''),'"')
                             ,concat('"ou"'              ,':"',nvl(ou              ,''),'"')
                             ,concat('"send_bank_code"'  ,':"',nvl(send_bank_code  ,''),'"')
                             ,concat('"ebs_biz_line_nm"' ,':"',nvl(ebs_biz_line_nm ,''),'"')
                             ,concat('"ebs_biz_line_id"' ,':"',nvl(ebs_biz_line_id ,''),'"')
                             ,concat('"ks_bank_mer_id"'  ,':"',nvl(ks_bank_mer_id  ,''),'"')
                             ,concat('"ks_ou"'           ,':"',nvl(ks_ou           ,''),'"')
                         ),decode(unhex('7D'),'UTF-8'))
                    when source = 'report'  --全款结算报表
                    then concat(decode(unhex('7B'),'UTF-8'),concat_ws(','
                             ,concat('"mer_id"'          ,':"',nvl(mer_id          ,''),'"')
                             ,concat('"mer_name"'        ,':"',nvl(mer_name        ,''),'"')
                             ,concat('"trade_category"'  ,':"',nvl(trade_category  ,''),'"')
                             ,concat('"pay_tools"'       ,':"',nvl(pay_tools       ,''),'"')
                             ,concat('"card_type"'       ,':"',nvl(card_type       ,''),'"')
                             ,concat('"trade_amt"'       ,':"',nvl(trans_amt       ,0 ),'"')
                             ,concat('"mer_fee"'         ,':"',nvl(mer_fee         ,0 ),'"')
                             ,concat('"created_date"'    ,':"',nvl(created_date    ,''),'"')
                             ,concat('"trade_date"'      ,':"',nvl(trade_date      ,''),'"')
                             ,concat('"ebs_biz_line_nm"' ,':"',nvl(ebs_biz_line_nm ,''),'"')
                             ,concat('"ebs_biz_line_id"' ,':"',nvl(ebs_biz_line_id ,''),'"')
                             ,concat('"ks_mer_id"'       ,':"',nvl(ks_mer_id       ,''),'"')
                         ),decode(unhex('7D'),'UTF-8'))
                    when source = 'recon_tc'  --成本分摊表
                    then concat(decode(unhex('7B'),'UTF-8'),concat_ws(','
                             ,concat('"jindie_name"'     ,':"',nvl(jindie_name     ,''),'"')
                             ,concat('"pay_tools"'       ,':"',nvl(pay_tools       ,''),'"')
                             ,concat('"bank_mer_id"'     ,':"',nvl(bank_mer_id     ,''),'"')
                             ,concat('"send_bank_code"'  ,':"',nvl(send_bank_code  ,''),'"')
                             ,concat('"card_type"'       ,':"',nvl(card_type       ,''),'"')
                             ,concat('"real_pay_fee"'    ,':"',nvl(real_pay_fee    ,0 ),'"')
                             ,concat('"trade_date"'      ,':"',nvl(trade_date      ,''),'"')
                             ,concat('"chazhi"'          ,':"',nvl(chazhi          ,0 ),'"')
                             ,concat('"created_date"'    ,':"',nvl(created_date    ,''),'"')
                             ,concat('"ebs_biz_line_nm"' ,':"',nvl(ebs_biz_line_nm ,''),'"')
                             ,concat('"ebs_biz_line_id"' ,':"',nvl(ebs_biz_line_id ,''),'"')
                             ,concat('"ks_jindie_name"'  ,':"',nvl(ks_jindie_name  ,''),'"')
                         ),decode(unhex('7D'),'UTF-8'))
               end as change_code_cols
              ,dt
              ,case when source = 'result' then 'odm_pay_sis_account_result_i_d'
                    when source = 'report' then 'odm_pay_sis_fi_sis_gross_settle_report_i_d'
                    when source = 'recon_tc' then 'odm_fi_hs_tc_detail_i_d'
               end as src_tab
    from dmf_bc.dmf_jdt_dmfbc_pay_i_det_d
    where dt >= '{START_DATE}'
      and source in ('result','report','recon_tc')
      and not (source='recon_tc' and dt='2023-08-11')
) t1
;
""",

#历史数据中涉及冲销部分
#Modified by renxiaowei7@20220804
#  直接取历史数据中增量数据涉及到的最新一笔joinkey即可
"sql_030": """
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_02;
create table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_02
as
select a2.*,row_number() over(partition by a2.joinkey order by a2.dt desc) as rank
from (select distinct joinkey
      from dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_01
     ) a1
inner join  dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d a2
        on  a2.dt < '{START_DATE}' and a2.data_type = '1'
       and  a1.joinkey = a2.joinkey
;
""",


"sql_040": """
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_04;
create table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_04
as
with dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_03
as (
    select *,row_number() over(partition by joinkey order by dt) as rank
    from (
        --增量数据
        select id,all_cols,change_code_cols,joinkey,change_code,dt,src_tab 
        from dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_01
        union all 
        --历史数据
        select id,all_cols,change_code_cols,joinkey,change_code,dt,src_tab
        from dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_02
        where rank = 1
    ) a1
)
select *,row_number() over(partition by joinkey order by dt) as rank
from (
    select a1.id, a1.all_cols, a1.change_code_cols, a1.joinkey, a1.change_code, a1.dt, a1.src_tab 
    from   dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_03 a1 
    left join  dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_03 a2
           on  a1.joinkey = a2.joinkey
          and  a1.rank = a2.rank + 1
        where  a1.change_code != a2.change_code
           or  a2.joinkey is null
) b
;
""",


#目标表-临时表-增量数据
"sql_050": """
set hive.auto.convert.join=false;
use dmf_tmp;

alter table dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d drop partition(dt >= '{START_DATE}');
from  dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_04 a1
left join  dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_json_i_d_04 a2
       on  a1.joinkey = a2.joinkey
      and  a1.rank = a2.rank + 1
insert overwrite table dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d partition(dt,src_tab,data_type)
select a1.id,a1.all_cols,a1.change_code_cols,a1.joinkey,a1.change_code,a1.dt as src_dt,a1.dt,a1.src_tab,'1' as data_type
where  a1.rank > 1 or (a1.rank = 1 and a1.dt >= '{START_DATE}')
--1、金额字段这里先不取反，比较麻烦
--2、dt需要取主表的dt
insert overwrite table dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d partition(dt,src_tab,data_type)
select a2.id,a2.all_cols,a2.change_code_cols,a2.joinkey,a2.change_code,a2.dt as src_dt,a1.dt,a2.src_tab,'2' as data_type
where  a1.rank > 1
;
""",

#入账明细表
"sql_060": """
use dmf_tmp;

alter table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d drop partition(dt >= '{START_DATE}' ,source='result');
insert overwrite table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d PARTITION (dt,source)
select     res.id                        as id
          ,res.trade_date                as trade_date
          ,res.trade_category            as trade_category
          ,res.bank_mer_id               as bank_mer_id
          ,res.mer_id                    as mer_id
          ,res.mer_name                  as mer_name
          ,res.trade_type                as trade_type
          ,res.pay_tools                 as pay_tools
          ,res.card_type                 as card_type
          ,cast(res.order_amt as double)/if(src_dt<'2023-08-01',100,1) as order_amt
          ,cast(res.trade_amt as double)/if(src_dt<'2023-08-01',100,1) as trade_amt
          ,cast(res.mer_fee   as double)/if(src_dt<'2023-08-01',100,1) as mer_fee
          ,cast(res.bank_fee  as double)/if(src_dt<'2023-08-01',100,1) as bank_fee
          ,cast(res.cal_cost  as double)/if(src_dt<'2023-08-01',100,1) as cal_cost
          ,0                             as trade_num
          ,0                             as real_pay_fee
          ,0                             as chazhi
          ,''                            as jindie_name
          ,res.send_bank_code            as send_bank_code
          ,res.owner                     as owner
          ,res.ou                        as ou
          ,res.product_id                as product_id
          ,res.created_date              as created_date
          ,res.modified_date             as modified_date
          ,res.ks_bank_mer_id            as ks_bank_mer_id  --存放类型为bank_mer_id 的金蝶编码
          ,res.ks_ou                     as ks_ou           --存放类型为ou 的金蝶编码
          ,''                            as ks_mer_id       --存放类型为mer_id 的金蝶编码
          ,''                            as exit_1
          ,''                            as exit_2
          ,res.src_tab                   as source_table
          ,''                            as ks_jindie_name
          ,res.joinkey                   as joinkey
          ,res.change_code               as change_code
          ,res.data_type                 as data_type
          ,res.src_dt                    as src_dt
          ,res.ebs_biz_line_nm           as ebs_biz_line_nm
          ,res.ebs_biz_line_id           as ebs_biz_line_id
          ,res.dt                        as dt
          ,'result'                      as source
from (
    select  a1.*,a2.*
    from dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d a1
    lateral view json_tuple(all_cols,'trade_date','trade_category','mer_id','mer_name','trade_type','pay_tools','card_type','bank_mer_id','order_amt','trade_amt','mer_fee','bank_fee','cal_cost','product_id','created_date','modified_date','owner','ou','send_bank_code','ebs_biz_line_nm','ebs_biz_line_id','ks_bank_mer_id','ks_ou') a2
    as trade_date,trade_category,mer_id,mer_name,trade_type,pay_tools,card_type,bank_mer_id,order_amt,trade_amt,mer_fee,bank_fee,cal_cost,product_id,created_date,modified_date,owner,ou,send_bank_code,ebs_biz_line_nm,ebs_biz_line_id,ks_bank_mer_id,ks_ou
    where a1.dt >= '{START_DATE}' and a1.src_tab='odm_pay_sis_account_result_i_d'
) res
;
""",

#全款结算报表
"sql_070": """
use dmf_tmp;

alter table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d drop partition(dt >= '{START_DATE}' ,source='report');
insert OVERWRITE table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d PARTITION (dt,source)
select     report.id                         as id
          ,case when nvl(report.trade_date,'')<>'' and nvl(report.trade_date,'') not like '0%' then report.trade_date
                when report.src_dt >= '2023-08-01' then report.trade_date
                else report.mer_date
           end                               as trade_date 
          ,report.trade_category             as trade_category
          ,''                                as bank_mer_id
          ,report.mer_id                     as mer_id
          ,report.mer_name                   as mer_name
          ,''                                as trade_type
          ,report.pay_tools                  as pay_tools
          ,report.card_type                  as card_type
          ,0                                 as order_amt
          ,cast(report.trade_amt as double)/if(src_dt<'2023-08-01',100,1) as trade_amt
          ,cast(report.mer_fee   as double)/if(src_dt<'2023-08-01',100,1) as mer_fee
          ,0                                 as bank_fee
          ,0                                 as cal_cost
          ,0                                 as trade_num
          ,0                                 as real_pay_fee
          ,0                                 as chazhi
          ,''                                as jindie_name
          ,''                                as send_bank_code
          ,report.owner                      as owner
          ,''                                as ou
          ,''                                as product_id
          ,report.created_date               as created_date
          ,report.modified_date              as modified_date
          ,''                                as ks_bank_mer_id
          ,''                                as ks_ou
          ,report.ks_mer_id                  as ks_mer_id
          ,''                                as exit_1
          ,''                                as exit_2
          ,report.src_tab                    as source_table
          ,''                                as ks_jindie_name
          ,report.joinkey                    as joinkey
          ,report.change_code                as change_code
          ,report.data_type                  as data_type
          ,report.src_dt                     as src_dt
          ,report.ebs_biz_line_nm            as ebs_biz_line_nm
          ,report.ebs_biz_line_id            as ebs_biz_line_id
          ,report.dt                         as dt
          ,'report'                          as source
from (
    select  a1.*,a2.*
    from dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d a1
    lateral view json_tuple(all_cols,'mer_id','mer_name','trade_category','pay_tools','card_type','mer_date','trade_amt','mer_fee','created_date','modified_date','trade_date','ebs_biz_line_nm','ebs_biz_line_id','ks_mer_id','owner') a2
    as mer_id,mer_name,trade_category,pay_tools,card_type,mer_date,trade_amt,mer_fee,created_date,modified_date,trade_date,ebs_biz_line_nm,ebs_biz_line_id,ks_mer_id,owner
    where a1.dt >= '{START_DATE}' and a1.src_tab='odm_pay_sis_fi_sis_gross_settle_report_i_d'
) report  
;
""",

#成本调差表
"sql_080": """
use dmf_tmp;

alter table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d drop partition(dt >= '{START_DATE}',source='recon_tc_m');
alter table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d drop partition(dt >= '{START_DATE}',source='recon_tc_d');
insert OVERWRITE table dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d PARTITION (dt,source)
select     b1.id                           as id  
          ,from_unixtime(unix_timestamp(rpad(real_pay_date_new, 8, '01'),'yyyymmdd'),'yyyy-mm-dd') as trade_date --特殊处理时间 因为表中数据不是标准的时间格式
          ,''                              as trade_category
          ,b1.bank_mer_id                  as bank_mer_id
          ,''                              as mer_id
          ,''                              as mer_name
          ,''                              as trade_type
          ,if(b1.src_dt<'2023-08-01',b1.pay_tool,b1.pay_tools) as pay_tools
          ,b1.card_type                    as card_type
          ,0                               as order_amt
          ,0                               as trade_amt
          ,0                               as mer_fee
          ,0                               as bank_fee
          ,0                               as cal_cost
          ,0                               as trade_num
          ,cast(b1.real_pay_fee as double)/if(src_dt<'2023-08-01',100,1) as real_pay_fee
          ,cast(b1.chazhi       as double)/if(src_dt<'2023-08-01',100,1) as chazhi
          ,b1.jindie_name                  as jindie_name
          ,if(b1.src_dt<'2023-08-01',b1.send_bank,b1.send_bank_code) as send_bank_code
          ,''                              as owner
          ,''                              as ou
          ,''                              as product_id
          ,b1.created_date                 as created_date
          ,b1.modified_date                as modified_date
          ,''                              as ks_bank_mer_id
          ,''                              as ks_ou
          ,''                              as ks_mer_id
          ,''                              as exit_1
          ,''                              as exit_2
          ,b1.src_tab                      as source_table
          ,b1.ks_jindie_name               as ks_jindie_name
          ,b1.joinkey                      as joinkey
          ,b1.change_code                  as change_code
          ,b1.data_type                    as data_type
          ,b1.src_dt                       as src_dt
          ,b1.ebs_biz_line_nm              as ebs_biz_line_nm
          ,b1.ebs_biz_line_id              as ebs_biz_line_id
          ,b1.dt                           as dt
          ,if(length(b1.real_pay_date_new)=6,'recon_tc_m','recon_tc_d') as source
from (
    select   a1.*,a2.*
            ,regexp_replace(trim(coalesce(real_pay_date, trade_date)),'-','') as real_pay_date_new
    from dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_json_i_d a1
    lateral view json_tuple(all_cols,'jindie_name','pay_tools','bank_mer_id','send_bank_code','card_type','real_pay_fee','trade_date','chazhi','created_date','modified_date','ebs_biz_line_nm','ebs_biz_line_id','ks_jindie_name','pay_tool','send_bank','real_pay_date') a2
    as jindie_name,pay_tools,bank_mer_id,send_bank_code,card_type,real_pay_fee,trade_date,chazhi,created_date,modified_date,ebs_biz_line_nm,ebs_biz_line_id,ks_jindie_name,pay_tool,send_bank,real_pay_date
    where  a1.dt >= '{START_DATE}' and a1.src_tab='odm_fi_hs_tc_detail_i_d'
      and (   (a1.src_dt >= '2023-08-01' and length(a2.trade_date) >= 6)
           or (a1.src_dt <  '2023-08-01' and length(trim(nvl(a2.real_pay_date,''))) >= 6 )
          )
) b1
;
""",

#插入最终结果表
"sql_090": """
use dmf_bc;

alter table dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_i_d drop partition (dt >= '{START_DATE}');
insert overwrite table dmf_bc.dmfbc_gj_pay_zftd_ywxt_transaction_i_d partition (dt,data_type)
select     joinkey
          ,change_code
          ,id
          ,trade_date
          ,nvl(from_unixtime(unix_timestamp(regexp_replace(trade_date,'-',''),'yyyymmdd'),'yyyy-mm-dd HH:MM:ss'),'') as trans_dt
          ,trade_category
          ,bank_mer_id
          ,mer_id
          ,mer_name
          ,trade_type
          ,pay_tools
          ,card_type
          ,if(data_type='2',-order_amt   ,order_amt   ) as order_amt
          ,if(data_type='2',-trade_amt   ,trade_amt   ) as trade_amt
          ,if(data_type='2',-mer_fee     ,mer_fee     ) as mer_fee
          ,if(data_type='2',-bank_fee    ,bank_fee    ) as bank_fee
          ,if(data_type='2',-cal_cost    ,cal_cost    ) as cal_cost
          ,if(data_type='2',-trade_num   ,trade_num   ) as trade_num
          ,if(data_type='2',-real_pay_fee,real_pay_fee) as real_pay_fee
          ,if(data_type='2',-chazhi      ,chazhi      ) as chazhi
          ,JINDIE_NAME
          ,send_bank_code
          ,owner
          ,ou
          ,product_id
          ,created_date
          ,source
          ,modified_date
          ,FROM_UNIXTIME(UNIX_TIMESTAMP(), 'yyyy-MM-dd HH:mm:ss') AS create_dt
          ,ks_bank_mer_id
          ,ks_ou
          ,ks_mer_id
          ,exit_1
          ,exit_2
          ,src_dt AS source_table_dt -- 来源表分区
          ,source_table              -- 来源表
          ,ks_jindie_name
          ,ebs_biz_line_nm
          ,ebs_biz_line_id
          ,dt
          ,data_type
from dmf_tmp.dmftmp_gj_pay_zftd_ywxt_transaction_i_d
where dt >= '{START_DATE}'
  and trade_date != '00000000'
;
""",

}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)