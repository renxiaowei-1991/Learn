select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;

select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                 ,'') as string))
,md5(cast(nvl(change_code                              ,'') as string))
,md5(cast(nvl(ele_md5                                  ,'') as string))
,md5(cast(nvl(unikey                                   ,'') as string))
,md5(cast(nvl(data_source_em                           ,'') as string))
,md5(cast(nvl(biz_id                                   ,'') as string))
,md5(cast(nvl(biz_type                                 ,'') as string))
,md5(cast(nvl(fee_id                                   ,'') as string))
,md5(cast(nvl(fee_type                                 ,'') as string))
,md5(cast(nvl(product_id                               ,'') as string))
,md5(cast(nvl(product_name                             ,'') as string))
,md5(cast(nvl(customer_id                              ,'') as string))
,md5(cast(nvl(customer_name                            ,'') as string))
,md5(cast(nvl(direction                                ,'') as string))
,md5(cast(nvl(amount                                   ,0) as string))
,md5(cast(nvl(sett_amount                              ,0) as string))
,md5(cast(nvl(need_invoice                             ,'') as string))
,md5(cast(nvl(source_id                                ,'') as string))
,md5(cast(nvl(rule_id                                  ,'') as string))
,md5(cast(nvl(status                                   ,'') as string))
,md5(cast(nvl(operator                                 ,'') as string))
,md5(cast(nvl(data_type                                ,'') as string))
,md5(cast(nvl(trans_time                               ,'') as string))
,md5(cast(nvl(yn_flag                                  ,'') as string))
,md5(cast(nvl(remark                                   ,'') as string))
,md5(cast(nvl(create_user                              ,'') as string))
,md5(cast(nvl(update_user                              ,'') as string))
,md5(cast(nvl(create_dt                                ,'') as string))
,md5(cast(nvl(update_dt                                ,'') as string))
,md5(cast(nvl(customer_type                            ,'') as string))
,md5(cast(nvl(card_id                                  ,'') as string))
,md5(cast(nvl(pay_channel_type                         ,'') as string))
,md5(cast(nvl(pay_channel_id                           ,'') as string))
,md5(cast(nvl(order_id                                 ,'') as string))
,md5(cast(nvl(ex_one                                   ,'') as string))
,md5(cast(nvl(ex_two                                   ,'') as string))
,md5(cast(nvl(ex_three                                 ,'') as string))
,md5(cast(nvl(org_id                                   ,'') as string))
,md5(cast(nvl(sett_id                                  ,'') as string))
,md5(cast(nvl(ex_four                                  ,'') as string))
,md5(cast(nvl(currency                                 ,'') as string))
,md5(cast(nvl(tax_rate                                 ,'') as string))
,md5(cast(nvl(contract_code                            ,'') as string))
,md5(cast(nvl(project_code                             ,'') as string))
,md5(cast(nvl(biz_association_id                       ,'') as string))
,md5(cast(nvl(composite_id                             ,'') as string))
,md5(cast(nvl(standby_field_one                        ,'') as string))
,md5(cast(nvl(standby_field_two                        ,'') as string))
,md5(cast(nvl(standby_field_three                      ,'') as string))
,md5(cast(nvl(standby_field_four                       ,'') as string))
,md5(cast(nvl(standby_field_five                       ,'') as string))
,md5(cast(nvl(prov_flag                                ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id        ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id        ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name      ,'') as string))
,md5(cast(nvl(bill_code                                ,'') as string))
,md5(cast(nvl(ex_five                                  ,'') as string))
,md5(cast(nvl(ex_six                                   ,'') as string))
,md5(cast(nvl(ex_seven                                 ,'') as string))
,md5(cast(nvl(ex_eight                                 ,'') as string))
,md5(cast(nvl(ex_nine                                  ,'') as string))
,md5(cast(nvl(ex_ten                                   ,'') as string))
,md5(cast(nvl(ex_eleven                                ,'') as string))
,md5(cast(nvl(ex_twelve                                ,'') as string))
,md5(cast(nvl(ex_thirteen                              ,'') as string))
,md5(cast(nvl(ex_fourteen                              ,'') as string))
,md5(cast(nvl(ex_fifteen                               ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                        ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id            ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type       ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag    ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src    ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src   ,'') as string))
,md5(cast(nvl(dept_id                                  ,'') as string))
,md5(cast(nvl(spec_type_cd                             ,'') as string))
,md5(cast(nvl(spe_val_map                              ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d
where dt='2022-08-09'
group by dt
;



--正式表备份及迁移
use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d
where end_dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_h_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_h_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_sett_all_h_d
where end_dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_i_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_i_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_sett_i_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_h_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_h_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_h_d
where end_dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_i_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_i_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_i_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_i_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_i_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_i_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_all_i_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_all_i_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_all_i_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_s_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_s_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_s_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_s_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_s_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_h_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_h_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_h_d
where end_dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_s_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_s_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_sett_all_s_d
where dt>='2022-06-14'
;

use dmf_tmp;
drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_valid_i_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_valid_i_d_tmp_01
as
select * from dmf_bc.dmfbc_bc_fi_fst_sett_valid_i_d
where dt>='2022-06-14'
;

--20220615tmp表备份及迁移
use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_clean_data as select * from dmf_tmp.tmp_fin_fee_detail_clean_data;
create table dmf_tmp.renxiaowei7_20220616_tmp_odm_fi_js_fin_fee_detail_i_d as select * from dmf_tmp.tmp_odm_fi_js_fin_fee_detail_i_d;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_all_1 as select * from dmf_tmp.tmp_fin_fee_detail_all_1;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_month_brush as select * from dmf_tmp.tmp_fin_fee_detail_month_brush;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_xjk_borrow_order as select * from dmf_tmp.tmp_fin_fee_detail_xjk_borrow_order;
create table dmf_tmp.renxiaowei7_20220616_tmp_tmp_fin_fee_detail_xjk_sku_id as select * from dmf_tmp.tmp_tmp_fin_fee_detail_xjk_sku_id;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_all_1_1 as select * from dmf_tmp.tmp_fin_fee_detail_all_1_1;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_sett_param as select * from dmf_tmp.tmp_fin_fee_detail_sett_param;
create table dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee as select * from dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee as select * from dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code_fee as select * from dmf_tmp.tmp_fin_sett_all_account_acc_brief_code_fee;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_all_6_new as select * from dmf_tmp.tmp_fin_fee_detail_all_6_new;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_01 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_01;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_02 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_02;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_03 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_03;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_04 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_04;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_tmp_fi_hs_yes_fin_sett_all_final_i_d as select * from dmf_tmp.dmftmp_tmp_fi_hs_yes_fin_sett_all_final_i_d;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code as select * from dmf_tmp.tmp_fin_sett_all_account_acc_brief_code;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_clean_data as select * from dmf_tmp.tmp_fin_sett_all_clean_data;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_single_0 as select * from dmf_tmp.tmp_fin_sett_all_single_0;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_real_pay_inc as select * from dmf_tmp.tmp_fin_sett_all_real_pay_inc;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_real_pay_acct_0 as select * from dmf_tmp.tmp_fin_sett_all_real_pay_acct_0;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_1 as select * from dmf_tmp.tmp_fin_sett_all_1;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_month_brush as select * from dmf_tmp.tmp_fin_sett_all_month_brush;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_dmfdim_dim_fi_fin_subject_principal_merchant_s_d_tmp_01 as select * from dmf_tmp.dmftmp_dmfdim_dim_fi_fin_subject_principal_merchant_s_d_tmp_01;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_1_1 as select * from dmf_tmp.tmp_fin_sett_all_1_1;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_settway as select * from dmf_tmp.tmp_fin_sett_all_settway;
create table dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_sett as select * from dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_sett;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_sett as select * from dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_sett;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_1_mercht_new as select * from dmf_tmp.tmp_fin_sett_all_1_mercht_new;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_account_01 as select * from dmf_tmp.tmp_fin_sett_all_payinfo_principal_company_account_01;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_01 as select * from dmf_tmp.tmp_fin_sett_all_payinfo_customer_company_account_01;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_03 as select * from dmf_tmp.tmp_fin_sett_all_payinfo_customer_company_account_03;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_02 as select * from dmf_tmp.tmp_fin_sett_all_payinfo_customer_company_account_02;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_name_01 as select * from dmf_tmp.tmp_fin_sett_all_payinfo_principal_company_name_01;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_name_01 as select * from dmf_tmp.tmp_fin_sett_all_payinfo_customer_company_name_01;
create table dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_final_1 as select * from dmf_tmp.tmp_fin_sett_all_final_1;

use dmf_tmp;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_01 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_sett_01;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_02 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_sett_02;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_03 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_sett_03;
create table dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_04 as select * from dmf_tmp.dmftmp_sett_spec_manage_tmp_sett_04;


--涉及表
 dmfbc_bc_fi_fst_fee_detail_h_d
,dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
,dmfbc_bc_fi_fst_fee_detail_i_d
,dmfbc_bc_fi_fst_fee_detail_all_i_d
,dmfbc_bc_fi_fst_fee_detail_period_h_d
,dmfbc_bc_fi_fst_fee_detail_period_s_d	
,dmfbc_bc_fi_fst_fee_detail_s_d
,dmfbc_bc_fi_fst_sett_i_d
,dmfbc_bc_fi_fst_sett_all_h_d
,dmfbc_bc_fi_fst_sett_part_pay_h_d
,dmfbc_bc_fi_fst_sett_part_pay_i_d
,dmfbc_bc_fi_fst_sett_all_s_d
,dmfbc_bc_fi_fst_sett_valid_i_d
,renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_h_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_i_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_h_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_i_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_i_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_all_i_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_s_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_s_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_h_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_s_d_tmp_01
,renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_valid_i_d_tmp_01

 renxiaowei7_20220616_tmp_fin_fee_detail_clean_data
,renxiaowei7_20220616_tmp_odm_fi_js_fin_fee_detail_i_d
,renxiaowei7_20220616_tmp_fin_fee_detail_all_1
,renxiaowei7_20220616_tmp_fin_fee_detail_month_brush
,renxiaowei7_20220616_tmp_fin_fee_detail_xjk_borrow_order
,renxiaowei7_20220616_tmp_tmp_fin_fee_detail_xjk_sku_id
,renxiaowei7_20220616_tmp_fin_fee_detail_all_1_1
,renxiaowei7_20220616_tmp_fin_fee_detail_sett_param
,renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee
,renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee
,renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code_fee
,renxiaowei7_20220616_tmp_fin_fee_detail_all_6_new
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_01
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_02
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_03
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_04
,renxiaowei7_20220616_dmftmp_tmp_fi_hs_yes_fin_sett_all_final_i_d
,renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code
,renxiaowei7_20220616_tmp_fin_sett_all_clean_data
,renxiaowei7_20220616_tmp_fin_sett_all_single_0
,renxiaowei7_20220616_tmp_fin_sett_all_real_pay_inc
,renxiaowei7_20220616_tmp_fin_sett_all_real_pay_acct_0
,renxiaowei7_20220616_tmp_fin_sett_all_1
,renxiaowei7_20220616_tmp_fin_sett_all_month_brush
,renxiaowei7_20220616_dmftmp_dmfdim_dim_fi_fin_subject_principal_merchant_s_d_tmp_01
,renxiaowei7_20220616_tmp_fin_sett_all_1_1
,renxiaowei7_20220616_tmp_fin_sett_all_settway
,renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_sett
,renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_sett
,renxiaowei7_20220616_tmp_fin_sett_all_1_mercht_new
,renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_account_01
,renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_01
,renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_03
,renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_02
,renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_name_01
,renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_name_01
,renxiaowei7_20220616_tmp_fin_sett_all_final_1
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_01
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_02
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_03
,renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_04

--备份表条数校验
select 'dmfbc_bc_fi_fst_fee_detail_h_d'                                        as tab,end_dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d                                         where end_dt>='2022-06-01' group by end_dt union all
select 'dmfbc_bc_fi_fst_fee_detail_period_h_d'                                 as tab,end_dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_h_d                                  where end_dt>='2022-06-01' group by end_dt union all
select 'dmfbc_bc_fi_fst_sett_all_h_d'                                          as tab,end_dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_sett_all_h_d                                           where end_dt>='2022-06-01' group by end_dt union all
select 'dmfbc_bc_fi_fst_sett_part_pay_h_d'                                     as tab,end_dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_h_d                                      where end_dt>='2022-06-01' group by end_dt union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01'            as tab,end_dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01            where end_dt>='2022-06-01' group by end_dt union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_h_d_tmp_01'              as tab,end_dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_h_d_tmp_01              where end_dt>='2022-06-01' group by end_dt union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_h_d_tmp_01'         as tab,end_dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_h_d_tmp_01         where end_dt>='2022-06-01' group by end_dt union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_h_d_tmp_01'     as tab,end_dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_h_d_tmp_01     where end_dt>='2022-06-01' group by end_dt union all
select 'dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d'                             as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d                              where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_fee_detail_i_d'                                        as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_fee_detail_i_d                                         where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_fee_detail_all_i_d'                                    as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_fee_detail_all_i_d                                     where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_fee_detail_period_s_d'                                 as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_s_d	                                 where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_fee_detail_s_d'                                        as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d                                         where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_sett_i_d'                                              as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_sett_i_d                                               where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_sett_part_pay_i_d'                                     as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_i_d                                      where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_sett_all_s_d'                                          as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_sett_all_s_d                                           where     dt>='2022-06-01' group by dt     union all
select 'dmfbc_bc_fi_fst_sett_valid_i_d'                                        as tab,    dt,count(*) from dmf_bc.dmfbc_bc_fi_fst_sett_valid_i_d                                         where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01' as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01 where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_i_d_tmp_01'                  as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_i_d_tmp_01                  where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_i_d_tmp_01'         as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_part_pay_i_d_tmp_01         where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_i_d_tmp_01'            as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_i_d_tmp_01            where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_all_i_d_tmp_01'        as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_all_i_d_tmp_01        where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_s_d_tmp_01'     as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_s_d_tmp_01     where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_s_d_tmp_01'            as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_s_d_tmp_01            where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_s_d_tmp_01'              as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_all_s_d_tmp_01              where     dt>='2022-06-01' group by dt     union all
select 'renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_valid_i_d_tmp_01'            as tab,    dt,count(*) from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_sett_valid_i_d_tmp_01            where     dt>='2022-06-01' group by dt     ;

select 'renxiaowei7_20220616_tmp_fin_fee_detail_clean_data'                                        as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_clean_data                                        union all
select 'renxiaowei7_20220616_tmp_odm_fi_js_fin_fee_detail_i_d'                                     as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_odm_fi_js_fin_fee_detail_i_d                                     union all
select 'renxiaowei7_20220616_tmp_fin_fee_detail_all_1'                                             as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_all_1                                             union all
select 'renxiaowei7_20220616_tmp_fin_fee_detail_month_brush'                                       as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_month_brush                                       union all
select 'renxiaowei7_20220616_tmp_fin_fee_detail_xjk_borrow_order'                                  as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_xjk_borrow_order                                  union all
select 'renxiaowei7_20220616_tmp_tmp_fin_fee_detail_xjk_sku_id'                                    as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_tmp_fin_fee_detail_xjk_sku_id                                    union all
select 'renxiaowei7_20220616_tmp_fin_fee_detail_all_1_1'                                           as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_all_1_1                                           union all
select 'renxiaowei7_20220616_tmp_fin_fee_detail_sett_param'                                        as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_sett_param                                        union all
select 'renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee'            as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee            union all
select 'renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee'  as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee  union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code_fee'                          as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code_fee                          union all
select 'renxiaowei7_20220616_tmp_fin_fee_detail_all_6_new'                                         as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_fee_detail_all_6_new                                         union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_01'                                   as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_01                                   union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_02'                                   as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_02                                   union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_03'                                   as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_03                                   union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_04'                                   as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_fee_04                                   union all
select 'renxiaowei7_20220616_dmftmp_tmp_fi_hs_yes_fin_sett_all_final_i_d'                          as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_tmp_fi_hs_yes_fin_sett_all_final_i_d                          union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code'                              as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_account_acc_brief_code                              union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_clean_data'                                          as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_clean_data                                          union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_single_0'                                            as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_single_0                                            union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_real_pay_inc'                                        as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_real_pay_inc                                        union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_real_pay_acct_0'                                     as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_real_pay_acct_0                                     union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_1'                                                   as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_1                                                   union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_month_brush'                                         as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_month_brush                                         union all
select 'renxiaowei7_20220616_dmftmp_dmfdim_dim_fi_fin_subject_principal_merchant_s_d_tmp_01'       as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_dmfdim_dim_fi_fin_subject_principal_merchant_s_d_tmp_01       union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_1_1'                                                 as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_1_1                                                 union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_settway'                                             as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_settway                                             union all
select 'renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_sett'           as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_sett           union all
select 'renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_sett' as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_sett union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_1_mercht_new'                                        as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_1_mercht_new                                        union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_account_01'                as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_account_01                union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_01'                 as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_01                 union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_03'                 as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_03                 union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_02'                 as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_account_02                 union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_name_01'                   as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_principal_company_name_01                   union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_name_01'                    as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_payinfo_customer_company_name_01                    union all
select 'renxiaowei7_20220616_tmp_fin_sett_all_final_1'                                             as tab,count(*) from dmf_tmp.renxiaowei7_20220616_tmp_fin_sett_all_final_1                                             union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_01'                                  as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_01                                  union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_02'                                  as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_02                                  union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_03'                                  as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_03                                  union all
select 'renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_04'                                  as tab,count(*) from dmf_tmp.renxiaowei7_20220616_dmftmp_sett_spec_manage_tmp_sett_04                                  ;



--数据校验
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;

--dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d-20220615
select end_dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                ,'') as string))
,md5(cast(nvl(change_code                             ,'') as string))
,md5(cast(nvl(ele_md5                                 ,'') as string))
,md5(cast(nvl(unikey                                  ,'') as string))
,md5(cast(nvl(data_source_em                          ,'') as string))
,md5(cast(nvl(biz_id                                  ,'') as string))
,md5(cast(nvl(biz_type                                ,'') as string))
,md5(cast(nvl(fee_id                                  ,'') as string))
,md5(cast(nvl(fee_type                                ,'') as string))
,md5(cast(nvl(product_id                              ,'') as string))
,md5(cast(nvl(product_name                            ,'') as string))
,md5(cast(nvl(customer_id                             ,'') as string))
,md5(cast(nvl(customer_name                           ,'') as string))
,md5(cast(nvl(direction                               ,'') as string))
,md5(cast(nvl(amount                                  ,0) as string))
,md5(cast(nvl(sett_amount                             ,0) as string))
,md5(cast(nvl(need_invoice                            ,'') as string))
,md5(cast(nvl(source_id                               ,'') as string))
,md5(cast(nvl(rule_id                                 ,'') as string))
,md5(cast(nvl(status                                  ,'') as string))
,md5(cast(nvl(operator                                ,'') as string))
,md5(cast(nvl(data_type                               ,'') as string))
,md5(cast(nvl(trans_time                              ,'') as string))
,md5(cast(nvl(yn_flag                                 ,'') as string))
,md5(cast(nvl(remark                                  ,'') as string))
,md5(cast(nvl(create_user                             ,'') as string))
,md5(cast(nvl(update_user                             ,'') as string))
,md5(cast(nvl(create_dt                               ,'') as string))
,md5(cast(nvl(update_dt                               ,'') as string))
,md5(cast(nvl(customer_type                           ,'') as string))
,md5(cast(nvl(card_id                                 ,'') as string))
,md5(cast(nvl(pay_channel_type                        ,'') as string))
,md5(cast(nvl(pay_channel_id                          ,'') as string))
,md5(cast(nvl(order_id                                ,'') as string))
,md5(cast(nvl(ex_one                                  ,'') as string))
,md5(cast(nvl(ex_two                                  ,'') as string))
,md5(cast(nvl(ex_three                                ,'') as string))
,md5(cast(nvl(org_id                                  ,'') as string))
,md5(cast(nvl(sett_id                                 ,'') as string))
,md5(cast(nvl(ex_four                                 ,'') as string))
,md5(cast(nvl(currency                                ,'') as string))
,md5(cast(nvl(tax_rate                                ,'') as string))
,md5(cast(nvl(contract_code                           ,'') as string))
,md5(cast(nvl(project_code                            ,'') as string))
,md5(cast(nvl(biz_association_id                      ,'') as string))
,md5(cast(nvl(composite_id                            ,'') as string))
,md5(cast(nvl(standby_field_one                       ,'') as string))
,md5(cast(nvl(standby_field_two                       ,'') as string))
,md5(cast(nvl(standby_field_three                     ,'') as string))
,md5(cast(nvl(standby_field_four                      ,'') as string))
,md5(cast(nvl(standby_field_five                      ,'') as string))
,md5(cast(nvl(prov_flag                               ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id       ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id       ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name     ,'') as string))
,md5(cast(nvl(bill_code                               ,'') as string))
,md5(cast(nvl(ex_five                                 ,'') as string))
,md5(cast(nvl(ex_six                                  ,'') as string))
,md5(cast(nvl(ex_seven                                ,'') as string))
,md5(cast(nvl(ex_eight                                ,'') as string))
,md5(cast(nvl(ex_nine                                 ,'') as string))
,md5(cast(nvl(ex_ten                                  ,'') as string))
,md5(cast(nvl(ex_eleven                               ,'') as string))
,md5(cast(nvl(ex_twelve                               ,'') as string))
,md5(cast(nvl(ex_thirteen                             ,'') as string))
,md5(cast(nvl(ex_fourteen                             ,'') as string))
,md5(cast(nvl(ex_fifteen                              ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                       ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id           ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type      ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag   ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src   ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src  ,'') as string))
,md5(cast(nvl(dept_id                                 ,'') as string))
,md5(cast(nvl(spec_type_cd                            ,'') as string))
,md5(cast(nvl(spe_val_map                             ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d
where end_dt='2022-06-15'
group by end_dt
;

--dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(ele_md5                                ,'') as string))
,md5(cast(nvl(unikey                                 ,'') as string))
,md5(cast(nvl(data_source_em                         ,'') as string))
,md5(cast(nvl(biz_id                                 ,'') as string))
,md5(cast(nvl(biz_type                               ,'') as string))
,md5(cast(nvl(fee_id                                 ,'') as string))
,md5(cast(nvl(fee_type                               ,'') as string))
,md5(cast(nvl(product_id                             ,'') as string))
,md5(cast(nvl(product_name                           ,'') as string))
,md5(cast(nvl(customer_id                            ,'') as string))
,md5(cast(nvl(customer_name                          ,'') as string))
,md5(cast(nvl(direction                              ,'') as string))
,md5(cast(nvl(amount                                 ,0) as string))
,md5(cast(nvl(sett_amount                            ,0) as string))
,md5(cast(nvl(need_invoice                           ,'') as string))
,md5(cast(nvl(source_id                              ,'') as string))
,md5(cast(nvl(rule_id                                ,'') as string))
,md5(cast(nvl(status                                 ,'') as string))
,md5(cast(nvl(operator                               ,'') as string))
,md5(cast(nvl(data_type                              ,'') as string))
,md5(cast(nvl(trans_time                             ,'') as string))
,md5(cast(nvl(yn_flag                                ,'') as string))
,md5(cast(nvl(remark                                 ,'') as string))
,md5(cast(nvl(create_user                            ,'') as string))
,md5(cast(nvl(update_user                            ,'') as string))
,md5(cast(nvl(create_dt                              ,'') as string))
,md5(cast(nvl(update_dt                              ,'') as string))
,md5(cast(nvl(customer_type                          ,'') as string))
,md5(cast(nvl(card_id                                ,'') as string))
,md5(cast(nvl(pay_channel_type                       ,'') as string))
,md5(cast(nvl(pay_channel_id                         ,'') as string))
,md5(cast(nvl(order_id                               ,'') as string))
,md5(cast(nvl(ex_one                                 ,'') as string))
,md5(cast(nvl(ex_two                                 ,'') as string))
,md5(cast(nvl(ex_three                               ,'') as string))
,md5(cast(nvl(org_id                                 ,'') as string))
,md5(cast(nvl(sett_id                                ,'') as string))
,md5(cast(nvl(ex_four                                ,'') as string))
,md5(cast(nvl(currency                               ,'') as string))
,md5(cast(nvl(tax_rate                               ,'') as string))
,md5(cast(nvl(contract_code                          ,'') as string))
,md5(cast(nvl(project_code                           ,'') as string))
,md5(cast(nvl(biz_association_id                     ,'') as string))
,md5(cast(nvl(composite_id                           ,'') as string))
,md5(cast(nvl(standby_field_one                      ,'') as string))
,md5(cast(nvl(standby_field_two                      ,'') as string))
,md5(cast(nvl(standby_field_three                    ,'') as string))
,md5(cast(nvl(standby_field_four                     ,'') as string))
,md5(cast(nvl(standby_field_five                     ,'') as string))
,md5(cast(nvl(prov_flag                              ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id      ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id      ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name    ,'') as string))
,md5(cast(nvl(last_dt                                ,'') as string))
,md5(cast(nvl(bill_code                              ,'') as string))
,md5(cast(nvl(ex_five                                ,'') as string))
,md5(cast(nvl(ex_six                                 ,'') as string))
,md5(cast(nvl(ex_seven                               ,'') as string))
,md5(cast(nvl(ex_eight                               ,'') as string))
,md5(cast(nvl(ex_nine                                ,'') as string))
,md5(cast(nvl(ex_ten                                 ,'') as string))
,md5(cast(nvl(ex_eleven                              ,'') as string))
,md5(cast(nvl(ex_twelve                              ,'') as string))
,md5(cast(nvl(ex_thirteen                            ,'') as string))
,md5(cast(nvl(ex_fourteen                            ,'') as string))
,md5(cast(nvl(ex_fifteen                             ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                      ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id          ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type     ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag  ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src  ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src ,'') as string))
,md5(cast(nvl(dept_id                                ,'') as string))
,md5(cast(nvl(spec_type_cd                           ,'') as string))
,md5(cast(nvl(change_flag                            ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
where dt>='2022-09-01'
group by dt

--dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                               ,'') as string))
--,md5(cast(nvl(change_code                            ,'') as string))
--,md5(cast(nvl(ele_md5                                ,'') as string))
,md5(cast(nvl(unikey                                 ,'') as string))
,md5(cast(nvl(data_source_em                         ,'') as string))
,md5(cast(nvl(biz_id                                 ,'') as string))
,md5(cast(nvl(biz_type                               ,'') as string))
,md5(cast(nvl(fee_id                                 ,'') as string))
,md5(cast(nvl(fee_type                               ,'') as string))
,md5(cast(nvl(product_id                             ,'') as string))
,md5(cast(nvl(product_name                           ,'') as string))
,md5(cast(nvl(customer_id                            ,'') as string))
,md5(cast(nvl(customer_name                          ,'') as string))
,md5(cast(nvl(direction                              ,'') as string))
,md5(cast(nvl(amount                                 ,0) as string))
,md5(cast(nvl(sett_amount                            ,0) as string))
,md5(cast(nvl(need_invoice                           ,'') as string))
,md5(cast(nvl(source_id                              ,'') as string))
,md5(cast(nvl(rule_id                                ,'') as string))
,md5(cast(nvl(status                                 ,'') as string))
,md5(cast(nvl(operator                               ,'') as string))
,md5(cast(nvl(data_type                              ,'') as string))
,md5(cast(nvl(trans_time                             ,'') as string))
,md5(cast(nvl(yn_flag                                ,'') as string))
,md5(cast(nvl(remark                                 ,'') as string))
,md5(cast(nvl(create_user                            ,'') as string))
,md5(cast(nvl(update_user                            ,'') as string))
,md5(cast(nvl(create_dt                              ,'') as string))
,md5(cast(nvl(update_dt                              ,'') as string))
,md5(cast(nvl(customer_type                          ,'') as string))
,md5(cast(nvl(card_id                                ,'') as string))
,md5(cast(nvl(pay_channel_type                       ,'') as string))
,md5(cast(nvl(pay_channel_id                         ,'') as string))
,md5(cast(nvl(order_id                               ,'') as string))
,md5(cast(nvl(ex_one                                 ,'') as string))
,md5(cast(nvl(ex_two                                 ,'') as string))
,md5(cast(nvl(ex_three                               ,'') as string))
,md5(cast(nvl(org_id                                 ,'') as string))
,md5(cast(nvl(sett_id                                ,'') as string))
,md5(cast(nvl(ex_four                                ,'') as string))
,md5(cast(nvl(currency                               ,'') as string))
,md5(cast(nvl(tax_rate                               ,'') as string))
,md5(cast(nvl(contract_code                          ,'') as string))
,md5(cast(nvl(project_code                           ,'') as string))
,md5(cast(nvl(biz_association_id                     ,'') as string))
,md5(cast(nvl(composite_id                           ,'') as string))
,md5(cast(nvl(standby_field_one                      ,'') as string))
,md5(cast(nvl(standby_field_two                      ,'') as string))
,md5(cast(nvl(standby_field_three                    ,'') as string))
,md5(cast(nvl(standby_field_four                     ,'') as string))
,md5(cast(nvl(standby_field_five                     ,'') as string))
,md5(cast(nvl(prov_flag                              ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id      ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id      ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name    ,'') as string))
,md5(cast(nvl(bill_code                              ,'') as string))
,md5(cast(nvl(ex_five                                ,'') as string))
,md5(cast(nvl(ex_six                                 ,'') as string))
,md5(cast(nvl(ex_seven                               ,'') as string))
,md5(cast(nvl(ex_eight                               ,'') as string))
,md5(cast(nvl(ex_nine                                ,'') as string))
,md5(cast(nvl(ex_ten                                 ,'') as string))
,md5(cast(nvl(ex_eleven                              ,'') as string))
,md5(cast(nvl(ex_twelve                              ,'') as string))
,md5(cast(nvl(ex_thirteen                            ,'') as string))
,md5(cast(nvl(ex_fourteen                            ,'') as string))
,md5(cast(nvl(ex_fifteen                             ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                      ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id          ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type     ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag  ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src  ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src ,'') as string))
,md5(cast(nvl(dept_id                                ,'') as string))
--,md5(cast(nvl(spec_type_cd                           ,'') as string))
,md5(cast(nvl(spe_val_map                            ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d
where dt='2022-06-15'
group by dt



--dmf_bc.dmfbc_bc_fi_fst_fee_detail_i_d-20220615
select dt,count(*) as num
,sum(hash(
-- md5(cast(nvl(ele_md5                                 ,'') as string))
--,
md5(cast(nvl(change_flag                             ,'') as string))
,md5(cast(nvl(data_source_em                          ,'') as string))
,md5(cast(nvl(origin_id                               ,'') as string))
,md5(cast(nvl(biz_id                                  ,'') as string))
,md5(cast(nvl(biz_type                                ,'') as string))
,md5(cast(nvl(fee_id                                  ,'') as string))
,md5(cast(nvl(fee_type                                ,'') as string))
,md5(cast(nvl(product_id                              ,'') as string))
,md5(cast(nvl(product_name                            ,'') as string))
,md5(cast(nvl(customer_id                             ,'') as string))
,md5(cast(nvl(customer_name                           ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id           ,'') as string))
,md5(cast(nvl(direction                               ,'') as string))
,md5(cast(nvl(amount                                  ,0) as string))
,md5(cast(nvl(sett_amount                             ,0) as string))
,md5(cast(nvl(need_invoice                            ,'') as string))
,md5(cast(nvl(source_id                               ,'') as string))
,md5(cast(nvl(rule_id                                 ,'') as string))
,md5(cast(nvl(status                                  ,'') as string))
,md5(cast(nvl(operator                                ,'') as string))
,md5(cast(nvl(data_type                               ,'') as string))
,md5(cast(nvl(trans_time                              ,'') as string))
,md5(cast(nvl(yn_flag                                 ,'') as string))
,md5(cast(nvl(remark                                  ,'') as string))
,md5(cast(nvl(create_user                             ,'') as string))
,md5(cast(nvl(update_user                             ,'') as string))
,md5(cast(nvl(create_dt                               ,'') as string))
,md5(cast(nvl(update_dt                               ,'') as string))
,md5(cast(nvl(customer_type                           ,'') as string))
,md5(cast(nvl(card_id                                 ,'') as string))
,md5(cast(nvl(pay_channel_type                        ,'') as string))
,md5(cast(nvl(pay_channel_id                          ,'') as string))
,md5(cast(nvl(order_id                                ,'') as string))
,md5(cast(nvl(ex_one                                  ,'') as string))
,md5(cast(nvl(ex_two                                  ,'') as string))
,md5(cast(nvl(ex_three                                ,'') as string))
,md5(cast(nvl(org_id                                  ,'') as string))
,md5(cast(nvl(sett_id                                 ,'') as string))
,md5(cast(nvl(ex_four                                 ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type      ,'') as string))
,md5(cast(nvl(currency                                ,'') as string))
,md5(cast(nvl(tax_rate                                ,'') as string))
,md5(cast(nvl(contract_code                           ,'') as string))
,md5(cast(nvl(project_code                            ,'') as string))
,md5(cast(nvl(biz_association_id                      ,'') as string))
,md5(cast(nvl(composite_id                            ,'') as string))
,md5(cast(nvl(standby_field_one                       ,'') as string))
,md5(cast(nvl(standby_field_two                       ,'') as string))
,md5(cast(nvl(standby_field_three                     ,'') as string))
,md5(cast(nvl(standby_field_four                      ,'') as string))
,md5(cast(nvl(standby_field_five                      ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag   ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id       ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id       ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name     ,'') as string))
,md5(cast(nvl(last_dt                                 ,'') as string))
,md5(cast(nvl(bill_code                               ,'') as string))
,md5(cast(nvl(ex_five                                 ,'') as string))
,md5(cast(nvl(ex_six                                  ,'') as string))
,md5(cast(nvl(ex_seven                                ,'') as string))
,md5(cast(nvl(ex_eight                                ,'') as string))
,md5(cast(nvl(ex_nine                                 ,'') as string))
,md5(cast(nvl(ex_ten                                  ,'') as string))
,md5(cast(nvl(ex_eleven                               ,'') as string))
,md5(cast(nvl(ex_twelve                               ,'') as string))
,md5(cast(nvl(ex_thirteen                             ,'') as string))
,md5(cast(nvl(ex_fourteen                             ,'') as string))
,md5(cast(nvl(ex_fifteen                              ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src   ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                      ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                    ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                       ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src  ,'') as string))
,md5(cast(nvl(dept_id                                 ,'') as string))
--,md5(cast(nvl(spec_type_cd                            ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_i_d
where dt='2022-06-15'
group by dt

--dmf_bc.dmfbc_bc_fi_fst_fee_detail_all_i_d-20220615
select dt,count(*) as num
,sum(hash(
-- md5(cast(nvl(ele_md5                                 ,'') as string))
--,
md5(cast(nvl(change_flag                             ,'') as string))
,md5(cast(nvl(data_source_em                          ,'') as string))
,md5(cast(nvl(origin_id                               ,'') as string))
,md5(cast(nvl(biz_id                                  ,'') as string))
,md5(cast(nvl(biz_type                                ,'') as string))
,md5(cast(nvl(fee_id                                  ,'') as string))
,md5(cast(nvl(fee_type                                ,'') as string))
,md5(cast(nvl(product_id                              ,'') as string))
,md5(cast(nvl(product_name                            ,'') as string))
,md5(cast(nvl(customer_id                             ,'') as string))
,md5(cast(nvl(customer_name                           ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id           ,'') as string))
,md5(cast(nvl(direction                               ,'') as string))
,md5(cast(nvl(amount                                  ,0) as string))
,md5(cast(nvl(sett_amount                             ,0) as string))
,md5(cast(nvl(need_invoice                            ,'') as string))
,md5(cast(nvl(source_id                               ,'') as string))
,md5(cast(nvl(rule_id                                 ,'') as string))
,md5(cast(nvl(status                                  ,'') as string))
,md5(cast(nvl(operator                                ,'') as string))
,md5(cast(nvl(data_type                               ,'') as string))
,md5(cast(nvl(trans_time                              ,'') as string))
,md5(cast(nvl(yn_flag                                 ,'') as string))
,md5(cast(nvl(remark                                  ,'') as string))
,md5(cast(nvl(create_user                             ,'') as string))
,md5(cast(nvl(update_user                             ,'') as string))
,md5(cast(nvl(create_dt                               ,'') as string))
,md5(cast(nvl(update_dt                               ,'') as string))
,md5(cast(nvl(customer_type                           ,'') as string))
,md5(cast(nvl(card_id                                 ,'') as string))
,md5(cast(nvl(pay_channel_type                        ,'') as string))
,md5(cast(nvl(pay_channel_id                          ,'') as string))
,md5(cast(nvl(order_id                                ,'') as string))
,md5(cast(nvl(ex_one                                  ,'') as string))
,md5(cast(nvl(ex_two                                  ,'') as string))
,md5(cast(nvl(ex_three                                ,'') as string))
,md5(cast(nvl(org_id                                  ,'') as string))
,md5(cast(nvl(sett_id                                 ,'') as string))
,md5(cast(nvl(ex_four                                 ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type      ,'') as string))
,md5(cast(nvl(currency                                ,'') as string))
,md5(cast(nvl(tax_rate                                ,'') as string))
,md5(cast(nvl(contract_code                           ,'') as string))
,md5(cast(nvl(project_code                            ,'') as string))
,md5(cast(nvl(biz_association_id                      ,'') as string))
,md5(cast(nvl(composite_id                            ,'') as string))
,md5(cast(nvl(standby_field_one                       ,'') as string))
,md5(cast(nvl(standby_field_two                       ,'') as string))
,md5(cast(nvl(standby_field_three                     ,'') as string))
,md5(cast(nvl(standby_field_four                      ,'') as string))
,md5(cast(nvl(standby_field_five                      ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag   ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id       ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id       ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name     ,'') as string))
,md5(cast(nvl(last_dt                                 ,'') as string))
,md5(cast(nvl(bill_code                               ,'') as string))
,md5(cast(nvl(ex_five                                 ,'') as string))
,md5(cast(nvl(ex_six                                  ,'') as string))
,md5(cast(nvl(ex_seven                                ,'') as string))
,md5(cast(nvl(ex_eight                                ,'') as string))
,md5(cast(nvl(ex_nine                                 ,'') as string))
,md5(cast(nvl(ex_ten                                  ,'') as string))
,md5(cast(nvl(ex_eleven                               ,'') as string))
,md5(cast(nvl(ex_twelve                               ,'') as string))
,md5(cast(nvl(ex_thirteen                             ,'') as string))
,md5(cast(nvl(ex_fourteen                             ,'') as string))
,md5(cast(nvl(ex_fifteen                              ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src   ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                      ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                    ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                       ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src  ,'') as string))
,md5(cast(nvl(dept_id                                 ,'') as string))
--,md5(cast(nvl(spec_type_cd                            ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_all_i_d
where dt='2022-06-15'
group by dt


--dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_h_d-20220615
select end_dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                   ,'') as string))
--,md5(cast(nvl(ele_md5                                    ,'') as string))
,md5(cast(nvl(change_flag                                ,'') as string))
,md5(cast(nvl(data_source_em                             ,'') as string))
,md5(cast(nvl(origin_id                                  ,'') as string))
,md5(cast(nvl(biz_id                                     ,'') as string))
,md5(cast(nvl(biz_type                                   ,'') as string))
,md5(cast(nvl(fee_id                                     ,'') as string))
,md5(cast(nvl(fee_type                                   ,'') as string))
,md5(cast(nvl(product_id                                 ,'') as string))
,md5(cast(nvl(product_name                               ,'') as string))
,md5(cast(nvl(customer_id                                ,'') as string))
,md5(cast(nvl(customer_name                              ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id              ,'') as string))
,md5(cast(nvl(direction                                  ,'') as string))
,md5(cast(nvl(amount                                     ,'') as string))
,md5(cast(nvl(sett_amount                                ,'') as string))
,md5(cast(nvl(need_invoice                               ,'') as string))
,md5(cast(nvl(source_id                                  ,'') as string))
,md5(cast(nvl(rule_id                                    ,'') as string))
,md5(cast(nvl(status                                     ,'') as string))
,md5(cast(nvl(operator                                   ,'') as string))
,md5(cast(nvl(data_type                                  ,'') as string))
,md5(cast(nvl(trans_time                                 ,'') as string))
,md5(cast(nvl(yn_flag                                    ,'') as string))
,md5(cast(nvl(remark                                     ,'') as string))
,md5(cast(nvl(create_user                                ,'') as string))
,md5(cast(nvl(update_user                                ,'') as string))
,md5(cast(nvl(create_dt                                  ,'') as string))
,md5(cast(nvl(update_dt                                  ,'') as string))
,md5(cast(nvl(customer_type                              ,'') as string))
,md5(cast(nvl(card_id                                    ,'') as string))
,md5(cast(nvl(pay_channel_type                           ,'') as string))
,md5(cast(nvl(pay_channel_id                             ,'') as string))
,md5(cast(nvl(order_id                                   ,'') as string))
,md5(cast(nvl(ex_one                                     ,'') as string))
,md5(cast(nvl(ex_two                                     ,'') as string))
,md5(cast(nvl(ex_three                                   ,'') as string))
,md5(cast(nvl(org_id                                     ,'') as string))
,md5(cast(nvl(sett_id                                    ,'') as string))
,md5(cast(nvl(ex_four                                    ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type         ,'') as string))
,md5(cast(nvl(currency                                   ,'') as string))
,md5(cast(nvl(tax_rate                                   ,'') as string))
,md5(cast(nvl(contract_code                              ,'') as string))
,md5(cast(nvl(project_code                               ,'') as string))
,md5(cast(nvl(biz_association_id                         ,'') as string))
,md5(cast(nvl(composite_id                               ,'') as string))
,md5(cast(nvl(standby_field_one                          ,'') as string))
,md5(cast(nvl(standby_field_two                          ,'') as string))
,md5(cast(nvl(standby_field_three                        ,'') as string))
,md5(cast(nvl(standby_field_four                         ,'') as string))
,md5(cast(nvl(standby_field_five                         ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag      ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id          ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id          ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name        ,'') as string))
,md5(cast(nvl(last_dt                                    ,'') as string))
,md5(cast(nvl(bill_code                                  ,'') as string))
,md5(cast(nvl(ex_five                                    ,'') as string))
,md5(cast(nvl(ex_six                                     ,'') as string))
,md5(cast(nvl(ex_seven                                   ,'') as string))
,md5(cast(nvl(ex_eight                                   ,'') as string))
,md5(cast(nvl(ex_nine                                    ,'') as string))
,md5(cast(nvl(ex_ten                                     ,'') as string))
,md5(cast(nvl(ex_eleven                                  ,'') as string))
,md5(cast(nvl(ex_twelve                                  ,'') as string))
,md5(cast(nvl(ex_thirteen                                ,'') as string))
,md5(cast(nvl(ex_fourteen                                ,'') as string))
,md5(cast(nvl(ex_fifteen                                 ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src      ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                         ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                       ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                          ,'') as string))
,md5(cast(nvl(origin_dt                                  ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src     ,'') as string))
,md5(cast(nvl(dept_id                                    ,'') as string))
--,md5(cast(nvl(spec_type_cd                               ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_h_d
where end_dt='2022-06-15'
group by end_dt
;

--dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_s_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                  ,'') as string))
--,md5(cast(nvl(ele_md5                                   ,'') as string))
,md5(cast(nvl(change_flag                               ,'') as string))
,md5(cast(nvl(data_source_em                            ,'') as string))
,md5(cast(nvl(origin_id                                 ,'') as string))
,md5(cast(nvl(biz_id                                    ,'') as string))
,md5(cast(nvl(biz_type                                  ,'') as string))
,md5(cast(nvl(fee_id                                    ,'') as string))
,md5(cast(nvl(fee_type                                  ,'') as string))
,md5(cast(nvl(product_id                                ,'') as string))
,md5(cast(nvl(product_name                              ,'') as string))
,md5(cast(nvl(customer_id                               ,'') as string))
,md5(cast(nvl(customer_name                             ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id             ,'') as string))
,md5(cast(nvl(direction                                 ,'') as string))
,md5(cast(nvl(amount                                    ,'') as string))
,md5(cast(nvl(sett_amount                               ,'') as string))
,md5(cast(nvl(need_invoice                              ,'') as string))
,md5(cast(nvl(source_id                                 ,'') as string))
,md5(cast(nvl(rule_id                                   ,'') as string))
,md5(cast(nvl(status                                    ,'') as string))
,md5(cast(nvl(operator                                  ,'') as string))
,md5(cast(nvl(data_type                                 ,'') as string))
,md5(cast(nvl(trans_time                                ,'') as string))
,md5(cast(nvl(yn_flag                                   ,'') as string))
,md5(cast(nvl(remark                                    ,'') as string))
,md5(cast(nvl(create_user                               ,'') as string))
,md5(cast(nvl(update_user                               ,'') as string))
,md5(cast(nvl(create_dt                                 ,'') as string))
,md5(cast(nvl(update_dt                                 ,'') as string))
,md5(cast(nvl(customer_type                             ,'') as string))
,md5(cast(nvl(card_id                                   ,'') as string))
,md5(cast(nvl(pay_channel_type                          ,'') as string))
,md5(cast(nvl(pay_channel_id                            ,'') as string))
,md5(cast(nvl(order_id                                  ,'') as string))
,md5(cast(nvl(ex_one                                    ,'') as string))
,md5(cast(nvl(ex_two                                    ,'') as string))
,md5(cast(nvl(ex_three                                  ,'') as string))
,md5(cast(nvl(org_id                                    ,'') as string))
,md5(cast(nvl(sett_id                                   ,'') as string))
,md5(cast(nvl(ex_four                                   ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type        ,'') as string))
,md5(cast(nvl(currency                                  ,'') as string))
,md5(cast(nvl(tax_rate                                  ,'') as string))
,md5(cast(nvl(contract_code                             ,'') as string))
,md5(cast(nvl(project_code                              ,'') as string))
,md5(cast(nvl(biz_association_id                        ,'') as string))
,md5(cast(nvl(composite_id                              ,'') as string))
,md5(cast(nvl(standby_field_one                         ,'') as string))
,md5(cast(nvl(standby_field_two                         ,'') as string))
,md5(cast(nvl(standby_field_three                       ,'') as string))
,md5(cast(nvl(standby_field_four                        ,'') as string))
,md5(cast(nvl(standby_field_five                        ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag     ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id         ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id         ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name       ,'') as string))
,md5(cast(nvl(last_dt                                   ,'') as string))
,md5(cast(nvl(bill_code                                 ,'') as string))
,md5(cast(nvl(ex_five                                   ,'') as string))
,md5(cast(nvl(ex_six                                    ,'') as string))
,md5(cast(nvl(ex_seven                                  ,'') as string))
,md5(cast(nvl(ex_eight                                  ,'') as string))
,md5(cast(nvl(ex_nine                                   ,'') as string))
,md5(cast(nvl(ex_ten                                    ,'') as string))
,md5(cast(nvl(ex_eleven                                 ,'') as string))
,md5(cast(nvl(ex_twelve                                 ,'') as string))
,md5(cast(nvl(ex_thirteen                               ,'') as string))
,md5(cast(nvl(ex_fourteen                               ,'') as string))
,md5(cast(nvl(ex_fifteen                                ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src     ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                        ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                      ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                         ,'') as string))
,md5(cast(nvl(origin_dt                                 ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src    ,'') as string))
,md5(cast(nvl(dept_id                                   ,'') as string))
--,md5(cast(nvl(spec_type_cd                              ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_s_d
where dt='2022-06-15'
group by dt

--临时表校验
select count(*) as num,,sum(hash(
 md5(cast(nvl(clean_tag                ,'') as string))
,md5(cast(nvl(id                       ,0) as string))
,md5(cast(nvl(biz_id                   ,'') as string))
,md5(cast(nvl(biz_type                 ,'') as string))
,md5(cast(nvl(fee_id                   ,'') as string))
,md5(cast(nvl(fee_type                 ,'') as string))
,md5(cast(nvl(product_id               ,'') as string))
,md5(cast(nvl(product_name             ,'') as string))
,md5(cast(nvl(customer_id              ,'') as string))
,md5(cast(nvl(customer_name            ,'') as string))
,md5(cast(nvl(direction                ,'') as string))
,md5(cast(nvl(amount                   ,0) as string))
,md5(cast(nvl(sett_amount              ,0) as string))
,md5(cast(nvl(need_invoice             ,'') as string))
,md5(cast(nvl(source_id                ,'') as string))
,md5(cast(nvl(rule_id                  ,'') as string))
,md5(cast(nvl(status                   ,'') as string))
,md5(cast(nvl(operator                 ,'') as string))
,md5(cast(nvl(data_type                ,'') as string))
,md5(cast(nvl(data_time                ,'') as string))
,md5(cast(nvl(yn_flag                  ,'') as string))
,md5(cast(nvl(prov_flag                ,'') as string))
,md5(cast(nvl(remark                   ,'') as string))
,md5(cast(nvl(creator                  ,'') as string))
,md5(cast(nvl(editor                   ,'') as string))
,md5(cast(nvl(created_time             ,'') as string))
,md5(cast(nvl(modified_time            ,'') as string))
,md5(cast(nvl(customer_type            ,'') as string))
,md5(cast(nvl(card_id                  ,'') as string))
,md5(cast(nvl(pay_channel_type         ,'') as string))
,md5(cast(nvl(pay_channel_id           ,'') as string))
,md5(cast(nvl(order_id                 ,'') as string))
,md5(cast(nvl(ex_one                   ,'') as string))
,md5(cast(nvl(ex_two                   ,'') as string))
,md5(cast(nvl(ex_three                 ,'') as string))
,md5(cast(nvl(ex_four                  ,'') as string))
,md5(cast(nvl(org_id                   ,'') as string))
,md5(cast(nvl(unikey                   ,'') as string))
,md5(cast(nvl(sett_id                  ,'') as string))
,md5(cast(nvl(currency                 ,'') as string))
,md5(cast(nvl(tax_rate                 ,'') as string))
,md5(cast(nvl(contract_code            ,'') as string))
,md5(cast(nvl(project_code             ,'') as string))
,md5(cast(nvl(biz_association_id       ,'') as string))
,md5(cast(nvl(composite_id             ,'') as string))
,md5(cast(nvl(standby_field_one        ,'') as string))
,md5(cast(nvl(standby_field_two        ,'') as string))
,md5(cast(nvl(standby_field_three      ,'') as string))
,md5(cast(nvl(standby_field_four       ,'') as string))
,md5(cast(nvl(standby_field_five       ,'') as string))
,md5(cast(nvl(bill_code                ,'') as string))
,md5(cast(nvl(ex_five                  ,'') as string))
,md5(cast(nvl(ex_six                   ,'') as string))
,md5(cast(nvl(ex_seven                 ,'') as string))
,md5(cast(nvl(ex_eight                 ,'') as string))
,md5(cast(nvl(ex_nine                  ,'') as string))
,md5(cast(nvl(ex_ten                   ,'') as string))
,md5(cast(nvl(ex_eleven                ,'') as string))
,md5(cast(nvl(ex_twelve                ,'') as string))
,md5(cast(nvl(ex_thirteen              ,'') as string))
,md5(cast(nvl(ex_fourteen              ,'') as string))
,md5(cast(nvl(ex_fifteen               ,'') as string))
,md5(cast(nvl(customer_id_ex           ,'') as string))
,md5(cast(nvl(customer_id_ex_typ       ,'') as string))
,md5(cast(nvl(dxxjk_adv_bnk            ,'') as string))
,md5(cast(nvl(xjk_bizsys_mercht_id     ,'') as string))
,md5(cast(nvl(spe_val_map              ,'') as string))

)) as hash_num
from  dmf_tmp.tmp_fin_fee_detail_all_1_1 




--联合验证 
--dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d-4712-12-31
select a1.unikey,a1.hash_num,a2.hash_num as aa
from (select     unikey
                ,hash(
                     md5(cast(nvl(start_dt                                ,'') as string))
                    ,md5(cast(nvl(change_code                             ,'') as string))
                    ,md5(cast(nvl(ele_md5                                 ,'') as string))
                    ,md5(cast(nvl(unikey                                  ,'') as string))
                    ,md5(cast(nvl(data_source_em                          ,'') as string))
                    ,md5(cast(nvl(biz_id                                  ,'') as string))
                    ,md5(cast(nvl(biz_type                                ,'') as string))
                    ,md5(cast(nvl(fee_id                                  ,'') as string))
                    ,md5(cast(nvl(fee_type                                ,'') as string))
                    ,md5(cast(nvl(product_id                              ,'') as string))
                    ,md5(cast(nvl(product_name                            ,'') as string))
                    ,md5(cast(nvl(customer_id                             ,'') as string))
                    ,md5(cast(nvl(customer_name                           ,'') as string))
                    ,md5(cast(nvl(direction                               ,'') as string))
                    ,md5(cast(nvl(amount                                  ,0) as string))
                    ,md5(cast(nvl(sett_amount                             ,0) as string))
                    ,md5(cast(nvl(need_invoice                            ,'') as string))
                    ,md5(cast(nvl(source_id                               ,'') as string))
                    ,md5(cast(nvl(rule_id                                 ,'') as string))
                    ,md5(cast(nvl(status                                  ,'') as string))
                    ,md5(cast(nvl(operator                                ,'') as string))
                    ,md5(cast(nvl(data_type                               ,'') as string))
                    ,md5(cast(nvl(trans_time                              ,'') as string))
                    ,md5(cast(nvl(yn_flag                                 ,'') as string))
                    ,md5(cast(nvl(remark                                  ,'') as string))
                    ,md5(cast(nvl(create_user                             ,'') as string))
                    ,md5(cast(nvl(update_user                             ,'') as string))
                    ,md5(cast(nvl(create_dt                               ,'') as string))
                    ,md5(cast(nvl(update_dt                               ,'') as string))
                    ,md5(cast(nvl(customer_type                           ,'') as string))
                    ,md5(cast(nvl(card_id                                 ,'') as string))
                    ,md5(cast(nvl(pay_channel_type                        ,'') as string))
                    ,md5(cast(nvl(pay_channel_id                          ,'') as string))
                    ,md5(cast(nvl(order_id                                ,'') as string))
                    ,md5(cast(nvl(ex_one                                  ,'') as string))
                    ,md5(cast(nvl(ex_two                                  ,'') as string))
                    ,md5(cast(nvl(ex_three                                ,'') as string))
                    ,md5(cast(nvl(org_id                                  ,'') as string))
                    ,md5(cast(nvl(sett_id                                 ,'') as string))
                    ,md5(cast(nvl(ex_four                                 ,'') as string))
                    ,md5(cast(nvl(currency                                ,'') as string))
                    ,md5(cast(nvl(tax_rate                                ,'') as string))
                    ,md5(cast(nvl(contract_code                           ,'') as string))
                    ,md5(cast(nvl(project_code                            ,'') as string))
                    ,md5(cast(nvl(biz_association_id                      ,'') as string))
                    ,md5(cast(nvl(composite_id                            ,'') as string))
                    ,md5(cast(nvl(standby_field_one                       ,'') as string))
                    ,md5(cast(nvl(standby_field_two                       ,'') as string))
                    ,md5(cast(nvl(standby_field_three                     ,'') as string))
                    ,md5(cast(nvl(standby_field_four                      ,'') as string))
                    ,md5(cast(nvl(standby_field_five                      ,'') as string))
                    ,md5(cast(nvl(prov_flag                               ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_id       ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_merchant_id       ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_name     ,'') as string))
                    ,md5(cast(nvl(bill_code                               ,'') as string))
                    ,md5(cast(nvl(ex_five                                 ,'') as string))
                    ,md5(cast(nvl(ex_six                                  ,'') as string))
                    ,md5(cast(nvl(ex_seven                                ,'') as string))
                    ,md5(cast(nvl(ex_eight                                ,'') as string))
                    ,md5(cast(nvl(ex_nine                                 ,'') as string))
                    ,md5(cast(nvl(ex_ten                                  ,'') as string))
                    ,md5(cast(nvl(ex_eleven                               ,'') as string))
                    ,md5(cast(nvl(ex_twelve                               ,'') as string))
                    ,md5(cast(nvl(ex_thirteen                             ,'') as string))
                    ,md5(cast(nvl(ex_fourteen                             ,'') as string))
                    ,md5(cast(nvl(ex_fifteen                              ,'') as string))
                    ,md5(cast(nvl(accti_biz_line_cd                       ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id           ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_type      ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag   ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_all_src   ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src  ,'') as string))
                    ,md5(cast(nvl(dept_id                                 ,'') as string))
                    ,md5(cast(nvl(spec_type_cd                            ,'') as string))
                    ,md5(cast(nvl(spe_val_map                             ,'') as string))
                ) as hash_num
      from dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d
	  where end_dt='4712-12-31'
     ) a1 
left join (select unikey
                ,hash(
                     md5(cast(nvl(start_dt                                ,'') as string))
                    ,md5(cast(nvl(change_code                             ,'') as string))
                    ,md5(cast(nvl(ele_md5                                 ,'') as string))
                    ,md5(cast(nvl(unikey                                  ,'') as string))
                    ,md5(cast(nvl(data_source_em                          ,'') as string))
                    ,md5(cast(nvl(biz_id                                  ,'') as string))
                    ,md5(cast(nvl(biz_type                                ,'') as string))
                    ,md5(cast(nvl(fee_id                                  ,'') as string))
                    ,md5(cast(nvl(fee_type                                ,'') as string))
                    ,md5(cast(nvl(product_id                              ,'') as string))
                    ,md5(cast(nvl(product_name                            ,'') as string))
                    ,md5(cast(nvl(customer_id                             ,'') as string))
                    ,md5(cast(nvl(customer_name                           ,'') as string))
                    ,md5(cast(nvl(direction                               ,'') as string))
                    ,md5(cast(nvl(amount                                  ,0) as string))
                    ,md5(cast(nvl(sett_amount                             ,0) as string))
                    ,md5(cast(nvl(need_invoice                            ,'') as string))
                    ,md5(cast(nvl(source_id                               ,'') as string))
                    ,md5(cast(nvl(rule_id                                 ,'') as string))
                    ,md5(cast(nvl(status                                  ,'') as string))
                    ,md5(cast(nvl(operator                                ,'') as string))
                    ,md5(cast(nvl(data_type                               ,'') as string))
                    ,md5(cast(nvl(trans_time                              ,'') as string))
                    ,md5(cast(nvl(yn_flag                                 ,'') as string))
                    ,md5(cast(nvl(remark                                  ,'') as string))
                    ,md5(cast(nvl(create_user                             ,'') as string))
                    ,md5(cast(nvl(update_user                             ,'') as string))
                    ,md5(cast(nvl(create_dt                               ,'') as string))
                    ,md5(cast(nvl(update_dt                               ,'') as string))
                    ,md5(cast(nvl(customer_type                           ,'') as string))
                    ,md5(cast(nvl(card_id                                 ,'') as string))
                    ,md5(cast(nvl(pay_channel_type                        ,'') as string))
                    ,md5(cast(nvl(pay_channel_id                          ,'') as string))
                    ,md5(cast(nvl(order_id                                ,'') as string))
                    ,md5(cast(nvl(ex_one                                  ,'') as string))
                    ,md5(cast(nvl(ex_two                                  ,'') as string))
                    ,md5(cast(nvl(ex_three                                ,'') as string))
                    ,md5(cast(nvl(org_id                                  ,'') as string))
                    ,md5(cast(nvl(sett_id                                 ,'') as string))
                    ,md5(cast(nvl(ex_four                                 ,'') as string))
                    ,md5(cast(nvl(currency                                ,'') as string))
                    ,md5(cast(nvl(tax_rate                                ,'') as string))
                    ,md5(cast(nvl(contract_code                           ,'') as string))
                    ,md5(cast(nvl(project_code                            ,'') as string))
                    ,md5(cast(nvl(biz_association_id                      ,'') as string))
                    ,md5(cast(nvl(composite_id                            ,'') as string))
                    ,md5(cast(nvl(standby_field_one                       ,'') as string))
                    ,md5(cast(nvl(standby_field_two                       ,'') as string))
                    ,md5(cast(nvl(standby_field_three                     ,'') as string))
                    ,md5(cast(nvl(standby_field_four                      ,'') as string))
                    ,md5(cast(nvl(standby_field_five                      ,'') as string))
                    ,md5(cast(nvl(prov_flag                               ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_id       ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_merchant_id       ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_name     ,'') as string))
                    ,md5(cast(nvl(bill_code                               ,'') as string))
                    ,md5(cast(nvl(ex_five                                 ,'') as string))
                    ,md5(cast(nvl(ex_six                                  ,'') as string))
                    ,md5(cast(nvl(ex_seven                                ,'') as string))
                    ,md5(cast(nvl(ex_eight                                ,'') as string))
                    ,md5(cast(nvl(ex_nine                                 ,'') as string))
                    ,md5(cast(nvl(ex_ten                                  ,'') as string))
                    ,md5(cast(nvl(ex_eleven                               ,'') as string))
                    ,md5(cast(nvl(ex_twelve                               ,'') as string))
                    ,md5(cast(nvl(ex_thirteen                             ,'') as string))
                    ,md5(cast(nvl(ex_fourteen                             ,'') as string))
                    ,md5(cast(nvl(ex_fifteen                              ,'') as string))
                    ,md5(cast(nvl(accti_biz_line_cd                       ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id           ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_type      ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag   ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_all_src   ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src  ,'') as string))
                    ,md5(cast(nvl(dept_id                                 ,'') as string))
                    ,md5(cast(nvl(spec_type_cd                            ,'') as string))
                    ,md5(cast(nvl(spe_val_map                             ,'') as string))
                ) as hash_num
           from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01
		   where end_dt='4712-12-31'
          ) a2
       on  a1.unikey = a2.unikey
	where  a1.hash_num != a2.hash_num
	

--ele_md5、change_code 不一致问题
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d
where end_dt='4712-12-31'
and unikey in('bx_slicer_1000000237246259201347497660537626625100000023724625921','bx_slicer_100000061294063618210108073682818101419716100000061294063619')
;
select * from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01
where end_dt='4712-12-31'
and unikey in('bx_slicer_1000000237246259201347497660537626625100000023724625921','bx_slicer_100000061294063618210108073682818101419716100000061294063619')
;

--spec_type_cd 内部字段顺序问题。例如：dmf_dept,dmf_tax 与 dmf_tax,dmf_dept; dmf_product,dmf_tax 与 dmf_tax,dmf_product
--collect_set外面嵌套 sort_array解决
select * from dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d
where end_dt='4712-12-31'
and unikey in('fin_fee_detail_8283007035463','fin_fee_detail_8283010284580','fin_fee_detail_8283011525086','fin_fee_detail_8283013667814','fin_fee_detail_8282875498001','fin_fee_detail_8282995939688','fin_fee_detail_8283011697573','fin_fee_detail_8283019532823','fin_fee_detail_1663001121550','fin_fee_detail_1663001126005','fin_fee_detail_8283013169402','fin_fee_detail_8283017638683','fin_fee_detail_8282923645901','fin_fee_detail_8283009849549','fin_fee_detail_8283011688268','fin_fee_detail_8282891731596','fin_fee_detail_8283000683986','fin_fee_detail_8283001156395','fin_fee_detail_8283000683988','fin_fee_detail_8283013177546','fin_fee_detail_8283013905213','fin_fee_detail_8282946808721','fin_fee_detail_8282995577339','fin_fee_detail_8283009508600','fin_fee_detail_1662804839365','fin_fee_detail_8283003632336','fin_fee_detail_8283010119776','fin_fee_detail_8283013283964','fin_fee_detail_8283016683514','fin_fee_detail_8283020229205','fin_fee_detail_8283007551528','fin_fee_detail_8283009563585','fin_fee_detail_8283017413515','fin_fee_detail_8283013456739','fin_fee_detail_8283015206688','fin_fee_detail_8283017940427','fin_fee_detail_8283000683989','fin_fee_detail_8283013462216','fin_fee_detail_8283013905214','fin_fee_detail_8282937468132','fin_fee_detail_8283012285806','fin_fee_detail_8283019453024','fin_fee_detail_8283000674953','fin_fee_detail_8283001113729','fin_fee_detail_8283020547941','fin_fee_detail_8282995577395','fin_fee_detail_8283005129278','fin_fee_detail_8283012797419','fin_fee_detail_8283009140865','fin_fee_detail_8283014637750','fin_fee_detail_8283021042659','fin_fee_detail_8282939722697','fin_fee_detail_8283006322673','fin_fee_detail_8283021890533','fin_fee_detail_1662946533730','fin_fee_detail_8283010499399','fin_fee_detail_8283010594780','fin_fee_detail_8282900605653','fin_fee_detail_8283006587133','fin_fee_detail_8283010533658','fin_fee_detail_8282928126361','fin_fee_detail_8283007035477','fin_fee_detail_8283011508666','fin_fee_detail_8283006480243','fin_fee_detail_8283006806971','fin_fee_detail_8283019741953','fin_fee_detail_1662999377040','fin_fee_detail_8283009856534','fin_fee_detail_8283011148476','fin_fee_detail_1662937138959','fin_fee_detail_8283015898432','fin_fee_detail_1662999377091','fin_fee_detail_1662999620441','fin_fee_detail_8282995577262','fin_fee_detail_8282999636710','fin_fee_detail_8282995577389','fin_fee_detail_8283021325015','fin_fee_detail_1662804832442','fin_fee_detail_8283013210417','fin_fee_detail_1663017681640','fin_fee_detail_8283009856521','fin_fee_detail_1662999377081','fin_fee_detail_8283010541619','fin_fee_detail_1662999377086','fin_fee_detail_1662999620436','fin_fee_detail_1662999620447','fin_fee_detail_8283009087765','fin_fee_detail_1662875485313','fin_fee_detail_8283001349423','fin_fee_detail_8283007035564','fin_fee_detail_8283010458264','fin_fee_detail_1663000855654','fin_fee_detail_8283012342525','fin_fee_detail_8283005825030','fin_fee_detail_8283007035475','fin_fee_detail_8282995577241','fin_fee_detail_8282995577359','fin_fee_detail_8282995577249','fin_fee_detail_8283014412673','fin_fee_detail_8283002759222')
;
select * from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_h_d_tmp_01
where end_dt='4712-12-31'
and unikey in('fin_fee_detail_8283007035463','fin_fee_detail_8283010284580','fin_fee_detail_8283011525086','fin_fee_detail_8283013667814','fin_fee_detail_8282875498001','fin_fee_detail_8282995939688','fin_fee_detail_8283011697573','fin_fee_detail_8283019532823','fin_fee_detail_1663001121550','fin_fee_detail_1663001126005','fin_fee_detail_8283013169402','fin_fee_detail_8283017638683','fin_fee_detail_8282923645901','fin_fee_detail_8283009849549','fin_fee_detail_8283011688268','fin_fee_detail_8282891731596','fin_fee_detail_8283000683986','fin_fee_detail_8283001156395','fin_fee_detail_8283000683988','fin_fee_detail_8283013177546','fin_fee_detail_8283013905213','fin_fee_detail_8282946808721','fin_fee_detail_8282995577339','fin_fee_detail_8283009508600','fin_fee_detail_1662804839365','fin_fee_detail_8283003632336','fin_fee_detail_8283010119776','fin_fee_detail_8283013283964','fin_fee_detail_8283016683514','fin_fee_detail_8283020229205','fin_fee_detail_8283007551528','fin_fee_detail_8283009563585','fin_fee_detail_8283017413515','fin_fee_detail_8283013456739','fin_fee_detail_8283015206688','fin_fee_detail_8283017940427','fin_fee_detail_8283000683989','fin_fee_detail_8283013462216','fin_fee_detail_8283013905214','fin_fee_detail_8282937468132','fin_fee_detail_8283012285806','fin_fee_detail_8283019453024','fin_fee_detail_8283000674953','fin_fee_detail_8283001113729','fin_fee_detail_8283020547941','fin_fee_detail_8282995577395','fin_fee_detail_8283005129278','fin_fee_detail_8283012797419','fin_fee_detail_8283009140865','fin_fee_detail_8283014637750','fin_fee_detail_8283021042659','fin_fee_detail_8282939722697','fin_fee_detail_8283006322673','fin_fee_detail_8283021890533','fin_fee_detail_1662946533730','fin_fee_detail_8283010499399','fin_fee_detail_8283010594780','fin_fee_detail_8282900605653','fin_fee_detail_8283006587133','fin_fee_detail_8283010533658','fin_fee_detail_8282928126361','fin_fee_detail_8283007035477','fin_fee_detail_8283011508666','fin_fee_detail_8283006480243','fin_fee_detail_8283006806971','fin_fee_detail_8283019741953','fin_fee_detail_1662999377040','fin_fee_detail_8283009856534','fin_fee_detail_8283011148476','fin_fee_detail_1662937138959','fin_fee_detail_8283015898432','fin_fee_detail_1662999377091','fin_fee_detail_1662999620441','fin_fee_detail_8282995577262','fin_fee_detail_8282999636710','fin_fee_detail_8282995577389','fin_fee_detail_8283021325015','fin_fee_detail_1662804832442','fin_fee_detail_8283013210417','fin_fee_detail_1663017681640','fin_fee_detail_8283009856521','fin_fee_detail_1662999377081','fin_fee_detail_8283010541619','fin_fee_detail_1662999377086','fin_fee_detail_1662999620436','fin_fee_detail_1662999620447','fin_fee_detail_8283009087765','fin_fee_detail_1662875485313','fin_fee_detail_8283001349423','fin_fee_detail_8283007035564','fin_fee_detail_8283010458264','fin_fee_detail_1663000855654','fin_fee_detail_8283012342525','fin_fee_detail_8283005825030','fin_fee_detail_8283007035475','fin_fee_detail_8282995577241','fin_fee_detail_8282995577359','fin_fee_detail_8282995577249','fin_fee_detail_8283014412673','fin_fee_detail_8283002759222')
;


--collect_set 排序解决
use dmf_dev;
drop table if exists dmf_dev.renxiaowei7_20220617_tmp_01;
create table dmf_dev.renxiaowei7_20220617_tmp_01(
     id string
    ,typecd string
    ,result_val string
);

insert into dmf_dev.renxiaowei7_20220617_tmp_01
select '100' as id,'dmf_tax'     as typecd,'0.06'    as result_val from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d union all 
select '100' as id,'dmf_product' as typecd,'300100'  as result_val from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d union all 
select '200' as id,'dmf_tax'     as typecd,'0.13'    as result_val from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d union all 
select '200' as id,'dmf_dept'    as typecd,'1001100' as result_val from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d 
;

select * from dmf_dev.renxiaowei7_20220617_tmp_01;

select     id,concat_ws(',',collect_set(typecd) ) as spec_type_cd
          ,concat_ws(','
                    ,collect_list(
                         concat(
                              typecd
                             ,if(nvl(typecd,'')!='',':','')
                             ,result_val
                         )
                     )
                    ) as conn_spe_cols
from dmf_dev.renxiaowei7_20220617_tmp_01
group by id
;

select     id,concat_ws(',',sort_array(collect_set(typecd)) ) as spec_type_cd
          ,concat_ws(','
                    ,collect_list(
                         concat(
                              typecd
                             ,if(nvl(typecd,'')!='',':','')
                             ,result_val
                         )
                     )
                    ) as conn_spe_cols
from dmf_dev.renxiaowei7_20220617_tmp_01
group by id
;


	
--dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d-4712-12-31
select a1.unikey,a1.change_flag,a1.hash_num,a2.hash_num as aa
from (select     unikey,change_flag
                ,hash(
                    -- md5(cast(nvl(ele_md5                                ,'') as string))
                    --,
					 md5(cast(nvl(unikey                                 ,'') as string))
                    ,md5(cast(nvl(data_source_em                         ,'') as string))
                    ,md5(cast(nvl(biz_id                                 ,'') as string))
                    ,md5(cast(nvl(biz_type                               ,'') as string))
                    ,md5(cast(nvl(fee_id                                 ,'') as string))
                    ,md5(cast(nvl(fee_type                               ,'') as string))
                    ,md5(cast(nvl(product_id                             ,'') as string))
                    ,md5(cast(nvl(product_name                           ,'') as string))
                    ,md5(cast(nvl(customer_id                            ,'') as string))
                    ,md5(cast(nvl(customer_name                          ,'') as string))
                    ,md5(cast(nvl(direction                              ,'') as string))
                    ,md5(cast(nvl(amount                                 ,0) as string))
                    ,md5(cast(nvl(sett_amount                            ,0) as string))
                    ,md5(cast(nvl(need_invoice                           ,'') as string))
                    ,md5(cast(nvl(source_id                              ,'') as string))
                    ,md5(cast(nvl(rule_id                                ,'') as string))
                    ,md5(cast(nvl(status                                 ,'') as string))
                    ,md5(cast(nvl(operator                               ,'') as string))
                    ,md5(cast(nvl(data_type                              ,'') as string))
                    ,md5(cast(nvl(trans_time                             ,'') as string))
                    ,md5(cast(nvl(yn_flag                                ,'') as string))
                    ,md5(cast(nvl(remark                                 ,'') as string))
                    ,md5(cast(nvl(create_user                            ,'') as string))
                    ,md5(cast(nvl(update_user                            ,'') as string))
                    ,md5(cast(nvl(create_dt                              ,'') as string))
                    ,md5(cast(nvl(update_dt                              ,'') as string))
                    ,md5(cast(nvl(customer_type                          ,'') as string))
                    ,md5(cast(nvl(card_id                                ,'') as string))
                    ,md5(cast(nvl(pay_channel_type                       ,'') as string))
                    ,md5(cast(nvl(pay_channel_id                         ,'') as string))
                    ,md5(cast(nvl(order_id                               ,'') as string))
                    ,md5(cast(nvl(ex_one                                 ,'') as string))
                    ,md5(cast(nvl(ex_two                                 ,'') as string))
                    ,md5(cast(nvl(ex_three                               ,'') as string))
                    ,md5(cast(nvl(org_id                                 ,'') as string))
                    ,md5(cast(nvl(sett_id                                ,'') as string))
                    ,md5(cast(nvl(ex_four                                ,'') as string))
                    ,md5(cast(nvl(currency                               ,'') as string))
                    ,md5(cast(nvl(tax_rate                               ,'') as string))
                    ,md5(cast(nvl(contract_code                          ,'') as string))
                    ,md5(cast(nvl(project_code                           ,'') as string))
                    ,md5(cast(nvl(biz_association_id                     ,'') as string))
                    ,md5(cast(nvl(composite_id                           ,'') as string))
                    ,md5(cast(nvl(standby_field_one                      ,'') as string))
                    ,md5(cast(nvl(standby_field_two                      ,'') as string))
                    ,md5(cast(nvl(standby_field_three                    ,'') as string))
                    ,md5(cast(nvl(standby_field_four                     ,'') as string))
                    ,md5(cast(nvl(standby_field_five                     ,'') as string))
                    ,md5(cast(nvl(prov_flag                              ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_merchant_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_name    ,'') as string))
                    ,md5(cast(nvl(last_dt                                ,'') as string))
                    ,md5(cast(nvl(bill_code                              ,'') as string))
                    ,md5(cast(nvl(ex_five                                ,'') as string))
                    ,md5(cast(nvl(ex_six                                 ,'') as string))
                    ,md5(cast(nvl(ex_seven                               ,'') as string))
                    ,md5(cast(nvl(ex_eight                               ,'') as string))
                    ,md5(cast(nvl(ex_nine                                ,'') as string))
                    ,md5(cast(nvl(ex_ten                                 ,'') as string))
                    ,md5(cast(nvl(ex_eleven                              ,'') as string))
                    ,md5(cast(nvl(ex_twelve                              ,'') as string))
                    ,md5(cast(nvl(ex_thirteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fourteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fifteen                             ,'') as string))
                    ,md5(cast(nvl(accti_biz_line_cd                      ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id          ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_type     ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_all_src  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src ,'') as string))
                    ,md5(cast(nvl(dept_id                                ,'') as string))
                    ,md5(cast(nvl(spec_type_cd                           ,'') as string))
                    ,md5(cast(nvl(change_flag                            ,'') as string))
                    ) as hash_num
      from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
	  where dt='2022-06-15'
     ) a1 
left join (select unikey,change_flag
                ,hash(
                    -- md5(cast(nvl(ele_md5                                ,'') as string))
                    --,
					 md5(cast(nvl(unikey                                 ,'') as string))
                    ,md5(cast(nvl(data_source_em                         ,'') as string))
                    ,md5(cast(nvl(biz_id                                 ,'') as string))
                    ,md5(cast(nvl(biz_type                               ,'') as string))
                    ,md5(cast(nvl(fee_id                                 ,'') as string))
                    ,md5(cast(nvl(fee_type                               ,'') as string))
                    ,md5(cast(nvl(product_id                             ,'') as string))
                    ,md5(cast(nvl(product_name                           ,'') as string))
                    ,md5(cast(nvl(customer_id                            ,'') as string))
                    ,md5(cast(nvl(customer_name                          ,'') as string))
                    ,md5(cast(nvl(direction                              ,'') as string))
                    ,md5(cast(nvl(amount                                 ,0) as string))
                    ,md5(cast(nvl(sett_amount                            ,0) as string))
                    ,md5(cast(nvl(need_invoice                           ,'') as string))
                    ,md5(cast(nvl(source_id                              ,'') as string))
                    ,md5(cast(nvl(rule_id                                ,'') as string))
                    ,md5(cast(nvl(status                                 ,'') as string))
                    ,md5(cast(nvl(operator                               ,'') as string))
                    ,md5(cast(nvl(data_type                              ,'') as string))
                    ,md5(cast(nvl(trans_time                             ,'') as string))
                    ,md5(cast(nvl(yn_flag                                ,'') as string))
                    ,md5(cast(nvl(remark                                 ,'') as string))
                    ,md5(cast(nvl(create_user                            ,'') as string))
                    ,md5(cast(nvl(update_user                            ,'') as string))
                    ,md5(cast(nvl(create_dt                              ,'') as string))
                    ,md5(cast(nvl(update_dt                              ,'') as string))
                    ,md5(cast(nvl(customer_type                          ,'') as string))
                    ,md5(cast(nvl(card_id                                ,'') as string))
                    ,md5(cast(nvl(pay_channel_type                       ,'') as string))
                    ,md5(cast(nvl(pay_channel_id                         ,'') as string))
                    ,md5(cast(nvl(order_id                               ,'') as string))
                    ,md5(cast(nvl(ex_one                                 ,'') as string))
                    ,md5(cast(nvl(ex_two                                 ,'') as string))
                    ,md5(cast(nvl(ex_three                               ,'') as string))
                    ,md5(cast(nvl(org_id                                 ,'') as string))
                    ,md5(cast(nvl(sett_id                                ,'') as string))
                    ,md5(cast(nvl(ex_four                                ,'') as string))
                    ,md5(cast(nvl(currency                               ,'') as string))
                    ,md5(cast(nvl(tax_rate                               ,'') as string))
                    ,md5(cast(nvl(contract_code                          ,'') as string))
                    ,md5(cast(nvl(project_code                           ,'') as string))
                    ,md5(cast(nvl(biz_association_id                     ,'') as string))
                    ,md5(cast(nvl(composite_id                           ,'') as string))
                    ,md5(cast(nvl(standby_field_one                      ,'') as string))
                    ,md5(cast(nvl(standby_field_two                      ,'') as string))
                    ,md5(cast(nvl(standby_field_three                    ,'') as string))
                    ,md5(cast(nvl(standby_field_four                     ,'') as string))
                    ,md5(cast(nvl(standby_field_five                     ,'') as string))
                    ,md5(cast(nvl(prov_flag                              ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_merchant_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_name    ,'') as string))
                    ,md5(cast(nvl(last_dt                                ,'') as string))
                    ,md5(cast(nvl(bill_code                              ,'') as string))
                    ,md5(cast(nvl(ex_five                                ,'') as string))
                    ,md5(cast(nvl(ex_six                                 ,'') as string))
                    ,md5(cast(nvl(ex_seven                               ,'') as string))
                    ,md5(cast(nvl(ex_eight                               ,'') as string))
                    ,md5(cast(nvl(ex_nine                                ,'') as string))
                    ,md5(cast(nvl(ex_ten                                 ,'') as string))
                    ,md5(cast(nvl(ex_eleven                              ,'') as string))
                    ,md5(cast(nvl(ex_twelve                              ,'') as string))
                    ,md5(cast(nvl(ex_thirteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fourteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fifteen                             ,'') as string))
                    ,md5(cast(nvl(accti_biz_line_cd                      ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id          ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_type     ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_all_src  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src ,'') as string))
                    ,md5(cast(nvl(dept_id                                ,'') as string))
                    ,md5(cast(nvl(spec_type_cd                           ,'') as string))
                    ,md5(cast(nvl(change_flag                            ,'') as string))
                    ) as hash_num
           from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01
	       where dt='2022-06-15'
          ) a2
       on  a1.unikey = a2.unikey
	  and  a1.change_flag = a2.change_flag
	where  a1.hash_num != a2.hash_num
	
	
--ele_md5 不一致问题
select * from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
where dt='2022-06-15'
and unikey in ('bx_slicer_147310673735901184220614090863973066416676147310673735901185','bx_slicer_147311107818106880220615090004113075315508147311107818106881')
;
select * from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01
where dt='2022-06-15'
and unikey in ('bx_slicer_147310673735901184220614090863973066416676147310673735901185','bx_slicer_147311107818106880220615090004113075315508147311107818106881')

--spec_type_cd 内部字段顺序问题。例如：dmf_dept,dmf_tax 与 dmf_tax,dmf_dept
select * from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
where dt='2022-06-15'
and unikey in ('fin_fee_detail_8283020976551'
,'fin_fee_detail_8283021042659'
,'fin_fee_detail_8283021047124'
,'fin_fee_detail_8283022019861'
,'fin_fee_detail_8283022060092'
,'fin_fee_detail_8283022105265'
,'fin_fee_detail_8283021033403'
,'fin_fee_detail_8283021070833'
,'fin_fee_detail_8283021605123'
,'fin_fee_detail_8283021871492'
,'fin_fee_detail_8283021873582'
,'fin_fee_detail_8283022088949'
,'fin_fee_detail_8283020245116'
,'fin_fee_detail_8283021325015'
,'fin_fee_detail_8283021890533'
,'fin_fee_detail_8283021890537'
,'fin_fee_detail_8283021906261'
,'fin_fee_detail_8283021940230'
,'fin_fee_detail_8283021999678'
,'fin_fee_detail_8283022104383'
,'fin_fee_detail_8283020245119'
,'fin_fee_detail_8283020547941'
,'fin_fee_detail_8283021035054'
,'fin_fee_detail_8283021042410'
,'fin_fee_detail_8283021045695'
,'fin_fee_detail_8283021931529'
,'fin_fee_detail_8283021976724'
,'fin_fee_detail_8283022096144'
)
;

select * from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01
where dt='2022-06-15'
and unikey in ('fin_fee_detail_8283020976551'
,'fin_fee_detail_8283021042659'
,'fin_fee_detail_8283021047124'
,'fin_fee_detail_8283022019861'
,'fin_fee_detail_8283022060092'
,'fin_fee_detail_8283022105265'
,'fin_fee_detail_8283021033403'
,'fin_fee_detail_8283021070833'
,'fin_fee_detail_8283021605123'
,'fin_fee_detail_8283021871492'
,'fin_fee_detail_8283021873582'
,'fin_fee_detail_8283022088949'
,'fin_fee_detail_8283020245116'
,'fin_fee_detail_8283021325015'
,'fin_fee_detail_8283021890533'
,'fin_fee_detail_8283021890537'
,'fin_fee_detail_8283021906261'
,'fin_fee_detail_8283021940230'
,'fin_fee_detail_8283021999678'
,'fin_fee_detail_8283022104383'
,'fin_fee_detail_8283020245119'
,'fin_fee_detail_8283020547941'
,'fin_fee_detail_8283021035054'
,'fin_fee_detail_8283021042410'
,'fin_fee_detail_8283021045695'
,'fin_fee_detail_8283021931529'
,'fin_fee_detail_8283021976724'
,'fin_fee_detail_8283022096144'
)
;




select a1.unikey,a1.change_flag,a1.hash_num,a2.hash_num as aa
from (select     unikey,change_flag
                ,hash(
                    -- md5(cast(nvl(ele_md5                                ,'') as string))
                    --,
					 md5(cast(nvl(unikey                                 ,'') as string))
                    ,md5(cast(nvl(data_source_em                         ,'') as string))
                    ,md5(cast(nvl(biz_id                                 ,'') as string))
                    ,md5(cast(nvl(biz_type                               ,'') as string))
                    ,md5(cast(nvl(fee_id                                 ,'') as string))
                    ,md5(cast(nvl(fee_type                               ,'') as string))
                    ,md5(cast(nvl(product_id                             ,'') as string))
                    ,md5(cast(nvl(product_name                           ,'') as string))
                    ,md5(cast(nvl(customer_id                            ,'') as string))
                    ,md5(cast(nvl(customer_name                          ,'') as string))
                    ,md5(cast(nvl(direction                              ,'') as string))
                    ,md5(cast(nvl(amount                                 ,0) as string))
                    ,md5(cast(nvl(sett_amount                            ,0) as string))
                    ,md5(cast(nvl(need_invoice                           ,'') as string))
                    ,md5(cast(nvl(source_id                              ,'') as string))
                    ,md5(cast(nvl(rule_id                                ,'') as string))
                    ,md5(cast(nvl(status                                 ,'') as string))
                    ,md5(cast(nvl(operator                               ,'') as string))
                    ,md5(cast(nvl(data_type                              ,'') as string))
                    ,md5(cast(nvl(trans_time                             ,'') as string))
                    ,md5(cast(nvl(yn_flag                                ,'') as string))
                    ,md5(cast(nvl(remark                                 ,'') as string))
                    ,md5(cast(nvl(create_user                            ,'') as string))
                    ,md5(cast(nvl(update_user                            ,'') as string))
                    ,md5(cast(nvl(create_dt                              ,'') as string))
                    ,md5(cast(nvl(update_dt                              ,'') as string))
                    ,md5(cast(nvl(customer_type                          ,'') as string))
                    ,md5(cast(nvl(card_id                                ,'') as string))
                    ,md5(cast(nvl(pay_channel_type                       ,'') as string))
                    ,md5(cast(nvl(pay_channel_id                         ,'') as string))
                    ,md5(cast(nvl(order_id                               ,'') as string))
                    ,md5(cast(nvl(ex_one                                 ,'') as string))
                    ,md5(cast(nvl(ex_two                                 ,'') as string))
                    ,md5(cast(nvl(ex_three                               ,'') as string))
                    ,md5(cast(nvl(org_id                                 ,'') as string))
                    ,md5(cast(nvl(sett_id                                ,'') as string))
                    ,md5(cast(nvl(ex_four                                ,'') as string))
                    ,md5(cast(nvl(currency                               ,'') as string))
                    ,md5(cast(nvl(tax_rate                               ,'') as string))
                    ,md5(cast(nvl(contract_code                          ,'') as string))
                    ,md5(cast(nvl(project_code                           ,'') as string))
                    ,md5(cast(nvl(biz_association_id                     ,'') as string))
                    ,md5(cast(nvl(composite_id                           ,'') as string))
                    ,md5(cast(nvl(standby_field_one                      ,'') as string))
                    ,md5(cast(nvl(standby_field_two                      ,'') as string))
                    ,md5(cast(nvl(standby_field_three                    ,'') as string))
                    ,md5(cast(nvl(standby_field_four                     ,'') as string))
                    ,md5(cast(nvl(standby_field_five                     ,'') as string))
                    ,md5(cast(nvl(prov_flag                              ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_merchant_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_name    ,'') as string))
                    ,md5(cast(nvl(last_dt                                ,'') as string))
                    ,md5(cast(nvl(bill_code                              ,'') as string))
                    ,md5(cast(nvl(ex_five                                ,'') as string))
                    ,md5(cast(nvl(ex_six                                 ,'') as string))
                    ,md5(cast(nvl(ex_seven                               ,'') as string))
                    ,md5(cast(nvl(ex_eight                               ,'') as string))
                    ,md5(cast(nvl(ex_nine                                ,'') as string))
                    ,md5(cast(nvl(ex_ten                                 ,'') as string))
                    ,md5(cast(nvl(ex_eleven                              ,'') as string))
                    ,md5(cast(nvl(ex_twelve                              ,'') as string))
                    ,md5(cast(nvl(ex_thirteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fourteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fifteen                             ,'') as string))
                    ,md5(cast(nvl(accti_biz_line_cd                      ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id          ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_type     ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_all_src  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src ,'') as string))
                    ,md5(cast(nvl(dept_id                                ,'') as string))
                    ,md5(cast(nvl(spec_type_cd                           ,'') as string))
                    ,md5(cast(nvl(change_flag                            ,'') as string))
                    ) as hash_num
      from dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d
	  where dt='2022-06-15'
     ) a1 
left join (select unikey,change_flag
                ,hash(
                    -- md5(cast(nvl(ele_md5                                ,'') as string))
                    --,
					 md5(cast(nvl(unikey                                 ,'') as string))
                    ,md5(cast(nvl(data_source_em                         ,'') as string))
                    ,md5(cast(nvl(biz_id                                 ,'') as string))
                    ,md5(cast(nvl(biz_type                               ,'') as string))
                    ,md5(cast(nvl(fee_id                                 ,'') as string))
                    ,md5(cast(nvl(fee_type                               ,'') as string))
                    ,md5(cast(nvl(product_id                             ,'') as string))
                    ,md5(cast(nvl(product_name                           ,'') as string))
                    ,md5(cast(nvl(customer_id                            ,'') as string))
                    ,md5(cast(nvl(customer_name                          ,'') as string))
                    ,md5(cast(nvl(direction                              ,'') as string))
                    ,md5(cast(nvl(amount                                 ,0) as string))
                    ,md5(cast(nvl(sett_amount                            ,0) as string))
                    ,md5(cast(nvl(need_invoice                           ,'') as string))
                    ,md5(cast(nvl(source_id                              ,'') as string))
                    ,md5(cast(nvl(rule_id                                ,'') as string))
                    ,md5(cast(nvl(status                                 ,'') as string))
                    ,md5(cast(nvl(operator                               ,'') as string))
                    ,md5(cast(nvl(data_type                              ,'') as string))
                    ,md5(cast(nvl(trans_time                             ,'') as string))
                    ,md5(cast(nvl(yn_flag                                ,'') as string))
                    ,md5(cast(nvl(remark                                 ,'') as string))
                    ,md5(cast(nvl(create_user                            ,'') as string))
                    ,md5(cast(nvl(update_user                            ,'') as string))
                    ,md5(cast(nvl(create_dt                              ,'') as string))
                    ,md5(cast(nvl(update_dt                              ,'') as string))
                    ,md5(cast(nvl(customer_type                          ,'') as string))
                    ,md5(cast(nvl(card_id                                ,'') as string))
                    ,md5(cast(nvl(pay_channel_type                       ,'') as string))
                    ,md5(cast(nvl(pay_channel_id                         ,'') as string))
                    ,md5(cast(nvl(order_id                               ,'') as string))
                    ,md5(cast(nvl(ex_one                                 ,'') as string))
                    ,md5(cast(nvl(ex_two                                 ,'') as string))
                    ,md5(cast(nvl(ex_three                               ,'') as string))
                    ,md5(cast(nvl(org_id                                 ,'') as string))
                    ,md5(cast(nvl(sett_id                                ,'') as string))
                    ,md5(cast(nvl(ex_four                                ,'') as string))
                    ,md5(cast(nvl(currency                               ,'') as string))
                    ,md5(cast(nvl(tax_rate                               ,'') as string))
                    ,md5(cast(nvl(contract_code                          ,'') as string))
                    ,md5(cast(nvl(project_code                           ,'') as string))
                    ,md5(cast(nvl(biz_association_id                     ,'') as string))
                    ,md5(cast(nvl(composite_id                           ,'') as string))
                    ,md5(cast(nvl(standby_field_one                      ,'') as string))
                    ,md5(cast(nvl(standby_field_two                      ,'') as string))
                    ,md5(cast(nvl(standby_field_three                    ,'') as string))
                    ,md5(cast(nvl(standby_field_four                     ,'') as string))
                    ,md5(cast(nvl(standby_field_five                     ,'') as string))
                    ,md5(cast(nvl(prov_flag                              ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_merchant_id      ,'') as string))
                    ,md5(cast(nvl(fee_principal_company_customer_name    ,'') as string))
                    ,md5(cast(nvl(last_dt                                ,'') as string))
                    ,md5(cast(nvl(bill_code                              ,'') as string))
                    ,md5(cast(nvl(ex_five                                ,'') as string))
                    ,md5(cast(nvl(ex_six                                 ,'') as string))
                    ,md5(cast(nvl(ex_seven                               ,'') as string))
                    ,md5(cast(nvl(ex_eight                               ,'') as string))
                    ,md5(cast(nvl(ex_nine                                ,'') as string))
                    ,md5(cast(nvl(ex_ten                                 ,'') as string))
                    ,md5(cast(nvl(ex_eleven                              ,'') as string))
                    ,md5(cast(nvl(ex_twelve                              ,'') as string))
                    ,md5(cast(nvl(ex_thirteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fourteen                            ,'') as string))
                    ,md5(cast(nvl(ex_fifteen                             ,'') as string))
                    ,md5(cast(nvl(accti_biz_line_cd                      ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id          ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_type     ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_id_all_src  ,'') as string))
                    ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src ,'') as string))
                    ,md5(cast(nvl(dept_id                                ,'') as string))
                    ,md5(cast(nvl(spec_type_cd                           ,'') as string))
                    ,md5(cast(nvl(change_flag                            ,'') as string))
                    ) as hash_num
           from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d_tmp_01
	       where dt='2022-06-15'
          ) a2
       on  a1.unikey = a2.unikey
	  and  a1.change_flag = a2.change_flag
	where  a1.hash_num != a2.hash_num
	
	
	
--dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_h_d-4712-12-31
select a1.origin_id,a1.hash_num,a2.hash_num as aa
from (select     origin_id
                ,hash(
                      md5(cast(nvl(start_dt                                   ,'') as string))
                     --,md5(cast(nvl(ele_md5                                    ,'') as string))
                     ,md5(cast(nvl(change_flag                                ,'') as string))
                     ,md5(cast(nvl(data_source_em                             ,'') as string))
                     ,md5(cast(nvl(origin_id                                  ,'') as string))
                     ,md5(cast(nvl(biz_id                                     ,'') as string))
                     ,md5(cast(nvl(biz_type                                   ,'') as string))
                     ,md5(cast(nvl(fee_id                                     ,'') as string))
                     ,md5(cast(nvl(fee_type                                   ,'') as string))
                     ,md5(cast(nvl(product_id                                 ,'') as string))
                     ,md5(cast(nvl(product_name                               ,'') as string))
                     ,md5(cast(nvl(customer_id                                ,'') as string))
                     ,md5(cast(nvl(customer_name                              ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id              ,'') as string))
                     ,md5(cast(nvl(direction                                  ,'') as string))
                     ,md5(cast(nvl(amount                                     ,'') as string))
                     ,md5(cast(nvl(sett_amount                                ,'') as string))
                     ,md5(cast(nvl(need_invoice                               ,'') as string))
                     ,md5(cast(nvl(source_id                                  ,'') as string))
                     ,md5(cast(nvl(rule_id                                    ,'') as string))
                     ,md5(cast(nvl(status                                     ,'') as string))
                     ,md5(cast(nvl(operator                                   ,'') as string))
                     ,md5(cast(nvl(data_type                                  ,'') as string))
                     ,md5(cast(nvl(trans_time                                 ,'') as string))
                     ,md5(cast(nvl(yn_flag                                    ,'') as string))
                     ,md5(cast(nvl(remark                                     ,'') as string))
                     ,md5(cast(nvl(create_user                                ,'') as string))
                     ,md5(cast(nvl(update_user                                ,'') as string))
                     ,md5(cast(nvl(create_dt                                  ,'') as string))
                     ,md5(cast(nvl(update_dt                                  ,'') as string))
                     ,md5(cast(nvl(customer_type                              ,'') as string))
                     ,md5(cast(nvl(card_id                                    ,'') as string))
                     ,md5(cast(nvl(pay_channel_type                           ,'') as string))
                     ,md5(cast(nvl(pay_channel_id                             ,'') as string))
                     ,md5(cast(nvl(order_id                                   ,'') as string))
                     ,md5(cast(nvl(ex_one                                     ,'') as string))
                     ,md5(cast(nvl(ex_two                                     ,'') as string))
                     ,md5(cast(nvl(ex_three                                   ,'') as string))
                     ,md5(cast(nvl(org_id                                     ,'') as string))
                     ,md5(cast(nvl(sett_id                                    ,'') as string))
                     ,md5(cast(nvl(ex_four                                    ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id_type         ,'') as string))
                     ,md5(cast(nvl(currency                                   ,'') as string))
                     ,md5(cast(nvl(tax_rate                                   ,'') as string))
                     ,md5(cast(nvl(contract_code                              ,'') as string))
                     ,md5(cast(nvl(project_code                               ,'') as string))
                     ,md5(cast(nvl(biz_association_id                         ,'') as string))
                     ,md5(cast(nvl(composite_id                               ,'') as string))
                     ,md5(cast(nvl(standby_field_one                          ,'') as string))
                     ,md5(cast(nvl(standby_field_two                          ,'') as string))
                     ,md5(cast(nvl(standby_field_three                        ,'') as string))
                     ,md5(cast(nvl(standby_field_four                         ,'') as string))
                     ,md5(cast(nvl(standby_field_five                         ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag      ,'') as string))
                     ,md5(cast(nvl(fee_principal_company_customer_id          ,'') as string))
                     ,md5(cast(nvl(fee_principal_company_merchant_id          ,'') as string))
                     ,md5(cast(nvl(fee_principal_company_customer_name        ,'') as string))
                     ,md5(cast(nvl(last_dt                                    ,'') as string))
                     ,md5(cast(nvl(bill_code                                  ,'') as string))
                     ,md5(cast(nvl(ex_five                                    ,'') as string))
                     ,md5(cast(nvl(ex_six                                     ,'') as string))
                     ,md5(cast(nvl(ex_seven                                   ,'') as string))
                     ,md5(cast(nvl(ex_eight                                   ,'') as string))
                     ,md5(cast(nvl(ex_nine                                    ,'') as string))
                     ,md5(cast(nvl(ex_ten                                     ,'') as string))
                     ,md5(cast(nvl(ex_eleven                                  ,'') as string))
                     ,md5(cast(nvl(ex_twelve                                  ,'') as string))
                     ,md5(cast(nvl(ex_thirteen                                ,'') as string))
                     ,md5(cast(nvl(ex_fourteen                                ,'') as string))
                     ,md5(cast(nvl(ex_fifteen                                 ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id_all_src      ,'') as string))
                     ,md5(cast(nvl(fst_cust_mercht_id                         ,'') as string))
                     ,md5(cast(nvl(accti_cust_mercht_id                       ,'') as string))
                     ,md5(cast(nvl(accti_biz_line_cd                          ,'') as string))
                     ,md5(cast(nvl(origin_dt                                  ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src     ,'') as string))
                     ,md5(cast(nvl(dept_id                                    ,'') as string))
                     --,md5(cast(nvl(spec_type_cd                               ,'') as string))
                     ) as hash_num
      from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_h_d
	  where end_dt='4712-12-31'
     ) a1 
left join (select origin_id
                ,hash(
                      md5(cast(nvl(start_dt                                   ,'') as string))
                     --,md5(cast(nvl(ele_md5                                    ,'') as string))
                     ,md5(cast(nvl(change_flag                                ,'') as string))
                     ,md5(cast(nvl(data_source_em                             ,'') as string))
                     ,md5(cast(nvl(origin_id                                  ,'') as string))
                     ,md5(cast(nvl(biz_id                                     ,'') as string))
                     ,md5(cast(nvl(biz_type                                   ,'') as string))
                     ,md5(cast(nvl(fee_id                                     ,'') as string))
                     ,md5(cast(nvl(fee_type                                   ,'') as string))
                     ,md5(cast(nvl(product_id                                 ,'') as string))
                     ,md5(cast(nvl(product_name                               ,'') as string))
                     ,md5(cast(nvl(customer_id                                ,'') as string))
                     ,md5(cast(nvl(customer_name                              ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id              ,'') as string))
                     ,md5(cast(nvl(direction                                  ,'') as string))
                     ,md5(cast(nvl(amount                                     ,'') as string))
                     ,md5(cast(nvl(sett_amount                                ,'') as string))
                     ,md5(cast(nvl(need_invoice                               ,'') as string))
                     ,md5(cast(nvl(source_id                                  ,'') as string))
                     ,md5(cast(nvl(rule_id                                    ,'') as string))
                     ,md5(cast(nvl(status                                     ,'') as string))
                     ,md5(cast(nvl(operator                                   ,'') as string))
                     ,md5(cast(nvl(data_type                                  ,'') as string))
                     ,md5(cast(nvl(trans_time                                 ,'') as string))
                     ,md5(cast(nvl(yn_flag                                    ,'') as string))
                     ,md5(cast(nvl(remark                                     ,'') as string))
                     ,md5(cast(nvl(create_user                                ,'') as string))
                     ,md5(cast(nvl(update_user                                ,'') as string))
                     ,md5(cast(nvl(create_dt                                  ,'') as string))
                     ,md5(cast(nvl(update_dt                                  ,'') as string))
                     ,md5(cast(nvl(customer_type                              ,'') as string))
                     ,md5(cast(nvl(card_id                                    ,'') as string))
                     ,md5(cast(nvl(pay_channel_type                           ,'') as string))
                     ,md5(cast(nvl(pay_channel_id                             ,'') as string))
                     ,md5(cast(nvl(order_id                                   ,'') as string))
                     ,md5(cast(nvl(ex_one                                     ,'') as string))
                     ,md5(cast(nvl(ex_two                                     ,'') as string))
                     ,md5(cast(nvl(ex_three                                   ,'') as string))
                     ,md5(cast(nvl(org_id                                     ,'') as string))
                     ,md5(cast(nvl(sett_id                                    ,'') as string))
                     ,md5(cast(nvl(ex_four                                    ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id_type         ,'') as string))
                     ,md5(cast(nvl(currency                                   ,'') as string))
                     ,md5(cast(nvl(tax_rate                                   ,'') as string))
                     ,md5(cast(nvl(contract_code                              ,'') as string))
                     ,md5(cast(nvl(project_code                               ,'') as string))
                     ,md5(cast(nvl(biz_association_id                         ,'') as string))
                     ,md5(cast(nvl(composite_id                               ,'') as string))
                     ,md5(cast(nvl(standby_field_one                          ,'') as string))
                     ,md5(cast(nvl(standby_field_two                          ,'') as string))
                     ,md5(cast(nvl(standby_field_three                        ,'') as string))
                     ,md5(cast(nvl(standby_field_four                         ,'') as string))
                     ,md5(cast(nvl(standby_field_five                         ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id_src_tag      ,'') as string))
                     ,md5(cast(nvl(fee_principal_company_customer_id          ,'') as string))
                     ,md5(cast(nvl(fee_principal_company_merchant_id          ,'') as string))
                     ,md5(cast(nvl(fee_principal_company_customer_name        ,'') as string))
                     ,md5(cast(nvl(last_dt                                    ,'') as string))
                     ,md5(cast(nvl(bill_code                                  ,'') as string))
                     ,md5(cast(nvl(ex_five                                    ,'') as string))
                     ,md5(cast(nvl(ex_six                                     ,'') as string))
                     ,md5(cast(nvl(ex_seven                                   ,'') as string))
                     ,md5(cast(nvl(ex_eight                                   ,'') as string))
                     ,md5(cast(nvl(ex_nine                                    ,'') as string))
                     ,md5(cast(nvl(ex_ten                                     ,'') as string))
                     ,md5(cast(nvl(ex_eleven                                  ,'') as string))
                     ,md5(cast(nvl(ex_twelve                                  ,'') as string))
                     ,md5(cast(nvl(ex_thirteen                                ,'') as string))
                     ,md5(cast(nvl(ex_fourteen                                ,'') as string))
                     ,md5(cast(nvl(ex_fifteen                                 ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_id_all_src      ,'') as string))
                     ,md5(cast(nvl(fst_cust_mercht_id                         ,'') as string))
                     ,md5(cast(nvl(accti_cust_mercht_id                       ,'') as string))
                     ,md5(cast(nvl(accti_biz_line_cd                          ,'') as string))
                     ,md5(cast(nvl(origin_dt                                  ,'') as string))
                     ,md5(cast(nvl(fee_customer_name_merchant_typ_all_src     ,'') as string))
                     ,md5(cast(nvl(dept_id                                    ,'') as string))
                     --,md5(cast(nvl(spec_type_cd                               ,'') as string))
                     ) as hash_num
           from dmf_tmp.renxiaowei7_20220616_dmfbc_bc_fi_fst_fee_detail_period_h_d_tmp_01
		   where end_dt='4712-12-31'
          ) a2
       on  a1.origin_id = a2.origin_id
	where  a1.hash_num != a2.hash_num
	
		
		
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;

select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(model_id          ,'') as string))
,md5(cast(nvl(biz_typ           ,'') as string))
,md5(cast(nvl(cap_typ           ,'') as string))
,md5(cast(nvl(field_01          ,'') as string))
,md5(cast(nvl(field_02          ,'') as string))
,md5(cast(nvl(field_03          ,'') as string))
,md5(cast(nvl(field_04          ,'') as string))
,md5(cast(nvl(field_05          ,'') as string))
,md5(cast(nvl(field_06          ,'') as string))
,md5(cast(nvl(field_07          ,'') as string))
,md5(cast(nvl(field_08          ,'') as string))
,md5(cast(nvl(data_source_em    ,'') as string))
,md5(cast(nvl(trans_type        ,'') as string))
,md5(cast(nvl(corp_role_typ     ,'') as string))
,md5(cast(nvl(mercht_01_role_typ,'') as string))
,md5(cast(nvl(mercht_02_role_typ,'') as string))
,md5(cast(nvl(impt_dt           ,'') as string))
,md5(cast(nvl(coef_para         ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d
where dt>='2022-01-01'
group by dt
;


use dmf_dev;
drop table if exists dmf_dev.renxiaowei7_20220614_tmp_01;
create table dmf_dev.renxiaowei7_20220614_tmp_01 like dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d;
insert into dmf_dev.renxiaowei7_20220614_tmp_01 partition(dt)
select * from dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d
where dt>='2022-06-01'
;

dmf_dev.renxiaowei7_20220614_tmp_01

dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d



select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;

select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(model_id                       ,'') as string))
,md5(cast(nvl(indx_id                        ,'') as string))
,md5(cast(nvl(src_sys                        ,'') as string))
,md5(cast(nvl(src_tab                        ,'') as string))
,md5(cast(nvl(change_flag                    ,'') as string))
,md5(cast(nvl(rev_data_orig_dt               ,'') as string))
,md5(cast(nvl(data_unikey                    ,'') as string))
,md5(cast(nvl(accti_biz_line_cd              ,'') as string))
,md5(cast(nvl(accti_prod_cd                  ,'') as string))
,md5(cast(nvl(tx_tm                          ,'') as string))
,md5(cast(nvl(tx_amt                         ,'') as string))
,md5(cast(nvl(biz_typ                        ,'') as string))
,md5(cast(nvl(cap_typ                        ,'') as string))
,md5(cast(nvl(currency                       ,'') as string))
,md5(cast(nvl(corp_ids                       ,'') as string))
,md5(cast(nvl(corp_mercht_ids                ,'') as string))
,md5(cast(nvl(corp_nms                       ,'') as string))
,md5(cast(nvl(corp_role_typ                  ,'') as string))
,md5(cast(nvl(mercht_ids                     ,'') as string))
,md5(cast(nvl(mercht_nms                     ,'') as string))
,md5(cast(nvl(mercht_typs                    ,'') as string))
,md5(cast(nvl(recv_acct_id                   ,'') as string))
,md5(cast(nvl(recv_bank_acct_no              ,'') as string))
,md5(cast(nvl(recv_acct_brvt_cd              ,'') as string))
,md5(cast(nvl(recv_acct_mercht_id            ,'') as string))
,md5(cast(nvl(recv_acct_corp_nm              ,'') as string))
,md5(cast(nvl(recv_acct_dpst_charc           ,'') as string))
,md5(cast(nvl(pay_acct_id                    ,'') as string))
,md5(cast(nvl(pay_bank_acct_no               ,'') as string))
,md5(cast(nvl(pay_acct_brvt_cd               ,'') as string))
,md5(cast(nvl(pay_acct_mercht_id             ,'') as string))
,md5(cast(nvl(pay_acct_corp_nm               ,'') as string))
,md5(cast(nvl(pay_acct_dpst_charc            ,'') as string))
,md5(cast(nvl(linkg_acct_id                  ,'') as string))
,md5(cast(nvl(linkg_bank_acct_no             ,'') as string))
,md5(cast(nvl(linkg_acct_brvt_cd             ,'') as string))
,md5(cast(nvl(linkg_acct_mercht_id           ,'') as string))
,md5(cast(nvl(linkg_acct_corp_nm             ,'') as string))
,md5(cast(nvl(linkg_acct_dpst_charc          ,'') as string))
,md5(cast(nvl(linkg_acct_recv_pay_drct       ,'') as string))
,md5(cast(nvl(sett_id                        ,'') as string))
,md5(cast(nvl(fee_id                         ,'') as string))
,md5(cast(nvl(fst_biz_typ                    ,'') as string))
,md5(cast(nvl(fst_sett_scen                  ,'') as string))
,md5(cast(nvl(fst_fee_typ                    ,'') as string))
,md5(cast(nvl(pay_id                         ,'') as string))
,md5(cast(nvl(plat_id                        ,'') as string))
,md5(cast(nvl(biz_pay_id                     ,'') as string))
,md5(cast(nvl(biz_ids                        ,'') as string))
,md5(cast(nvl(tax_rate                       ,'') as string))
,md5(cast(nvl(contr_id                       ,'') as string))
,md5(cast(nvl(proj_id                        ,'') as string))
,md5(cast(nvl(cret_tm                        ,'') as string))
,md5(cast(nvl(modi_tm                        ,'') as string))
,md5(cast(nvl(prod_id                        ,'') as string))
,md5(cast(nvl(prod_nm                        ,'') as string))
,md5(cast(nvl(cust_id                        ,'') as string))
,md5(cast(nvl(cust_nm                        ,'') as string))
,md5(cast(nvl(origin_id                      ,'') as string))
,md5(cast(nvl(ordr_id                        ,'') as string))
,md5(cast(nvl(is_cntn_tax                    ,'') as string))
,md5(cast(nvl(cap_acct_chk_stat              ,'') as string))
,md5(cast(nvl(biz_tm                         ,'') as string))
,md5(cast(nvl(pay_tm                         ,'') as string))
,md5(cast(nvl(acct_chk_tm                    ,'') as string))
,md5(cast(nvl(fst_tm                         ,'') as string))
,md5(cast(nvl(stmt_no                        ,'') as string))
,md5(cast(nvl(writeoff_status                ,'') as string))
,md5(cast(nvl(sett_stat                      ,'') as string))
,md5(cast(nvl(fee_stat                       ,'') as string))
,md5(cast(nvl(dept_id                        ,'') as string))
,md5(cast(nvl(spec_type_cd                   ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d
where dt>='2022-06-01'
group by dt
;

select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(model_id                       ,'') as string))
,md5(cast(nvl(indx_id                        ,'') as string))
,md5(cast(nvl(src_sys                        ,'') as string))
,md5(cast(nvl(src_tab                        ,'') as string))
,md5(cast(nvl(change_flag                    ,'') as string))
,md5(cast(nvl(rev_data_orig_dt               ,'') as string))
,md5(cast(nvl(data_unikey                    ,'') as string))
,md5(cast(nvl(accti_biz_line_cd              ,'') as string))
,md5(cast(nvl(accti_prod_cd                  ,'') as string))
,md5(cast(nvl(tx_tm                          ,'') as string))
,md5(cast(nvl(tx_amt                         ,'') as string))
,md5(cast(nvl(biz_typ                        ,'') as string))
,md5(cast(nvl(cap_typ                        ,'') as string))
,md5(cast(nvl(currency                       ,'') as string))
,md5(cast(nvl(corp_ids                       ,'') as string))
,md5(cast(nvl(corp_mercht_ids                ,'') as string))
,md5(cast(nvl(corp_nms                       ,'') as string))
,md5(cast(nvl(corp_role_typ                  ,'') as string))
,md5(cast(nvl(mercht_ids                     ,'') as string))
,md5(cast(nvl(mercht_nms                     ,'') as string))
,md5(cast(nvl(mercht_typs                    ,'') as string))
,md5(cast(nvl(recv_acct_id                   ,'') as string))
,md5(cast(nvl(recv_bank_acct_no              ,'') as string))
,md5(cast(nvl(recv_acct_brvt_cd              ,'') as string))
,md5(cast(nvl(recv_acct_mercht_id            ,'') as string))
,md5(cast(nvl(recv_acct_corp_nm              ,'') as string))
,md5(cast(nvl(recv_acct_dpst_charc           ,'') as string))
,md5(cast(nvl(pay_acct_id                    ,'') as string))
,md5(cast(nvl(pay_bank_acct_no               ,'') as string))
,md5(cast(nvl(pay_acct_brvt_cd               ,'') as string))
,md5(cast(nvl(pay_acct_mercht_id             ,'') as string))
,md5(cast(nvl(pay_acct_corp_nm               ,'') as string))
,md5(cast(nvl(pay_acct_dpst_charc            ,'') as string))
,md5(cast(nvl(linkg_acct_id                  ,'') as string))
,md5(cast(nvl(linkg_bank_acct_no             ,'') as string))
,md5(cast(nvl(linkg_acct_brvt_cd             ,'') as string))
,md5(cast(nvl(linkg_acct_mercht_id           ,'') as string))
,md5(cast(nvl(linkg_acct_corp_nm             ,'') as string))
,md5(cast(nvl(linkg_acct_dpst_charc          ,'') as string))
,md5(cast(nvl(linkg_acct_recv_pay_drct       ,'') as string))
,md5(cast(nvl(sett_id                        ,'') as string))
,md5(cast(nvl(fee_id                         ,'') as string))
,md5(cast(nvl(fst_biz_typ                    ,'') as string))
,md5(cast(nvl(fst_sett_scen                  ,'') as string))
,md5(cast(nvl(fst_fee_typ                    ,'') as string))
,md5(cast(nvl(pay_id                         ,'') as string))
,md5(cast(nvl(plat_id                        ,'') as string))
,md5(cast(nvl(biz_pay_id                     ,'') as string))
,md5(cast(nvl(biz_ids                        ,'') as string))
,md5(cast(nvl(tax_rate                       ,'') as string))
,md5(cast(nvl(contr_id                       ,'') as string))
,md5(cast(nvl(proj_id                        ,'') as string))
,md5(cast(nvl(cret_tm                        ,'') as string))
,md5(cast(nvl(modi_tm                        ,'') as string))
,md5(cast(nvl(prod_id                        ,'') as string))
,md5(cast(nvl(prod_nm                        ,'') as string))
,md5(cast(nvl(cust_id                        ,'') as string))
,md5(cast(nvl(cust_nm                        ,'') as string))
,md5(cast(nvl(origin_id                      ,'') as string))
,md5(cast(nvl(ordr_id                        ,'') as string))
,md5(cast(nvl(is_cntn_tax                    ,'') as string))
,md5(cast(nvl(cap_acct_chk_stat              ,'') as string))
,md5(cast(nvl(biz_tm                         ,'') as string))
,md5(cast(nvl(pay_tm                         ,'') as string))
,md5(cast(nvl(acct_chk_tm                    ,'') as string))
,md5(cast(nvl(fst_tm                         ,'') as string))
,md5(cast(nvl(stmt_no                        ,'') as string))
,md5(cast(nvl(writeoff_status                ,'') as string))
,md5(cast(nvl(sett_stat                      ,'') as string))
,md5(cast(nvl(fee_stat                       ,'') as string))
,md5(cast(nvl(dept_id                        ,'') as string))
,md5(cast(nvl(spec_type_cd                   ,'') as string))
)) as hash_num
from dmf_dev.renxiaowei7_20220614_tmp_01
where dt>='2022-06-01'
group by dt
;



select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;

--dmf_bc.dmfbc_bc_fi_fst_sett_i_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(change_code                                  ,'') as string))
,md5(cast(nvl(change_flag                                  ,'') as string))
,md5(cast(nvl(sett_source                                  ,'') as string))
,md5(cast(nvl(data_source_em                               ,'') as string))
,md5(cast(nvl(origin_id                                    ,'') as string))
,md5(cast(nvl(sett_id                                      ,'') as string))
,md5(cast(nvl(principal_company                            ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id           ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id           ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name         ,'') as string))
,md5(cast(nvl(biz_type                                     ,'') as string))
,md5(cast(nvl(sett_scenes                                  ,'') as string))
,md5(cast(nvl(product_id                                   ,'') as string))
,md5(cast(nvl(product_name                                 ,'') as string))
,md5(cast(nvl(customer_id                                  ,'') as string))
,md5(cast(nvl(customer_name                                ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id               ,'') as string))
,md5(cast(nvl(customer_type                                ,'') as string))
,md5(cast(nvl(direction                                    ,'') as string))
,md5(cast(nvl(amount                                       ,0) as string))
,md5(cast(nvl(sett_amount                                  ,0) as string))
,md5(cast(nvl(status                                       ,'') as string))
,md5(cast(nvl(finance_sys_id                               ,'') as string))
,md5(cast(nvl(sett_final_time                              ,'') as string))
,md5(cast(nvl(yn_flag                                      ,'') as string))
,md5(cast(nvl(pay_id                                       ,'') as string))
,md5(cast(nvl(ref_apply_id                                 ,'') as string))
,md5(cast(nvl(sett_apply_type                              ,'') as string))
,md5(cast(nvl(create_dt                                    ,'') as string))
,md5(cast(nvl(update_dt                                    ,'') as string))
,md5(cast(nvl(payinfo_company_name                         ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id             ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                            ,'') as string))
,md5(cast(nvl(payinfo_company_account                      ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                   ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                   ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id       ,'') as string))
,md5(cast(nvl(payinfo_other_company_account                ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id             ,'') as string))
,md5(cast(nvl(fee_id                                       ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type          ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature               ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature         ,0) as string))
,md5(cast(nvl(sett_type                                    ,'') as string))
,md5(cast(nvl(sett_complete_time                           ,'') as string))
,md5(cast(nvl(sett_applyor                                 ,'') as string))
,md5(cast(nvl(sett_apply_time                              ,'') as string))
,md5(cast(nvl(refuse_reason                                ,'') as string))
,md5(cast(nvl(fail_reason                                  ,'') as string))
,md5(cast(nvl(remark                                       ,'') as string))
,md5(cast(nvl(creator                                      ,'') as string))
,md5(cast(nvl(task_id                                      ,'') as string))
,md5(cast(nvl(currency                                     ,'') as string))
,md5(cast(nvl(tax_rate                                     ,'') as string))
,md5(cast(nvl(contract_code                                ,'') as string))
,md5(cast(nvl(project_code                                 ,'') as string))
,md5(cast(nvl(standby_field_one                            ,'') as string))
,md5(cast(nvl(standby_field_two                            ,'') as string))
,md5(cast(nvl(standby_field_three                          ,'') as string))
,md5(cast(nvl(standby_field_four                           ,'') as string))
,md5(cast(nvl(standby_field_five                           ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag       ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag     ,'') as string))
,md5(cast(nvl(main_account_id                              ,'') as string))
,md5(cast(nvl(last_dt                                      ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                    ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc                 ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd              ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc           ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src       ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                           ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                         ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                            ,'') as string))
,md5(cast(nvl(real_pay_id                                  ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src      ,'') as string))
,md5(cast(nvl(dept_id                                      ,'') as string))
,md5(cast(nvl(spec_type_cd                                 ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_i_d
where dt='2022-06-15'
group by dt
;

--dmf_bc.dmfbc_bc_fi_fst_sett_all_h_d-20220615
select end_dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                    ,'') as string))
,md5(cast(nvl(change_code                                 ,'') as string))
,md5(cast(nvl(ele_md5                                     ,'') as string))
,md5(cast(nvl(sett_source                                 ,'') as string))
,md5(cast(nvl(data_source_em                              ,'') as string))
,md5(cast(nvl(origin_id                                   ,'') as string))
,md5(cast(nvl(sett_id                                     ,'') as string))
,md5(cast(nvl(principal_company                           ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id          ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id          ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name        ,'') as string))
,md5(cast(nvl(biz_type                                    ,'') as string))
,md5(cast(nvl(sett_scenes                                 ,'') as string))
,md5(cast(nvl(product_id                                  ,'') as string))
,md5(cast(nvl(product_name                                ,'') as string))
,md5(cast(nvl(customer_id                                 ,'') as string))
,md5(cast(nvl(customer_name                               ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id              ,'') as string))
,md5(cast(nvl(customer_type                               ,'') as string))
,md5(cast(nvl(direction                                   ,'') as string))
,md5(cast(nvl(amount                                      ,0) as string))
,md5(cast(nvl(sett_amount                                 ,0) as string))
,md5(cast(nvl(status                                      ,'') as string))
,md5(cast(nvl(finance_sys_id                              ,'') as string))
,md5(cast(nvl(sett_final_time                             ,'') as string))
,md5(cast(nvl(yn_flag                                     ,'') as string))
,md5(cast(nvl(pay_id                                      ,'') as string))
,md5(cast(nvl(ref_apply_id                                ,'') as string))
,md5(cast(nvl(sett_apply_type                             ,'') as string))
,md5(cast(nvl(create_dt                                   ,'') as string))
,md5(cast(nvl(update_dt                                   ,'') as string))
,md5(cast(nvl(payinfo_company_name                        ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id            ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                           ,'') as string))
,md5(cast(nvl(payinfo_company_account                     ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                  ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                  ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id      ,'') as string))
,md5(cast(nvl(payinfo_other_company_account               ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id            ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct                     ,'') as string))
,md5(cast(nvl(fee_id                                      ,'') as string))
,md5(cast(nvl(sett_type                                   ,'') as string))
,md5(cast(nvl(sett_complete_time                          ,'') as string))
,md5(cast(nvl(sett_applyor                                ,'') as string))
,md5(cast(nvl(sett_apply_time                             ,'') as string))
,md5(cast(nvl(refuse_reason                               ,'') as string))
,md5(cast(nvl(fail_reason                                 ,'') as string))
,md5(cast(nvl(remark                                      ,'') as string))
,md5(cast(nvl(creator                                     ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type         ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature              ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature        ,0) as string))
,md5(cast(nvl(task_id                                     ,'') as string))
,md5(cast(nvl(currency                                    ,'') as string))
,md5(cast(nvl(tax_rate                                    ,'') as string))
,md5(cast(nvl(contract_code                               ,'') as string))
,md5(cast(nvl(project_code                                ,'') as string))
,md5(cast(nvl(standby_field_one                           ,'') as string))
,md5(cast(nvl(standby_field_two                           ,'') as string))
,md5(cast(nvl(standby_field_three                         ,'') as string))
,md5(cast(nvl(standby_field_four                          ,'') as string))
,md5(cast(nvl(standby_field_five                          ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag      ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag    ,'') as string))
,md5(cast(nvl(main_account_id                             ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                   ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc                ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd             ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc          ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src      ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                          ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                        ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                           ,'') as string))
,md5(cast(nvl(real_pay_id                                 ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src     ,'') as string))
,md5(cast(nvl(dept_id                                     ,'') as string))
,md5(cast(nvl(spec_type_cd                                ,'') as string))
,md5(cast(nvl(spe_val_map                                 ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_all_h_d
where end_dt='2022-06-15'
group by end_dt
;

--dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_h_d-20220615
select end_dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                     ,'') as string))
,md5(cast(nvl(change_code                                  ,'') as string))
,md5(cast(nvl(ele_md5                                      ,'') as string))
,md5(cast(nvl(sett_source                                  ,'') as string))
,md5(cast(nvl(data_source_em                               ,'') as string))
,md5(cast(nvl(origin_id                                    ,'') as string))
,md5(cast(nvl(sett_id                                      ,'') as string))
,md5(cast(nvl(principal_company                            ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id           ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id           ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name         ,'') as string))
,md5(cast(nvl(biz_type                                     ,'') as string))
,md5(cast(nvl(sett_scenes                                  ,'') as string))
,md5(cast(nvl(product_id                                   ,'') as string))
,md5(cast(nvl(product_name                                 ,'') as string))
,md5(cast(nvl(customer_id                                  ,'') as string))
,md5(cast(nvl(customer_name                                ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id               ,'') as string))
,md5(cast(nvl(customer_type                                ,'') as string))
,md5(cast(nvl(direction                                    ,'') as string))
,md5(cast(nvl(amount                                       ,0) as string))
,md5(cast(nvl(sett_amount                                  ,0) as string))
,md5(cast(nvl(status                                       ,'') as string))
,md5(cast(nvl(finance_sys_id                               ,'') as string))
,md5(cast(nvl(sett_final_time                              ,'') as string))
,md5(cast(nvl(yn_flag                                      ,'') as string))
,md5(cast(nvl(pay_id                                       ,'') as string))
,md5(cast(nvl(ref_apply_id                                 ,'') as string))
,md5(cast(nvl(sett_apply_type                              ,'') as string))
,md5(cast(nvl(create_dt                                    ,'') as string))
,md5(cast(nvl(update_dt                                    ,'') as string))
,md5(cast(nvl(payinfo_company_name                         ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id             ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                            ,'') as string))
,md5(cast(nvl(payinfo_company_account                      ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                   ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                   ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id       ,'') as string))
,md5(cast(nvl(payinfo_other_company_account                ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id             ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct                      ,'') as string))
,md5(cast(nvl(fee_id                                       ,'') as string))
,md5(cast(nvl(sett_type                                    ,'') as string))
,md5(cast(nvl(sett_complete_time                           ,'') as string))
,md5(cast(nvl(sett_applyor                                 ,'') as string))
,md5(cast(nvl(sett_apply_time                              ,'') as string))
,md5(cast(nvl(refuse_reason                                ,'') as string))
,md5(cast(nvl(fail_reason                                  ,'') as string))
,md5(cast(nvl(remark                                       ,'') as string))
,md5(cast(nvl(creator                                      ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type          ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature               ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature         ,0) as string))
,md5(cast(nvl(task_id                                      ,'') as string))
,md5(cast(nvl(currency                                     ,'') as string))
,md5(cast(nvl(tax_rate                                     ,'') as string))
,md5(cast(nvl(contract_code                                ,'') as string))
,md5(cast(nvl(project_code                                 ,'') as string))
,md5(cast(nvl(standby_field_one                            ,'') as string))
,md5(cast(nvl(standby_field_two                            ,'') as string))
,md5(cast(nvl(standby_field_three                          ,'') as string))
,md5(cast(nvl(standby_field_four                           ,'') as string))
,md5(cast(nvl(standby_field_five                           ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag       ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag     ,'') as string))
,md5(cast(nvl(main_account_id                              ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                    ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc                 ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd              ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc           ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src       ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                           ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                         ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                            ,'') as string))
,md5(cast(nvl(real_pay_id                                  ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src      ,'') as string))
,md5(cast(nvl(dept_id                                      ,'') as string))
,md5(cast(nvl(spec_type_cd                                 ,'') as string))
,md5(cast(nvl(spe_val_map                                  ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_h_d
where end_dt='2022-06-15'
group by end_dt
;

--dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_i_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(change_code                                      ,'') as string))
,md5(cast(nvl(change_flag                                      ,'') as string))
,md5(cast(nvl(sett_source                                      ,'') as string))
,md5(cast(nvl(data_source_em                                   ,'') as string))
,md5(cast(nvl(origin_id                                        ,'') as string))
,md5(cast(nvl(sett_id                                          ,'') as string))
,md5(cast(nvl(principal_company                                ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id               ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id               ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name             ,'') as string))
,md5(cast(nvl(biz_type                                         ,'') as string))
,md5(cast(nvl(sett_scenes                                      ,'') as string))
,md5(cast(nvl(product_id                                       ,'') as string))
,md5(cast(nvl(product_name                                     ,'') as string))
,md5(cast(nvl(customer_id                                      ,'') as string))
,md5(cast(nvl(customer_name                                    ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id                   ,'') as string))
,md5(cast(nvl(customer_type                                    ,'') as string))
,md5(cast(nvl(direction                                        ,'') as string))
,md5(cast(nvl(amount                                           ,0) as string))
,md5(cast(nvl(sett_amount                                      ,0) as string))
,md5(cast(nvl(status                                           ,'') as string))
,md5(cast(nvl(finance_sys_id                                   ,'') as string))
,md5(cast(nvl(sett_final_time                                  ,'') as string))
,md5(cast(nvl(yn_flag                                          ,'') as string))
,md5(cast(nvl(pay_id                                           ,'') as string))
,md5(cast(nvl(ref_apply_id                                     ,'') as string))
,md5(cast(nvl(sett_apply_type                                  ,'') as string))
,md5(cast(nvl(create_dt                                        ,'') as string))
,md5(cast(nvl(update_dt                                        ,'') as string))
,md5(cast(nvl(payinfo_company_name                             ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id                 ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                                ,'') as string))
,md5(cast(nvl(payinfo_company_account                          ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                       ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                       ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id           ,'') as string))
,md5(cast(nvl(payinfo_other_company_account                    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id                 ,'') as string))
,md5(cast(nvl(fee_id                                           ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type              ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature                   ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature             ,0) as string))
,md5(cast(nvl(sett_type                                        ,'') as string))
,md5(cast(nvl(sett_complete_time                               ,'') as string))
,md5(cast(nvl(sett_applyor                                     ,'') as string))
,md5(cast(nvl(sett_apply_time                                  ,'') as string))
,md5(cast(nvl(refuse_reason                                    ,'') as string))
,md5(cast(nvl(fail_reason                                      ,'') as string))
,md5(cast(nvl(remark                                           ,'') as string))
,md5(cast(nvl(creator                                          ,'') as string))
,md5(cast(nvl(task_id                                          ,'') as string))
,md5(cast(nvl(currency                                         ,'') as string))
,md5(cast(nvl(tax_rate                                         ,'') as string))
,md5(cast(nvl(contract_code                                    ,'') as string))
,md5(cast(nvl(project_code                                     ,'') as string))
,md5(cast(nvl(standby_field_one                                ,'') as string))
,md5(cast(nvl(standby_field_two                                ,'') as string))
,md5(cast(nvl(standby_field_three                              ,'') as string))
,md5(cast(nvl(standby_field_four                               ,'') as string))
,md5(cast(nvl(standby_field_five                               ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag           ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag         ,'') as string))
,md5(cast(nvl(main_account_id                                  ,'') as string))
,md5(cast(nvl(last_dt                                          ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                        ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc                     ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd                  ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc               ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src           ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                               ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                             ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                                ,'') as string))
,md5(cast(nvl(real_pay_id                                      ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src          ,'') as string))
,md5(cast(nvl(dept_id                                          ,'') as string))
,md5(cast(nvl(spec_type_cd                                     ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_part_pay_i_d
where dt='2022-06-15'
group by dt
;


--dmfbc_bc_fi_fst_sett_all_s_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                  ,'') as string))
,md5(cast(nvl(change_code                               ,'') as string))
,md5(cast(nvl(ele_md5                                   ,'') as string))
,md5(cast(nvl(sett_source                               ,'') as string))
,md5(cast(nvl(data_source_em                            ,'') as string))
,md5(cast(nvl(origin_id                                 ,'') as string))
,md5(cast(nvl(sett_id                                   ,'') as string))
,md5(cast(nvl(principal_company                         ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id        ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id        ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name      ,'') as string))
,md5(cast(nvl(biz_type                                  ,'') as string))
,md5(cast(nvl(sett_scenes                               ,'') as string))
,md5(cast(nvl(product_id                                ,'') as string))
,md5(cast(nvl(product_name                              ,'') as string))
,md5(cast(nvl(customer_id                               ,'') as string))
,md5(cast(nvl(customer_name                             ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id            ,'') as string))
,md5(cast(nvl(customer_type                             ,'') as string))
,md5(cast(nvl(direction                                 ,'') as string))
,md5(cast(nvl(amount                                    ,0) as string))
,md5(cast(nvl(sett_amount                               ,0) as string))
,md5(cast(nvl(status                                    ,'') as string))
,md5(cast(nvl(finance_sys_id                            ,'') as string))
,md5(cast(nvl(sett_final_time                           ,'') as string))
,md5(cast(nvl(yn_flag                                   ,'') as string))
,md5(cast(nvl(pay_id                                    ,'') as string))
,md5(cast(nvl(ref_apply_id                              ,'') as string))
,md5(cast(nvl(sett_apply_type                           ,'') as string))
,md5(cast(nvl(create_dt                                 ,'') as string))
,md5(cast(nvl(update_dt                                 ,'') as string))
,md5(cast(nvl(payinfo_company_name                      ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id          ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                         ,'') as string))
,md5(cast(nvl(payinfo_company_account                   ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account             ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id          ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct                   ,'') as string))
,md5(cast(nvl(fee_id                                    ,'') as string))
,md5(cast(nvl(sett_type                                 ,'') as string))
,md5(cast(nvl(sett_complete_time                        ,'') as string))
,md5(cast(nvl(sett_applyor                              ,'') as string))
,md5(cast(nvl(sett_apply_time                           ,'') as string))
,md5(cast(nvl(refuse_reason                             ,'') as string))
,md5(cast(nvl(fail_reason                               ,'') as string))
,md5(cast(nvl(remark                                    ,'') as string))
,md5(cast(nvl(creator                                   ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type       ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature            ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature      ,0) as string))
,md5(cast(nvl(task_id                                   ,'') as string))
,md5(cast(nvl(currency                                  ,'') as string))
,md5(cast(nvl(tax_rate                                  ,'') as string))
,md5(cast(nvl(contract_code                             ,'') as string))
,md5(cast(nvl(project_code                              ,'') as string))
,md5(cast(nvl(standby_field_one                         ,'') as string))
,md5(cast(nvl(standby_field_two                         ,'') as string))
,md5(cast(nvl(standby_field_three                       ,'') as string))
,md5(cast(nvl(standby_field_four                        ,'') as string))
,md5(cast(nvl(standby_field_five                        ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag  ,'') as string))
,md5(cast(nvl(main_account_id                           ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                 ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc              ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd           ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc        ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src    ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                        ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                      ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                         ,'') as string))
,md5(cast(nvl(real_pay_id                               ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src   ,'') as string))
,md5(cast(nvl(dept_id                                   ,'') as string))
,md5(cast(nvl(spec_type_cd                              ,'') as string))
,md5(cast(nvl(spe_val_map                               ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_all_s_d
where dt>='2022-08-01'
group by dt
;

--dmfbc_bc_fi_fst_sett_valid_i_d-20220615
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(change_code                               ,'') as string))
,md5(cast(nvl(change_flag                               ,'') as string))
,md5(cast(nvl(sett_source                               ,'') as string))
,md5(cast(nvl(data_source_em                            ,'') as string))
,md5(cast(nvl(origin_id                                 ,'') as string))
,md5(cast(nvl(sett_id                                   ,'') as string))
,md5(cast(nvl(principal_company                         ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id        ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id        ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name      ,'') as string))
,md5(cast(nvl(biz_type                                  ,'') as string))
,md5(cast(nvl(sett_scenes                               ,'') as string))
,md5(cast(nvl(product_id                                ,'') as string))
,md5(cast(nvl(product_name                              ,'') as string))
,md5(cast(nvl(customer_id                               ,'') as string))
,md5(cast(nvl(customer_name                             ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id            ,'') as string))
,md5(cast(nvl(customer_type                             ,'') as string))
,md5(cast(nvl(direction                                 ,'') as string))
,md5(cast(nvl(amount                                    ,'') as string))
,md5(cast(nvl(sett_amount                               ,'') as string))
,md5(cast(nvl(status                                    ,'') as string))
,md5(cast(nvl(finance_sys_id                            ,'') as string))
,md5(cast(nvl(sett_final_time                           ,'') as string))
,md5(cast(nvl(yn_flag                                   ,'') as string))
,md5(cast(nvl(pay_id                                    ,'') as string))
,md5(cast(nvl(ref_apply_id                              ,'') as string))
,md5(cast(nvl(sett_apply_type                           ,'') as string))
,md5(cast(nvl(create_dt                                 ,'') as string))
,md5(cast(nvl(update_dt                                 ,'') as string))
,md5(cast(nvl(payinfo_company_name                      ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id          ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                         ,'') as string))
,md5(cast(nvl(payinfo_company_account                   ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account             ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id          ,'') as string))
,md5(cast(nvl(fee_id                                    ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type       ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature            ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_nature      ,'') as string))
,md5(cast(nvl(sett_type                                 ,'') as string))
,md5(cast(nvl(sett_complete_time                        ,'') as string))
,md5(cast(nvl(sett_applyor                              ,'') as string))
,md5(cast(nvl(sett_apply_time                           ,'') as string))
,md5(cast(nvl(refuse_reason                             ,'') as string))
,md5(cast(nvl(fail_reason                               ,'') as string))
,md5(cast(nvl(remark                                    ,'') as string))
,md5(cast(nvl(creator                                   ,'') as string))
,md5(cast(nvl(task_id                                   ,'') as string))
,md5(cast(nvl(currency                                  ,'') as string))
,md5(cast(nvl(tax_rate                                  ,'') as string))
,md5(cast(nvl(contract_code                             ,'') as string))
,md5(cast(nvl(project_code                              ,'') as string))
,md5(cast(nvl(standby_field_one                         ,'') as string))
,md5(cast(nvl(standby_field_two                         ,'') as string))
,md5(cast(nvl(standby_field_three                       ,'') as string))
,md5(cast(nvl(standby_field_four                        ,'') as string))
,md5(cast(nvl(standby_field_five                        ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag  ,'') as string))
,md5(cast(nvl(main_account_id                           ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                 ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc              ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd           ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc        ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src    ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                        ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                      ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                         ,'') as string))
,md5(cast(nvl(last_dt                                   ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_valid_i_d
where dt='2022-06-15'
group by dt
;


--临时表验证
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;


--dmf_tmp.tmp_fin_sett_all_month_brush
select  sum(hash(
 md5(start_dt                                )
,md5(change_code                             )
,md5(ele_md5                                 )
,md5(sett_source                             )
,md5(data_source_em                          )
,md5(origin_id                               )
,md5(sett_id                                 )
,md5(principal_company                       )
,md5(sett_principal_company_customer_id      )
,md5(sett_principal_company_merchant_id      )
,md5(sett_principal_company_customer_name    )
,md5(biz_type                                )
,md5(sett_scenes                             )
,md5(product_id                              )
,md5(product_name                            )
,md5(customer_id                             )
,md5(customer_name                           )
,md5(sett_customer_name_merchant_id          )
,md5(customer_type                           )
,md5(direction                               )
,md5(amount                                  )
,md5(sett_amount                             )
,md5(status                                  )
,md5(finance_sys_id                          )
,md5(sett_final_time                         )
,md5(yn_flag                                 )
,md5(pay_id                                  )
,md5(ref_apply_id                            )
,md5(sett_apply_type                         )
,md5(create_dt                               )
,md5(update_dt                               )
,md5(payinfo_company_name                    )
,md5(payinfo_company_name_merchant_id        )
,md5(payinfo_bank_acct                       )
,md5(payinfo_company_account                 )
,md5(payinfo_company_account_id              )
,md5(payinfo_other_company_name              )
,md5(payinfo_other_company_name_merchant_id  )
,md5(payinfo_other_company_account           )
,md5(payinfo_other_company_account_id        )
,md5(payinfo_other_bank_acct                 )
,md5(fee_id                                  )
,md5(sett_type                               )
,md5(sett_complete_time                      )
,md5(sett_applyor                            )
,md5(sett_apply_time                         )
,md5(refuse_reason                           )
,md5(fail_reason                             )
,md5(remark                                  )
,md5(creator                                 )
,md5(sett_customer_name_merchant_id_type     )
,md5(payinfo_company_account_nature          )
,md5(payinfo_other_company_account_nature    )
,md5(task_id                                 )
,md5(currency                                )
,md5(tax_rate                                )
,md5(contract_code                           )
,md5(project_code                            )
,md5(standby_field_one                       )
,md5(standby_field_two                       )
,md5(standby_field_three                     )
,md5(standby_field_four                      )
,md5(standby_field_five                      )
,md5(sett_customer_name_merchant_id_src_tag  )
,md5(payinfo_other_company_account_id_src_tag)
,md5(main_account_id                         )
,md5(payinfo_bank_acct_brvt_cd               )
,md5(payinfo_bank_acct_dpst_charc            )
,md5(payinfo_other_bank_acct_brvt_cd         )
,md5(payinfo_other_bank_acct_dpst_charc      )
,md5(sett_customer_name_merchant_id_all_src  )
,md5(fst_cust_mercht_id                      )
,md5(accti_cust_mercht_id                    )
,md5(accti_biz_line_cd                       )
,md5(real_pay_id                             )
,md5(sett_customer_name_merchant_typ_all_src )
,md5(dept_id                                 )
,md5(spec_type_cd                            )
,md5(spe_val_map                             )
,md5(dt                                      )
,md5(advancefund_bnk                         )
,md5(clean_tag                               )
,md5(conn_cols                               )
)) as hash_num
from (
select  cast(nvl(start_dt                                    ,'') as string) as start_dt                                
       ,cast(nvl(change_code                                 ,'') as string) as change_code                             
       ,cast(nvl(ele_md5                                     ,'') as string) as ele_md5                                 
       ,cast(nvl(sett_source                                 ,'') as string) as sett_source                             
       ,cast(nvl(data_source_em                              ,'') as string) as data_source_em                          
       ,cast(nvl(origin_id                                   ,'') as string) as origin_id                               
       ,cast(nvl(sett_id                                     ,'') as string) as sett_id                                 
       ,cast(nvl(principal_company                           ,'') as string) as principal_company                       
       ,cast(nvl(sett_principal_company_customer_id          ,'') as string) as sett_principal_company_customer_id      
       ,cast(nvl(sett_principal_company_merchant_id          ,'') as string) as sett_principal_company_merchant_id      
       ,cast(nvl(sett_principal_company_customer_name        ,'') as string) as sett_principal_company_customer_name    
       ,cast(nvl(biz_type                                    ,'') as string) as biz_type                                
       ,cast(nvl(sett_scenes                                 ,'') as string) as sett_scenes                             
       ,cast(nvl(product_id                                  ,'') as string) as product_id                              
       ,cast(nvl(product_name                                ,'') as string) as product_name                            
       ,cast(nvl(customer_id                                 ,'') as string) as customer_id                             
       ,cast(nvl(customer_name                               ,'') as string) as customer_name                           
       ,cast(nvl(sett_customer_name_merchant_id              ,'') as string) as sett_customer_name_merchant_id          
       ,cast(nvl(customer_type                               ,'') as string) as customer_type                           
       ,cast(nvl(direction                                   ,'') as string) as direction                               
       ,cast(nvl(amount                                      ,0 ) as string) as amount                                  
       ,cast(nvl(sett_amount                                 ,0 ) as string) as sett_amount                             
       ,cast(nvl(status                                      ,'') as string) as status                                  
       ,cast(nvl(finance_sys_id                              ,'') as string) as finance_sys_id                          
       ,cast(nvl(sett_final_time                             ,'') as string) as sett_final_time                         
       ,cast(nvl(yn_flag                                     ,'') as string) as yn_flag                                 
       ,cast(nvl(pay_id                                      ,'') as string) as pay_id                                  
       ,cast(nvl(ref_apply_id                                ,'') as string) as ref_apply_id                            
       ,cast(nvl(sett_apply_type                             ,'') as string) as sett_apply_type                         
       ,cast(nvl(create_dt                                   ,'') as string) as create_dt                               
       ,cast(nvl(update_dt                                   ,'') as string) as update_dt                               
       ,cast(nvl(payinfo_company_name                        ,'') as string) as payinfo_company_name                    
       ,cast(nvl(payinfo_company_name_merchant_id            ,'') as string) as payinfo_company_name_merchant_id        
       ,cast(nvl(payinfo_bank_acct                           ,'') as string) as payinfo_bank_acct                       
       ,cast(nvl(payinfo_company_account                     ,'') as string) as payinfo_company_account                 
       ,cast(nvl(payinfo_company_account_id                  ,'') as string) as payinfo_company_account_id              
       ,cast(nvl(payinfo_other_company_name                  ,'') as string) as payinfo_other_company_name              
       ,cast(nvl(payinfo_other_company_name_merchant_id      ,'') as string) as payinfo_other_company_name_merchant_id  
       ,cast(nvl(payinfo_other_company_account               ,'') as string) as payinfo_other_company_account           
       ,cast(nvl(payinfo_other_company_account_id            ,'') as string) as payinfo_other_company_account_id        
       ,cast(nvl(payinfo_other_bank_acct                     ,'') as string) as payinfo_other_bank_acct                 
       ,cast(nvl(fee_id                                      ,'') as string) as fee_id                                  
       ,cast(nvl(sett_type                                   ,'') as string) as sett_type                               
       ,cast(nvl(sett_complete_time                          ,'') as string) as sett_complete_time                      
       ,cast(nvl(sett_applyor                                ,'') as string) as sett_applyor                            
       ,cast(nvl(sett_apply_time                             ,'') as string) as sett_apply_time                         
       ,cast(nvl(refuse_reason                               ,'') as string) as refuse_reason                           
       ,cast(nvl(fail_reason                                 ,'') as string) as fail_reason                             
       ,cast(nvl(remark                                      ,'') as string) as remark                                  
       ,cast(nvl(creator                                     ,'') as string) as creator                                 
       ,cast(nvl(sett_customer_name_merchant_id_type         ,'') as string) as sett_customer_name_merchant_id_type     
       ,cast(nvl(payinfo_company_account_nature              ,0 ) as string) as payinfo_company_account_nature          
       ,cast(nvl(payinfo_other_company_account_nature        ,0 ) as string) as payinfo_other_company_account_nature    
       ,cast(nvl(task_id                                     ,'') as string) as task_id                                 
       ,cast(nvl(currency                                    ,'') as string) as currency                                
       ,cast(nvl(tax_rate                                    ,'') as string) as tax_rate                                
       ,cast(nvl(contract_code                               ,'') as string) as contract_code                           
       ,cast(nvl(project_code                                ,'') as string) as project_code                            
       ,cast(nvl(standby_field_one                           ,'') as string) as standby_field_one                       
       ,cast(nvl(standby_field_two                           ,'') as string) as standby_field_two                       
       ,cast(nvl(standby_field_three                         ,'') as string) as standby_field_three                     
       ,cast(nvl(standby_field_four                          ,'') as string) as standby_field_four                      
       ,cast(nvl(standby_field_five                          ,'') as string) as standby_field_five                      
       ,cast(nvl(sett_customer_name_merchant_id_src_tag      ,'') as string) as sett_customer_name_merchant_id_src_tag  
       ,cast(nvl(payinfo_other_company_account_id_src_tag    ,'') as string) as payinfo_other_company_account_id_src_tag
       ,cast(nvl(main_account_id                             ,'') as string) as main_account_id                         
       ,cast(nvl(payinfo_bank_acct_brvt_cd                   ,'') as string) as payinfo_bank_acct_brvt_cd               
       ,cast(nvl(payinfo_bank_acct_dpst_charc                ,'') as string) as payinfo_bank_acct_dpst_charc            
       ,cast(nvl(payinfo_other_bank_acct_brvt_cd             ,'') as string) as payinfo_other_bank_acct_brvt_cd         
       ,cast(nvl(payinfo_other_bank_acct_dpst_charc          ,'') as string) as payinfo_other_bank_acct_dpst_charc      
       ,cast(nvl(sett_customer_name_merchant_id_all_src      ,'') as string) as sett_customer_name_merchant_id_all_src  
       ,cast(nvl(fst_cust_mercht_id                          ,'') as string) as fst_cust_mercht_id                      
       ,cast(nvl(accti_cust_mercht_id                        ,'') as string) as accti_cust_mercht_id                    
       ,cast(nvl(accti_biz_line_cd                           ,'') as string) as accti_biz_line_cd                       
       ,cast(nvl(real_pay_id                                 ,'') as string) as real_pay_id                             
       ,cast(nvl(sett_customer_name_merchant_typ_all_src     ,'') as string) as sett_customer_name_merchant_typ_all_src 
       ,cast(nvl(dept_id                                     ,'') as string) as dept_id                                 
       ,cast(nvl(spec_type_cd                                ,'') as string) as spec_type_cd                            
       ,cast(nvl(spe_val_map                                 ,'') as string) as spe_val_map                             
       ,cast(nvl(dt                                          ,'') as string) as dt                                      
       ,cast(nvl(advancefund_bnk                             ,'') as string) as advancefund_bnk                         
       ,cast(nvl(clean_tag                                   ,'') as string) as clean_tag                               
       ,cast(nvl(concat_ws('_',collect_set(concat_ws('_',coalesce(a2.key,''),coalesce(a2.val,'')))),'') as string) as conn_cols
from dmf_tmp.tmp_fin_sett_all_month_brush a1
lateral view explode(conn_cols) a2 as key,val
group by  cast(nvl(start_dt                                    ,'') as string)
         ,cast(nvl(change_code                                 ,'') as string)
         ,cast(nvl(ele_md5                                     ,'') as string)
         ,cast(nvl(sett_source                                 ,'') as string)
         ,cast(nvl(data_source_em                              ,'') as string)
         ,cast(nvl(origin_id                                   ,'') as string)
         ,cast(nvl(sett_id                                     ,'') as string)
         ,cast(nvl(principal_company                           ,'') as string)
         ,cast(nvl(sett_principal_company_customer_id          ,'') as string)
         ,cast(nvl(sett_principal_company_merchant_id          ,'') as string)
         ,cast(nvl(sett_principal_company_customer_name        ,'') as string)
         ,cast(nvl(biz_type                                    ,'') as string)
         ,cast(nvl(sett_scenes                                 ,'') as string)
         ,cast(nvl(product_id                                  ,'') as string)
         ,cast(nvl(product_name                                ,'') as string)
         ,cast(nvl(customer_id                                 ,'') as string)
         ,cast(nvl(customer_name                               ,'') as string)
         ,cast(nvl(sett_customer_name_merchant_id              ,'') as string)
         ,cast(nvl(customer_type                               ,'') as string)
         ,cast(nvl(direction                                   ,'') as string)
         ,cast(nvl(amount                                      ,0 ) as string)
         ,cast(nvl(sett_amount                                 ,0 ) as string)
         ,cast(nvl(status                                      ,'') as string)
         ,cast(nvl(finance_sys_id                              ,'') as string)
         ,cast(nvl(sett_final_time                             ,'') as string)
         ,cast(nvl(yn_flag                                     ,'') as string)
         ,cast(nvl(pay_id                                      ,'') as string)
         ,cast(nvl(ref_apply_id                                ,'') as string)
         ,cast(nvl(sett_apply_type                             ,'') as string)
         ,cast(nvl(create_dt                                   ,'') as string)
         ,cast(nvl(update_dt                                   ,'') as string)
         ,cast(nvl(payinfo_company_name                        ,'') as string)
         ,cast(nvl(payinfo_company_name_merchant_id            ,'') as string)
         ,cast(nvl(payinfo_bank_acct                           ,'') as string)
         ,cast(nvl(payinfo_company_account                     ,'') as string)
         ,cast(nvl(payinfo_company_account_id                  ,'') as string)
         ,cast(nvl(payinfo_other_company_name                  ,'') as string)
         ,cast(nvl(payinfo_other_company_name_merchant_id      ,'') as string)
         ,cast(nvl(payinfo_other_company_account               ,'') as string)
         ,cast(nvl(payinfo_other_company_account_id            ,'') as string)
         ,cast(nvl(payinfo_other_bank_acct                     ,'') as string)
         ,cast(nvl(fee_id                                      ,'') as string)
         ,cast(nvl(sett_type                                   ,'') as string)
         ,cast(nvl(sett_complete_time                          ,'') as string)
         ,cast(nvl(sett_applyor                                ,'') as string)
         ,cast(nvl(sett_apply_time                             ,'') as string)
         ,cast(nvl(refuse_reason                               ,'') as string)
         ,cast(nvl(fail_reason                                 ,'') as string)
         ,cast(nvl(remark                                      ,'') as string)
         ,cast(nvl(creator                                     ,'') as string)
         ,cast(nvl(sett_customer_name_merchant_id_type         ,'') as string)
         ,cast(nvl(payinfo_company_account_nature              ,0 ) as string)
         ,cast(nvl(payinfo_other_company_account_nature        ,0 ) as string)
         ,cast(nvl(task_id                                     ,'') as string)
         ,cast(nvl(currency                                    ,'') as string)
         ,cast(nvl(tax_rate                                    ,'') as string)
         ,cast(nvl(contract_code                               ,'') as string)
         ,cast(nvl(project_code                                ,'') as string)
         ,cast(nvl(standby_field_one                           ,'') as string)
         ,cast(nvl(standby_field_two                           ,'') as string)
         ,cast(nvl(standby_field_three                         ,'') as string)
         ,cast(nvl(standby_field_four                          ,'') as string)
         ,cast(nvl(standby_field_five                          ,'') as string)
         ,cast(nvl(sett_customer_name_merchant_id_src_tag      ,'') as string)
         ,cast(nvl(payinfo_other_company_account_id_src_tag    ,'') as string)
         ,cast(nvl(main_account_id                             ,'') as string)
         ,cast(nvl(payinfo_bank_acct_brvt_cd                   ,'') as string)
         ,cast(nvl(payinfo_bank_acct_dpst_charc                ,'') as string)
         ,cast(nvl(payinfo_other_bank_acct_brvt_cd             ,'') as string)
         ,cast(nvl(payinfo_other_bank_acct_dpst_charc          ,'') as string)
         ,cast(nvl(sett_customer_name_merchant_id_all_src      ,'') as string)
         ,cast(nvl(fst_cust_mercht_id                          ,'') as string)
         ,cast(nvl(accti_cust_mercht_id                        ,'') as string)
         ,cast(nvl(accti_biz_line_cd                           ,'') as string)
         ,cast(nvl(real_pay_id                                 ,'') as string)
         ,cast(nvl(sett_customer_name_merchant_typ_all_src     ,'') as string)
         ,cast(nvl(dept_id                                     ,'') as string)
         ,cast(nvl(spec_type_cd                                ,'') as string)
         ,cast(nvl(spe_val_map                                 ,'') as string)
         ,cast(nvl(dt                                          ,'') as string)
         ,cast(nvl(advancefund_bnk                             ,'') as string)
         ,cast(nvl(clean_tag                                   ,'') as string)
) t




--数据校验


select biz_type,sett_scenes,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                    ,'') as string))
,md5(cast(nvl(change_code                                 ,'') as string))
,md5(cast(nvl(ele_md5                                     ,'') as string))
,md5(cast(nvl(sett_source                                 ,'') as string))
,md5(cast(nvl(data_source_em                              ,'') as string))
,md5(cast(nvl(origin_id                                   ,'') as string))
,md5(cast(nvl(sett_id                                     ,'') as string))
,md5(cast(nvl(principal_company                           ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id          ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id          ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name        ,'') as string))
,md5(cast(nvl(biz_type                                    ,'') as string))
,md5(cast(nvl(sett_scenes                                 ,'') as string))
,md5(cast(nvl(product_id                                  ,'') as string))
,md5(cast(nvl(product_name                                ,'') as string))
,md5(cast(nvl(customer_id                                 ,'') as string))
,md5(cast(nvl(customer_name                               ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id              ,'') as string))
,md5(cast(nvl(customer_type                               ,'') as string))
,md5(cast(nvl(direction                                   ,'') as string))
,md5(cast(nvl(amount                                      ,0) as string))
,md5(cast(nvl(sett_amount                                 ,0) as string))
,md5(cast(nvl(status                                      ,'') as string))
,md5(cast(nvl(finance_sys_id                              ,'') as string))
,md5(cast(nvl(sett_final_time                             ,'') as string))
,md5(cast(nvl(yn_flag                                     ,'') as string))
,md5(cast(nvl(pay_id                                      ,'') as string))
,md5(cast(nvl(ref_apply_id                                ,'') as string))
,md5(cast(nvl(sett_apply_type                             ,'') as string))
,md5(cast(nvl(create_dt                                   ,'') as string))
,md5(cast(nvl(update_dt                                   ,'') as string))
,md5(cast(nvl(payinfo_company_name                        ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id            ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                           ,'') as string))
,md5(cast(nvl(payinfo_company_account                     ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                  ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                  ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id      ,'') as string))
,md5(cast(nvl(payinfo_other_company_account               ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id            ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct                     ,'') as string))
,md5(cast(nvl(fee_id                                      ,'') as string))
,md5(cast(nvl(sett_type                                   ,'') as string))
,md5(cast(nvl(sett_complete_time                          ,'') as string))
,md5(cast(nvl(sett_applyor                                ,'') as string))
,md5(cast(nvl(sett_apply_time                             ,'') as string))
,md5(cast(nvl(refuse_reason                               ,'') as string))
,md5(cast(nvl(fail_reason                                 ,'') as string))
,md5(cast(nvl(remark                                      ,'') as string))
,md5(cast(nvl(creator                                     ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type         ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature              ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature        ,0) as string))
,md5(cast(nvl(task_id                                     ,'') as string))
,md5(cast(nvl(currency                                    ,'') as string))
,md5(cast(nvl(tax_rate                                    ,'') as string))
,md5(cast(nvl(contract_code                               ,'') as string))
,md5(cast(nvl(project_code                                ,'') as string))
,md5(cast(nvl(standby_field_one                           ,'') as string))
,md5(cast(nvl(standby_field_two                           ,'') as string))
,md5(cast(nvl(standby_field_three                         ,'') as string))
,md5(cast(nvl(standby_field_four                          ,'') as string))
,md5(cast(nvl(standby_field_five                          ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag      ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag    ,'') as string))
,md5(cast(nvl(main_account_id                             ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                   ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc                ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd             ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc          ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src      ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                          ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                        ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                           ,'') as string))
,md5(cast(nvl(real_pay_id                                 ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src     ,'') as string))
,md5(cast(nvl(dept_id                                     ,'') as string))
,md5(cast(nvl(spec_type_cd                                ,'') as string))
,md5(cast(nvl(spe_val_map                                 ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_all_h_d
where end_dt='2022-06-20'
group by biz_type,sett_scenes


--差异数据
--5k有，bdp无
select * from dmf_bc.dmfbc_bc_fi_fst_sett_all_h_d
where end_dt>='2022-06-20'
and biz_type='737' and sett_id in ('180008684','183037988')


select dt,biz_type,sett_scenes,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                                  ,'') as string))
,md5(cast(nvl(change_code                               ,'') as string))
,md5(cast(nvl(ele_md5                                   ,'') as string))
,md5(cast(nvl(sett_source                               ,'') as string))
,md5(cast(nvl(data_source_em                            ,'') as string))
,md5(cast(nvl(origin_id                                 ,'') as string))
,md5(cast(nvl(sett_id                                   ,'') as string))
,md5(cast(nvl(principal_company                         ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id        ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id        ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name      ,'') as string))
,md5(cast(nvl(biz_type                                  ,'') as string))
,md5(cast(nvl(sett_scenes                               ,'') as string))
,md5(cast(nvl(product_id                                ,'') as string))
,md5(cast(nvl(product_name                              ,'') as string))
,md5(cast(nvl(customer_id                               ,'') as string))
,md5(cast(nvl(customer_name                             ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id            ,'') as string))
,md5(cast(nvl(customer_type                             ,'') as string))
,md5(cast(nvl(direction                                 ,'') as string))
,md5(cast(nvl(amount                                    ,0) as string))
,md5(cast(nvl(sett_amount                               ,0) as string))
,md5(cast(nvl(status                                    ,'') as string))
,md5(cast(nvl(finance_sys_id                            ,'') as string))
,md5(cast(nvl(sett_final_time                           ,'') as string))
,md5(cast(nvl(yn_flag                                   ,'') as string))
,md5(cast(nvl(pay_id                                    ,'') as string))
,md5(cast(nvl(ref_apply_id                              ,'') as string))
,md5(cast(nvl(sett_apply_type                           ,'') as string))
,md5(cast(nvl(create_dt                                 ,'') as string))
,md5(cast(nvl(update_dt                                 ,'') as string))
,md5(cast(nvl(payinfo_company_name                      ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id          ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                         ,'') as string))
,md5(cast(nvl(payinfo_company_account                   ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account             ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id          ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct                   ,'') as string))
,md5(cast(nvl(fee_id                                    ,'') as string))
,md5(cast(nvl(sett_type                                 ,'') as string))
,md5(cast(nvl(sett_complete_time                        ,'') as string))
,md5(cast(nvl(sett_applyor                              ,'') as string))
,md5(cast(nvl(sett_apply_time                           ,'') as string))
,md5(cast(nvl(refuse_reason                             ,'') as string))
,md5(cast(nvl(fail_reason                               ,'') as string))
,md5(cast(nvl(remark                                    ,'') as string))
,md5(cast(nvl(creator                                   ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type       ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature            ,0) as string))
,md5(cast(nvl(payinfo_other_company_account_nature      ,0) as string))
,md5(cast(nvl(task_id                                   ,'') as string))
,md5(cast(nvl(currency                                  ,'') as string))
,md5(cast(nvl(tax_rate                                  ,'') as string))
,md5(cast(nvl(contract_code                             ,'') as string))
,md5(cast(nvl(project_code                              ,'') as string))
,md5(cast(nvl(standby_field_one                         ,'') as string))
,md5(cast(nvl(standby_field_two                         ,'') as string))
,md5(cast(nvl(standby_field_three                       ,'') as string))
,md5(cast(nvl(standby_field_four                        ,'') as string))
,md5(cast(nvl(standby_field_five                        ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag    ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag  ,'') as string))
,md5(cast(nvl(main_account_id                           ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                 ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc              ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd           ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc        ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src    ,'') as string))
,md5(cast(nvl(fst_cust_mercht_id                        ,'') as string))
,md5(cast(nvl(accti_cust_mercht_id                      ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                         ,'') as string))
,md5(cast(nvl(real_pay_id                               ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src   ,'') as string))
,md5(cast(nvl(dept_id                                   ,'') as string))
,md5(cast(nvl(spec_type_cd                              ,'') as string))
,md5(cast(nvl(spe_val_map                               ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_sett_all_s_d
where dt>='2022-06-20'
group by dt,biz_type,sett_scenes



--dmfbc_bc_fi_fin_sett_all_fee_detail_i_d
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(change_flag                                  ,'') as string))
,md5(cast(nvl(sett_source                                  ,'') as string))
,md5(cast(nvl(data_source_em                               ,'') as string))
,md5(cast(nvl(origin_id                                    ,'') as string))
,md5(cast(nvl(sett_id                                      ,'') as string))
,md5(cast(nvl(fee_id                                       ,'') as string))
,md5(cast(nvl(principal_company                            ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_id           ,'') as string))
,md5(cast(nvl(sett_principal_company_merchant_id           ,'') as string))
,md5(cast(nvl(sett_principal_company_customer_name         ,'') as string))
,md5(cast(nvl(biz_type                                     ,'') as string))
,md5(cast(nvl(sett_scenes                                  ,'') as string))
,md5(cast(nvl(fee_type                                     ,'') as string))
,md5(cast(nvl(product_id                                   ,'') as string))
,md5(cast(nvl(product_name                                 ,'') as string))
,md5(cast(nvl(customer_id                                  ,'') as string))
,md5(cast(nvl(customer_name                                ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id               ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id                ,'') as string))
,md5(cast(nvl(customer_type                                ,'') as string))
,md5(cast(nvl(direction                                    ,'') as string))
,md5(cast(nvl(amount                                       ,0 ) as decimal(24,6)))
,md5(cast(nvl(sett_amount                                  ,0 ) as decimal(24,6)))
,md5(cast(nvl(status                                       ,'') as string))
,md5(cast(nvl(finance_sys_id                               ,'') as string))
,md5(cast(nvl(sett_final_time                              ,'') as string))
,md5(cast(nvl(yn_flag                                      ,'') as string))
,md5(cast(nvl(pay_id                                       ,'') as string))
,md5(cast(nvl(ref_apply_id                                 ,'') as string))
,md5(cast(nvl(sett_apply_type                              ,'') as string))
,md5(cast(nvl(create_dt                                    ,'') as string))
,md5(cast(nvl(update_dt                                    ,'') as string))
,md5(cast(nvl(payinfo_company_name                         ,'') as string))
,md5(cast(nvl(payinfo_company_name_merchant_id             ,'') as string))
,md5(cast(nvl(payinfo_bank_acct                            ,'') as string))
,md5(cast(nvl(payinfo_company_account                      ,'') as string))
,md5(cast(nvl(payinfo_company_account_id                   ,'') as string))
,md5(cast(nvl(payinfo_other_company_name                   ,'') as string))
,md5(cast(nvl(payinfo_other_company_name_merchant_id       ,'') as string))
,md5(cast(nvl(payinfo_other_company_account                ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id             ,'') as string))
,md5(cast(nvl(sett_direction                               ,'') as string))
,md5(cast(nvl(ex_one                                       ,'') as string))
,md5(cast(nvl(ex_two                                       ,'') as string))
,md5(cast(nvl(ex_three                                     ,'') as string))
,md5(cast(nvl(org_id                                       ,'') as string))
,md5(cast(nvl(remark                                       ,'') as string))
,md5(cast(nvl(ex_four                                      ,'') as string))
,md5(cast(nvl(biz_id                                       ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_type          ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_type           ,'') as string))
,md5(cast(nvl(payinfo_company_account_nature               ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_nature         ,'') as string))
,md5(cast(nvl(sett_type                                    ,'') as string))
,md5(cast(nvl(sett_complete_time                           ,'') as string))
,md5(cast(nvl(sett_applyor                                 ,'') as string))
,md5(cast(nvl(sett_apply_time                              ,'') as string))
,md5(cast(nvl(refuse_reason                                ,'') as string))
,md5(cast(nvl(fail_reason                                  ,'') as string))
,md5(cast(nvl(sett_remark                                  ,'') as string))
,md5(cast(nvl(creator                                      ,'') as string))
,md5(cast(nvl(task_id                                      ,'') as string))
,md5(cast(nvl(currency                                     ,'') as string))
,md5(cast(nvl(tax_rate                                     ,'') as string))
,md5(cast(nvl(contract_code                                ,'') as string))
,md5(cast(nvl(project_code                                 ,'') as string))
,md5(cast(nvl(biz_association_id                           ,'') as string))
,md5(cast(nvl(composite_id                                 ,'') as string))
,md5(cast(nvl(standby_field_one                            ,'') as string))
,md5(cast(nvl(standby_field_two                            ,'') as string))
,md5(cast(nvl(standby_field_three                          ,'') as string))
,md5(cast(nvl(standby_field_four                           ,'') as string))
,md5(cast(nvl(standby_field_five                           ,'') as string))
,md5(cast(nvl(sett_currency                                ,'') as string))
,md5(cast(nvl(sett_tax_rate                                ,'') as string))
,md5(cast(nvl(sett_contract_code                           ,'') as string))
,md5(cast(nvl(sett_project_code                            ,'') as string))
,md5(cast(nvl(sett_main_account_id                         ,'') as string))
,md5(cast(nvl(sett_standby_field_one                       ,'') as string))
,md5(cast(nvl(sett_standby_field_two                       ,'') as string))
,md5(cast(nvl(sett_standby_field_three                     ,'') as string))
,md5(cast(nvl(sett_standby_field_four                      ,'') as string))
,md5(cast(nvl(sett_standby_field_five                      ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_src_tag       ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_src_tag        ,'') as string))
,md5(cast(nvl(payinfo_other_company_account_id_src_tag     ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_id            ,'') as string))
,md5(cast(nvl(fee_principal_company_merchant_id            ,'') as string))
,md5(cast(nvl(fee_principal_company_customer_name          ,'') as string))
,md5(cast(nvl(sett_status                                  ,'') as string))
,md5(cast(nvl(sett_yn_flag                                 ,'') as string))
,md5(cast(nvl(amount_in_sett                               ,0 ) as decimal(24,6)))
,md5(cast(nvl(last_dt                                      ,'') as string))
,md5(cast(nvl(bill_code                                    ,'') as string))
,md5(cast(nvl(ex_five                                      ,'') as string))
,md5(cast(nvl(ex_six                                       ,'') as string))
,md5(cast(nvl(ex_seven                                     ,'') as string))
,md5(cast(nvl(ex_eight                                     ,'') as string))
,md5(cast(nvl(ex_nine                                      ,'') as string))
,md5(cast(nvl(ex_ten                                       ,'') as string))
,md5(cast(nvl(ex_eleven                                    ,'') as string))
,md5(cast(nvl(ex_twelve                                    ,'') as string))
,md5(cast(nvl(ex_thirteen                                  ,'') as string))
,md5(cast(nvl(ex_fourteen                                  ,'') as string))
,md5(cast(nvl(ex_fifteen                                   ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_id_all_src        ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_brvt_cd                    ,'') as string))
,md5(cast(nvl(payinfo_bank_acct_dpst_charc                 ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_brvt_cd              ,'') as string))
,md5(cast(nvl(payinfo_other_bank_acct_dpst_charc           ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_id_all_src       ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                            ,'') as string))
,md5(cast(nvl(real_pay_id                                  ,'') as string))
,md5(cast(nvl(fee_customer_name_merchant_typ_all_src       ,'') as string))
,md5(cast(nvl(sett_customer_name_merchant_typ_all_src      ,'') as string))
,md5(cast(nvl(source_id                                    ,'') as string))
,md5(cast(nvl(dept_id                                      ,'') as string))
,md5(cast(nvl(spec_type_cd                                 ,'') as string))
,md5(cast(nvl(trans_time                                   ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fin_sett_all_fee_detail_i_d
where dt>='2022-08-01'
group by dt




select src_tab,fst_biz_typ,count(*) as num
,sum(hash(
 md5(cast(nvl(model_id                          ,'') as string))
,md5(cast(nvl(indx_id                           ,'') as string))
,md5(cast(nvl(src_sys                           ,'') as string))
,md5(cast(nvl(src_tab                           ,'') as string))
,md5(cast(nvl(change_flag                       ,'') as string))
,md5(cast(nvl(rev_data_orig_dt                  ,'') as string))
,md5(cast(nvl(data_unikey                       ,'') as string))
,md5(cast(nvl(accti_biz_line_cd                 ,'') as string))
,md5(cast(nvl(accti_prod_cd                     ,'') as string))
,md5(cast(nvl(tx_tm                             ,'') as string))
,md5(cast(nvl(tx_amt                            ,'') as string))
,md5(cast(nvl(biz_typ                           ,'') as string))
,md5(cast(nvl(cap_typ                           ,'') as string))
,md5(cast(nvl(currency                          ,'') as string))
,md5(cast(nvl(corp_ids                          ,'') as string))
,md5(cast(nvl(corp_mercht_ids                   ,'') as string))
,md5(cast(nvl(corp_nms                          ,'') as string))
,md5(cast(nvl(corp_role_typ                     ,'') as string))
,md5(cast(nvl(mercht_ids                        ,'') as string))
,md5(cast(nvl(mercht_nms                        ,'') as string))
,md5(cast(nvl(mercht_typs                       ,'') as string))
,md5(cast(nvl(recv_acct_id                      ,'') as string))
,md5(cast(nvl(recv_bank_acct_no                 ,'') as string))
,md5(cast(nvl(recv_acct_brvt_cd                 ,'') as string))
,md5(cast(nvl(recv_acct_mercht_id               ,'') as string))
,md5(cast(nvl(recv_acct_corp_nm                 ,'') as string))
,md5(cast(nvl(recv_acct_dpst_charc              ,'') as string))
,md5(cast(nvl(pay_acct_id                       ,'') as string))
,md5(cast(nvl(pay_bank_acct_no                  ,'') as string))
,md5(cast(nvl(pay_acct_brvt_cd                  ,'') as string))
,md5(cast(nvl(pay_acct_mercht_id                ,'') as string))
,md5(cast(nvl(pay_acct_corp_nm                  ,'') as string))
,md5(cast(nvl(pay_acct_dpst_charc               ,'') as string))
,md5(cast(nvl(linkg_acct_id                     ,'') as string))
,md5(cast(nvl(linkg_bank_acct_no                ,'') as string))
,md5(cast(nvl(linkg_acct_brvt_cd                ,'') as string))
,md5(cast(nvl(linkg_acct_mercht_id              ,'') as string))
,md5(cast(nvl(linkg_acct_corp_nm                ,'') as string))
,md5(cast(nvl(linkg_acct_dpst_charc             ,'') as string))
,md5(cast(nvl(linkg_acct_recv_pay_drct          ,'') as string))
,md5(cast(nvl(sett_id                           ,'') as string))
,md5(cast(nvl(fee_id                            ,'') as string))
,md5(cast(nvl(fst_biz_typ                       ,'') as string))
,md5(cast(nvl(fst_sett_scen                     ,'') as string))
,md5(cast(nvl(fst_fee_typ                       ,'') as string))
,md5(cast(nvl(pay_id                            ,'') as string))
,md5(cast(nvl(plat_id                           ,'') as string))
,md5(cast(nvl(biz_pay_id                        ,'') as string))
,md5(cast(nvl(biz_ids                           ,'') as string))
,md5(cast(nvl(tax_rate                          ,'') as string))
,md5(cast(nvl(contr_id                          ,'') as string))
,md5(cast(nvl(proj_id                           ,'') as string))
,md5(cast(nvl(cret_tm                           ,'') as string))
,md5(cast(nvl(modi_tm                           ,'') as string))
,md5(cast(nvl(prod_id                           ,'') as string))
,md5(cast(nvl(prod_nm                           ,'') as string))
,md5(cast(nvl(cust_id                           ,'') as string))
,md5(cast(nvl(cust_nm                           ,'') as string))
,md5(cast(nvl(origin_id                         ,'') as string))
,md5(cast(nvl(ordr_id                           ,'') as string))
,md5(cast(nvl(is_cntn_tax                       ,'') as string))
,md5(cast(nvl(cap_acct_chk_stat                 ,'') as string))
,md5(cast(nvl(biz_tm                            ,'') as string))
,md5(cast(nvl(pay_tm                            ,'') as string))
,md5(cast(nvl(acct_chk_tm                       ,'') as string))
,md5(cast(nvl(fst_tm                            ,'') as string))
,md5(cast(nvl(stmt_no                           ,'') as string))
,md5(cast(nvl(writeoff_status                   ,'') as string))
,md5(cast(nvl(sett_stat                         ,'') as string))
,md5(cast(nvl(fee_stat                          ,'') as string))
,md5(cast(nvl(dept_id                           ,'') as string))
,md5(cast(nvl(spec_type_cd                      ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d
where dt='2022-06-14'
group by src_tab,fst_biz_typ


select * from dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d
where dt>='2022-06-14' and src_tab='dmfbc_bc_fi_fin_sett_all_fee_detail_i_d' 
and sett_id in ('185698435','185698450')




--dmfbc_finsetts_fi_hs_fst_fee_invoice_s_d
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                ,'') as string))
,md5(cast(nvl(change_code             ,'') as string))
,md5(cast(nvl(joinkey                 ,'') as string))
,md5(cast(nvl(fee_id                  ,'') as string))
,md5(cast(nvl(sett_id                 ,'') as string))
,md5(cast(nvl(fee_type                ,'') as string))
,md5(cast(nvl(invoice_apply_id        ,'') as string))
,md5(cast(nvl(invoice_status          ,'') as string))
,md5(cast(nvl(invoice_apply_time      ,'') as string))
,md5(cast(nvl(complete_time           ,'') as string))
,md5(cast(nvl(mail_time               ,'') as string))
,md5(cast(nvl(amt_pct                 ,0 ) as decimal(30,12)))
,md5(cast(nvl(invoice_sett_rel        ,'') as string))
,md5(cast(nvl(sett_amount_invoiced    ,0 ) as decimal(38,6)))
,md5(cast(nvl(refund_time             ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_finsetts_fi_hs_fst_fee_invoice_s_d
where dt>='2022-07-05'
group by dt

select fee_type,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt                ,'') as string))
,md5(cast(nvl(change_code             ,'') as string))
,md5(cast(nvl(joinkey                 ,'') as string))
,md5(cast(nvl(fee_id                  ,'') as string))
,md5(cast(nvl(sett_id                 ,'') as string))
,md5(cast(nvl(fee_type                ,'') as string))
,md5(cast(nvl(invoice_apply_id        ,'') as string))
,md5(cast(nvl(invoice_status          ,'') as string))
,md5(cast(nvl(invoice_apply_time      ,'') as string))
,md5(cast(nvl(complete_time           ,'') as string))
,md5(cast(nvl(mail_time               ,'') as string))
,md5(cast(nvl(amt_pct                 ,0 ) as decimal(30,12)))
,md5(cast(nvl(invoice_sett_rel        ,'') as string))
,md5(cast(nvl(sett_amount_invoiced    ,0 ) as decimal(38,6)))
,md5(cast(nvl(refund_time             ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_finsetts_fi_hs_fst_fee_invoice_s_d
where dt='2022-07-25'
group by fee_type


--dmfbc_finsetts_fi_hs_fst_fee_invoice_h_d
select end_dt,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt             ,'') as string))
,md5(cast(nvl(change_code          ,'') as string))
,md5(cast(nvl(joinkey              ,'') as string))
,md5(cast(nvl(fee_id               ,'') as string))
,md5(cast(nvl(sett_id              ,'') as string))
,md5(cast(nvl(fee_type             ,'') as string))
,md5(cast(nvl(invoice_apply_id     ,'') as string))
,md5(cast(nvl(invoice_status       ,'') as string))
,md5(cast(nvl(invoice_apply_time   ,'') as string))
,md5(cast(nvl(complete_time        ,'') as string))
,md5(cast(nvl(mail_time            ,'') as string))
,md5(cast(nvl(amt_pct                 ,0 ) as decimal(30,12)))
,md5(cast(nvl(invoice_sett_rel     ,'') as string))
,md5(cast(nvl(sett_amount_invoiced    ,0 ) as decimal(38,6)))
,md5(cast(nvl(refund_time          ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_finsetts_fi_hs_fst_fee_invoice_h_d
where end_dt>='2022-07-05'
group by end_dt

select end_dt,fee_type,count(*) as num
,sum(hash(
 md5(cast(nvl(start_dt             ,'') as string))
,md5(cast(nvl(change_code          ,'') as string))
,md5(cast(nvl(joinkey              ,'') as string))
,md5(cast(nvl(fee_id               ,'') as string))
,md5(cast(nvl(sett_id              ,'') as string))
,md5(cast(nvl(fee_type             ,'') as string))
,md5(cast(nvl(invoice_apply_id     ,'') as string))
,md5(cast(nvl(invoice_status       ,'') as string))
,md5(cast(nvl(invoice_apply_time   ,'') as string))
,md5(cast(nvl(complete_time        ,'') as string))
,md5(cast(nvl(mail_time            ,'') as string))
,md5(cast(nvl(amt_pct                 ,0 ) as decimal(30,12)))
,md5(cast(nvl(invoice_sett_rel     ,'') as string))
,md5(cast(nvl(sett_amount_invoiced    ,0 ) as decimal(38,6)))
,md5(cast(nvl(refund_time          ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_finsetts_fi_hs_fst_fee_invoice_h_d
where end_dt>='2022-07-20' and end_dt<='2022-07-25'
group by end_dt,fee_type

select * from dmf_bc.dmfbc_finsetts_fi_hs_fst_fee_invoice_h_d
where end_dt>='2022-07-20' and end_dt<='2022-07-25'
and fee_type='67506'

--
select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(sett_id            ,'') as string))
,md5(cast(nvl(fee_type           ,'') as string))
,md5(cast(nvl(invoice_amount_shd ,'') as string))
,md5(cast(nvl(invoice_apply_id   ,'') as string))
,md5(cast(nvl(invoice_amount     ,'') as string))
,md5(cast(nvl(invoice_status     ,'') as string))
,md5(cast(nvl(invoice_apply_time ,'') as string))
,md5(cast(nvl(complete_time      ,'') as string))
,md5(cast(nvl(mail_time          ,'') as string))
,md5(cast(nvl(amt_pct            ,'') as string))
,md5(cast(nvl(invoice_sett_rel   ,'') as string))
,md5(cast(nvl(refund_time        ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_finsetts_fi_hs_fst_sett_invoice_s_d
where dt>='2022-06-23'
group by dt




select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(etl_dt                     ,'') as string))
,md5(cast(nvl(jrjt_del_dt                ,'') as string))
,md5(cast(nvl(start_dt1                  ,'') as string))
,md5(cast(nvl(rowkey                     ,'') as string))
,md5(cast(nvl(orderid                    ,'') as string))
,md5(cast(nvl(payid                      ,'') as string))
,md5(cast(nvl(paytime                    ,'') as string))
,md5(cast(nvl(payenum                    ,'') as string))
,md5(cast(nvl(currency                   ,'') as string))
,md5(cast(nvl(orderconfirmprice          ,'') as string))
,md5(cast(nvl(confirmtype                ,'') as string))
,md5(cast(nvl(confirmresulttype          ,'') as string))
,md5(cast(nvl(pin                        ,'') as string))
,md5(cast(nvl(orderconfirmtime           ,'') as string))
,md5(cast(nvl(orderconfirmid             ,'') as string))
,md5(cast(nvl(ordertype                  ,'') as string))
,md5(cast(nvl(ver                        ,'') as string))
,md5(cast(nvl(priceprotect               ,'') as string))
,md5(cast(nvl(realdueprice               ,'') as string))
,md5(cast(nvl(realpayprice               ,'') as string))
,md5(cast(nvl(paidin                     ,'') as string))
,md5(cast(nvl(auditstatus                ,'') as string))
,md5(cast(nvl(lastorderbankstatus        ,'') as string))
,md5(cast(nvl(refundtype                 ,'') as string))
,md5(cast(nvl(paymode                    ,'') as string))
,md5(cast(nvl(price                      ,'') as string))
,md5(cast(nvl(orderbankcreatesource      ,'') as string))
,md5(cast(nvl(paymoney                   ,'') as string))
,md5(cast(nvl(merchantid                 ,'') as string))
,md5(cast(nvl(merchantorderno            ,'') as string))
,md5(cast(nvl(exccedprice                ,'') as string))
,md5(cast(nvl(extendparams               ,'') as string))
,md5(cast(nvl(merchantno                 ,'') as string))
,md5(cast(nvl(bank_id                    ,'') as string))
,md5(cast(nvl(acc_brief_code             ,'') as string))
,md5(cast(nvl(acc_brief_name             ,'') as string))
,md5(cast(nvl(belong_company_id          ,'') as string))
,md5(cast(nvl(mercht_id                  ,'') as string))
,md5(cast(nvl(belong_company_name        ,'') as string))
)) as hash_num
from dmf_bc.dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d
where dt>='2022-06-14'
group by dt
;

select payid,paytime,count(*) as num
from dmf_bc.dmfbc_redu_odm_fi_tz_orderconfirm_success_1_i_d
group by payid,paytime
having count(*)>1
;

select payid,paytime,hash_num,count(*) as num 
from (
  select payid,paytime,count(*) as num
  ,sum(hash(
   md5(cast(nvl(etl_dt                 ,'') as string))
  ,md5(cast(nvl(rt_meta                ,'') as string))
  ,md5(cast(nvl(start_dt1              ,'') as string))
  ,md5(cast(nvl(rowkey                 ,'') as string))
  ,md5(cast(nvl(orderid                ,'') as string))
  ,md5(cast(nvl(payid                  ,'') as string))
  ,md5(cast(nvl(paytime                ,'') as string))
  ,md5(cast(nvl(payenum                ,'') as string))
  ,md5(cast(nvl(currency               ,'') as string))
  ,md5(cast(nvl(orderconfirmprice      ,'') as string))
  ,md5(cast(nvl(confirmtype            ,'') as string))
  ,md5(cast(nvl(confirmresulttype      ,'') as string))
  ,md5(cast(nvl(pin                    ,'') as string))
  ,md5(cast(nvl(orderconfirmtime       ,'') as string))
  ,md5(cast(nvl(orderconfirmid         ,'') as string))
  ,md5(cast(nvl(ordertype              ,'') as string))
  ,md5(cast(nvl(ver                    ,'') as string))
  ,md5(cast(nvl(priceprotect           ,'') as string))
  ,md5(cast(nvl(realdueprice           ,'') as string))
  ,md5(cast(nvl(realpayprice           ,'') as string))
  ,md5(cast(nvl(paidin                 ,'') as string))
  ,md5(cast(nvl(auditstatus            ,'') as string))
  ,md5(cast(nvl(lastorderbankstatus    ,'') as string))
  ,md5(cast(nvl(refundtype             ,'') as string))
  ,md5(cast(nvl(paymode                ,'') as string))
  ,md5(cast(nvl(price                  ,'') as string))
  ,md5(cast(nvl(orderbankcreatesource  ,'') as string))
  ,md5(cast(nvl(paymoney               ,'') as string))
  ,md5(cast(nvl(merchantid             ,'') as string))
  ,md5(cast(nvl(merchantorderno        ,'') as string))
  ,md5(cast(nvl(exccedprice            ,'') as string))
  ,md5(cast(nvl(extendparams           ,'') as string))
  ,md5(cast(nvl(merchantno             ,'') as string))
  ,md5(cast(nvl(bank_id                ,'') as string))
  ,md5(cast(nvl(acc_brief_code         ,'') as string))
  ,md5(cast(nvl(acc_brief_name         ,'') as string))
  ,md5(cast(nvl(belong_company_id      ,'') as string))
  ,md5(cast(nvl(mercht_id              ,'') as string))
  ,md5(cast(nvl(belong_company_name    ,'') as string))
  
  )) as hash_num
  from dmf_bc.dmfbc_redu_odm_fi_tz_orderconfirm_success_1_i_d
  group by payid,paytime
  having count(*)>1
) b
group by payid,paytime,hash_num
having count(*) >1
;



select a1.payid,a1.hash_num,a2.hash_num aa
from (select payid
          ,hash(
           md5(cast(nvl(etl_dt                     ,'') as string))
          ,md5(cast(nvl(jrjt_del_dt                ,'') as string))
          ,md5(cast(nvl(start_dt1                  ,'') as string))
          ,md5(cast(nvl(rowkey                     ,'') as string))
          ,md5(cast(nvl(orderid                    ,'') as string))
          ,md5(cast(nvl(payid                      ,'') as string))
          ,md5(cast(nvl(paytime                    ,'') as string))
          ,md5(cast(nvl(payenum                    ,'') as string))
          ,md5(cast(nvl(currency                   ,'') as string))
          ,md5(cast(nvl(orderconfirmprice          ,'') as string))
          ,md5(cast(nvl(confirmtype                ,'') as string))
          ,md5(cast(nvl(confirmresulttype          ,'') as string))
          ,md5(cast(nvl(pin                        ,'') as string))
          ,md5(cast(nvl(orderconfirmtime           ,'') as string))
          ,md5(cast(nvl(orderconfirmid             ,'') as string))
          ,md5(cast(nvl(ordertype                  ,'') as string))
          ,md5(cast(nvl(ver                        ,'') as string))
          ,md5(cast(nvl(priceprotect               ,'') as string))
          ,md5(cast(nvl(realdueprice               ,'') as string))
          ,md5(cast(nvl(realpayprice               ,'') as string))
          ,md5(cast(nvl(paidin                     ,'') as string))
          ,md5(cast(nvl(auditstatus                ,'') as string))
          ,md5(cast(nvl(lastorderbankstatus        ,'') as string))
          ,md5(cast(nvl(refundtype                 ,'') as string))
          ,md5(cast(nvl(paymode                    ,'') as string))
          ,md5(cast(nvl(price                      ,'') as string))
          ,md5(cast(nvl(orderbankcreatesource      ,'') as string))
          ,md5(cast(nvl(paymoney                   ,'') as string))
          ,md5(cast(nvl(merchantid                 ,'') as string))
          ,md5(cast(nvl(merchantorderno            ,'') as string))
          ,md5(cast(nvl(exccedprice                ,'') as string))
          ,md5(cast(nvl(extendparams               ,'') as string))
          ,md5(cast(nvl(merchantno                 ,'') as string))
          ,md5(cast(nvl(bank_id                    ,'') as string))
          ,md5(cast(nvl(acc_brief_code             ,'') as string))
          ,md5(cast(nvl(acc_brief_name             ,'') as string))
          ,md5(cast(nvl(belong_company_id          ,'') as string))
          ,md5(cast(nvl(mercht_id                  ,'') as string))
          ,md5(cast(nvl(belong_company_name        ,'') as string))
          ) as hash_num 
      from dmf_bc.dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d
	  where dt='2022-06-14'
	  ) a1
left join (select payid
                 ,hash(
                  md5(cast(nvl(etl_dt                     ,'') as string))
                 ,md5(cast(nvl(jrjt_del_dt                ,'') as string))
                 ,md5(cast(nvl(start_dt1                  ,'') as string))
                 ,md5(cast(nvl(rowkey                     ,'') as string))
                 ,md5(cast(nvl(orderid                    ,'') as string))
                 ,md5(cast(nvl(payid                      ,'') as string))
                 ,md5(cast(nvl(paytime                    ,'') as string))
                 ,md5(cast(nvl(payenum                    ,'') as string))
                 ,md5(cast(nvl(currency                   ,'') as string))
                 ,md5(cast(nvl(orderconfirmprice          ,'') as string))
                 ,md5(cast(nvl(confirmtype                ,'') as string))
                 ,md5(cast(nvl(confirmresulttype          ,'') as string))
                 ,md5(cast(nvl(pin                        ,'') as string))
                 ,md5(cast(nvl(orderconfirmtime           ,'') as string))
                 ,md5(cast(nvl(orderconfirmid             ,'') as string))
                 ,md5(cast(nvl(ordertype                  ,'') as string))
                 ,md5(cast(nvl(ver                        ,'') as string))
                 ,md5(cast(nvl(priceprotect               ,'') as string))
                 ,md5(cast(nvl(realdueprice               ,'') as string))
                 ,md5(cast(nvl(realpayprice               ,'') as string))
                 ,md5(cast(nvl(paidin                     ,'') as string))
                 ,md5(cast(nvl(auditstatus                ,'') as string))
                 ,md5(cast(nvl(lastorderbankstatus        ,'') as string))
                 ,md5(cast(nvl(refundtype                 ,'') as string))
                 ,md5(cast(nvl(paymode                    ,'') as string))
                 ,md5(cast(nvl(price                      ,'') as string))
                 ,md5(cast(nvl(orderbankcreatesource      ,'') as string))
                 ,md5(cast(nvl(paymoney                   ,'') as string))
                 ,md5(cast(nvl(merchantid                 ,'') as string))
                 ,md5(cast(nvl(merchantorderno            ,'') as string))
                 ,md5(cast(nvl(exccedprice                ,'') as string))
                 ,md5(cast(nvl(extendparams               ,'') as string))
                 ,md5(cast(nvl(merchantno                 ,'') as string))
                 ,md5(cast(nvl(bank_id                    ,'') as string))
                 ,md5(cast(nvl(acc_brief_code             ,'') as string))
                 ,md5(cast(nvl(acc_brief_name             ,'') as string))
                 ,md5(cast(nvl(belong_company_id          ,'') as string))
                 ,md5(cast(nvl(mercht_id                  ,'') as string))
                 ,md5(cast(nvl(belong_company_name        ,'') as string))
                 ) as hash_num 
           from dmf_bc.auto_validate_dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d
           where dt='2022-06-14'
		  ) a2
       on  a1.payid = a2.payid
    where  a1.hash_num != a2.hash_num
;


select * from dmf_bc.dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d
where dt='2022-06-14' and payid in ('1001151445488904864511','58612620091702542509282')
;

select * from dmf_bc.dmfbc_redu_odm_fi_tz_orderconfirm_success_1_i_d
where payid in ('1001151445488904864511','58612620091702542509282')
;


use dmf_tmp;

drop table if exists dmf_tmp.renxiaowei7_20220616_dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d_tmp_01;
create table dmf_tmp.renxiaowei7_20220616_dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d_tmp_01
as
select * from dmf_bc.dmfbc_redu_odm_fi_fi_tz_fi_hive_caiwu_orderconfirm_success_s_d
where dt='2022-06-14'
;


select   md5( cast( nvl( t.corp_id,'' )  as string) )    as corp_id
       , md5( cast( nvl( t.corp_nm,'' )  as string) )    as corp_nm
	   , md5( cast( nvl( t.mercht_id,'' )  as string) )    as mercht_id
	   , md5( cast( nvl( t.rn_corp_nm,0 )  as string) )    as rn_corp_nm
	   , md5( cast( nvl( t.rn_corp_id,0 )  as string) )    as rn_corp_id 
from dmf_dim.dmfdim_dim_fi_fin_subject_principal_merchant_s_d t 
where  dt='2022-05-24'


select count(*) from dmf_bc.dmfbc_redu_odm_fi_pay_zh_fi_bd_bank_account_info_s_d
where dt='2022-06-07'

select mercht_id
,count(*) as num
,sum(hash(md5(cast(nvl(dt_tag,'') as string))
,md5(cast(nvl(src_tag,'') as string))
,md5(cast(nvl(del_tag,'') as string))
,md5(cast(nvl(id,0) as string))
,md5(cast(nvl(acc_brief_code,'') as string))
,md5(cast(nvl(acc_brief_name,'') as string))
,md5(cast(nvl(account_code,'') as string))
,md5(cast(nvl(acc_name,'') as string))
,md5(cast(nvl(cnaps,'') as string))
,md5(cast(nvl(belong_bank_id,0) as string))
,md5(cast(nvl(belong_bank_name,'') as string))
,md5(cast(nvl(open_acc_bank_id,0) as string))
,md5(cast(nvl(open_acc_bank,'') as string))
,md5(cast(nvl(belong_company_id,0) as string))
,md5(cast(nvl(belong_company_ou,'') as string))
,md5(cast(nvl(belong_company,'') as string))
,md5(cast(nvl(currency,0) as string))
,md5(cast(nvl(currency_name,'') as string))
,md5(cast(nvl(acc_nature,0) as string))
,md5(cast(nvl(open_acc_area,'') as string))
,md5(cast(nvl(bank_linkman,'') as string))
,md5(cast(nvl(bank_linkman_tm,'') as string))
,md5(cast(nvl(bank_linkman_join,'') as string))
,md5(cast(nvl(bank_linkman_phone,'') as string))
,md5(cast(nvl(bank_linkman_phone_tm,'') as string))
,md5(cast(nvl(bank_linkman_phone_join,'') as string))
,md5(cast(nvl(acc_leader,'') as string))
,md5(cast(nvl(acc_leader_tm,'') as string))
,md5(cast(nvl(acc_leader_join,'') as string))
,md5(cast(nvl(fund_manage_org,0) as string))
,md5(cast(nvl(acc_manage_org,0) as string))
,md5(cast(nvl(bank_address,'') as string))
,md5(cast(nvl(bank_address_join,'') as string))
,md5(cast(nvl(open_acc_date,'') as string))
,md5(cast(nvl(cancel_acc_date,'') as string))
,md5(cast(nvl(acc_use,0) as string))
,md5(cast(nvl(limit_type,0) as string))
,md5(cast(nvl(fund_cache_acc,0) as string))
,md5(cast(nvl(is_access_cache,0) as string))
,md5(cast(nvl(acc_type,0) as string))
,md5(cast(nvl(acc_status,0) as string))
,md5(cast(nvl(money_properties,0) as string))
,md5(cast(nvl(creator_pin,'') as string))
,md5(cast(nvl(creator,'') as string))
,md5(cast(nvl(create_date,'') as string))
,md5(cast(nvl(last_update_user_pin,'') as string))
,md5(cast(nvl(last_update_user,'') as string))
,md5(cast(nvl(last_update_date,'') as string))
,md5(cast(nvl(memo,'') as string))
,md5(cast(nvl(swift_code,'') as string))
,md5(cast(nvl(city,'') as string))
,md5(cast(nvl(country,'') as string))
,md5(cast(nvl(domestic_overseas,0) as string))
,md5(cast(nvl(business_section,0) as string))
,md5(cast(nvl(limit_type_detail,0) as string))
,md5(cast(nvl(independent_account,0) as string))
,md5(cast(nvl(accounting_leader,'') as string))
,md5(cast(nvl(bank_leader,'') as string))
,md5(cast(nvl(company_ou,'') as string))
,md5(cast(nvl(fa_ren,'') as string))
,md5(cast(nvl(cw_chapter,'') as string))
,md5(cast(nvl(fund_start_date,'') as string))
,md5(cast(nvl(report_type,0) as string))
,md5(cast(nvl(first_number,'') as string))
,md5(cast(nvl(bank_exchange_number,'') as string))
,md5(cast(nvl(consolidate_account,'') as string))
,md5(cast(nvl(account_type,'') as string))
,md5(cast(nvl(subject,'') as string))
,md5(cast(nvl(sub_subject,'') as string))
,md5(cast(nvl(bank_code,'') as string))
,md5(cast(nvl(bank_name,'') as string))
,md5(cast(nvl(mercht_id,'') as string))
,md5(cast(nvl(payenum,'') as string))
,md5(cast(nvl(dt,'') as string))
)) as hash_num
from dmf_bc.dmfbc_redu_odm_fi_pay_zh_fi_bd_bank_account_info_s_d
where dt='2022-06-07'
group by mercht_id
;


select * from dmf_bc.dmfbc_redu_odm_fi_pay_zh_fi_bd_bank_account_info_s_d
where dt='2022-06-07'
and mercht_id='1001678'
;


(SELECT * FROM 
   (SELECT *
          , if (substr(last_update_date, 1, 10) > dt, '3', '1') as dt_tag
          , '1' as src_tag
          , '0' as del_tag
          , ROW_NUMBER() OVER (DISTRIBUTE BY id SORT BY substr(create_date,1,19)  DESC,substr(last_update_date,1,19) DESC,dt DESC) rank
      FROM odm.odm_pay_zh_fi_bd_bank_account_info_i_d
      WHERE dt <= '{TX_DATE}' and id>=450 and id!=4796 and id!=4083 and id!=6046 and id!=5048 and id!=1108 and id!=973 and id!=3136 and id!=1109    --排除业务系统已经物理删除的数据
    ) x
   WHERE rank = 1
) t1

select * from odm.odm_pay_zh_fi_bd_bank_account_info_i_d
where dt>='2022-02-23'
and id in ('7512','7513','7514')




select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(payenum          ,'') as string))
,md5(cast(nvl(payenum_desc     ,'') as string))
,md5(cast(nvl(use_chnl_model   ,'') as string))
,md5(cast(nvl(ordr_type        ,'') as string))
,md5(cast(nvl(ordr_type_desc   ,'') as string))
,md5(cast(nvl(pay_type         ,'') as string))
,md5(cast(nvl(pay_type_desc    ,'') as string))
,md5(cast(nvl(mht_no           ,'') as string))
,md5(cast(nvl(status           ,'') as string))
,md5(cast(nvl(setitems         ,'') as string))
,md5(cast(nvl(create_time      ,'') as string))
,md5(cast(nvl(modify_time      ,'') as string))
,md5(cast(nvl(bank_id          ,'') as string))
,md5(cast(nvl(acc_brief_code   ,'') as string))
,md5(cast(nvl(acc_brief_name   ,'') as string))
,md5(cast(nvl(acc_name         ,'') as string))
,md5(cast(nvl(belong_company_id,'') as string))
,md5(cast(nvl(mercht_id        ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d a1
group by dt
;


use dmf_dev;
drop table if exists dmf_dev.renxiaowei7_20220614_dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d_tmp_01;
create table dmf_dev.renxiaowei7_20220614_dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d_tmp_01
like dmf_dim.dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d;
insert into dmf_dev.renxiaowei7_20220614_dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d_tmp_01 partition(dt)
select * from dmf_dim.dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d;


alter table dmf_dim.dmfdim_dim_fi_pay_syt_payenum_cnfg_bank_account_info_s_d drop partition(dt<='2022-06-13');




select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(id           ,'') as string))
,md5(cast(nvl(account_code ,'') as string))
,md5(cast(nvl(acc_nature   ,'') as string))
)) as hash_num
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
group by dt
;

select a1.account_code,a1.id,a2.id as aa
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
left join  dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a2 
       on  a2.dt='2022-05-30'
      and  a1.account_code = a2.account_code
    where  a1.dt = '2022-05-31'
      and  a1.id != a2.id
;    
select a1.account_code,a1.acc_nature,a2.acc_nature as aa
from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a1
left join  dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d a2 
       on  a2.dt='2022-05-30'
      and  a1.account_code = a2.account_code
    where  a1.dt = '2022-05-31'
      and  a1.acc_nature != a2.acc_nature
;


select * from dmf_dim.dmfdim_finsetts_fi_hs_bank_account_code_s_d
where dt='2022-05-31' and account_code in ('01287593012595','11050163560000001412')
;

select * from dmf_bc.dmfbc_redu_odm_fi_pay_zh_fi_bd_bank_account_info_s_d
where dt='2022-05-31' and account_code in ('01287593012595','11050163560000001412')
;




--dmfbc_bc_sett_spec_conf_s_d

select dt,count(*) as num
,sum(hash(
 md5(cast(nvl(change_flag  ,'') as string))
,md5(cast(nvl(modlecd      ,'') as string))
,md5(cast(nvl(tabcd        ,'') as string))
,md5(cast(nvl(typecd       ,'') as string))
,md5(cast(nvl(biztype      ,'') as string))
,md5(cast(nvl(settscenes   ,'') as string))
,md5(cast(nvl(feetype      ,'') as string))
,md5(cast(nvl(field_01     ,'') as string))
,md5(cast(nvl(field_02     ,'') as string))
,md5(cast(nvl(field_03     ,'') as string))
,md5(cast(nvl(field_04     ,'') as string))
,md5(cast(nvl(field_05     ,'') as string))
,md5(cast(nvl(field_06     ,'') as string))
,md5(cast(nvl(field_07     ,'') as string))
,md5(cast(nvl(field_08     ,'') as string))
,md5(cast(nvl(mapp_01_name ,'') as string))
,md5(cast(nvl(mapp_01_val  ,'') as string))
,md5(cast(nvl(mapp_02_name ,'') as string))
,md5(cast(nvl(mapp_02_val  ,'') as string))
,md5(cast(nvl(mapp_03_name ,'') as string))
,md5(cast(nvl(mapp_03_val  ,'') as string))
,md5(cast(nvl(result_sql   ,'') as string))
,md5(cast(nvl(impt_dt      ,'') as string))
,md5(cast(nvl(origin_id    ,'') as string))
,md5(cast(nvl(impt_erp     ,'') as string))

)) as hash_num
from dmf_bc.dmfbc_bc_sett_spec_conf_s_d
where dt>='2022-08-01'
group by dt
;

select * from dmf_bc.dmfbc_bc_sett_spec_conf_s_d
where dt='2022-08-23'
