# !/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE
def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

"sql_01": """
use dmf_bc;

alter table dmf_bc.dmfbc_bc_sett_spec_conf_s_d drop partition(dt = '4712-12-31');
alter table dmf_bc.dmfbc_bc_sett_spec_conf_s_d add  partition(dt = '4712-12-31');
alter table dmf_bc.dmfbc_bc_sett_spec_conf_s_d drop partition(dt = '{TX_DATE}' );
alter table dmf_bc.dmfbc_bc_sett_spec_conf_s_d add  partition(dt = '{TX_DATE}' );
""",


"sql_02": """
use dmf_bc;

from (
    select  change_flag,modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val,result_sql,impt_dt
	       --每次处理完成后重新生产origin_id，避免出现数据和origin_id不一致的情况
	       ,dmf_bc.getmd5(concat_ws(',',modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val)) as origin_id
		   ,impt_erp
           ,row_number() over(partition by origin_id order by change_flag desc,data_flag asc) as rank
    from (
        --历史数据
        select     '0' as data_flag  --数据标志 0-历史数据/1-当日数据
    	          ,'0' as change_flag,modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val,result_sql,impt_dt
                  ,if(nvl(origin_id,'')=''
        		     ,dmf_bc.getmd5(concat_ws(',',modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val))
        			 ,origin_id
        			 ) as origin_id
				  ,impt_erp
        from dmf_bc.dmfbc_bc_sett_spec_conf_s_d
        where dt = date_sub('{TX_DATE}',1)
        union all
        --当日新增/删除/更新 change_flag 变更标志 0-新增/1-删除/2-更新
        select     '1' as data_flag  --数据标志 0-历史数据/1-当日数据
    	          ,change_flag,modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val,result_sql,impt_dt
                  ,if(change_flag = '0'
    			     ,dmf_bc.getmd5(concat_ws(',',modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val))
    			     ,origin_id
    				 ) as origin_id
				  ,impt_erp
        from dmf_add.dmfadd_add_sett_spec_conf_i_d  --补录表
        where  impt_dt = '{TX_DATE}'
          and (change_flag = '0'
    	       or (change_flag in ('1','2') and nvl(origin_id,'') != ''))  --防止导入的时候删除和更新的数据漏填origin_id
    ) a
) t
insert into table dmf_bc.dmfbc_bc_sett_spec_conf_s_d partition(dt='{TX_DATE}')
select change_flag,modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val,result_sql,impt_dt,origin_id,impt_erp
where rank = 1 and change_flag != '1'
insert into table dmf_bc.dmfbc_bc_sett_spec_conf_s_d partition(dt='4712-12-31')
select change_flag,modleCd,tabCd,typeCd,bizType,settScenes,feeType,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,mapp_01_name,mapp_01_val,mapp_02_name,mapp_02_val,mapp_03_name,mapp_03_val,result_sql,impt_dt,origin_id,impt_erp
where rank = 1 and change_flag != '1'
;
""",

"sql_03": """
use dmf_bc;

truncate table dmf_bc.dmfbc_bc_sett_spec_conf_detail_a_d;
insert into table dmf_bc.dmfbc_bc_sett_spec_conf_detail_a_d
select     modleCd      --层级
          ,tabCd        --处理表
          ,typeCd       --处理类型
          ,bizType      --结算业务类型
          ,settScenes   --结算场景
          ,feeType      --结算费用类型
          ,nvl(split(field_01,'#')[0],'')               as field_01_flag --扩展字段01-条件类型
          ,nvl(split(split(field_01,'#')[1],'&')[0],'') as field_01_coll --扩展字段01-条件字段
          ,nvl(split(split(field_01,'#')[1],'&')[1],'') as field_01_val  --扩展字段01-条件值
          ,nvl(split(field_02,'#')[0],'')               as field_02_flag --扩展字段02-条件类型
          ,nvl(split(split(field_02,'#')[1],'&')[0],'') as field_02_coll --扩展字段02-条件字段
          ,nvl(split(split(field_02,'#')[1],'&')[1],'') as field_02_val  --扩展字段02-条件值
          ,nvl(split(field_03,'#')[0],'')               as field_03_flag --扩展字段03-条件类型
          ,nvl(split(split(field_03,'#')[1],'&')[0],'') as field_03_coll --扩展字段03-条件字段
          ,nvl(split(split(field_03,'#')[1],'&')[1],'') as field_03_val  --扩展字段03-条件值
          ,nvl(split(field_04,'#')[0],'')               as field_04_flag --扩展字段04-条件类型
          ,nvl(split(split(field_04,'#')[1],'&')[0],'') as field_04_coll --扩展字段04-条件字段
          ,nvl(split(split(field_04,'#')[1],'&')[1],'') as field_04_val  --扩展字段04-条件值
          ,nvl(split(field_05,'#')[0],'')               as field_05_flag --扩展字段05-条件类型
          ,nvl(split(split(field_05,'#')[1],'&')[0],'') as field_05_coll --扩展字段05-条件字段
          ,nvl(split(split(field_05,'#')[1],'&')[1],'') as field_05_val  --扩展字段05-条件值
          ,nvl(split(field_06,'#')[0],'')               as field_06_flag --扩展字段06-条件类型
          ,nvl(split(split(field_06,'#')[1],'&')[0],'') as field_06_coll --扩展字段06-条件字段
          ,nvl(split(split(field_06,'#')[1],'&')[1],'') as field_06_val  --扩展字段06-条件值
          ,nvl(split(field_07,'#')[0],'')               as field_07_flag --扩展字段07-条件类型
          ,nvl(split(split(field_07,'#')[1],'&')[0],'') as field_07_coll --扩展字段07-条件字段
          ,nvl(split(split(field_07,'#')[1],'&')[1],'') as field_07_val  --扩展字段07-条件值
          ,nvl(split(field_08,'#')[0],'')               as field_08_flag --扩展字段08-条件类型
          ,nvl(split(split(field_08,'#')[1],'&')[0],'') as field_08_coll --扩展字段08-条件字段
          ,nvl(split(split(field_08,'#')[1],'&')[1],'') as field_08_val  --扩展字段08-条件值

		  --映射函数条件01
          ,nvl(split(split(mapp_01_name,'#')[1],'&')[0],'') as func_01_nm                    --映射函数条件01-映射函数名称
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[0],'') as func_01_coll_01 --映射函数条件01-映射函数字段01
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[1],'') as func_01_coll_02 --映射函数条件01-映射函数字段02
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[2],'') as func_01_coll_03 --映射函数条件01-映射函数字段03
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[3],'') as func_01_coll_04 --映射函数条件01-映射函数字段04
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[4],'') as func_01_coll_05 --映射函数条件01-映射函数字段05
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[5],'') as func_01_coll_06 --映射函数条件01-映射函数字段06
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[6],'') as func_01_coll_07 --映射函数条件01-映射函数字段07
          ,nvl(split(split(split(mapp_01_name,'#')[1],'&')[1],',')[7],'') as func_01_coll_08 --映射函数条件01-映射函数字段08
          ,nvl(split(mapp_01_val,'#')[0],'') as func_01_flag                                 --映射函数条件01-条件类型
          ,nvl(split(split(mapp_01_val,'#')[1],'&')[1],'') as func_01_val                    --映射函数条件01-条件值
          --映射函数条件02
          ,nvl(split(split(mapp_02_name,'#')[1],'&')[0],'') as func_02_nm                    --映射函数条件02-映射函数名称
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[0],'') as func_02_coll_01 --映射函数条件02-映射函数字段01
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[1],'') as func_02_coll_02 --映射函数条件02-映射函数字段02
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[2],'') as func_02_coll_03 --映射函数条件02-映射函数字段03
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[3],'') as func_02_coll_04 --映射函数条件02-映射函数字段04
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[4],'') as func_02_coll_05 --映射函数条件02-映射函数字段05
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[5],'') as func_02_coll_06 --映射函数条件02-映射函数字段06
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[6],'') as func_02_coll_07 --映射函数条件02-映射函数字段07
          ,nvl(split(split(split(mapp_02_name,'#')[1],'&')[1],',')[7],'') as func_02_coll_08 --映射函数条件02-映射函数字段08
          ,nvl(split(mapp_02_val,'#')[0],'') as func_02_flag                                 --映射函数条件02-条件类型
          ,nvl(split(split(mapp_02_val,'#')[1],'&')[1],'') as func_02_val                    --映射函数条件02-条件值
          --映射函数条件03
          ,nvl(split(split(mapp_03_name,'#')[1],'&')[0],'') as func_03_nm                    --映射函数条件03-映射函数名称
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[0],'') as func_03_coll_01 --映射函数条件03-映射函数字段01
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[1],'') as func_03_coll_02 --映射函数条件03-映射函数字段02
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[2],'') as func_03_coll_03 --映射函数条件03-映射函数字段03
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[3],'') as func_03_coll_04 --映射函数条件03-映射函数字段04
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[4],'') as func_03_coll_05 --映射函数条件03-映射函数字段05
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[5],'') as func_03_coll_06 --映射函数条件03-映射函数字段06
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[6],'') as func_03_coll_07 --映射函数条件03-映射函数字段07
          ,nvl(split(split(split(mapp_03_name,'#')[1],'&')[1],',')[7],'') as func_03_coll_08 --映射函数条件03-映射函数字段08
          ,nvl(split(mapp_03_val,'#')[0],'') as func_03_flag                                 --映射函数条件03-条件类型
          ,nvl(split(split(mapp_03_val,'#')[1],'&')[1],'') as func_03_val                    --映射函数条件03-条件值
          
          --映射结果
          ,result_sql   --映射结果
          ,split(result_sql,'#')[0] as result_flag                                                                                     --结果标志
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(result_sql,'#')[1],'&')[0],''),'') as result_val_func_nm                    --映射结果-映射函数名称
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[0],''),'') as result_val_func_coll_01 --映射结果-映射函数字段01
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[1],''),'') as result_val_func_coll_02 --映射结果-映射函数字段02
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[2],''),'') as result_val_func_coll_03 --映射结果-映射函数字段03
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[3],''),'') as result_val_func_coll_04 --映射结果-映射函数字段04
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[4],''),'') as result_val_func_coll_05 --映射结果-映射函数字段05
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[5],''),'') as result_val_func_coll_06 --映射结果-映射函数字段06
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[6],''),'') as result_val_func_coll_07 --映射结果-映射函数字段07
          ,if(split(result_sql,'#')[0]='F',nvl(split(split(split(result_sql,'#')[1],'&')[1],',')[7],''),'') as result_val_func_coll_08 --映射结果-映射函数字段08
          ,if(split(result_sql,'#')[0]!='F',split(result_sql,'#')[1],'') as result_val_sql                                             --结果-语句
          
          ,impt_dt      --导入时间
		  ,origin_id    --唯一键
          
from dmf_bc.dmfbc_bc_sett_spec_conf_s_d
where dt='4712-12-31'
;
""",

}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)