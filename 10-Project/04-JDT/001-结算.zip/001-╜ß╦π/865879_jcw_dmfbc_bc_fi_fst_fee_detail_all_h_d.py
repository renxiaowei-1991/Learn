#!/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *
import os

#
# ######### 修改记录 #########
# 20210120 Modified by machunliang 修改税率和项目编号的取值。
#   0109日晚，结算系统变更上线，启用了税率、合同编号、项目编号等字段。
#   之前的税率和项目编号，在部分业务中从ex_one和ex_four取值，本次修改为兼容之前的取值方法，避免重跑之前的数据时取不到这两个字段值。
#   0120对2021-01月份数据进行了清洗，按规则对现有数据进行了税率和项目编号的补数
#
# 20210122 Modified by machunliang 针对fee_type in ('31122','31138','31147','31175') 在凌晨0点后处理前一日业务数据的问题（暂定：只针对金条，product_id = '03'）
#   新抽一张表 odm.odm_fi_js_fin_fee_detail_311_i_d ，在凌晨1点开始抽取前一日1:00~当日1:00的数据，从中取当日0~1点期间的上述费用类型的数据
#   与原来的odm.odm_fi_js_fin_fee_detail_i_d 取数进行去重处理，生成上述费用类型的临时表使用
#   原来从odm.odm_fi_js_fin_fee_detail_i_d取数的片段中，排除上述费用类型
#
# 问题：
#   业务需求：创建时间≤T+1月 1日1:00 且 业务日期≤T月，于T月集成入账。   
#   1. 有没有：1日凌晨创建的，但业务时间是上上月的数据？                    是否纳入？
#   2. 有没有：1日凌晨更新的，但上上月及之前创建的，上月从未更新的数据？    是否纳入？
#
# Modified by machunliang@20210203 
#   针对增量表增加last_dt（上一次日期，即被冲销的数据日期）
#   增加12个新增字段：bill_code（账单编码） + 11个扩展字段
#
# Modified by machunliang@20210330 
#   补充肖宁提出的从扩展字段取值名称关联主体的口径，目前仅修改在主体客商ID
#
# Modified by machunliang@20210610
#   针对商票秒融（biz_type=699）业务补充特殊客商逻辑
#
# Added by machunliang@20210701 
#   增加张华保险业务的扩展字段作为财务要素（存部门、客商等）
#
# Added by machunliang@20210708 
#   加工514业务的税率（20210716日增加535同样逻辑）
#   对核算业务线映射增加函数处理
#
# Modified by renxiaowei7@20210616
#   添加按月冲销数据的逻辑
#
# Modified by renxiaowei7@20210713 
#   解决历史旧数据（3月之前）没有主体的问题
#
# Modified by machunliang@20210713 
#   增加664业务的项目段逻辑
#   增加 201业务使用扩展字段6取核算业务线产品
#
# Modified by renxiaowei7@20210713
#   增加149扩展字段3取客商逻辑

# Modified by machunliang@20210719 
#   处理445业务的项目代码及业务线

# Modified by machunliang@20210721 
#   小金库增加从业务系统取客商的逻辑

# Modified by machunliang@20210728
#   处理455业务的项目代码增加兜底函数处理

# Modified by machunliang@20210817
#   处理742业务通过扩展字段5的名称取客商

# Modified by renxiaowei7@20210819
#   结算特殊处理逻辑下沉
#   修改历史数据change_code、ele_md5的逻辑

# Modified by renxiaowei7@20211103
#   处理历史数据刷新问题

# Modified by renxiaowei7@20211104
#   主体逻辑变更
#   1、单主体：以结算配置为准(若配置有误，修改配置，核算手工入账)
#   2、多主体：以数据为准(若数据有误，修改业务传结算参数，核算手工入账)
#     DMFBC_REDU_ODM_FI_PAY_ZH_FI_BD_BANK_ACCOUNT_INFO_S_D，资金主数据，id唯一，暂时简码唯一，为了避免后续=出现简码不唯一的问题，增加简码唯一去重临时表

# Modified by machunliang@20210817 
#   处理754业务通过扩展字段3的json串取客商账户ID，关联获取主数据ID

# Modified by renxiaowei7@20220106
#   保险业务线拆分，扩展字段json串取主体名称关联客商
#   未来期数据业务时间等于当天数据，当作手工数据冲销

# Modified by renxiaowei7@20220713
#   处理440业务,费用类型44003,通过扩展字段1关联结算映射取客商ID的逻辑

# Modified by renxiaowei7@20220718
#   处理620业务,费用类型6204,通过扩展字段4获取客商名称关联获取客商ID改为通过扩展字段5获取

# Modified by renxiaowei7@20220919
#   在结算升级的过程中，会有一部分数据在新旧结算系统同时产生，这部分数据在就结算系统是99状态，属于不需要入账的状态。
#   这部分数据需要冲销掉(先冲销再过滤)

# Modified by renxiaowei7@20220923 
#   结算升级，切换过程中，已经在旧结算产生并且入账的一部分数据，需要在新结算进行结算，但是又不能在旧结算进行冲销，所以把这部分数据手工改为98状态作为过渡状态，直接过滤掉
#   这部分数据需要过滤掉(先过滤再冲销)


def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    # Modified by machunliang@20210215 解决tx_date错误取值的变量
    #today = Time.today()
    today = sql_task._tx_date
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    
    # Modified by machunliang@20210215 解决tx_date错误取值的变量
    #txdate_str = sys.argv[1].split("_")[-1].split(".")[0]
    #tx_date = "{yyyy}-{mm}-{dd}".format(yyyy=txdate_str[0:4],mm=txdate_str[4:6],dd=txdate_str[6:8])
    #TX_DATE = Time.date_format(date=tx_date)
    #TX_PRE_90_DATE = Time.date_sub(date=TX_DATE, itv=90)
    TX_PRE_90_DATE = Time.date_sub(date=today, itv=90)

    # 临时表基础词   计费明细
    TMP_TAB_BASE = 'tmp_dmfbc_bc_fi_fst_fee_detail_h_d'

    return locals()
    
#执行sql的方法
def execute_hive_e_sql(sql):
    """
    使用hive -e来执行
    :param sql:
    :return:
    """
    exe_sql = 'hive -e "{}"'.format(sql)
    print("开始执行：" + exe_sql)
    result = os.popen(exe_sql).readlines()
    print("执行完成：" + exe_sql)
    #print(exe_sql)
    return result

#获取sql的结果
def get_sys_config_data(sql_str):
    """
    读取sql结果信息
    :param sys:
    :return:
    """
    #print("sql："+sql_str)
    result_line = execute_hive_e_sql(sql_str)
    
    config_data = [ele.split("\t") for ele in result_line]

    #print("---配置表的信息---")
    #print(config_data)
    return config_data

#SQL执行环境
# 目前支持：RUNNER_SPARK_SQL和 RUNNER_HIVE 、RUNNER_STINGER
#sql_runner = RUNNER_STINGER
sql_runner = RUNNER_HIVE
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
    
sql_map_01={

# ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

# 需要被冲销的数据
# 【注意】结构要与 dmf_tmp.tmp_fin_fee_detail_all_1 保持一致

"sql_010": """
use dmf_tmp;
drop table if exists dmf_tmp.tmp_fin_fee_detail_clean_data;
create table dmf_tmp.tmp_fin_fee_detail_clean_data as 
select cast(0 as bigint) as id, biz_id, biz_type, fee_id, fee_type, product_id, product_name, customer_id, customer_name, direction, amount, sett_amount, need_invoice, source_id, rule_id, status, operator, data_type, 
       trans_time as data_time, yn_flag, prov_flag, remark, create_user as creator, update_user as editor, create_dt as created_time, 
       update_dt as modified_time, 
       customer_type, card_id, pay_channel_type, 
       pay_channel_id, order_id, ex_one, ex_two, ex_three, ex_four, org_id, unikey, sett_id, currency, tax_rate, contract_code, project_code, biz_association_id, composite_id, standby_field_one, 
       standby_field_two, standby_field_three, standby_field_four, standby_field_five, bill_code, ex_five, ex_six, ex_seven, ex_eight, ex_nine, ex_ten, ex_eleven, ex_twelve, ex_thirteen, ex_fourteen, 
       ex_fifteen, fee_principal_company_customer_id, fee_principal_company_merchant_id, fee_principal_company_customer_name, 
       -- 以下两个字段不落地，且org_flag在前面加工主体已经使用完成，下面不再使用。在这里可置空
       '' as org_flag, '' as merchant_id_src_tag
       -- Modified by renxiaowei7@20210819 结算特殊逻辑下沉，核算产品加工逻辑归一，删除此处的逻辑
       --accti_biz_line_cd
from (
      select t1.* 
      from dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d t1 
      left semi join (select origin_id from dmf_add.dmfadd_add_fi_fst_clean_data_origin_id_i_d
                      where dt = '{TX_DATE}' and tab_tag = 'fee'
                      union
                      --Added by renxiaowei7@20220106 未来期数据业务时间等于当天数据，当作手工数据冲销
                      select origin_id from dmf_bc.dmfbc_bc_fi_fst_fee_detail_period_s_d
                      where dt = date_sub('{TX_DATE}',1) and to_date(trans_time) = '{TX_DATE}'
                     ) t2 
                  on  t1.unikey = t2.origin_id
               where  t1.dt = '{TX_PRE_1_DATE}'
     ) t 
;
""",

 # 计费明细拉链表   作业名称  JCW_DMFBC_BC_FI_FST_FEE_DETAIL_ALL_H_D
"sql_020": """
use dmf_tmp;

DROP TABLE if exists dmf_tmp.tmp_odm_fi_js_fin_fee_detail_i_d;
CREATE TABLE dmf_tmp.tmp_odm_fi_js_fin_fee_detail_i_d as 
 SELECT * 
   FROM (
         SELECT *
                ,row_number() over(distribute by unikey sort by modified_time desc) as rn
           FROM (SELECT CONCAT('fin_fee_detail_',biz_type,fee_id) AS unikey
                       ,id,biz_id,biz_type,fee_id,fee_type,product_id,product_name,customer_id,customer_name,direction,amount,sett_amount,need_invoice,source_id
                       ,rule_id,status,operator,data_type,data_time,yn_flag,remark,creator,editor,created_time,modified_time,customer_type,card_id,pay_channel_type
                       ,pay_channel_id,order_id,ex_one,ex_two,ex_three,org_id,sett_id,ex_four,currency,tax_rate,contract_code,project_code,biz_association_id,composite_id
                       ,standby_field_one,standby_field_two,standby_field_three,standby_field_four,standby_field_five
                       -- Added by machunliang@20210203 for 新增字段
                       ,bill_code,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen
                   FROM odm.odm_fi_js_fin_fee_detail_i_d            -- 原来的表
                  WHERE dt='{TX_DATE}'
                    AND fee_type in ('31122','31138','31147','31175') 
                    -- AND product_id in ('03') -- 仅金条的
                 UNION ALL 
                 SELECT CONCAT('fin_fee_detail_',biz_type,fee_id) AS unikey
                       ,id,biz_id,biz_type,fee_id,fee_type,product_id,product_name,customer_id,customer_name,direction,amount,sett_amount,need_invoice,source_id
                       ,rule_id,status,operator,data_type,data_time,yn_flag,remark,creator,editor,created_time,modified_time,customer_type,card_id,pay_channel_type
                       ,pay_channel_id,order_id,ex_one,ex_two,ex_three,org_id,sett_id,ex_four,currency,tax_rate,contract_code,project_code,biz_association_id,composite_id
                       ,standby_field_one,standby_field_two,standby_field_three,standby_field_four,standby_field_five
                       -- Added by machunliang@20210203 for 新增字段
                       ,bill_code,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen
                   FROM odm.odm_fi_js_fin_fee_detail_311_i_d        -- 针本次处理新增抽数的表
                  WHERE dt='{TX_DATE}'
                    AND fee_type in ('31122','31138','31147','31175') 
                ) t1
        ) t2
  WHERE rn = 1
        ;
DROP TABLE if exists dmf_tmp.tmp_fin_fee_detail_all_1;
CREATE TABLE dmf_tmp.tmp_fin_fee_detail_all_1
AS
-- added by machunliang@20210122 ------------------
SELECT id,biz_id,biz_type,fee_id,fee_type,product_id,TRIM(product_name) AS product_name
      ,customer_id
      ,REPLACE(REPLACE(REGEXP_REPLACE(TRIM(customer_name),'\\\\\\n|\\\\\\t|\\\\\\r',''),'(', '（'),')', '）') AS customer_name
      ,direction,CAST(amount AS decimal(24,6)) AS amount,CAST(sett_amount AS decimal(24,6)) AS sett_amount,need_invoice
      ,source_id,rule_id,status,operator,data_type,data_time
      ,yn_flag,case when status not in ('3','4','5','9','99') then '1' else '0' end as prov_flag
      ,remark,creator,editor,created_time,modified_time,customer_type
      ,card_id,pay_channel_type,pay_channel_id,order_id
      ,ex_one,ex_two,ex_three,ex_four,org_id
      ,CONCAT('fin_fee_detail_',biz_type,fee_id) AS unikey
      ,sett_id
      ,currency,tax_rate,contract_code,project_code,biz_association_id,composite_id,standby_field_one
      ,standby_field_two,standby_field_three,standby_field_four,standby_field_five
      -- Added by machunliang@20210203 for 新增字段
      ,bill_code,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen
FROM dmf_tmp.tmp_odm_fi_js_fin_fee_detail_i_d       -- 202101022 针对4个费项取0点后数据的
-- End of added by machunliang@20210122 ------------------
UNION ALL    
SELECT id,biz_id,biz_type,fee_id,fee_type,product_id,TRIM(product_name) AS product_name
      ,customer_id
      ,REPLACE(REPLACE(REGEXP_REPLACE(TRIM(customer_name),'\\\\\\n|\\\\\\t|\\\\\\r',''),'(', '（'),')', '）') AS customer_name
      ,direction,CAST(amount AS decimal(24,6)) AS amount,CAST(sett_amount AS decimal(24,6)) AS sett_amount,need_invoice
      ,source_id,rule_id,status,operator,data_type,data_time
      ,yn_flag,case when status not in ('3','4','5','9','99') then '1' else '0' end as prov_flag
      ,remark,creator,editor,created_time,modified_time,customer_type
      ,card_id,pay_channel_type,pay_channel_id,order_id
      ,ex_one,ex_two,ex_three,ex_four,org_id
      ,CONCAT('fin_fee_detail_',biz_type,fee_id) AS unikey
      ,sett_id
      ,currency,tax_rate,contract_code,project_code,biz_association_id,composite_id,standby_field_one
      ,standby_field_two,standby_field_three,standby_field_four,standby_field_five
      -- Added by machunliang@20210203 for 新增字段
      ,bill_code,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen
FROM odm.odm_fi_js_fin_fee_detail_i_d       -- 20201027   切换结算计费明细表  chengsong 
WHERE dt='{TX_DATE}'
-- Added by machunliang@20210122 排除上述4个费项的数据
  AND fee_type NOT in ('31122','31138','31147','31175') 
UNION ALL    
--保险+白条 业务分库分表
SELECT id,biz_id,biz_type,fee_id,fee_type,product_id,TRIM(product_name) AS product_name
      ,customer_id
      ,REPLACE(REPLACE(REGEXP_REPLACE(TRIM(customer_name),'\\\\\\n|\\\\\\t|\\\\\\r',''),'(', '（'),')', '）') AS customer_name
      ,direction,CAST(amount AS decimal(24,6)) AS amount,CAST(sett_amount AS decimal(24,6)) AS sett_amount,need_invoice
      ,source_id,rule_id,status,operator,data_type,data_time
      -- Modified by machunliang@20201021 拆分status和yn_flag
      ,yn_flag,case when status not in ('3','4','5','9','99') then '1' else '0' end as prov_flag
      ,remark,creator,editor,created_time,modified_time,customer_type
      ,card_id,pay_channel_type,pay_channel_id,order_id
      ,ex_one,ex_two,ex_three,ex_four,org_id
      ,CONCAT('bx_slicer_',id,biz_id,fee_id) AS unikey
      ,'' AS sett_id
      --20201024 新增字段  chengsong
      ,currency
      ,tax_rate
      ,contract_code
      ,project_code
      ,biz_association_id
      ,composite_id
      ,standby_field_one
      ,standby_field_two
      ,standby_field_three
      ,standby_field_four
      ,standby_field_five
      -- Added by machunliang@20210203 for 新增字段
      ,'' as bill_code,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen
FROM odm.odm_fi_js_fin_fee_detail_slicer_20160601_0_i_d t1
inner JOIN(SELECT fee_types
            FROM (SELECT fee_types,mark
                        ,ROW_NUMBER() OVER (DISTRIBUTE BY fee_types SORT BY modified_time DESC) rank
                  FROM odm.odm_fi_js_fin_sett_settway_s_d
                  WHERE dt='{TX_DATE}'
                 ) x
            WHERE rank = 1 and mark&16=16
          ) t3
on t1.fee_type = t3.fee_types
WHERE t1.dt='{TX_DATE}'
;

""",

#20210616 renxiaowei7 按月跑数逻辑
#  获取冲销数据，取上一日快照表中创建时间是指定范围之内的数据
#   1、如果跑数日期小于10号，冲销上月初到当天
#   2、如果跑数日期大于等于10号，冲销本月初到当天
# 20210913 renxiaowei7 添加下沉逻辑
#   1、关联下沉配置表，获取需要刷数的历史数据
#   2、关联下沉配置表会出现重复数据，这里不进行下沉，在下面进行数据合并的时候去重，减少一步去重逻辑
#   3、每次导入都重新刷历史数据，但是只刷不进行自动刷数的部分。这部分数据不进增量表，只更新拉链和快照
# 20211103 renxiaowei7 处理历史数据刷新问题
#   1、结算单&计费明细&结算明细 增加spe_val_map(map结构存储特殊值)字段，用于存储一些用于程序控制的字段
#   2、在新增map格式字段中设置下述key-value对
#     说明：clean_tag字段功能类似，但是没有存储到结果表
#     spec_brush_flag:下沉刷数标志(用于标识拉链数据的产生是下沉配置导致的历史数据刷新还是正常的数据增量变更)
#       spec_his:下沉配置刷新历史数据产生的拉链
#       spec_now:下沉配置刷新当月数据产生的拉链
#       data_add:add表手工刷数产生的拉链
#       data_new:当月增量数据产生的拉链

"sql_030": """
set mapred.max.split.size=64000000;
set mapred.min.split.size.per.node=64000000;
set mapred.min.split.size.per.rack=64000000;
set hive.auto.convert.join=true;
use dmf_tmp;

drop table if exists dmf_tmp.tmp_fin_fee_detail_month_brush;
create table dmf_tmp.tmp_fin_fee_detail_month_brush
as 
select     a1.*
          ,cast(0 as bigint) as id
          ,a1.trans_time     as data_time
          ,a1.create_user    as creator
          ,a1.update_user    as editor
          ,a1.create_dt      as created_time
          ,a1.update_dt      as modified_time
          -- 以下两个字段不落地，且org_flag在前面加工主体已经使用完成，下面不再使用。在这里可置空
          ,'' as org_flag
          ,'' as merchant_id_src_tag
          ,case when (    ('{TX_DATE}' <  CONCAT(SUBSTR('{TX_DATE}',1,8),'10') and a1.start_dt >= TRUNC(ADD_MONTHS('{TX_DATE}',-1),'MM') and a1.start_dt < '{TX_DATE}')  --小于10号，冲销上月初到当天
                       or ('{TX_DATE}' >= CONCAT(SUBSTR('{TX_DATE}',1,8),'10') and a1.start_dt >= TRUNC('{TX_DATE}','MM') and a1.start_dt < '{TX_DATE}')                 --大于等于10号，冲销本月初到当天
                     )
                then case when str_to_map(a1.spe_val_map)['spec_brush_flag'] = 'spec_his' --下沉配置刷新历史数据产生的拉链
                          then '5' --非自动刷数-下沉-刷历史数据
                          when a2.typecd is not null and nvl(a1.spec_type_cd,'') != ''
                          then '2' --自动刷数-已下沉-冲销取历史
                          when a2.typecd is not null and nvl(a1.spec_type_cd,'') = ''
                          then '3' --自动刷数-未下沉-冲销取新值
                          else '4' --自动刷数-非下沉
                     end
                else case when a2.typecd is not null
                          then '5' --非自动刷数-下沉-刷历史数据
                          else ''  --非自动刷数-非下沉
                     end
           end as clean_tag --数据类型标识
            
from (select     *
                ,str_to_map(concat_ws('#'
                               ,concat('biz_type&'     ,nvl(biz_type     ,''))
                               ,concat('fee_type&'     ,nvl(fee_type     ,''))
                               ,concat('status&'       ,nvl(status       ,''))
                               ,concat('product_id&'   ,nvl(product_id   ,''))
                               ,concat('customer_id&'  ,nvl(customer_id  ,''))
                               ,concat('source_id&'    ,nvl(source_id    ,''))
                               ,concat('ex_one&'       ,nvl(ex_one       ,''))
                               ,concat('ex_two&'       ,nvl(ex_two       ,''))
                               ,concat('ex_three&'     ,nvl(ex_three     ,''))
                               ,concat('ex_four&'      ,nvl(ex_four      ,''))
                               ,concat('ex_five&'      ,nvl(ex_five      ,''))
                               ,concat('ex_six&'       ,nvl(ex_six       ,''))
                               ,concat('ex_seven&'     ,nvl(ex_seven     ,''))
                               ,concat('ex_eight&'     ,nvl(ex_eight     ,''))
                               ,concat('ex_nine&'      ,nvl(ex_nine      ,''))
                               ,concat('ex_ten&'       ,nvl(ex_ten       ,''))
                               ,concat('ex_eleven&'    ,nvl(ex_eleven    ,''))
                               ,concat('ex_twelve&'    ,nvl(ex_twelve    ,''))
                               ,concat('ex_thirteen&'  ,nvl(ex_thirteen  ,''))
                               ,concat('ex_fourteen&'  ,nvl(ex_fourteen  ,''))
                               ,concat('ex_fifteen&'   ,nvl(ex_fifteen   ,''))
                               ,concat('product_name&' ,nvl(product_name ,''))
                               ,concat('customer_name&',nvl(customer_name,''))
                               ,concat('fee_customer_name_merchant_id&',nvl(fee_customer_name_merchant_id,''))
                          ),'#','&') as conn_cols
      from dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d
      where  dt = '{TX_PRE_1_DATE}'
     ) a1
left join (select * from dmf_bc.dmfbc_bc_sett_spec_conf_detail_a_d
           where modleCd = 'sett_gdm'  --配置层级 结算中间层
             and tabCd   = 'fee'       --处理表   计费明细
             and impt_dt = '{TX_DATE}' --历史数据只刷当天导入的配置
          ) a2
       on  a1.biz_type = a2.bizType
      and (   (a2.feeType     like '!%' and concat(',',substr(a2.feeType,2),',') not like concat('%,',a1.fee_type,',%'))
           or (a2.feeType not like '!%' and concat(',',a2.feeType,',')               like concat('%,',a1.fee_type,',%'))
           or nvl(a2.feeType,'')=''
          )
      and  case when nvl(a2.field_01_flag,'') = 'S&='     and a1.conn_cols[a2.field_01_coll] =  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&!='    and a1.conn_cols[a2.field_01_coll] != a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&>'     and a1.conn_cols[a2.field_01_coll] >  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&<'     and a1.conn_cols[a2.field_01_coll] <  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&>='    and a1.conn_cols[a2.field_01_coll] >= a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&<='    and a1.conn_cols[a2.field_01_coll] <= a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&IN'    and concat(',',a2.field_01_val,',') like     concat('%,',a1.conn_cols[a2.field_01_coll],',%') then '1'
                when nvl(a2.field_01_flag,'') = 'S&!IN'   and concat(',',a2.field_01_val,',') not like concat('%,',a1.conn_cols[a2.field_01_coll],',%') then '1'
                when nvl(a2.field_01_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_01_coll]  like     a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_01_coll]  not like a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_02_flag,'') = 'S&='     and a1.conn_cols[a2.field_02_coll] =  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&!='    and a1.conn_cols[a2.field_02_coll] != a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&>'     and a1.conn_cols[a2.field_02_coll] >  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&<'     and a1.conn_cols[a2.field_02_coll] <  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&>='    and a1.conn_cols[a2.field_02_coll] >= a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&<='    and a1.conn_cols[a2.field_02_coll] <= a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&IN'    and concat(',',a2.field_02_val,',') like     concat('%,',a1.conn_cols[a2.field_02_coll],',%') then '1'
                when nvl(a2.field_02_flag,'') = 'S&!IN'   and concat(',',a2.field_02_val,',') not like concat('%,',a1.conn_cols[a2.field_02_coll],',%') then '1'
                when nvl(a2.field_02_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_02_coll]  like     a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_02_coll]  not like a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_03_flag,'') = 'S&='     and a1.conn_cols[a2.field_03_coll] =  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&!='    and a1.conn_cols[a2.field_03_coll] != a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&>'     and a1.conn_cols[a2.field_03_coll] >  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&<'     and a1.conn_cols[a2.field_03_coll] <  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&>='    and a1.conn_cols[a2.field_03_coll] >= a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&<='    and a1.conn_cols[a2.field_03_coll] <= a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&IN'    and concat(',',a2.field_03_val,',') like     concat('%,',a1.conn_cols[a2.field_03_coll],',%') then '1'
                when nvl(a2.field_03_flag,'') = 'S&!IN'   and concat(',',a2.field_03_val,',') not like concat('%,',a1.conn_cols[a2.field_03_coll],',%') then '1'
                when nvl(a2.field_03_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_03_coll]  like     a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_03_coll]  not like a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_04_flag,'') = 'S&='     and a1.conn_cols[a2.field_04_coll] =  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&!='    and a1.conn_cols[a2.field_04_coll] != a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&>'     and a1.conn_cols[a2.field_04_coll] >  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&<'     and a1.conn_cols[a2.field_04_coll] <  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&>='    and a1.conn_cols[a2.field_04_coll] >= a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&<='    and a1.conn_cols[a2.field_04_coll] <= a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&IN'    and concat(',',a2.field_04_val,',') like     concat('%,',a1.conn_cols[a2.field_04_coll],',%') then '1'
                when nvl(a2.field_04_flag,'') = 'S&!IN'   and concat(',',a2.field_04_val,',') not like concat('%,',a1.conn_cols[a2.field_04_coll],',%') then '1'
                when nvl(a2.field_04_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_04_coll]  like     a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_04_coll]  not like a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_05_flag,'') = 'S&='     and a1.conn_cols[a2.field_05_coll] =  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&!='    and a1.conn_cols[a2.field_05_coll] != a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&>'     and a1.conn_cols[a2.field_05_coll] >  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&<'     and a1.conn_cols[a2.field_05_coll] <  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&>='    and a1.conn_cols[a2.field_05_coll] >= a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&<='    and a1.conn_cols[a2.field_05_coll] <= a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&IN'    and concat(',',a2.field_05_val,',') like     concat('%,',a1.conn_cols[a2.field_05_coll],',%') then '1'
                when nvl(a2.field_05_flag,'') = 'S&!IN'   and concat(',',a2.field_05_val,',') not like concat('%,',a1.conn_cols[a2.field_05_coll],',%') then '1'
                when nvl(a2.field_05_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_05_coll]  like     a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_05_coll]  not like a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_06_flag,'') = 'S&='     and a1.conn_cols[a2.field_06_coll] =  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&!='    and a1.conn_cols[a2.field_06_coll] != a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&>'     and a1.conn_cols[a2.field_06_coll] >  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&<'     and a1.conn_cols[a2.field_06_coll] <  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&>='    and a1.conn_cols[a2.field_06_coll] >= a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&<='    and a1.conn_cols[a2.field_06_coll] <= a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&IN'    and concat(',',a2.field_06_val,',') like     concat('%,',a1.conn_cols[a2.field_06_coll],',%') then '1'
                when nvl(a2.field_06_flag,'') = 'S&!IN'   and concat(',',a2.field_06_val,',') not like concat('%,',a1.conn_cols[a2.field_06_coll],',%') then '1'
                when nvl(a2.field_06_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_06_coll]  like     a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_06_coll]  not like a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_07_flag,'') = 'S&='     and a1.conn_cols[a2.field_07_coll] =  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&!='    and a1.conn_cols[a2.field_07_coll] != a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&>'     and a1.conn_cols[a2.field_07_coll] >  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&<'     and a1.conn_cols[a2.field_07_coll] <  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&>='    and a1.conn_cols[a2.field_07_coll] >= a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&<='    and a1.conn_cols[a2.field_07_coll] <= a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&IN'    and concat(',',a2.field_07_val,',') like     concat('%,',a1.conn_cols[a2.field_07_coll],',%') then '1'
                when nvl(a2.field_07_flag,'') = 'S&!IN'   and concat(',',a2.field_07_val,',') not like concat('%,',a1.conn_cols[a2.field_07_coll],',%') then '1'
                when nvl(a2.field_07_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_07_coll]  like     a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_07_coll]  not like a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_08_flag,'') = 'S&='     and a1.conn_cols[a2.field_08_coll] =  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&!='    and a1.conn_cols[a2.field_08_coll] != a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&>'     and a1.conn_cols[a2.field_08_coll] >  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&<'     and a1.conn_cols[a2.field_08_coll] <  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&>='    and a1.conn_cols[a2.field_08_coll] >= a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&<='    and a1.conn_cols[a2.field_08_coll] <= a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&IN'    and concat(',',a2.field_08_val,',') like     concat('%,',a1.conn_cols[a2.field_08_coll],',%') then '1'
                when nvl(a2.field_08_flag,'') = 'S&!IN'   and concat(',',a2.field_08_val,',') not like concat('%,',a1.conn_cols[a2.field_08_coll],',%') then '1'
                when nvl(a2.field_08_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_08_coll]  like     a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_08_coll]  not like a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_01_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') =  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') != a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') >  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') <  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') >= a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') <= a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&IN'    and concat(',',a2.func_01_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),''),',%') then '1'
                when nvl(a2.func_01_flag,'') = 'S&!IN'   and concat(',',a2.func_01_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),''),',%') then '1'
                when nvl(a2.func_01_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'')  like     a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'')  not like a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_02_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') =  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') != a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') >  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') <  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') >= a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') <= a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&IN'    and concat(',',a2.func_02_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),''),',%') then '1'
                when nvl(a2.func_02_flag,'') = 'S&!IN'   and concat(',',a2.func_02_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),''),',%') then '1'
                when nvl(a2.func_02_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'')  like     a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'')  not like a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_03_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') =  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') != a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') >  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') <  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') >= a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') <= a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&IN'    and concat(',',a2.func_03_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),''),',%') then '1'
                when nvl(a2.func_03_flag,'') = 'S&!IN'   and concat(',',a2.func_03_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),''),',%') then '1'
                when nvl(a2.func_03_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'')  like     a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'')  not like a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = '' then '1'
                else '0'
           end = '1'
;
""",

# Added by machunliang@20210721 
# 小金库 需要使用扩展字段1关联业务系统取客商
# 业务系统表去重
"sql_040": """
use dmf_tmp;
drop table if exists dmf_tmp.tmp_fin_fee_detail_xjk_borrow_order;
create table dmf_tmp.tmp_fin_fee_detail_xjk_borrow_order
as 
select borrow_order_no, mht_code 
  from (select borrow_order_no, mht_code,row_number() over(partition by borrow_order_no order by modified_time desc) as rn
               from odm.odm_fin_xjk_xjk_borrow_order_i_d where dt <= '{TX_DATE}') x
 where rn =1;
""",

"sql_050": """
use dmf_tmp;
drop table if exists dmf_tmp.tmp_tmp_fin_fee_detail_xjk_sku_id;
create table dmf_tmp.tmp_tmp_fin_fee_detail_xjk_sku_id
as 
select biz_request_no, sku_id 
  from (select biz_request_no, sku_id,row_number() over(partition by biz_request_no order by modified_time desc) as rn
          from odm.odm_fin_ap_advance_request_master_i_d 
         where dt <= '{TX_DATE}' 
           --Modified by renxiaowei7@20220124 去掉channel_code的限定
           --and channel_code= 'xjk_consume_szxjk'
       ) x
 where rn =1;
""",


# 合并上面的结果和待清洗的结果并去重
"sql_110": """
set hive.execution.engine=mr;
set mapred.max.split.size=128000000; 
set hive.exec.reducers.bytes.per.reducer=128000000;
use dmf_tmp;

drop table if exists dmf_tmp.tmp_fin_fee_detail_all_1_1;
create table if not exists dmf_tmp.tmp_fin_fee_detail_all_1_1 as 
select     t1.clean_tag  --20210624 renxiaowei7
          ,t1.id,t1.biz_id,t1.biz_type,t1.fee_id,t1.fee_type,t1.product_id,t1.product_name,t1.customer_id,t1.customer_name,t1.direction,t1.amount
          ,t1.sett_amount,t1.need_invoice,t1.source_id,t1.rule_id,t1.status,t1.operator,t1.data_type,t1.data_time,t1.yn_flag,t1.prov_flag,t1.remark
          ,t1.creator,t1.editor,t1.created_time,t1.modified_time,t1.customer_type,t1.card_id,t1.pay_channel_type,t1.pay_channel_id,t1.order_id,t1.ex_one,t1.ex_two,t1.ex_three,t1.ex_four,t1.org_id,t1.unikey,t1.sett_id
          ,t1.currency,t1.tax_rate,t1.contract_code,t1.project_code,t1.biz_association_id,t1.composite_id,t1.standby_field_one
          ,t1.standby_field_two,t1.standby_field_three,t1.standby_field_four,t1.standby_field_five,t1.bill_code,t1.ex_five,t1.ex_six,t1.ex_seven,t1.ex_eight,t1.ex_nine,t1.ex_ten,t1.ex_eleven,t1.ex_twelve,t1.ex_thirteen,t1.ex_fourteen,t1.ex_fifteen
          -- 扩展字段取客商的
          ,case when t1.biz_type='528' AND t1.fee_type in ('52815', '52820') then t1.ex_one 
                when t1.biz_type='475' AND t1.fee_type in ('47535') then t1.ex_one 
                --when t1.biz_type='149' AND t1.fee_type in ('14993','149125','149113','149117','149129','149131','149132','14992','149114','149118','149130','149133','149115','149116','149119','14991') then t1.ex_three --Modified by renxiaowei7@20210713
                when t1.biz_type='149' AND t2.sett_scenes in ('14993','149125','149113','149117','149129','149131','149132','14992','149114','149118','149130','149133','149115','149116','149119','14991') then t1.ex_three --Modified by renxiaowei7@20210717 改为使用结算场景限定
                -- Added by machunliang@20210817 
                when t1.biz_type='742' AND t1.fee_type in ('74201') then t1.ex_five 
                -- Added by renxiaowei7@20211115
                when t1.biz_type='754' and t1.fee_type in ('75401') then get_json_object(t1.ex_three,'$.customerId')
                -- Added by renxiaowei7@20220106 保险业务线拆分，扩展字段json串取主体名称关联客商
                when t1.biz_type in ('820','833') then get_json_object(t1.ex_four,'$.LPNM')
                --Modified by renxiaowei7@20220621 828改为截取前12位
                when t1.biz_type in ('828') then nvl(substr(get_json_object(t1.ex_four,'$.LPNM'),0,12),'京东数科保险代理有限公司')
                --Modified by renxiaowei7@20220718
                --when t1.biz_type='620' and t1.fee_type in ('6204') then get_json_object(t1.ex_four,'$.LPNM')
                when t1.biz_type='620' and t1.fee_type in ('6204') then get_json_object(t1.ex_five,'$.LPNM')
                --Modified by renxiaowei7@20220713 处理440业务,费用类型44003,通过扩展字段1关联结算映射取客商ID的逻辑
                when t1.biz_type='440' and t1.fee_type in ('44003') then t1.ex_one
            end as customer_id_ex
          -- 扩展字段取客商的关联方法
          ,case when t1.biz_type='528' AND t1.fee_type in ('52815', '52820') then '2'   -- 结算映射关联账户取客商
                when t1.biz_type='475' AND t1.fee_type in ('47535')          then '5'   -- 名称关联客商表
                --when t1.biz_type='149' AND t1.fee_type in ('14993','149125','149113','149117','149129','149131','149132','14992','149114','149118','149130','149133','149115','149116','149119','14991') then '5' --Modified by renxiaowei7@20210713 名称关联客商表
                when t1.biz_type='149' AND t2.sett_scenes in ('14993','149125','149113','149117','149129','149131','149132','14992','149114','149118','149130','149133','149115','149116','149119','14991') then '5' --Modified by renxiaowei7@20210717  改为使用结算场景限定
                -- Added by machunliang@20210817 
                when t1.biz_type='742' AND t1.fee_type in ('74201') then '5'
                -- Added by renxiaowei7@20211115
                when t1.biz_type='754' and t1.fee_type in ('75401') then '3'            --客商ID关联账户取客商
                -- Added by renxiaowei7@20220106 保险业务线拆分，扩展字段json串取主体名称关联客商
                when t1.biz_type in ('820','828','833') then '5'
                when t1.biz_type='620' and t1.fee_type in ('6204') then '5'
                --Modified by renxiaowei7@20220713 处理440业务,费用类型44003,通过扩展字段1关联结算映射取客商ID的逻辑
                when t1.biz_type='440' and t1.fee_type in ('44003') then '1'
            end as customer_id_ex_typ
          ,case -- 小金库的垫资行客商
                when t1.biz_type='493' AND t1.fee_type='49315' and get_json_object(t1.ex_three,'$.bankInterId') LIKE '%PAB%' THEN '1002890'    -- 平安银行
                when t1.biz_type='493' AND t1.fee_type='49315' and get_json_object(t1.ex_three,'$.bankInterId') LIKE '%CEB%' THEN '1005812'    -- 中国光大银行股份有限公司北京分行
                when t1.biz_type='493' AND t1.fee_type='49315' and get_json_object(t1.ex_three,'$.bankInterId') LIKE '%SPDB%' THEN '1573608'   -- 上海浦东发展银行股份有限公司北京分行 renxiaowei7 20210220
                when t1.biz_type='493' AND t1.fee_type='49315' then get_json_object(t1.ex_three,'$.bankInterId')
            end as dxxjk_adv_bnk    
          -- Added by machunliang@20210721 增加小金库关联业务系统取客商的逻辑
          ,case 
                when t1.biz_type = '493' and t1.fee_type in ('49357', '49358', '49360') then dmf_bc.dmdictDesc('dxxjk_product_customer_map', t3.mht_code)
                when t1.biz_type = '493' and t1.fee_type in ('49388') then dmf_bc.dmdictDesc('dxxjk_product_customer_map', t4.sku_id)
            end as xjk_bizsys_mercht_id     -- 小金库业务系统取客商
          --Added by renxiaowei7@20211103 map结构存储特殊值
          ,t1.spe_val_map
from (select *, row_number() over(partition by unikey, biz_type order by clean_tag, modified_time desc) as rn 
        from (--自动刷数 20210616 renxiaowei7
              select -- '2' as clean_tag, 
                     clean_tag, --Modified by renxiaowei7@20210913 下沉逻辑，刷历史数据
                     id,biz_id,biz_type,fee_id,fee_type,product_id,product_name,customer_id,customer_name,direction,amount,
                     sett_amount,need_invoice,source_id,rule_id,status,operator,data_type,data_time,yn_flag,prov_flag,remark,
                     creator,editor,created_time,modified_time,
                     customer_type,
                     card_id,pay_channel_type,pay_channel_id,order_id,ex_one,ex_two,ex_three,ex_four,org_id,unikey,sett_id,
                     currency,tax_rate,contract_code,project_code,biz_association_id,composite_id,standby_field_one,
                     standby_field_two,standby_field_three,standby_field_four,standby_field_five,bill_code,
                     ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen,
                     --Added by renxiaowei7@20211103 map结构存储特殊值
                     concat_ws(','
                              ,concat('spec_brush_flag:'
                                     ,(case when clean_tag = '5' then 'spec_his'         --下沉配置刷新历史数据产生的拉链
                                            when clean_tag in ('2','3') then 'spec_now'  --下沉配置刷新当月数据产生的拉链
                                            when clean_tag = '4' then 'data_new'         --当月增量数据产生的拉链
                                            else ''
                                       end)
                                     )
                              ) as spe_val_map
                from dmf_tmp.tmp_fin_fee_detail_month_brush 
                --Modified by renxiaowei7@20210913 下沉逻辑，刷历史数据
                where clean_tag != ''
              union all 
              --手工刷数
              select '1' as clean_tag, 
                     id,biz_id,biz_type,fee_id,fee_type,product_id,product_name,customer_id,customer_name,direction,amount,
                     sett_amount,need_invoice,source_id,rule_id,status,operator,data_type,data_time,yn_flag,prov_flag,remark,
                     creator,editor,created_time,modified_time,
                     customer_type,
                     card_id,pay_channel_type,pay_channel_id,order_id,ex_one,ex_two,ex_three,ex_four,org_id,unikey,sett_id,
                     currency,tax_rate,contract_code,project_code,biz_association_id,composite_id,standby_field_one,
                     standby_field_two,standby_field_three,standby_field_four,standby_field_five,bill_code,
                     ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen,
                     --Added by renxiaowei7@20211103 map结构存储特殊值
                     concat_ws(',',concat('spec_brush_flag:','data_add')) as spe_val_map
                from dmf_tmp.tmp_fin_fee_detail_clean_data 
              union all 
              --当天增量
              select '0' as clean_tag, 
                     id,biz_id,biz_type,fee_id,fee_type,product_id,product_name,customer_id,customer_name,direction,amount,
                     sett_amount,need_invoice,source_id,rule_id,status,operator,data_type,data_time,yn_flag,prov_flag,remark,
                     creator,editor,created_time,modified_time,
                     cast(customer_type as string) as customer_type,
                     card_id,pay_channel_type,pay_channel_id,order_id,ex_one,ex_two,ex_three,ex_four,org_id,unikey,sett_id,
                     currency,tax_rate,contract_code,project_code,biz_association_id,composite_id,standby_field_one,
                     standby_field_two,standby_field_three,standby_field_four,standby_field_five,bill_code,
                     ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen,
                     --Added by renxiaowei7@20211103 map结构存储特殊值
                     concat_ws(',',concat('spec_brush_flag:','data_new')) as spe_val_map
                from dmf_tmp.tmp_fin_fee_detail_all_1 
                where status != '98'  --Modified by renxiaowei7@20220923 结算升级，切换过程中，已经在旧结算产生并且入账的一部分数据，需要在新结算进行结算，但是又不能在旧结算进行冲销，所以把这部分数据手工改为98状态作为过渡状态，直接过滤掉
				  and not (coalesce(ex_three,'') like '%历史数据清理%' and '{TX_DATE}'>'2023-01-16')  --Modified by renxiaowei7@20230116 结算升级，切换过程中，根据切换需要人工打标一部分数据，无需进老结算模型。
             ) t2
     ) t1
left join (select b1.biz_type,b1.sett_code as sett_scenes,b1.sett_type,b1.fee_types,b2.fee_type
           from odm.odm_fi_js_fin_sett_settway_s_d b1
           lateral view explode(split(fee_types,',')) b2 as fee_type
           where b1.dt='{TX_DATE}' and b1.yn = '1'
             --Modified by renxiaowei7@20210901 添加结算场景限定，这里的逻辑仅仅是为了处理这些场景的数据，其它场景有一个fee_type对应多个sett_scenes的数据，否则会导致临时表数据翻倍
             and b1.sett_code in ('14993','149125','149113','149117','149129','149131','149132','14992','149114','149118','149130','149133','149115','149116','149119','14991') 
           ) t2
       on  t1.biz_type = t2.biz_type
      and  t1.fee_type = t2.fee_type
-- Added by machunliang@20210721 for 增加小金库用扩展字段1关联业务系统取客商逻辑
left join dmf_tmp.tmp_fin_fee_detail_xjk_borrow_order t3
  on t1.biz_type = '493' and t1.fee_type in ('49357', '49358', '49360') and 
     t1.ex_one = t3.borrow_order_no
-- Added by lff@20210812 for 增加小金库用扩展字段1关联业务系统取客商逻辑
left join dmf_tmp.tmp_tmp_fin_fee_detail_xjk_sku_id t4
  on t1.biz_type = '493' and t1.fee_type in ('49388') and 
     t1.ex_one = t4.biz_request_no
where t1.rn = 1
;
""",

# ----------------------------------------------- Start Add machunliang@20210524 for 主体修改 -------------------------------------------------

# 参数配置表和参数配置子表关联加工取得主体信息
"sql_120": """

use dmf_tmp;
drop table if exists dmf_tmp.tmp_fin_fee_detail_sett_param;
create table dmf_tmp.tmp_fin_fee_detail_sett_param as 
select d.biz_type, d.fee_type 
       ,d.org_flag          -- 多主体标识：0-单主体，1-多主体
       ,d.obj_customer_source   -- 取客商的来源标识：1-结算映射，2-主数据账户映射，3-超级账户映射
       ,if(d.org_flag = '1', s1.org_id, s0.org_id) as principal_company     -- 主体
       ,s1.org_code         --  对于多主体，需要用此字段关联计费明细的org_id
       ,t3.corp_id   AS fee_principal_company_customer_id
       ,t3.mercht_id AS fee_principal_company_merchant_id
       ,t3.corp_nm   AS fee_principal_company_customer_name
from dmf_dim.dmfdim_finsetts_fi_hs_fin_sett_param_s_d d   -- 参数配置表
left join  dmf_dim.dmfdim_finsetts_fi_hs_fin_sett_param_sub_ts_i_d s0 
       on  d.org_flag = '0' and d.id = s0.param_id and s0.dt = '{TX_DATE}'
left join  dmf_dim.dmfdim_finsetts_fi_hs_fin_sett_param_sub_s_d s1
       on  d.org_flag = '1' and d.id = s1.param_id and s1.dt = '{TX_DATE}'
left join  dmf_dim.dmfdim_dim_fi_fin_subject_principal_merchant_s_d t3
       on  if(d.org_flag = '1', s1.org_id, s0.org_id) = t3.corp_id and t3.dt = '{TX_DATE}' and t3.rn_corp_id = 1
    WHERE  d.dt='{TX_DATE}'
      and  d.org_flag in ('0', '1')
      and (d.org_flag = '0' and s0.param_id is not null
           or d.org_flag = '1' and s1.param_id is not null
           or 1=2
          )
;
""",

#20210624 renxiaowei7 客商表dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d关联会产生倾斜。先提取能关联到的，走默认mapjoin，需要配合下面sql_07一起

"sql_130": """
use dmf_tmp;

drop table if exists dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee;
create table dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee
as 
select b.*
from (select customer_id from dmf_tmp.tmp_fin_fee_detail_all_1_1
      group by customer_id
     ) a
--Modified by renxiaowei7@20221020 同时重跑上下游的连续几天的数据，这里会导致使用的数据日期不一致，修改为限定分区处理
--inner join  dmf_dim.dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d b
inner join (select * from dmf_dim.dmfdim_dim_fi_fin_subject_merchant_maps_s_d where dt='{TX_DATE}') b
        on  a.customer_id = b.cust_id
;
""",

#20210624 renxiaowei7 客商表dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d关联会产生倾斜。先提取能关联到的，走默认mapjoin，需要配合上面sql_06一起

"sql_140": """
use dmf_tmp;

drop table if exists dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee;
create table dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee
as
select c.*
from (select company_name
      from (select customer_id_ex as company_name
            from dmf_tmp.tmp_fin_fee_detail_all_1_1
            where customer_id_ex_typ = '5'
            union all
            select customer_name as company_name 
            from dmf_tmp.tmp_fin_fee_detail_all_1_1
            union all
            select replace(get_json_object(ex_one, '$.LPNM'),'鼎鼎保险代理有限公司','京东数科保险代理有限公司')     as company_name
            from dmf_tmp.tmp_fin_fee_detail_all_1_1
            where biz_type in ('628')
              and fee_type in ('62801','6280301','6280302','6280303','6280304','6280305','6280306','6280307'    ,'6280401','6280402','6280403','6280404','6280405')
         ) b
      group by company_name
     ) a
inner join  dmf_dim.dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d c
        on  c.dt = '{TX_DATE}'
       and  a.company_name = c.company_name
;
""",

# Added by renxiaowei7@20211104 增加对账户的简码去重，避免关联时导致数据重复。通常简码是唯一的，历史上曾经存在过重复，重复的都被物理删除了。避免以后还会偶尔暂时出现简码重复。
"sql_141": """
use dmf_tmp;
drop table if exists dmf_tmp.tmp_fin_sett_all_account_acc_brief_code_fee;
create table if not exists dmf_tmp.tmp_fin_sett_all_account_acc_brief_code_fee
as 
select * from (
    select *,row_number() over(partition by acc_brief_code order by last_update_date desc) as rn
    from dmf_bc.dmfbc_redu_odm_fi_pay_zh_fi_bd_bank_account_info_s_d 
    where dt='{TX_DATE}'
) t1 where rn = 1
;
""",

# 将主体关联到计费明细临时表上
# Modified by renxiaowei7@20211104
#   主体逻辑变更
#   1、单主体：以结算配置为准(若配置有误，修改配置，核算手工入账)
#   2、多主体：以数据为准(若数据有误，修改业务传结算参数，核算手工入账)
#     如果数据中有的主体标识，配置中没有，关联资金主数据获取

"sql_150": """
set hive.auto.convert.join=true;
set mapred.max.split.size=12800000; 
set hive.exec.reducers.bytes.per.reducer=12800000;
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles=true;
set hive.merge.size.per.task=12800000;

set hive.execution.engine=mr;
set mapreduce.map.memory.mb=6144;
set mapreduce.map.java.opts=-Xmx4608M;
set mapreduce.map.cpu.vcores = 4;

use dmf_tmp;

drop table if exists dmf_tmp.tmp_fin_fee_detail_all_6_new;
create table dmf_tmp.tmp_fin_fee_detail_all_6_new
as 
select     *
          -- 确定原来唯一客商ID
          ,case when obj_customer_source = '1' and 
                     mercht_id_all_map['ID-2'] is not null then mercht_id_all_map['ID-2']
                when obj_customer_source = '2' and 
                     mercht_id_all_map['ID-3'] is not null then mercht_id_all_map['ID-3']
                when obj_customer_source = '3' and 
                     mercht_id_all_map['ID-4'] is not null then mercht_id_all_map['ID-4']
                when mercht_id_all_map['ID-2'] is not null then mercht_id_all_map['ID-2']
                when mercht_id_all_map['ID-3'] is not null then mercht_id_all_map['ID-3']
                when mercht_id_all_map['ID-4'] is not null then mercht_id_all_map['ID-4']
                when mercht_id_all_map['ID-6'] is not null then mercht_id_all_map['ID-6']
                when mercht_id_all_map['ID-5'] is not null then mercht_id_all_map['ID-5']
           end as fee_customer_name_merchant_id
          -- 客商类型
          ,case when obj_customer_source = '1' and 
                     mercht_id_all_map['ID-2'] is not null then mercht_typ_all_map['ID-2']
                when obj_customer_source = '2' and 
                     mercht_id_all_map['ID-3'] is not null then mercht_typ_all_map['ID-3']
                when obj_customer_source = '3' and 
                     mercht_id_all_map['ID-4'] is not null then mercht_typ_all_map['ID-4']
                when mercht_id_all_map['ID-2'] is not null then mercht_typ_all_map['ID-2']
                when mercht_id_all_map['ID-3'] is not null then mercht_typ_all_map['ID-3']
                when mercht_id_all_map['ID-4'] is not null then mercht_typ_all_map['ID-4']
                when mercht_id_all_map['ID-6'] is not null then mercht_typ_all_map['ID-6']
                when mercht_id_all_map['ID-5'] is not null then mercht_typ_all_map['ID-5']
           end as fee_customer_name_merchant_id_type
          -- 确定原来唯一客商ID来源标识
          ,case when obj_customer_source = '1' and 
                     mercht_id_all_map['ID-2'] is not null then 'p1'
                when obj_customer_source = '2' and 
                     mercht_id_all_map['ID-3'] is not null then 'p2'
                when obj_customer_source = '3' and 
                     mercht_id_all_map['ID-4'] is not null then 'p3'
                when mercht_id_all_map['ID-2'] is not null then 't4'
                when mercht_id_all_map['ID-3'] is not null then 't6'
                when mercht_id_all_map['ID-4'] is not null then 't8'
                when mercht_id_all_map['ID-6'] is not null then 't5'
                when mercht_id_all_map['ID-5'] is not null then 't2'
           end as fee_customer_name_merchant_id_src_tag
          ,mercht_id_all as fee_customer_name_merchant_id_all_src
          ,mercht_typ_all as fee_customer_name_merchant_typ_all_src 
          ,'' as dept_id --部门 Added by renxiaowei7@20210819 结算特殊处理逻辑下沉
from (select     *
                ,str_to_map(mercht_id_all) as mercht_id_all_map
                ,str_to_map(mercht_typ_all) as mercht_typ_all_map 
      from (select     t1.clean_tag  --20210624 renxiaowei7
                      ,t1.id
                      ,t1.biz_id
                      ,t1.biz_type
                      ,t1.fee_id
                      ,t1.fee_type
                      ,t1.product_id
                      ,t1.product_name
                      ,t1.customer_id
                      ,t1.customer_name
                      ,t1.direction
                      ,t1.amount
                      ,t1.sett_amount
                      ,t1.need_invoice
                      ,t1.source_id
                      ,t1.rule_id
                      ,t1.status
                      ,t1.operator
                      ,t1.data_type
                      ,t1.data_time
                      ,t1.yn_flag
                      ,t1.prov_flag
                      ,t1.remark
                      ,t1.creator
                      ,t1.editor
                      ,t1.created_time
                      ,t1.modified_time
                      ,t1.customer_type
                      ,t1.card_id
                      ,t1.pay_channel_type
                      ,t1.pay_channel_id
                      ,t1.order_id
                      ,t1.ex_one
                      ,t1.ex_two
                      ,t1.ex_three
                      ,t1.ex_four
                      ,t1.org_id
                      ,t1.unikey
                      ,t1.sett_id
                      ,t1.currency
                      ,case when trim(nvl(t1.tax_rate, '')) = '' and t1.biz_type in ('700','705', '547') -- 没有填税率字段&限定业务内的
                            then cast(replace(t1.ex_one,'%','')*0.01 as string)
                            -- Added by machunliang@20210708 增加514业务的税率规则，来自立新。
                            -- 514业务从扩展字段1取税率，从中去掉非数字的字符，且取得的数值是合理的税率（<70%）
                            when t1.biz_type in ('514', '535')
                                 and t1.ex_one regexp '%|税率'
                                 and abs(regexp_replace(t1.ex_one, '%|税率|:|：', '')) < 70
                            then cast(regexp_replace(t1.ex_one, '%|税率|:|：', '')*0.01 as string)
                            when t1.biz_type in ('514', '535') then '0.06'
                            else t1.tax_rate
                       end as tax_rate
                      ,t1.contract_code
                      ,case 
                            -- Modified by machunliang@20210713 增加春风的 特殊逻辑项目代码
                            when trim(nvl(project_code, '')) = '' and t1.biz_type = '664' and t1.fee_type in ('66408490', '6640901') then '0008KZ99999'
                            when trim(nvl(project_code, '')) = ''         -- 没有填项目字段
                            then get_json_object(ex_four,'$.projectCode') -- 能取到则取，不限定业务范围
                            -- Modified by machunliang@20210719 445业务的项目代码处理
                            when t1.biz_type = '445'
                            then coalesce(dmf_bc.dmdictDesc('gyl_abs_off_project_no',t1.product_id),
                                          dmf_bc.dmdictDesc('gyl_abs_project_no',t1.product_id),
                                          dmf_bc.dmdictDesc('gyl_cl_abs_off_project_no',t1.product_id),
                                          project_code
                                          )
                            -- Modified by machunliang@20210728 455业务的项目代码处理
                            -- Added by machunliang@20210728 增加455的项目段兜底逻辑
                            when t1.biz_type = '455' and t1.fee_type in ('45511','45515','45516')
                            then coalesce(dmf_bc.dmdictDesc('jt_abs_project_no',t1.product_id), 
                                          dmf_bc.dmdictDesc('fst_spv_project_no',t1.customer_id,'03'), 
                                          project_code
                                          )
                            else project_code
                       end as project_code 
                      ,t1.biz_association_id
                      ,t1.composite_id
                      ,t1.standby_field_one
                      ,t1.standby_field_two
                      ,t1.standby_field_three
                      ,t1.standby_field_four
                      ,t1.standby_field_five
                      ,t1.bill_code
                      ,t1.ex_five
                      ,t1.ex_six
                      ,t1.ex_seven
                      ,t1.ex_eight
                      ,t1.ex_nine
                      ,t1.ex_ten
                      ,t1.ex_eleven
                      ,t1.ex_twelve
                      ,t1.ex_thirteen
                      ,t1.ex_fourteen
                      ,t1.ex_fifteen
                      --Modified by renxiaowei7@20211104 主体逻辑变更
                      ,coalesce(t2.fee_principal_company_customer_id,if(nvl(t21.org_flag,'')='1',t22.belong_company_id,'')) as fee_principal_company_customer_id       --计费明细公司主体编码对应的主体主数据ID
                      ,coalesce(t3.id, t2.fee_principal_company_merchant_id,if(nvl(t21.org_flag,'')='1',t22.mercht_id,null), dmf_bc.dmdictdesc('fst_jrxz_org_id_mapping', org_id)) AS fee_principal_company_merchant_id                     --计费明细公司主体编码对应的客商主数据ID
                      --Modified by renxiaowei7@20211104 主体逻辑变更
                      ,coalesce(t2.fee_principal_company_customer_name,if(nvl(t21.org_flag,'')='1',t22.belong_company,'')) as fee_principal_company_customer_name      --计费明细公司主体编码对应的公司名称
                      -- Modified by machunliang@20210330 增加扩展字段取值
                      ,case when t3.id is not null then '5' 
                            --Modified by renxiaowei7@20211104 主体逻辑变更
                            --when t2.fee_principal_company_merchant_id is not null then t2.org_flag 
                            when nvl(t21.org_flag,'') != '' then t21.org_flag
                            --else '4' 
                            when dmf_bc.dmdictdesc('fst_jrxz_org_id_mapping', org_id) is not null then '4'
                       end as principal_merchant_id_src_tag           -- 来源标识：0-单主体，1-多主体，4-函数， 5-扩展字段取名称关联客商维表
                      --Modified by renxiaowei7@20211105
                      --,t2.obj_customer_source                         -- 客体取值来源：1-结算映射，2-主数据账户映射，3-超级账户映射
                      ,t21.obj_customer_source                         -- 客体取值来源：1-结算映射，2-主数据账户映射，3-超级账户映射
                      ,concat(
                          NVL(concat(',ID-1:', t11.mercht_id), '')    -- 结算映射（直接取客商）
                         ,NVL(concat(',ID-2:', t11.mercht_id2), '')   -- 结算映射（关联账户间接取客商）
                         ,NVL(concat(',ID-3:', t13.mercht_id), '')    -- 主数据（账户）ID
                         ,NVL(concat(',ID-4:', t14.mercht_id), '')    -- 超级账户
                         ,NVL(concat(',ID-5:', t15.id), '')           -- 名称兜底
                         ,NVL(concat(',ID-6:', t16.mercht_id), '')    -- customer_id 是商户号
                         ,NVL(concat(',ID-7:', case 
                                                    -- 小金库的垫资行客商
                                                    when t1.biz_type='493' AND t1.fee_type='49315' THEN dxxjk_adv_bnk   -- 代销小金库的垫资行客商
                                                    when t1.customer_id_ex_typ = '1' then tx11.mercht_id                -- （扩展字段）结算映射直接取客商
                                                    when t1.customer_id_ex_typ = '2' then tx11.mercht_id2               -- （扩展字段）结算映射关联主数据账户间接取客商
                                                    -- Added by renxiaowei7@20211115
                                                    when t1.customer_id_ex_typ = '3' then tx13.mercht_id                -- （扩展字段）结算客商关联主数据账户直接取客商
                                                    when t1.customer_id_ex_typ = '5' then tx15.id                       -- （扩展字段）名称关联客商表
                                                end 
                                                , ''), '')
                         -- Added by machunliang@20210610 增加699-金融科技的客商特殊逻辑：宝付网络科技（上海）有限公司（1497718）--客商取主体字段
                         -- ,case when t1.biz_type = '699' and t1.customer_id in ('2696686', '1003252')
                        ,case when t1.biz_type = '699' and t1.customer_id in ('2696686')
                               then NVL(concat(',ID-8:', coalesce(t3.id, t2.fee_principal_company_merchant_id,if(nvl(t21.org_flag,'')='1',t22.mercht_id,null), dmf_bc.dmdictdesc('fst_jrxz_org_id_mapping', org_id))), '')
                               else ''
                          end
                        -- Added by machunliang@20210721 for 小金库使用扩展字段1关联业务系统取客商逻辑
                        ,case when t1.biz_type = '493' and t1.fee_type in ('49357', '49358', '49360', '49388') 
                               then NVL(concat(',ID-9:', xjk_bizsys_mercht_id), '')
                               else ''
                          end
                       ) as mercht_id_all 
                      ,concat(
                          NVL(concat(',ID-1:', t11.mercht_typ), '')   -- 结算映射（直接取客商）
                         ,NVL(concat(',ID-2:', t11.mercht_typ2), '')  -- 结算映射（关联账户间接取客商）
                         ,NVL(concat(',ID-3:', t13.mercht_typ), '')   -- 主数据（账户）ID
                         ,NVL(concat(',ID-4:', t14.mercht_typ), '')   -- 超级账户
                         ,NVL(concat(',ID-5:', t15.mercht_typ), '')   -- 名称兜底
                         ,NVL(concat(',ID-6:', t16.mercht_typ), '')   -- customer_id 是商户号
                         ,NVL(concat(',ID-7:', case 
                                                    -- 小金库的垫资行客商
                                                    when t1.biz_type='493' AND t1.fee_type='49315' THEN '1'               -- 代销小金库的垫资行客商，默认外部
                                                    when t1.customer_id_ex_typ = '1' then tx11.mercht_typ                 -- （扩展字段）结算映射直接取客商
                                                    when t1.customer_id_ex_typ = '2' then tx11.mercht_typ2                -- （扩展字段）结算映射关联主数据账户间接取客商
                                                    -- Added by renxiaowei7@20211115
                                                    when t1.customer_id_ex_typ = '3' then tx13.mercht_typ                -- （扩展字段）结算客商关联主数据账户直接取客商
                                                    when t1.customer_id_ex_typ = '5' then tx15.mercht_typ                 -- （扩展字段）名称关联客商表
                                                end 
                                                , ''), '')
                         -- Added by machunliang@20210610 增加699-金融科技的客商特殊逻辑：宝付网络科技（上海）有限公司（1497718）--客商取主体字段
                         ,case when t1.biz_type = '699' and t1.customer_id in ('2696686', '1003252')
                               then NVL(concat(',ID-8:', '1'), '')    -- 取到的是信托公司，为外部客商
                               else ''
                           end
                        -- Added by machunliang@20210721 for 小金库使用扩展字段1关联业务系统取客商逻辑 均为外部客商
                        ,case when t1.biz_type = '493' and t1.fee_type in ('49357', '49358', '49360', '49388') 
                               then NVL(concat(',ID-9:', '1'), '')
                               else ''
                          end
                       ) as mercht_typ_all 
                      
                      -- Added by machunliang@20210308 增加核算业务线
                      -- Modified by machunliang@20210708 for 用于函数调用的参数字段条件，或用于动态关联
                      -- Modified by renxiaowei7@20210819 核算业务线产品只存放产品，业务线在核算交易明细获取
                      -- Modified by renxiaowei7@20210819 结算特殊逻辑下沉，核算产品加工逻辑归一，删除此处的逻辑
                      --,'' as Accti_Biz_Line_Cd        -- 核算业务线产品
                      --Added by renxiaowei7@20211103 map结构存储特殊值
                      ,t1.spe_val_map
            -- Modified by machunliang@20210708 for 用于函数调用的参数字段条件，或用于动态关联
            -- Modified by renxiaowei7@20210819 结算特殊逻辑下沉，核算产品加工逻辑归一，删除此处的逻辑
            from dmf_tmp.tmp_fin_fee_detail_all_1_1 t1
            -- ------------------------ 取主体 -----------------------------
            left join  dmf_tmp.tmp_fin_fee_detail_sett_param t2 
                   on  t1.biz_type = t2.biz_type
                  and  t1.fee_type = t2.fee_type
                  and  if(t2.org_flag = '1', t1.org_id, '') = if(t2.org_flag = '1', t2.org_code, '')
            --用于获取多主体未配置主体映射的主体标识对应的主体信息
            left join  dmf_dim.dmfdim_finsetts_fi_hs_fin_sett_param_s_d t21 
                   on  1 = 1
                  --and  nvl(t21.org_flag,'') in ('0','1')
                  and  t21.dt='{TX_DATE}'
                  and  t1.biz_type = t21.biz_type
                  and  t1.fee_type = t21.fee_type
            left join  dmf_tmp.tmp_fin_sett_all_account_acc_brief_code_fee t22
                   on  t1.org_id = t22.acc_brief_code
            -- 取主体特殊口径 
            -- Added by machunliang@20210330 for 根据肖宁的业务规则，增加从扩展字段取主体的口径。目前仅生效在主体客商ID字段。主体公司字段暂不处理。业务和费用类型参考作业：JCW_DMFGJ_GJ_INSU_FI_HS_TRANSACTION_DETAIL_DDBD_I_D
            left join  dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee t3
                   on  1 = 1
                  --and  replace(get_json_object(t1.ex_one, '$.LPNM'),'鼎鼎保险代理有限公司','京东数科保险代理有限公司') = t3.company_name
                  --and  t1.biz_type in ('628')
                  --and  t1.fee_type in ('62801','6280301','6280302','6280303','6280304','6280305','6280306','6280307','6280401','6280402','6280403','6280404','6280405')
                  and  (case when t1.biz_type in ('628')
                                  and t1.fee_type in ('62801','6280301','6280302','6280303','6280304','6280305','6280306','6280307','6280401','6280402','6280403','6280404','6280405')
                             then replace(get_json_object(t1.ex_one, '$.LPNM'),'鼎鼎保险代理有限公司','京东数科保险代理有限公司')
                             else t1.fee_id
                        end) = t3.company_name  --20210623 renxiaowei7 解决ex_one关联倾斜的问题
            -- ------------------------ 取客体 -----------------------------
            -- 结算映射取值
            left join  dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee t11
                   on  t11.map_typ = 'ID-1'
                  and  t11.biz_typ = t1.biz_type
                  and  t11.cust_id = t1.customer_id
            -- 主数据账户映射
            left join  dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee t13
                   on  t13.map_typ = 'ID-3'
                  and  t13.cust_id = t1.customer_id
            -- 超级账户映射
            left join  dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee t14
                   on  t14.map_typ = 'ID-4'
                  and  t14.cust_id = t1.customer_id
            -- 主数据账户商户号映射
            left join  dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee t16
                   on  t16.map_typ = 'ID-6'
                  and  t16.cust_id = t1.customer_id
            -- 名称兜底
            left join  dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee t15
                   on  1 = 1
                  and  t15.company_name = t1.customer_name
            -- Added by machunliang@20210413 通过扩展字段取客商
            -- 扩展字段 使用结算映射 
            left join  dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee tx11
                   on  tx11.map_typ = 'ID-1'
                  and  t1.customer_id_ex_typ in ('1', '2')
                  and  tx11.cust_id = t1.customer_id_ex
                  and  tx11.biz_typ = t1.biz_type  
            -- Added by renxiaowei7@20211115 通过扩展字段取账户，映射客商
            -- 扩展字段 使用结算映射 
            left join  dmf_tmp.tmp_dmfdim_dim_fi_fin_subject_merchant_maps_a_s_d_tmp_fee tx13
                   on  tx13.map_typ = 'ID-3'
                  and  t1.customer_id_ex_typ in ('3')
                  and  tx13.cust_id = t1.customer_id_ex
                  --and  tx13.biz_typ = t1.biz_type                   
            -- 扩展字段 名称兜底
            left join  dmf_tmp.tmp_dmfdim_finsetts_fi_hs_subject_merchant_company_name_s_d_tmp_fee tx15
                   on  1 = 1
                  and  t1.customer_id_ex_typ = '5'
                  and  tx15.company_name=t1.customer_id_ex
           ) tt1
     ) tt2
;
""",
# ----------------------------------------------- End Add machunliang@20210524 -------------------------------------------------

#Added by renxiaowei7@20210819
#结算特殊处理逻辑下沉
"sql_160": """
use dmf_tmp;
set hive.auto.convert.join=true;

drop table if exists dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_01;
create table dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_01
as
select     a1.*
          ,a2.typecd       --处理类型
          ,a2.result_flag  --结果类型
          ,a2.result_sql   --映射结果
          ,case when a2.result_flag = 'S' then a2.result_val_sql    --固定值
                --映射函数
                when a2.result_flag = 'F' then nvl(dmf_bc.dmdictDesc(a2.result_val_func_nm,if(substr(a2.result_val_func_coll_01,1,2)='S$',substr(a2.result_val_func_coll_01,3),a1.conn_cols[a2.result_val_func_coll_01]),if(substr(a2.result_val_func_coll_02,1,2)='S$',substr(a2.result_val_func_coll_02,3),a1.conn_cols[a2.result_val_func_coll_02]),if(substr(a2.result_val_func_coll_03,1,2)='S$',substr(a2.result_val_func_coll_03,3),a1.conn_cols[a2.result_val_func_coll_03]),if(substr(a2.result_val_func_coll_04,1,2)='S$',substr(a2.result_val_func_coll_04,3),a1.conn_cols[a2.result_val_func_coll_04]),if(substr(a2.result_val_func_coll_05,1,2)='S$',substr(a2.result_val_func_coll_05,3),a1.conn_cols[a2.result_val_func_coll_05]),if(substr(a2.result_val_func_coll_06,1,2)='S$',substr(a2.result_val_func_coll_06,3),a1.conn_cols[a2.result_val_func_coll_06]),if(substr(a2.result_val_func_coll_07,1,2)='S$',substr(a2.result_val_func_coll_07,3),a1.conn_cols[a2.result_val_func_coll_07]),if(substr(a2.result_val_func_coll_08,1,2)='S$',substr(a2.result_val_func_coll_08,3),a1.conn_cols[a2.result_val_func_coll_08])),'')
                when a2.result_flag = 'C' then a2.result_val_sql
                else ''
           end as result_val
from (select     *
                ,str_to_map(concat_ws('#'
                               ,concat('biz_type&'     ,nvl(biz_type     ,''))
                               ,concat('fee_type&'     ,nvl(fee_type     ,''))
                               ,concat('status&'       ,nvl(status       ,''))
                               ,concat('product_id&'   ,nvl(product_id   ,''))
                               ,concat('customer_id&'  ,nvl(customer_id  ,''))
                               ,concat('source_id&'    ,nvl(source_id    ,''))
                               ,concat('ex_one&'       ,nvl(ex_one       ,''))
                               ,concat('ex_two&'       ,nvl(ex_two       ,''))
                               ,concat('ex_three&'     ,nvl(ex_three     ,''))
                               ,concat('ex_four&'      ,nvl(ex_four      ,''))
                               ,concat('ex_five&'      ,nvl(ex_five      ,''))
                               ,concat('ex_six&'       ,nvl(ex_six       ,''))
                               ,concat('ex_seven&'     ,nvl(ex_seven     ,''))
                               ,concat('ex_eight&'     ,nvl(ex_eight     ,''))
                               ,concat('ex_nine&'      ,nvl(ex_nine      ,''))
                               ,concat('ex_ten&'       ,nvl(ex_ten       ,''))
                               ,concat('ex_eleven&'    ,nvl(ex_eleven    ,''))
                               ,concat('ex_twelve&'    ,nvl(ex_twelve    ,''))
                               ,concat('ex_thirteen&'  ,nvl(ex_thirteen  ,''))
                               ,concat('ex_fourteen&'  ,nvl(ex_fourteen  ,''))
                               ,concat('ex_fifteen&'   ,nvl(ex_fifteen   ,''))
                               ,concat('product_name&' ,nvl(product_name ,''))
                               ,concat('customer_name&',nvl(customer_name,''))
                               ,concat('fee_customer_name_merchant_id&',nvl(fee_customer_name_merchant_id,''))
                          ),'#','&') as conn_cols
      from dmf_tmp.tmp_fin_fee_detail_all_6_new
     ) a1
left join (select * from dmf_bc.dmfbc_bc_sett_spec_conf_detail_a_d
           where modleCd = 'sett_gdm' --配置层级 结算中间层
             and tabCd   = 'fee'      --处理表   计费明细
          ) a2
       on  a1.biz_type = a2.bizType
      and (   (a2.feeType     like '!%' and concat(',',substr(a2.feeType,2),',') not like concat('%,',a1.fee_type,',%'))
           or (a2.feeType not like '!%' and concat(',',a2.feeType,',')               like concat('%,',a1.fee_type,',%'))
           or nvl(a2.feeType,'')=''
          )
      and  case when nvl(a2.field_01_flag,'') = 'S&='     and a1.conn_cols[a2.field_01_coll] =  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&!='    and a1.conn_cols[a2.field_01_coll] != a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&>'     and a1.conn_cols[a2.field_01_coll] >  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&<'     and a1.conn_cols[a2.field_01_coll] <  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&>='    and a1.conn_cols[a2.field_01_coll] >= a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&<='    and a1.conn_cols[a2.field_01_coll] <= a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&IN'    and concat(',',a2.field_01_val,',') like     concat('%,',a1.conn_cols[a2.field_01_coll],',%') then '1'
                when nvl(a2.field_01_flag,'') = 'S&!IN'   and concat(',',a2.field_01_val,',') not like concat('%,',a1.conn_cols[a2.field_01_coll],',%') then '1'
                when nvl(a2.field_01_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_01_coll]  like     a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_01_coll]  not like a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_02_flag,'') = 'S&='     and a1.conn_cols[a2.field_02_coll] =  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&!='    and a1.conn_cols[a2.field_02_coll] != a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&>'     and a1.conn_cols[a2.field_02_coll] >  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&<'     and a1.conn_cols[a2.field_02_coll] <  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&>='    and a1.conn_cols[a2.field_02_coll] >= a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&<='    and a1.conn_cols[a2.field_02_coll] <= a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&IN'    and concat(',',a2.field_02_val,',') like     concat('%,',a1.conn_cols[a2.field_02_coll],',%') then '1'
                when nvl(a2.field_02_flag,'') = 'S&!IN'   and concat(',',a2.field_02_val,',') not like concat('%,',a1.conn_cols[a2.field_02_coll],',%') then '1'
                when nvl(a2.field_02_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_02_coll]  like     a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_02_coll]  not like a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_03_flag,'') = 'S&='     and a1.conn_cols[a2.field_03_coll] =  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&!='    and a1.conn_cols[a2.field_03_coll] != a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&>'     and a1.conn_cols[a2.field_03_coll] >  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&<'     and a1.conn_cols[a2.field_03_coll] <  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&>='    and a1.conn_cols[a2.field_03_coll] >= a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&<='    and a1.conn_cols[a2.field_03_coll] <= a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&IN'    and concat(',',a2.field_03_val,',') like     concat('%,',a1.conn_cols[a2.field_03_coll],',%') then '1'
                when nvl(a2.field_03_flag,'') = 'S&!IN'   and concat(',',a2.field_03_val,',') not like concat('%,',a1.conn_cols[a2.field_03_coll],',%') then '1'
                when nvl(a2.field_03_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_03_coll]  like     a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_03_coll]  not like a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_04_flag,'') = 'S&='     and a1.conn_cols[a2.field_04_coll] =  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&!='    and a1.conn_cols[a2.field_04_coll] != a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&>'     and a1.conn_cols[a2.field_04_coll] >  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&<'     and a1.conn_cols[a2.field_04_coll] <  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&>='    and a1.conn_cols[a2.field_04_coll] >= a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&<='    and a1.conn_cols[a2.field_04_coll] <= a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&IN'    and concat(',',a2.field_04_val,',') like     concat('%,',a1.conn_cols[a2.field_04_coll],',%') then '1'
                when nvl(a2.field_04_flag,'') = 'S&!IN'   and concat(',',a2.field_04_val,',') not like concat('%,',a1.conn_cols[a2.field_04_coll],',%') then '1'
                when nvl(a2.field_04_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_04_coll]  like     a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_04_coll]  not like a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_05_flag,'') = 'S&='     and a1.conn_cols[a2.field_05_coll] =  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&!='    and a1.conn_cols[a2.field_05_coll] != a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&>'     and a1.conn_cols[a2.field_05_coll] >  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&<'     and a1.conn_cols[a2.field_05_coll] <  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&>='    and a1.conn_cols[a2.field_05_coll] >= a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&<='    and a1.conn_cols[a2.field_05_coll] <= a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&IN'    and concat(',',a2.field_05_val,',') like     concat('%,',a1.conn_cols[a2.field_05_coll],',%') then '1'
                when nvl(a2.field_05_flag,'') = 'S&!IN'   and concat(',',a2.field_05_val,',') not like concat('%,',a1.conn_cols[a2.field_05_coll],',%') then '1'
                when nvl(a2.field_05_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_05_coll]  like     a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_05_coll]  not like a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_06_flag,'') = 'S&='     and a1.conn_cols[a2.field_06_coll] =  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&!='    and a1.conn_cols[a2.field_06_coll] != a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&>'     and a1.conn_cols[a2.field_06_coll] >  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&<'     and a1.conn_cols[a2.field_06_coll] <  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&>='    and a1.conn_cols[a2.field_06_coll] >= a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&<='    and a1.conn_cols[a2.field_06_coll] <= a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&IN'    and concat(',',a2.field_06_val,',') like     concat('%,',a1.conn_cols[a2.field_06_coll],',%') then '1'
                when nvl(a2.field_06_flag,'') = 'S&!IN'   and concat(',',a2.field_06_val,',') not like concat('%,',a1.conn_cols[a2.field_06_coll],',%') then '1'
                when nvl(a2.field_06_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_06_coll]  like     a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_06_coll]  not like a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_07_flag,'') = 'S&='     and a1.conn_cols[a2.field_07_coll] =  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&!='    and a1.conn_cols[a2.field_07_coll] != a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&>'     and a1.conn_cols[a2.field_07_coll] >  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&<'     and a1.conn_cols[a2.field_07_coll] <  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&>='    and a1.conn_cols[a2.field_07_coll] >= a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&<='    and a1.conn_cols[a2.field_07_coll] <= a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&IN'    and concat(',',a2.field_07_val,',') like     concat('%,',a1.conn_cols[a2.field_07_coll],',%') then '1'
                when nvl(a2.field_07_flag,'') = 'S&!IN'   and concat(',',a2.field_07_val,',') not like concat('%,',a1.conn_cols[a2.field_07_coll],',%') then '1'
                when nvl(a2.field_07_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_07_coll]  like     a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_07_coll]  not like a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_08_flag,'') = 'S&='     and a1.conn_cols[a2.field_08_coll] =  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&!='    and a1.conn_cols[a2.field_08_coll] != a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&>'     and a1.conn_cols[a2.field_08_coll] >  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&<'     and a1.conn_cols[a2.field_08_coll] <  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&>='    and a1.conn_cols[a2.field_08_coll] >= a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&<='    and a1.conn_cols[a2.field_08_coll] <= a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&IN'    and concat(',',a2.field_08_val,',') like     concat('%,',a1.conn_cols[a2.field_08_coll],',%') then '1'
                when nvl(a2.field_08_flag,'') = 'S&!IN'   and concat(',',a2.field_08_val,',') not like concat('%,',a1.conn_cols[a2.field_08_coll],',%') then '1'
                when nvl(a2.field_08_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_08_coll]  like     a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_08_coll]  not like a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_01_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') =  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') != a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') >  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') <  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') >= a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') <= a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&IN'    and concat(',',a2.func_01_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),''),',%') then '1'
                when nvl(a2.func_01_flag,'') = 'S&!IN'   and concat(',',a2.func_01_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),''),',%') then '1'
                when nvl(a2.func_01_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'')  like     a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'')  not like a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_02_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') =  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') != a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') >  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') <  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') >= a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') <= a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&IN'    and concat(',',a2.func_02_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),''),',%') then '1'
                when nvl(a2.func_02_flag,'') = 'S&!IN'   and concat(',',a2.func_02_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),''),',%') then '1'
                when nvl(a2.func_02_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'')  like     a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'')  not like a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_03_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') =  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') != a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') >  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') <  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') >= a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') <= a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&IN'    and concat(',',a2.func_03_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),''),',%') then '1'
                when nvl(a2.func_03_flag,'') = 'S&!IN'   and concat(',',a2.func_03_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),''),',%') then '1'
                when nvl(a2.func_03_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'')  like     a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'')  not like a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = '' then '1'
                else '0'
           end = '1'
;
""",

}

parallel_keys_01 = [
    ['sql_010','sql_020','sql_030'],
    ['sql_040','sql_050'],
    ['sql_110','sql_120'],
    ['sql_130','sql_140','sql_141'],
    ['sql_150'],
    ['sql_160'],
]

#return_code = sql_task.execute_sqls(sql_map_01)
return_code = sql_task.execute_sqls_parallel(sql_map_01, parallel_keys_01)

###################Added by renxiaowei7@20210819 结算特殊处理逻辑下沉 特殊逻辑处理 start########
#临时表-库表-定义
database_name_01 = 'dmf_tmp'
table_name_01 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_01'
table_name_02 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_02'
table_name_03 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_03'
table_name_04 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_04'

#sql模板01-获取结果表想要的字段
#提取公共字段，用于sql替换，否则脚本长度太长，可读性不好
sql_model_01= """
    desc {table_name_01}
"""
    
#sql模板02-获取拼sql-需要拼sql的sql主键及需要拼接的sql
sql_model_02= """
    select dmf_bc.getmd5(typecd,result_flag,result_val) as result_val_md5,result_val
    from {table_name_01}
    where result_flag not in ('S','F')
    group by dmf_bc.getmd5(typecd,result_flag,result_val),result_val
"""

#sql模板03-获取拼sql-固定部分逻辑
sql_model_03= """
    use {database_name_01};
    drop table if exists {table_name_02};
    create table {table_name_02}
    as
    select     {result_cols_sql}
              ,conn_cols,typecd,result_flag,result_sql
              ,result_val
    from {table_name_01}
    where nvl(result_flag,'') in ('S','F','')
"""

#sql模板04-获取拼sql-可变部分逻辑
sql_model_04= """
    select     {result_cols_sql}
              ,conn_cols,typecd,result_flag,result_sql
              ,nvl({spec_sql},'') as result_val
    from {table_name_01}
    where nvl(result_flag,'') not in ('S','F','')
      and dmf_bc.getmd5(typecd,result_flag,result_val) = '{unikey}'
"""

#sql模板05-获取拼sql-如果union all超过30则拆sql
sql_model_05="""
    ;
    insert into table {table_name_02}
    select     {result_cols_sql}
              ,conn_cols,typecd,result_flag,result_sql
              ,'' as result_val
    from {table_name_01}
    where 1 = 2
"""

#sql模板06-获取客商类型临时表sql-优化mapjoin-客商逻辑提前
sql_model_06="""
    set hive.auto.convert.join=true;
    use {database_name_01};
    drop table if exists {table_name_03};
    create table {table_name_03}
    as
    select a2.mercht_id,a2.mercht_typ
    from (select result_val
          from {table_name_02}
          where nvl(typeCd,'') in ('dmf_cust_ID7','dmf_cust_ID8')
            and nvl(result_val,'')!=''
          group by result_val
         ) a1
    left join (select mercht_id,mercht_typ
               from dmf_bc.dmfbc_bc_view_odm_fi_fin_subject_merchant_s_d  --客商类型映射表
               where dt = '{TX_DATE}'
              ) a2
           on  a1.result_val = a2.mercht_id
    ;
"""

#sql模板07-获取聚合数据的sql-下沉逻辑处理完成后
#Modified by renxiaowei7@20220617 添加sort_array排序逻辑
sql_model_07= """
    set hive.auto.convert.join=true;
    set hive.execution.engine=mr;
    use {database_name_01};
    drop table if exists {table_name_04};
    create table {table_name_04}
    as
    select     {result_cols_sql}
              ,concat_ws(',',sort_array(collect_set(a1.typecd))) as spec_type_cd --下沉类型编码
              ,concat_ws(',',collect_list(concat(
                    a1.typecd
                   ,if(nvl(a1.typecd,'')!='',':','')
                   ,a1.result_val
                   ,case when nvl(a1.typecd,'') in ('dmf_cust_ID7','dmf_cust_ID8') then concat('&',a2.mercht_typ)
                         else ''
                    end
                ))) as conn_spe_cols
    from (select     {result_cols_sql}
                    ,'' as typecd
                    ,'' as result_val
          from {table_name_02}
          where nvl(result_val,'')=''
          union all
          select     {result_cols_sql}
                    ,typecd
                    ,case when typecd not in ('dmf_product') then max(result_val)  --除核算业务线外，如果映射配置表出现一条数据对应多个映射的，直接max取值
                          when typecd in ('dmf_product') then concat_ws('&',sort_array(collect_set(result_val)))
                          else ''
                     end as result_val
          from {table_name_02}
          where nvl(result_val,'') !=''
          group by   {result_cols_sql}
                    ,typecd
         ) a1
    left join  {table_name_03} a2
           on  a1.typeCd in ('dmf_cust_ID7','dmf_cust_ID8')
          and  a1.result_val = a2.mercht_id
    group by   {result_cols_sql}
"""

#下沉函数定义01-获取未进行下沉逻辑处理之前临时表的字段
def get_result_cols_sql():
    select_result_map = get_sys_config_data(sql_model_01.format(table_name_01=table_name_01))
    select_result_map_col = [cols[0].replace(' ','') for cols in select_result_map]
    result_cols_sql = '\n              ,'.join(select_result_map_col[0:-5])
    return result_cols_sql

#下沉函数定义02-获取使用python处理的下沉逻辑sql_map
def get_union_all_sql():
    #获取固定字段
    result_cols_sql = get_result_cols_sql()
    #获取拼sql
    union_all_sql_list = []
    #获取拼sql-固定部分逻辑
    sql_model_03_list = {}
    sql_model_03_list['database_name_01'] = database_name_01
    sql_model_03_list['table_name_01'] = table_name_01
    sql_model_03_list['table_name_02'] = table_name_02
    sql_model_03_list['result_cols_sql'] = result_cols_sql
    union_all_sql_list.append(sql_model_03.format(**sql_model_03_list))
    #获取拼sql-可变部分逻辑
    num = 0
    select_result_map = get_sys_config_data(sql_model_02.format(table_name_01=table_name_01))
    for cols in select_result_map:
        num += 1
        sql_model_04_list = {}
        sql_model_04_list['result_cols_sql'] = result_cols_sql
        sql_model_04_list['table_name_01'] = table_name_01
        sql_model_04_list['unikey'] = cols[0]
        sql_model_04_list['spec_sql'] = cols[1]
        if(num%30 == 0):
            union_all_sql_list.append(sql_model_04.format(**sql_model_04_list)+sql_model_05.format(table_name_01=table_name_01,table_name_02=table_name_02,result_cols_sql=result_cols_sql))
        else:
            union_all_sql_list.append(sql_model_04.format(**sql_model_04_list))
    
    #获取拼sql结果
    sql_310 = union_all_sql_list[0] if(len(union_all_sql_list)<=1) else 'union all'.join(union_all_sql_list)
    #获取客商类型临时表sql
    sql_model_06_list = {}
    sql_model_06_list['database_name_01'] = database_name_01
    sql_model_06_list['table_name_02'] = table_name_02
    sql_model_06_list['table_name_03'] = table_name_03
    sql_model_06_list['TX_DATE'] = sql_task._tx_date
    sql_320 = sql_model_06.format(**sql_model_06_list)
    #获取聚合数据的sql
    sql_model_07_list = {}
    sql_model_07_list['database_name_01'] = database_name_01
    sql_model_07_list['table_name_02'] = table_name_02
    sql_model_07_list['table_name_03'] = table_name_03
    sql_model_07_list['table_name_04'] = table_name_04
    sql_model_07_list['result_cols_sql'] = result_cols_sql
    sql_330 = sql_model_07.format(**sql_model_07_list)
    #下沉特殊处理sql放入sql_map
    sql_map = {}
    sql_map['sql_310']=sql_310
    sql_map['sql_320']=sql_320
    sql_map['sql_330']=sql_330
    return sql_map
    
#执行下沉函数定义02，获取下沉逻辑需要执行的sql_map
sql_map_02 = get_union_all_sql()
return_code = sql_task.execute_sqls(sql_map_02)

###################Added by renxiaowei7@20210819 结算特殊处理逻辑下沉 特殊逻辑处理 end  ########


sql_map_03={
# 计费明细拉链表以及计费明细的增量表的中间表插入数据
"sql_410": """
set hive.exec.reducers.max=5000;
set hive.exec.reducers.bytes.per.reducer=64000000;
set hive.exec.parallel=true;
set hive.exec.parallel.thread.number=16;
set mapred.max.split.size=64000000;
set mapred.min.split.size.per.node=64000000;
set mapred.min.split.size.per.rack=64000000;
set hive.auto.convert.join=true;
set hive.execution.engine=mr;
set mapreduce.map.memory.mb=12288;
set mapreduce.map.java.opts=-Xmx10g;
use dmf_bc;

ALTER TABLE dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d DROP IF EXISTS PARTITION (end_dt>='{TX_DATE}');
ALTER TABLE dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d DROP IF EXISTS PARTITION (dt='{TX_DATE}');
ALTER TABLE dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d DROP IF EXISTS PARTITION (dt<='{TX_PRE_90_DATE}');

-- Modified by machunliang@20210111 改成快照表，以支持重跑前几天和当日
-- FROM (SELECT * FROM dmf_tmp.dmftmp_bc_fi_fst_fee_detail_a_d) H
FROM (SELECT  *
             ,dmf_bc.getmd5(NVL(biz_id, 'null')
                           ,NVL(biz_type, 'null')
                           ,NVL(fee_id, 'null')
                           ,NVL(fee_type, 'null')
                           ,NVL(product_id, 'null')
                           ,NVL(product_name, 'null')
                           ,NVL(customer_id, 'null')
                           ,NVL(customer_name, 'null')
                           ,NVL(direction, 'null')
                           ,NVL(amount, 'null')
                           ,NVL(sett_amount, 'null')
                           ,NVL(need_invoice, 'null')
                           ,NVL(source_id, 'null')
                           ,NVL(rule_id, 'null')
                           ,NVL(status, 'null')
                           ,NVL(operator, 'null')
                           ,NVL(data_type, 'null')
                           ,UNIX_TIMESTAMP(trans_time,'yyyy-MM-dd HH:mm:ss')  --字段不一致
                           ,NVL(yn_flag, 'null')
                           ,NVL(remark, 'null')
                           ,NVL(create_user, 'null')  --字段不一致
                           ,NVL(update_user, 'null')  --字段不一致
                           ,UNIX_TIMESTAMP(create_dt,'yyyy-MM-dd HH:mm:ss')  --字段不一致
                           ,UNIX_TIMESTAMP(update_dt,'yyyy-MM-dd HH:mm:ss')  --字段不一致
                           ,NVL(customer_type, 'null')
                           ,NVL(card_id, 'null')
                           ,NVL(pay_channel_type, 'null')
                           ,NVL(pay_channel_id, 'null')
                           ,NVL(order_id, 'null')
                           ,NVL(ex_one, 'null')
                           ,NVL(ex_two, 'null')
                           ,NVL(ex_three, 'null')
                           ,NVL(org_id, 'null')
                           ,NVL(sett_id, 'null')
                           ,NVL(ex_four, 'null')
                           ,NVL(currency, 'null')
                           ,NVL(tax_rate, 'null')
                           ,NVL(contract_code, 'null')
                           ,NVL(project_code, 'null')
                           ,NVL(biz_association_id, 'null')
                           ,NVL(composite_id, 'null')
                           ,NVL(standby_field_one, 'null')
                           ,NVL(standby_field_two, 'null')
                           ,NVL(standby_field_three, 'null')
                           ,NVL(standby_field_four, 'null')
                           ,NVL(standby_field_five, 'null')
                           ,NVL(prov_flag, '')
                           ,NVL(fee_principal_company_customer_id, '')
                           ,NVL(fee_principal_company_merchant_id, '')
                           ,NVL(fee_principal_company_customer_name, '')
                           -- Added by machunliang@20210203 for 新增字段
                           ,NVL(bill_code, '')
                           ,NVL(ex_five, '')
                           ,NVL(ex_six, '')
                           ,NVL(ex_seven, '')
                           ,NVL(ex_eight, '')
                           ,NVL(ex_nine, '')
                           ,NVL(ex_ten, '')
                           ,NVL(ex_eleven, '')
                           ,NVL(ex_twelve, '')
                           ,NVL(ex_thirteen, '')
                           ,NVL(ex_fourteen, '')
                           ,NVL(ex_fifteen, '')
                           -- Added by machunliang@20210524 增加客商字段
                           ,NVL(fee_customer_name_merchant_id, '')
                           -- Added by machunliang@20210424 增加洗数的标识，用于强制冲销。id=1的是手工洗数的数据。非洗数的此处为空串，不影响md5值
                           ,''  -- clean_tag Modified by renxiaowei7@20210825 历史数据洗数标识全部使用空格，不会影响连续手工刷数
                           -- Added by renxiaowei7@20210625 增加核算业务线
                           ,if(accti_biz_line_cd like 'PROD_ID%',NVL(str_to_map(accti_biz_line_cd)['PROD_ID'], ''),accti_biz_line_cd)
                           --,NVL(fee_customer_name_merchant_id_all_src,'')
                           --,NVL(regexp_replace(fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*,*', ''),'')
                           ,if(NVL(regexp_replace(fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')=',','',NVL(regexp_replace(fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),''))
                           ,NVL(dept_id,'')
                           ) as change_code_new
             ,dmf_bc.getmd5(NVL(biz_type, 'null')
                           ,NVL(fee_id, 'null')
                           ,NVL(fee_type, 'null')
                           ,NVL(product_id, 'null')
                           ,NVL(product_name, 'null')
                           ,NVL(customer_id, 'null')
                           ,NVL(customer_name, 'null')
                           ,NVL(amount, 'null')
                           ,UNIX_TIMESTAMP(trans_time,'yyyy-MM-dd HH:mm:ss')
                           ,NVL(yn_flag, 'null')
                           ,NVL(org_id, 'null')
                           ,NVL(currency, 'null')
                           ,NVL(tax_rate, 'null')
                           ,NVL(contract_code, 'null')
                           ,NVL(project_code, 'null')
                           ,NVL(biz_association_id, 'null')
                           ,NVL(composite_id, 'null')
                           ,NVL(prov_flag, '')
                           ,NVL(fee_principal_company_customer_id, '')
                           ,NVL(fee_principal_company_merchant_id, '')
                           -- Added by machunliang@20210524 增加客商字段
                           ,NVL(fee_customer_name_merchant_id, '')
                           -- Added by machunliang@20210701 增加张华保险业务的扩展字段作为财务要素（存部门、客商等）， @20211018 增加683业务类型对扩展1的冲销
                           -- ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694'), NVL(ex_one, ''), '')
                           ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694','683'), NVL(ex_one, ''), '')
                           ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694'), NVL(ex_three, ''), '')
                           ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694'), NVL(ex_ten, ''), '')
						   --Added by renxiaowei7@20221227 增加肖宁京灵平台等业务的扩展字段5作为财务要素(存部门)
                           ,IF(biz_type in ('215','654'), NVL(ex_five, ''), '')
                           -- Added by machunliang@20210424 增加洗数的标识，用于强制冲销。id=0的是洗数的数据，非洗数的此处为空串，不影响md5值
                           ,''  -- clean_tag Modified by renxiaowei7@20210825 历史数据洗数标识全部使用空格，不会影响连续手工刷数
                           -- Added by renxiaowei7@20210625 增加核算业务线
                           ,if(accti_biz_line_cd like 'PROD_ID%',NVL(str_to_map(accti_biz_line_cd)['PROD_ID'], ''),accti_biz_line_cd)
                           --,NVL(fee_customer_name_merchant_id_all_src,'')
                           --,NVL(regexp_replace(fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*,*', ''),'')
                           ,if(NVL(regexp_replace(fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')=',','',NVL(regexp_replace(fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),''))
                           ,NVL(dept_id,'')
                           ,NVL(direction,'')  --Added by renxiaowei7@20220513 解决保险,费用类型:20131,计费明细数据应收应付方向变更的问题
                           ) as ele_md5_new
      FROM dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d
      WHERE DT = date_sub('{TX_DATE}', 1)
     ) H
FULL OUTER JOIN (
    SELECT * FROM (
        SELECT  *
               ,dmf_bc.getmd5(NVL(biz_id, 'null')
                             ,NVL(biz_type, 'null')
                             ,NVL(fee_id, 'null')
                             ,NVL(fee_type, 'null')
                             ,NVL(product_id, 'null')
                             ,NVL(product_name, 'null')
                             ,NVL(customer_id, 'null')
                             ,NVL(customer_name, 'null')
                             ,NVL(direction, 'null')
                             ,NVL(amount, 'null')
                             ,NVL(sett_amount, 'null')
                             ,NVL(need_invoice, 'null')
                             ,NVL(source_id, 'null')
                             ,NVL(rule_id, 'null')
                             ,NVL(status, 'null')
                             ,NVL(operator, 'null')
                             ,NVL(data_type, 'null')
                             ,UNIX_TIMESTAMP(data_time,'yyyy-MM-dd HH:mm:ss')
                             ,NVL(yn_flag, 'null')
                             ,NVL(remark, 'null')
                             ,NVL(creator, 'null')
                             ,NVL(editor, 'null')
                             ,UNIX_TIMESTAMP(created_time,'yyyy-MM-dd HH:mm:ss')
                             ,UNIX_TIMESTAMP(modified_time,'yyyy-MM-dd HH:mm:ss')
                             ,NVL(customer_type, 'null')
                             ,NVL(card_id, 'null')
                             ,NVL(pay_channel_type, 'null')
                             ,NVL(pay_channel_id, 'null')
                             ,NVL(order_id, 'null')
                             ,NVL(ex_one, 'null')
                             ,NVL(ex_two, 'null')
                             ,NVL(ex_three, 'null')
                             ,NVL(org_id, 'null')
                             ,NVL(sett_id, 'null')
                             ,NVL(ex_four, 'null')
                             ,NVL(currency, 'null')
                             ,NVL(tax_rate, 'null')
                             ,NVL(contract_code, 'null')
                             ,NVL(project_code, 'null')
                             ,NVL(biz_association_id, 'null')
                             ,NVL(composite_id, 'null')
                             ,NVL(standby_field_one, 'null')
                             ,NVL(standby_field_two, 'null')
                             ,NVL(standby_field_three, 'null')
                             ,NVL(standby_field_four, 'null')
                             ,NVL(standby_field_five, 'null')
                             ,NVL(prov_flag, '')
                             ,NVL(fee_principal_company_customer_id, '')
                             ,NVL(fee_principal_company_merchant_id, '')
                             ,NVL(fee_principal_company_customer_name, '')
                             -- Added by machunliang@20210203 for 新增字段
                             ,NVL(bill_code, '')
                             ,NVL(ex_five, '')
                             ,NVL(ex_six, '')
                             ,NVL(ex_seven, '')
                             ,NVL(ex_eight, '')
                             ,NVL(ex_nine, '')
                             ,NVL(ex_ten, '')
                             ,NVL(ex_eleven, '')
                             ,NVL(ex_twelve, '')
                             ,NVL(ex_thirteen, '')
                             ,NVL(ex_fourteen, '')
                             ,NVL(ex_fifteen, '')
                             -- Added by machunliang@20210524 增加客商字段
                             ,NVL(fee_customer_name_merchant_id, '')
                             -- Added by machunliang@20210424 增加洗数的标识，用于强制冲销。id=1的是手工洗数的数据。非洗数的此处为空串，不影响md5值
                             ,IF(clean_tag = '1', '{TX_DATE}', '')
                             -- Added by renxiaowei7@20210625 增加核算业务线
                             ,NVL(Accti_Biz_Line_Cd, '')
                             ,NVL(fee_customer_name_merchant_id_all_src,'')
                             ,NVL(dept_id,'')
                             ) as change_code
               ,dmf_bc.getmd5(NVL(biz_type, 'null')
                             ,NVL(fee_id, 'null')
                             ,NVL(fee_type, 'null')
                             ,NVL(product_id, 'null')
                             ,NVL(product_name, 'null')
                             ,NVL(customer_id, 'null')
                             ,NVL(customer_name, 'null')
                             ,NVL(amount, 'null')
                             ,UNIX_TIMESTAMP(data_time,'yyyy-MM-dd HH:mm:ss')
                             ,NVL(yn_flag, 'null')
                             ,NVL(org_id, 'null')
                             ,NVL(currency, 'null')
                             ,NVL(tax_rate, 'null')
                             ,NVL(contract_code, 'null')
                             ,NVL(project_code, 'null')
                             ,NVL(biz_association_id, 'null')
                             ,NVL(composite_id, 'null')
                             ,NVL(prov_flag, '')
                             ,NVL(fee_principal_company_customer_id, '')
                             ,NVL(fee_principal_company_merchant_id, '')
                             -- Added by machunliang@20210524 增加客商字段
                             ,NVL(fee_customer_name_merchant_id, '')
                             -- Added by machunliang@20210701 增加张华保险业务的扩展字段作为财务要素（存部门、客商等）
                             ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694'), NVL(ex_one, ''), '')
                             ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694'), NVL(ex_three, ''), '')
                             ,IF(biz_type in ('208','223','220','206','219','623','634','224','620','209','711','694'), NVL(ex_ten, ''), '')
						     --Added by renxiaowei7@20221227 增加肖宁京灵平台等业务的扩展字段5作为财务要素(存部门)
                             ,IF(biz_type in ('215','654'), NVL(ex_five, ''), '')
                             -- Added by machunliang@20210424 增加洗数的标识，用于强制冲销。id=0的是洗数的数据，非洗数的此处为空串，不影响md5值
                             ,IF(clean_tag = '1', '{TX_DATE}', '')
                             -- Added by renxiaowei7@20210625 增加核算业务线
                             ,NVL(Accti_Biz_Line_Cd, '')
                             ,NVL(fee_customer_name_merchant_id_all_src,'')
                             ,NVL(dept_id,'')
                             ,NVL(direction,'')  --Added by renxiaowei7@20220513 解决保险,费用类型:20131,计费明细数据应收应付方向变更的问题
                             ) as ele_md5
               ,ROW_NUMBER() OVER (DISTRIBUTE BY biz_type,fee_id SORT BY FROM_UNIXTIME(UNIX_TIMESTAMP(modified_time,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') DESC) rank
        FROM (select     clean_tag,id,biz_id,biz_type,fee_id,fee_type,product_id,product_name,customer_id,customer_name,direction,amount,sett_amount,need_invoice,source_id,rule_id,status,operator,data_type,data_time,yn_flag,prov_flag,remark,creator,editor,created_time,modified_time,customer_type,card_id,pay_channel_type,pay_channel_id,order_id,ex_one,ex_two,ex_three,ex_four,org_id,unikey,sett_id,currency,contract_code
                        ,biz_association_id,composite_id,standby_field_one,standby_field_two,standby_field_three,standby_field_four,standby_field_five,bill_code,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_eleven,ex_twelve,ex_thirteen,ex_fourteen,ex_fifteen,fee_principal_company_customer_id,fee_principal_company_merchant_id,fee_principal_company_customer_name,principal_merchant_id_src_tag,obj_customer_source
                        --,mercht_id_all 未使用，和fee_customer_name_merchant_id_all_src重复
                        --,mercht_typ_all 未使用，和fee_customer_name_merchant_typ_all_src重复
                        --,mercht_id_all_map 未使用，和fee_customer_name_merchant_id_all_src重复
                        --,mercht_typ_all_map 未使用，和fee_customer_name_merchant_typ_all_src重复
                        ,fee_customer_name_merchant_id,fee_customer_name_merchant_id_type,fee_customer_name_merchant_id_src_tag
                        ,concat(
                                --nvl(concat('src_tag:',str_to_map(fee_customer_name_merchant_id_all_src)['src_tag']),'')
                                nvl(concat(',ID-0:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-0']),'')
                               ,nvl(concat(',ID-1:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-1']),'')
                               ,nvl(concat(',ID-2:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-2']),'')
                               ,nvl(concat(',ID-3:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-3']),'')
                               ,nvl(concat(',ID-4:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-4']),'')
                               ,nvl(concat(',ID-5:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-5']),'')
                               ,nvl(concat(',ID-6:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-6']),'')
                               ,coalesce(concat(',ID-7:',split(str_to_map(conn_spe_cols)['dmf_cust_ID7'],'&')[0]),concat(',ID-7:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-7']),'')
                               ,coalesce(concat(',ID-8:',split(str_to_map(conn_spe_cols)['dmf_cust_ID8'],'&')[0]),concat(',ID-8:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-8']),'')
                               ,nvl(concat(',ID-9:',str_to_map(fee_customer_name_merchant_id_all_src)['ID-9']),'')
                             ) as fee_customer_name_merchant_id_all_src   --特殊逻辑下沉字段-计费客商all
                        ,concat(
                                nvl(concat(',ID-0:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-0']),'')
                               ,nvl(concat(',ID-1:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-1']),'')
                               ,nvl(concat(',ID-2:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-2']),'')
                               ,nvl(concat(',ID-3:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-3']),'')
                               ,nvl(concat(',ID-4:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-4']),'')
                               ,nvl(concat(',ID-5:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-5']),'')
                               ,nvl(concat(',ID-6:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-6']),'')
                               ,coalesce(concat(',ID-7:',split(str_to_map(conn_spe_cols)['dmf_cust_ID7'],'&')[1]),concat(',ID-7:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-7']),'')
                               ,coalesce(concat(',ID-8:',split(str_to_map(conn_spe_cols)['dmf_cust_ID8'],'&')[1]),concat(',ID-8:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-8']),'')
                               ,nvl(concat(',ID-9:',str_to_map(fee_customer_name_merchant_typ_all_src)['ID-9']),'')
                             ) as fee_customer_name_merchant_typ_all_src  --特殊逻辑下沉字段-计费客商类型all
                        ,if(conn_spe_cols like '%dmf_project%',str_to_map(conn_spe_cols)['dmf_project'],project_code) as project_code  --特殊逻辑下沉字段-项目段
                        ,if(conn_spe_cols like '%dmf_product%',str_to_map(conn_spe_cols)['dmf_product'],'') as Accti_Biz_Line_Cd       --特殊逻辑下沉字段-核算业务线产品
                        ,if(conn_spe_cols like '%dmf_dept%',str_to_map(conn_spe_cols)['dmf_dept'],dept_id) as dept_id                  --特殊逻辑下沉字段-核算部门(成本中心) Added by renxiaowei7@20210817
                        ,if(conn_spe_cols like '%dmf_tax%',str_to_map(conn_spe_cols)['dmf_tax'],tax_rate) as tax_rate                  --特殊逻辑下沉字段-税率 Added by renxiaowei7@20220106
                        ,spec_type_cd  --Added by renxiaowei7@20210913 下沉类型编码
                        ,conn_spe_cols
                        --Added by renxiaowei7@20211103 map结构存储特殊值
                        ,spe_val_map
              from dmf_tmp.dmftmp_sett_spec_manage_tmp_fee_04
              WHERE unikey IS NOT null
             ) a
    ) x WHERE rank = 1 AND amount<>0
) C
-- ON  C.unikey=H.unikey
ON C.biz_type=H.biz_type  AND  C.fee_id=H.fee_id
INSERT OVERWRITE TABLE dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d PARTITION (end_dt='{TX_DATE}')
SELECT   H.start_dt
        ,H.change_code
        ,H.ele_md5
        ,H.unikey
        ,'a10' AS data_source_em
        ,H.biz_id
        ,H.biz_type
        ,H.fee_id
        ,H.fee_type
        ,H.product_id
        ,H.product_name
        ,H.customer_id
        ,H.customer_name
        ,H.direction
        ,H.amount
        ,H.sett_amount
        ,H.need_invoice
        ,H.source_id
        ,H.rule_id
        ,H.status
        ,H.operator
        ,H.data_type
        ,H.trans_time
        ,H.yn_flag
        ,H.remark
        ,H.create_user
        ,H.update_user
        ,H.create_dt
        ,H.update_dt
        ,H.customer_type
        ,H.card_id
        ,H.pay_channel_type
        ,H.pay_channel_id
        ,H.order_id
        ,H.ex_one
        ,H.ex_two
        ,H.ex_three
        ,H.org_id
        ,H.sett_id
        ,H.ex_four
        -- Added by machunliang@20201001 增加字段
        ,H.currency
        ,H.tax_rate
        ,H.contract_code
        ,H.project_code
        ,H.biz_association_id
        ,H.composite_id
        ,H.standby_field_one
        ,H.standby_field_two
        ,H.standby_field_three
        ,H.standby_field_four
        ,H.standby_field_five
        -- Added by machunliang@20201021 闭链时，对历史为空数据默认取yn_flag，因历史上数据是需要入账的
        ,NVL(H.prov_flag, H.yn_flag) as prov_flag
        ,H.fee_principal_company_customer_id       --计费明细公司主体编码对应的主体主数据ID
        ,H.fee_principal_company_merchant_id                     --计费明细公司主体编码对应的客商主数据ID
        ,H.fee_principal_company_customer_name         --计费明细公司主体编码对应的公司名称
        -- Added by machunliang@20210203 for 新增字段
        ,H.bill_code
        ,H.ex_five
        ,H.ex_six
        ,H.ex_seven
        ,H.ex_eight
        ,H.ex_nine
        ,H.ex_ten
        ,H.ex_eleven
        ,H.ex_twelve
        ,H.ex_thirteen
        ,H.ex_fourteen
        ,H.ex_fifteen
        -- Added by machunliang@20210308 增加核算业务线
        ,H.Accti_Biz_Line_Cd
        -- Added by machunliang@20210524 增加客商字段
        ,H.fee_customer_name_merchant_id
        ,H.fee_customer_name_merchant_id_type
        ,H.fee_customer_name_merchant_id_src_tag
        --,H.fee_customer_name_merchant_id_all_src
        ,if(NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')=',','',NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')) as fee_customer_name_merchant_id_all_src
        ,H.fee_customer_name_merchant_typ_all_src
        --结算特殊处理逻辑下沉
        ,H.dept_id       --部门         Added by renxiaowei7@20210819
        ,H.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
        --Added by renxiaowei7@20211103 
        ,H.spe_val_map   --map结构存储特殊值
WHERE H.unikey IS NOT NULL AND C.unikey IS NOT NULL AND H.change_code_new <> C.change_code
INSERT OVERWRITE TABLE dmf_bc.dmfbc_bc_fi_fst_fee_detail_h_d PARTITION (end_dt='4712-12-31')
SELECT   CASE WHEN C.unikey IS NULL
             OR (H.unikey IS NOT NULL AND H.change_code_new=C.change_code) THEN H.start_dt
            ELSE '{TX_DATE}' END AS start_dt
        ,if(C.unikey is null,H.change_code_new,C.change_code) as change_code
        ,if(C.unikey is null,H.ele_md5_new,C.ele_md5) as ele_md5
        ,if(C.unikey is null,H.unikey,C.unikey) as unikey
        ,'a10' AS data_source_em
        ,if(C.unikey is null,H.biz_id,C.biz_id) as biz_id
        ,if(C.unikey is null,H.biz_type,C.biz_type) as biz_type
        ,if(C.unikey is null,H.fee_id,C.fee_id) as fee_id
        ,if(C.unikey is null,H.fee_type,C.fee_type) as fee_type
        ,if(C.unikey is null,H.product_id,C.product_id) as product_id
        ,if(C.unikey is null,H.product_name,C.product_name) as product_name
        ,if(C.unikey is null,H.customer_id,C.customer_id) as customer_id
        ,if(C.unikey is null,H.customer_name,C.customer_name) as customer_name
        ,if(C.unikey is null,H.direction,C.direction) as direction
        ,if(C.unikey is null,H.amount,C.amount) as amount
        ,if(C.unikey is null,H.sett_amount,C.sett_amount) as sett_amount
        ,if(C.unikey is null,H.need_invoice,C.need_invoice) as need_invoice
        ,if(C.unikey is null,H.source_id,C.source_id) as source_id
        ,if(C.unikey is null,H.rule_id,C.rule_id) as rule_id
        ,if(C.unikey is null,H.status,C.status) as status
        ,if(C.unikey is null,H.operator,C.operator) as operator
        ,if(C.unikey is null,H.data_type,C.data_type) as data_type
        ,if(C.unikey is null,H.trans_time,C.data_time) as trans_time
        ,if(C.unikey is null,H.yn_flag,C.yn_flag) as yn_flag
        ,if(C.unikey is null,H.remark,C.remark) as remark
        ,if(C.unikey is null,H.create_user,C.creator) as create_user
        ,if(C.unikey is null,H.update_user,C.editor) as update_user
        ,if(C.unikey is null,H.create_dt,C.created_time) as create_dt
        ,if(C.unikey is null,H.update_dt,C.modified_time) as update_dt
        ,if(C.unikey is null,H.customer_type,C.customer_type) as customer_type
        ,if(C.unikey is null,H.card_id,C.card_id) as card_id
        ,if(C.unikey is null,H.pay_channel_type,C.pay_channel_type) as pay_channel_type
        ,if(C.unikey is null,H.pay_channel_id,C.pay_channel_id) as pay_channel_id
        ,if(C.unikey is null,H.order_id,C.order_id) as order_id
        ,if(C.unikey is null,H.ex_one,C.ex_one) as ex_one
        ,if(C.unikey is null,H.ex_two,C.ex_two) as ex_two
        ,if(C.unikey is null,H.ex_three,C.ex_three) as ex_three
        ,if(C.unikey is null,H.org_id,C.org_id) as org_id
        ,if(C.unikey is null,H.sett_id,C.sett_id) as sett_id
        ,if(C.unikey is null,H.ex_four,C.ex_four) as ex_four
        -- Added by machunliang@20201001 增加字段
        ,if(C.unikey is null,H.currency,C.currency) as currency
        ,if(C.unikey is null,H.tax_rate,C.tax_rate) as tax_rate
        ,if(C.unikey is null,H.contract_code,C.contract_code) as contract_code
        ,if(C.unikey is null,H.project_code,C.project_code) as project_code
        ,if(C.unikey is null,H.biz_association_id,C.biz_association_id) as biz_association_id
        ,if(C.unikey is null,H.composite_id,C.composite_id) as composite_id
        ,if(C.unikey is null,H.standby_field_one,C.standby_field_one) as standby_field_one
        ,if(C.unikey is null,H.standby_field_two,C.standby_field_two) as standby_field_two
        ,if(C.unikey is null,H.standby_field_three,C.standby_field_three) as standby_field_three
        ,if(C.unikey is null,H.standby_field_four,C.standby_field_four) as standby_field_four
        ,if(C.unikey is null,H.standby_field_five,C.standby_field_five) as standby_field_five
        -- Added by machunliang@20201021 对历史为空数据默认取yn_flag，因历史上数据是需要入账的
        ,if(C.unikey is null,NVL(H.prov_flag, H.yn_flag),C.prov_flag) as prov_flag
        ,if(C.unikey is null,H.fee_principal_company_customer_id,C.fee_principal_company_customer_id) as fee_principal_company_customer_id
        ,if(C.unikey is null,H.fee_principal_company_merchant_id,C.fee_principal_company_merchant_id) as fee_principal_company_merchant_id
        ,if(C.unikey is null,H.fee_principal_company_customer_name,C.fee_principal_company_customer_name) as fee_principal_company_customer_name
        -- Added by machunliang@20210203 for 新增字段
        ,if(C.unikey is null,H.bill_code,C.bill_code) as bill_code
        ,if(C.unikey is null,H.ex_five,C.ex_five) as ex_five
        ,if(C.unikey is null,H.ex_six,C.ex_six) as ex_six
        ,if(C.unikey is null,H.ex_seven,C.ex_seven) as ex_seven
        ,if(C.unikey is null,H.ex_eight,C.ex_eight) as ex_eight
        ,if(C.unikey is null,H.ex_nine,C.ex_nine) as ex_nine
        ,if(C.unikey is null,H.ex_ten,C.ex_ten) as ex_ten
        ,if(C.unikey is null,H.ex_eleven,C.ex_eleven) as ex_eleven
        ,if(C.unikey is null,H.ex_twelve,C.ex_twelve) as ex_twelve
        ,if(C.unikey is null,H.ex_thirteen,C.ex_thirteen) as ex_thirteen
        ,if(C.unikey is null,H.ex_fourteen,C.ex_fourteen) as ex_fourteen
        ,if(C.unikey is null,H.ex_fifteen,C.ex_fifteen) as ex_fifteen
        -- Added by machunliang@20210308 增加核算业务线
        ,if(C.unikey is null,H.Accti_Biz_Line_Cd,C.Accti_Biz_Line_Cd) as Accti_Biz_Line_Cd
        -- Added by machunliang@20210524 增加客商字段
        ,if(C.unikey is null,H.fee_customer_name_merchant_id,C.fee_customer_name_merchant_id) as fee_customer_name_merchant_id
        ,if(C.unikey is null,H.fee_customer_name_merchant_id_type,C.fee_customer_name_merchant_id_type) as fee_customer_name_merchant_id_type
        ,if(C.unikey is null,H.fee_customer_name_merchant_id_src_tag,C.fee_customer_name_merchant_id_src_tag) as fee_customer_name_merchant_id_src_tag
        --,if(C.unikey is null,H.fee_customer_name_merchant_id_all_src,C.fee_customer_name_merchant_id_all_src) as fee_customer_name_merchant_id_all_src
        ,if(C.unikey is null,if(NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')=',','',NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')),C.fee_customer_name_merchant_id_all_src) as fee_customer_name_merchant_id_all_src
        ,if(C.unikey is null,H.fee_customer_name_merchant_typ_all_src,C.fee_customer_name_merchant_typ_all_src) as fee_customer_name_merchant_typ_all_src
        --结算特殊处理逻辑下沉
        ,if(C.unikey is null,H.dept_id,C.dept_id) as dept_id                 --部门         Added by renxiaowei7@20210819 结算特殊处理逻辑下沉
        ,if(C.unikey is null,H.spec_type_cd,C.spec_type_cd) as spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
        --Added by renxiaowei7@20211103 
        ,if(C.unikey is null,H.spe_val_map,C.spe_val_map) as spe_val_map     --map结构存储特殊值
WHERE 1=1
INSERT OVERWRITE TABLE dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d PARTITION (dt='{TX_DATE}',change_flag='6')
SELECT
        H.ele_md5
        ,H.unikey
        ,'a10' AS data_source_em
        ,H.biz_id
        ,H.biz_type
        ,H.fee_id
        ,H.fee_type
        ,H.product_id
        ,H.product_name
        ,H.customer_id
        ,H.customer_name
        ,H.direction
        ,-H.amount
        ,H.sett_amount
        ,H.need_invoice
        ,H.source_id
        ,H.rule_id
        ,H.status
        ,H.operator
        ,H.data_type
        ,H.trans_time
        ,H.yn_flag
        ,H.remark
        ,H.create_user
        ,H.update_user
        ,H.create_dt
        ,H.update_dt
        ,H.customer_type
        ,H.card_id
        ,H.pay_channel_type
        ,H.pay_channel_id
        ,H.order_id
        ,H.ex_one
        ,H.ex_two
        ,H.ex_three
        ,H.org_id
        ,H.sett_id
        ,H.ex_four
        -- Added by machunliang@20201001 增加字段
        ,H.currency
        ,H.tax_rate
        ,H.contract_code
        --,if(C.clean_tag='3' and conn_spe_cols like '%dmf_project%',C.project_code,H.project_code) as project_code
        ,H.project_code
        ,H.biz_association_id
        ,H.composite_id
        ,H.standby_field_one
        ,H.standby_field_two
        ,H.standby_field_three
        ,H.standby_field_four
        ,H.standby_field_five
        -- Added by machunliang@20201021 冲销时，对历史为空数据默认取yn_flag，因历史上数据是需要入账的
        ,NVL(H.prov_flag, H.yn_flag) as prov_flag
        ,H.fee_principal_company_customer_id       --计费明细公司主体编码对应的主体主数据ID
        -- ,H.fee_principal_company_merchant_id                     --计费明细公司主体编码对应的客商主数据ID
        -- ,NVL(H.fee_principal_company_merchant_id,dmf_bc.dmdictdesc('fst_jrxz_org_id_mapping', H.org_id)) AS fee_principal_company_merchant_id  --计费明细公司主体编码对应的客商主数据ID
        --Modified by renxiaowei7@20210727 冲销数据的兜底只有20210301之前创建或变更的数据使用，20210701之后的数据已经添加了主体字段，不需要兜底了，也不能兜底
        ,case when H.start_dt>='2021-03-01' then H.fee_principal_company_merchant_id
              else NVL(H.fee_principal_company_merchant_id,dmf_bc.dmdictdesc('fst_jrxz_org_id_mapping', H.org_id))
         end as fee_principal_company_merchant_id  --计费明细公司主体编码对应的客商主数据ID
        ,H.fee_principal_company_customer_name         
        -- Added by machunliang@20210203 for 增加被冲销数据的日期
        ,H.start_dt as last_dt
        -- Added by machunliang@20210203 for 新增字段
        ,H.bill_code
        ,H.ex_five
        ,H.ex_six
        ,H.ex_seven
        ,H.ex_eight
        ,H.ex_nine
        ,H.ex_ten
        ,H.ex_eleven
        ,H.ex_twelve
        ,H.ex_thirteen
        ,H.ex_fourteen
        ,H.ex_fifteen
        -- Added by machunliang@20210308 增加核算业务线
        --,if(C.clean_tag='3' and conn_spe_cols like '%dmf_product%',C.Accti_Biz_Line_Cd,H.Accti_Biz_Line_Cd) as Accti_Biz_Line_Cd
        ,H.Accti_Biz_Line_Cd
        -- Added by machunliang@20210524 增加客商字段
        ,H.fee_customer_name_merchant_id
        ,H.fee_customer_name_merchant_id_type
        ,H.fee_customer_name_merchant_id_src_tag
        --,if(C.clean_tag='3' and (conn_spe_cols like '%dmf_cust_ID7%' or conn_spe_cols like '%dmf_cust_ID8%'),C.fee_customer_name_merchant_id_all_src,H.fee_customer_name_merchant_id_all_src) as fee_customer_name_merchant_id_all_src
        --,if(C.clean_tag='3' and (conn_spe_cols like '%dmf_cust_ID7%' or conn_spe_cols like '%dmf_cust_ID8%'),C.fee_customer_name_merchant_id_all_src,if(NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')=',','',NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),''))) as fee_customer_name_merchant_id_all_src
        ,if(NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')=',','',NVL(regexp_replace(H.fee_customer_name_merchant_id_all_src, 'src_tag:[^,]*', ''),'')) as fee_customer_name_merchant_id_all_src
        --,if(C.clean_tag='3' and (conn_spe_cols like '%dmf_cust_ID7%' or conn_spe_cols like '%dmf_cust_ID8%'),C.fee_customer_name_merchant_typ_all_src,H.fee_customer_name_merchant_typ_all_src) as fee_customer_name_merchant_typ_all_src        
        ,H.fee_customer_name_merchant_typ_all_src
        --结算特殊处理逻辑下沉
        --,if(C.clean_tag='3' and conn_spe_cols like '%dmf_dept%',C.dept_id,H.dept_id) as dept_id  --部门         Added by renxiaowei7@20210819
        ,H.dept_id
        --,if(C.clean_tag='3',C.spec_type_cd,H.spec_type_cd) as spec_type_cd                       --下沉类型编码 Added by renxiaowei7@20210913
        ,H.spec_type_cd
WHERE H.unikey IS NOT NULL AND C.unikey IS NOT NULL AND H.ele_md5_new <> C.ele_md5
  --Modified by renxiaowei7@20210913
  --5|非自动刷数-下沉-刷历史数据
  --不进增量表
  AND C.clean_tag not in ('5')
INSERT OVERWRITE TABLE dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d PARTITION (dt='{TX_DATE}',change_flag='5')
SELECT
        C.ele_md5
        ,C.unikey
        ,'a10' AS data_source_em
        ,C.biz_id
        ,C.biz_type
        ,C.fee_id
        ,C.fee_type
        ,C.product_id
        ,C.product_name
        ,C.customer_id
        ,C.customer_name
        ,C.direction
        ,C.amount
        ,C.sett_amount
        ,C.need_invoice
        ,C.source_id
        ,C.rule_id
        ,C.status
        ,C.operator
        ,C.data_type
        ,C.data_time AS trans_time
        ,C.yn_flag
        ,C.remark
        ,C.creator AS create_user
        ,C.editor AS update_user
        ,C.created_time AS create_dt
        ,C.modified_time AS update_dt
        ,C.customer_type
        ,C.card_id
        ,C.pay_channel_type
        ,C.pay_channel_id
        ,C.order_id
        ,C.ex_one
        ,C.ex_two
        ,C.ex_three
        ,C.org_id
        ,C.sett_id
        ,C.ex_four
        -- Added by machunliang@20201001 增加字段
        ,C.currency
        ,C.tax_rate
        ,C.contract_code
        ,C.project_code
        ,C.biz_association_id
        ,C.composite_id
        ,C.standby_field_one
        ,C.standby_field_two
        ,C.standby_field_three
        ,C.standby_field_four
        ,C.standby_field_five
        -- Added by machunliang@20201021
        ,C.prov_flag
        ,C.fee_principal_company_customer_id       --计费明细公司主体编码对应的主体主数据ID
        ,C.fee_principal_company_merchant_id       --计费明细公司主体编码对应的客商主数据ID
        ,C.fee_principal_company_customer_name       
        -- Added by machunliang@20210203 for 增加被冲销数据的日期
        ,H.start_dt as last_dt
        -- Added by machunliang@20210203 for 新增字段
        ,C.bill_code
        ,C.ex_five
        ,C.ex_six
        ,C.ex_seven
        ,C.ex_eight
        ,C.ex_nine
        ,C.ex_ten
        ,C.ex_eleven
        ,C.ex_twelve
        ,C.ex_thirteen
        ,C.ex_fourteen
        ,C.ex_fifteen
        -- Added by machunliang@20210308 增加核算业务线
        ,C.Accti_Biz_Line_Cd
        -- Added by machunliang@20210524 增加客商字段
        ,C.fee_customer_name_merchant_id
        ,C.fee_customer_name_merchant_id_type
        ,C.fee_customer_name_merchant_id_src_tag
        ,C.fee_customer_name_merchant_id_all_src
        ,C.fee_customer_name_merchant_typ_all_src
        --结算特殊处理逻辑下沉
        ,C.dept_id       --部门         Added by renxiaowei7@20210819
        ,C.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
WHERE H.unikey IS NOT NULL AND C.unikey IS NOT NULL AND H.ele_md5_new <> C.ele_md5
  --Modified by renxiaowei7@20210913
  --5|非自动刷数-下沉-刷历史数据
  --不进增量表
  AND C.clean_tag not in ('5')
INSERT OVERWRITE TABLE dmf_bc.dmfbc_bc_fi_tmp_cwmart_fst_fee_detail_i_d PARTITION (dt='{TX_DATE}',change_flag='1')
SELECT
        C.ele_md5
        ,C.unikey
        ,'a10' AS data_source_em
        ,C.biz_id
        ,C.biz_type
        ,C.fee_id
        ,C.fee_type
        ,C.product_id
        ,C.product_name
        ,C.customer_id
        ,C.customer_name
        ,C.direction
        ,C.amount
        ,C.sett_amount
        ,C.need_invoice
        ,C.source_id
        ,C.rule_id
        ,C.status
        ,C.operator
        ,C.data_type
        ,C.data_time AS trans_time
        ,C.yn_flag
        ,C.remark
        ,C.creator AS create_user
        ,C.editor AS update_user
        ,C.created_time AS create_dt
        ,C.modified_time AS update_dt
        ,C.customer_type
        ,C.card_id
        ,C.pay_channel_type
        ,C.pay_channel_id
        ,C.order_id
        ,C.ex_one
        ,C.ex_two
        ,C.ex_three
        ,C.org_id
        ,C.sett_id
        ,C.ex_four
        -- Added by machunliang@20201001 增加字段
        ,C.currency
        ,C.tax_rate
        ,C.contract_code
        ,C.project_code
        ,C.biz_association_id
        ,C.composite_id
        ,C.standby_field_one
        ,C.standby_field_two
        ,C.standby_field_three
        ,C.standby_field_four
        ,C.standby_field_five
        -- Added by machunliang@20201021
        ,C.prov_flag
        ,C.fee_principal_company_customer_id       --计费明细公司主体编码对应的主体主数据ID
        ,C.fee_principal_company_merchant_id       --计费明细公司主体编码对应的客商主数据ID
        ,C.fee_principal_company_customer_name        
        -- Added by machunliang@20210203 for 增加被冲销数据的日期，新增的数据，此处为空
        ,'' as last_dt
        -- Added by machunliang@20210203 for 新增字段
        ,C.bill_code
        ,C.ex_five
        ,C.ex_six
        ,C.ex_seven
        ,C.ex_eight
        ,C.ex_nine
        ,C.ex_ten
        ,C.ex_eleven
        ,C.ex_twelve
        ,C.ex_thirteen
        ,C.ex_fourteen
        ,C.ex_fifteen
        -- Added by machunliang@20210308 增加核算业务线
        ,C.Accti_Biz_Line_Cd
        -- Added by machunliang@20210524 增加客商字段
        ,C.fee_customer_name_merchant_id
        ,C.fee_customer_name_merchant_id_type
        ,C.fee_customer_name_merchant_id_src_tag
        ,C.fee_customer_name_merchant_id_all_src
        ,C.fee_customer_name_merchant_typ_all_src
        --结算特殊处理逻辑下沉
        ,C.dept_id       --部门         Added by renxiaowei7@20210819
        ,C.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
WHERE H.unikey IS NULL AND C.unikey IS NOT NULL
  --Modified by renxiaowei7@20210913
  --5|非自动刷数-下沉-刷历史数据
  --不进增量表
  AND C.clean_tag not in ('5')
;
""",

# Modified by machunliang@20210111 换成快照表 dmf_bc.dmfbc_bc_fi_fst_fee_detail_s_d ，以支持重跑
# 输出最后全量临时表的脚本
}

return_code = sql_task.execute_sqls(sql_map_03)
exit(return_code)