# !/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *

####################################### 变更历史 ######################################
#
# Modified by machunliang@20210609 
#   补录表增加导入日期字段，不再清除。需要清除时手工清理
#
# Modified by machunliang@20210722  
#   为 账户取值标识 赋值默认值0
#

#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_STINGER
##sql_runner=RUNNER_HIVE
##sql_runner=RUNNER_SPARK_SQL


def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    return locals()


sql_map={

     # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！
    "sql_01": """
    use dmf_bc;
    alter table dmf_bc.dmfbc_bc_fi_fst_indx_make_cnfg_s_d drop if exists partition(dt = '{TX_DATE}'),partition(dt='4712-12-31');
    
       from (select *, 
                    -- Modified by machunliang@20210722 for 为账户取值标识赋默认值0
                    if (trim(NVL(recv_pay_acct_get_val_ind, '')) = '', '0', recv_pay_acct_get_val_ind) as recv_pay_acct_get_val_ind1, 
                    row_number() over(distribute by partition_key sort by src_tag desc) as rn 
               from (select '0' as src_tag, '0' as del_sign, model_id,indx_id,src_sys,src_tab,accti_biz_line_cd,accti_prod_cd,biz_typ,cap_typ
                            ,fst_biz_typ,fst_sett_scen,fst_fee_typ
                            ,corp_01_role_typ,corp_01_src,corp_02_role_typ,corp_02_src,corp_03_role_typ,corp_03_src,corp_04_role_typ,corp_04_src,corp_05_role_typ,corp_05_src
                            ,mercht_01_role_typ,mercht_01_id,mercht_01_src,mercht_02_role_typ,mercht_02_id,mercht_02_src,mercht_03_role_typ,mercht_03_id,mercht_03_src
                            ,mercht_04_role_typ,mercht_04_id,mercht_04_src,mercht_05_role_typ,mercht_05_id,mercht_05_src,mercht_06_role_typ,mercht_06_id,mercht_06_src
                            ,mercht_07_role_typ,mercht_07_id,mercht_07_src,mercht_08_role_typ,mercht_08_id,mercht_08_src,mercht_09_role_typ,mercht_09_id,mercht_09_src
                            ,mercht_10_role_typ,mercht_10_id,mercht_10_src
                            ,recv_pay_acct_get_val_ind,linkg_acct_get_val_ind
                            ,sett_stat, fee_stat
							,imp_dt,imp_erp,sett_fee_dir_type,amt_dir_type
                            ,dmf_bc.getmd5(model_id,indx_id,src_sys,src_tab,biz_typ,cap_typ,fst_biz_typ,fst_sett_scen,fst_fee_typ) as partition_key
                       from dmf_bc.dmfbc_bc_fi_fst_indx_make_cnfg_s_d
                      where dt = '{TX_PRE_1_DATE}'
                      union all
                     select '1' as src_tag, del_sign, model_id,indx_id,src_sys,src_tab,accti_biz_line_cd,accti_prod_cd,biz_typ,cap_typ
                            ,fst_biz_typ,fst_sett_scen,fst_fee_typ
                            ,corp_01_role_typ,corp_01_src,corp_02_role_typ,corp_02_src,corp_03_role_typ,corp_03_src,corp_04_role_typ,corp_04_src,corp_05_role_typ,corp_05_src
                            ,mercht_01_role_typ,mercht_01_id,mercht_01_src,mercht_02_role_typ,mercht_02_id,mercht_02_src,mercht_03_role_typ,mercht_03_id,mercht_03_src
                            ,mercht_04_role_typ,mercht_04_id,mercht_04_src,mercht_05_role_typ,mercht_05_id,mercht_05_src,mercht_06_role_typ,mercht_06_id,mercht_06_src
                            ,mercht_07_role_typ,mercht_07_id,mercht_07_src,mercht_08_role_typ,mercht_08_id,mercht_08_src,mercht_09_role_typ,mercht_09_id,mercht_09_src
                            ,mercht_10_role_typ,mercht_10_id,mercht_10_src
                            ,recv_pay_acct_get_val_ind,linkg_acct_get_val_ind
                            ,sett_stat, fee_stat
							,imp_dt,imp_erp,sett_fee_dir_type,amt_dir_type
                            ,dmf_bc.getmd5(model_id,indx_id,src_sys,src_tab,biz_typ,cap_typ,fst_biz_typ,fst_sett_scen,fst_fee_typ) as partition_key
                       from dmf_add.dmfadd_add_fi_fst_indx_make_cnfg_a_d
                     -- Added by machunliang@20210609 补录表增加导入日期字段，不再清除
                      where imp_dt = '{TX_DATE}'
                    ) t1
            ) t 
    insert overwrite table dmf_bc.dmfbc_bc_fi_fst_indx_make_cnfg_s_d partition(dt = '{TX_DATE}')
     select model_id,indx_id,src_sys,src_tab,accti_biz_line_cd,accti_prod_cd,biz_typ,cap_typ
            ,fst_biz_typ,fst_sett_scen,fst_fee_typ
            ,'' as corp_role_typ,'' as corp_get_val_src
            ,corp_01_role_typ,corp_01_src,corp_02_role_typ,corp_02_src,corp_03_role_typ,corp_03_src,corp_04_role_typ,corp_04_src,corp_05_role_typ,corp_05_src
            ,mercht_01_role_typ,mercht_01_id,mercht_01_src,mercht_02_role_typ,mercht_02_id,mercht_02_src,mercht_03_role_typ,mercht_03_id,mercht_03_src
            ,mercht_04_role_typ,mercht_04_id,mercht_04_src,mercht_05_role_typ,mercht_05_id,mercht_05_src,mercht_06_role_typ,mercht_06_id,mercht_06_src
            ,mercht_07_role_typ,mercht_07_id,mercht_07_src,mercht_08_role_typ,mercht_08_id,mercht_08_src,mercht_09_role_typ,mercht_09_id,mercht_09_src
            ,mercht_10_role_typ,mercht_10_id,mercht_10_src
            ,recv_pay_acct_get_val_ind1 as recv_pay_acct_get_val_ind,linkg_acct_get_val_ind
            ,sett_stat, fee_stat
			,imp_dt,imp_erp,sett_fee_dir_type,amt_dir_type
      where rn = 1 and del_sign <> '1'
    insert overwrite table dmf_bc.dmfbc_bc_fi_fst_indx_make_cnfg_s_d partition(dt = '4712-12-31')
     select model_id,indx_id,src_sys,src_tab,accti_biz_line_cd,accti_prod_cd,biz_typ,cap_typ
            ,fst_biz_typ,fst_sett_scen,fst_fee_typ
            ,'' as corp_role_typ,'' as corp_get_val_src
            ,corp_01_role_typ,corp_01_src,corp_02_role_typ,corp_02_src,corp_03_role_typ,corp_03_src,corp_04_role_typ,corp_04_src,corp_05_role_typ,corp_05_src
            ,mercht_01_role_typ,mercht_01_id,mercht_01_src,mercht_02_role_typ,mercht_02_id,mercht_02_src,mercht_03_role_typ,mercht_03_id,mercht_03_src
            ,mercht_04_role_typ,mercht_04_id,mercht_04_src,mercht_05_role_typ,mercht_05_id,mercht_05_src,mercht_06_role_typ,mercht_06_id,mercht_06_src
            ,mercht_07_role_typ,mercht_07_id,mercht_07_src,mercht_08_role_typ,mercht_08_id,mercht_08_src,mercht_09_role_typ,mercht_09_id,mercht_09_src
            ,mercht_10_role_typ,mercht_10_id,mercht_10_src
            ,recv_pay_acct_get_val_ind1 as recv_pay_acct_get_val_ind,linkg_acct_get_val_ind
            ,sett_stat, fee_stat
			,imp_dt,imp_erp,sett_fee_dir_type,amt_dir_type
      where rn = 1 and del_sign <> '1'
    ;
    
    """,
# Modified by machunliang@20210609 补录表增加导入日期字段，不再清除
#    "sql_02": """
#    truncate table dmf_add.dmfadd_add_fi_fst_indx_make_cnfg_a_d;
#    """,
}


# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)