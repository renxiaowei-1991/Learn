# !/usr/bin/env python
# -*- coding: utf-8 -*-
from template.base_sql_task import *
#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_HIVE

#获取月初日期
def get_month_start(in_date):
    in_year,in_month,in_day = str(in_date).split('-')
    
    out_year = in_year
    out_month = in_month
    out_day = "01"
    
    list_date = [out_year,out_month,out_day]
    #split_str = "-"
    out_date = "-".join(list_date)

    return out_date
    
#当前日期加减n月
def get_add_months(in_date,num):
    in_year,in_month,in_day = str(in_date).split('-')
    
    #print(in_year,in_month,in_day)
    
    if (int(in_month)+num) % 12 == 0 :
        out_year = str(int(in_year) + (int(in_month)+num) / 12 - 1)
        out_month = str("12")
    else :
        out_year = str(int(in_year) + (int(in_month)+num) / 12)
        out_month = str((int(in_month)+num) % 12).zfill(2) #月份补齐两位
        
    out_day = in_day
    
    #print(out_year,out_month,out_day)

    list_date = [out_year,out_month,out_day]
    #split_str = "-"
    out_date = "-".join(list_date)
    
    return out_date

get_run_date = SqlTask()
#获取脚本参数
run_date = get_run_date._tx_date
print("run_date:" + run_date)

#日期判断:获取分区删除开始日期
if int(run_date.split('-')[2])<10 :
    start_date = get_month_start(get_add_months(run_date,-1))
else :
    start_date = get_month_start(run_date)

def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
	
	#按月重跑开始日期，用于删除分区
    START_DATE = start_date
	
    return locals()
sql_map={
    # ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！
      
	#结算交易明细-配置表
	
	  
"sql_01": """
set hive.stats.column.autogather=false;
use dmf_bc;
    
alter table dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d drop partition(dt = '4712-12-31');
alter table dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d add  partition(dt = '4712-12-31');
alter table dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d drop partition(dt = '{TX_DATE}' );
alter table dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d add  partition(dt = '{TX_DATE}' );
;
""",

#获取交易明细表中所有来源系统的数据
#  1、获取业务管理配置
#  2、获取交易明细来源系统&业务线数据
#    如果有新增的业务大类，需要添加对应的交易明细表到下面的逻辑中
#  3、获取有数据&有配置的来源系统&业务线

"sql_02": """
set hive.stats.column.autogather=false;
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_01;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_01
as
select     a1.node_id as small_biz_type
          ,a1.node_name as small_biz_type_name
		  ,a1.parent_node_id as big_biz_type
		  ,a2.node_name as big_biz_type_name
		  ,a1.data_source_em
from (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online,data_source as data_source_em
      from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
      where  dt='{TX_DATE}'
        and  status='1'  --业务线生效状态 0失效/1有效
        and (expire_date is null or  expire_date = '' or expire_date > '{TX_DATE}')
        and  type='1'
        and (data_source is not null or data_source != '')
     ) a1
left join (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online
           from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
           where  dt='{TX_DATE}'
             and  status='1'  --业务线生效状态 0失效/1有效
             and (expire_date is null or  expire_date = '' or expire_date > '{TX_DATE}')
             and  type='0'
          ) a2
       on  a1.parent_node_id = a2.node_id
;

drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_02;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_02
as
select big_biz_type,small_biz_type,data_source_em,count(*) as num from (
    select '000001' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_sec_fi_transaction_detail_i_d           union all
    select '000003' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_ncjr_fi_hs_transaction_detail_i_d       union all
    select '000004' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_000004_i_d  union all
    select '000005' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_crowdfu_fi_transaction_detail_i_d       union all
    select '000006' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_fin_fi_hs_transaction_detail_i_d        union all
    select '000007' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_ftc_fi_hs_transaction_detail_i_d        union all
    select '000008' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_sec_fi_transaction_detail_i_d           union all
    select '000009' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_insu_fi_hs_transaction_detail_i_d       union all
    select '000010' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_am_fi_hs_transaction_detail_i_d         union all
    select '000011' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_pay_fi_hs_transaction_detail_i_d        union all
    select '000012' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_000012_i_d  union all
    select '000014' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_ct_fi_hs_transaction_detail_i_d         union all
    select '000015' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_uc_fi_transaction_detail_i_d            union all
    select '000016' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_alpha_fi_hs_transaction_detail_i_d      union all
    select '000017' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_ctr_fi_transaction_detail_i_d           union all
    select '000019' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_mb_fi_hs_transaction_detail_i_d         union all
    select '000021' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_ad_fi_hs_transaction_detail_i_d         union all
    select '000022' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_cf_fi_hs_transaction_detail_000022_i_d  union all
    select '000023' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_cf_fi_hs_transaction_detail_000023_i_d  union all
    select '000024' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_sf_fi_hs_transaction_detail_000024_i_d  union all
    select '000030' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_fms_fi_transaction_detail_i_d           union all
    select '000031' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_user_fi_hs_transaction_detail_i_d       union all
    select '000032' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_fee_fi_transaction_detail_i_d           union all
    select '000035' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_pay_fi_hs_transaction_detail_000035_i_d union all
    select '000036' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_ftc_fi_hs_transaction_detail_000036_i_d union all
    select '000037' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_fin_fi_hs_transaction_detail_000037_i_d union all
    select '000039' as big_biz_type,biz_type as small_biz_type,data_source_em,dt from dmf_gj.dmfgj_gj_cf_fi_hs_transaction_detail_000039_i_d
) a where dt>='{START_DATE}' and dt<'{TX_DATE}'
group by big_biz_type,small_biz_type,data_source_em
;

drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_03;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_03
as
select a1.big_biz_type,a1.small_biz_type,a1.data_source_em
from  dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_02 a1
inner join (select b2.data_source_em,b1.small_biz_type,b1.big_biz_type
            from dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_01 b1
            lateral view explode(split(data_source_em,',')) b2 as data_source_em
            group by b2.data_source_em,b1.small_biz_type,b1.big_biz_type
           ) a2
         on  a1.data_source_em = a2.data_source_em
        and  a1.small_biz_type = a2.small_biz_type
        and  a1.big_biz_type   = a2.big_biz_type
;
""",

#表头数据
#renxiaowei7 20210510
#  表头数据将动态字段和group_flag去重，支持多人多模型随便修改配置表 
#  去掉原来按照model_id和impt_dt关联的逻辑，改为使用去重后的group_flag关联
#  数据导入的时候，如果当天没有其他人添加配置，可以覆盖，可以追加。但是如果当天有其他人添加配置，需要追加。
#  group_flag的值，需要先执行，得到结果后替换
#
# Modified by machunliang@20210603 
#   增加系数参数字段。半角逗号分隔，前面为乘的系数，后面为除的系数。系数为百分位量级
#

      
"sql_03": """
set hive.stats.column.autogather=false;
use dmf_tmp;
      
drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_01;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_01
as
select field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,group_flag
from  dmf_add.dmfadd_add_fi_fst_indx_detail_a_d
where impt_dt = '{TX_DATE}'  --配置数据导入日期
  and title_flag = '1'       --表头标志 0 表体/1 表头
group by field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,group_flag
;
""",

#表头数据关联表体数据

"sql_04": """
set hive.stats.column.autogather=false;
use dmf_tmp;
      
drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_02;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_02
as
select     t1.del_sign                                  --删除标志
          ,t1.model_id                                  --财务核算中间表模型编号
          ,t1.biz_typ                                   --指标业务类型
          ,t1.cap_typ                                   --指标资金类型
          ,if(nvl(t2.field_01,'')='','',concat(t2.field_01,':',t1.field_01)) as field_01  --扩展字段01
          ,if(nvl(t2.field_02,'')='','',concat(t2.field_02,':',t1.field_02)) as field_02  --扩展字段02
          ,if(nvl(t2.field_03,'')='','',concat(t2.field_03,':',t1.field_03)) as field_03  --扩展字段03
          ,if(nvl(t2.field_04,'')='','',concat(t2.field_04,':',t1.field_04)) as field_04  --扩展字段04
          ,if(nvl(t2.field_05,'')='','',concat(t2.field_05,':',t1.field_05)) as field_05  --扩展字段05
          ,if(nvl(t2.field_06,'')='','',concat(t2.field_06,':',t1.field_06)) as field_06  --扩展字段06
          ,if(nvl(t2.field_07,'')='','',concat(t2.field_07,':',t1.field_07)) as field_07  --扩展字段07
          ,if(nvl(t2.field_08,'')='','',concat(t2.field_08,':',t1.field_08)) as field_08  --扩展字段08
          ,t1.data_source_em                            --来源系统
          ,t1.trans_type                                --交易环节
          ,nvl(t1.corp_role_typ,'') as corp_role_typ            --主体角色类型
          ,nvl(t1.mercht_01_role_typ,'') as mercht_01_role_typ  --客体角色类型01
          ,nvl(t1.mercht_02_role_typ,'') as mercht_02_role_typ  --客体角色类型02
          ,t1.impt_dt                                   --导入日期
            -- Added by machunliang@20210603 增加系数参数字段
          ,t1.Coef_Para
		  ,t1.impt_erp   --导入人
from  dmf_add.dmfadd_add_fi_fst_indx_detail_a_d t1
inner join  dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_01 t2
        on  t1.group_flag = t2.group_flag
     where  t1.impt_dt = '{TX_DATE}'  --配置数据导入日期
	   and  t1.title_flag = '0'       --表头标志 0 表体/1 表头
;

""",

#renxiaowei7 20210510
#为了配置表的处理需要有一个分组值。这里限定 来源系统+交易环节 固定。如果交易环节有修改，可以先查询到原来的 来源系统+交易环节 的配置，同时补录两个数据，一条是原来配置的删除，一条是新的 来源系统+交易环节 的配置
#由于逻辑里面按照 来源系统+交易环节 固定，如果 1个 来源系统+交易环节，对应多条配置，修改的时候，查询到该 来源系统+交易环节 的所以配置，全部标记删除，然后再将这个 来源系统+交易环节 对应的配置全部新增
#默认：对于一个 来源系统+交易环节，如果配置有变更，例如先删除，后新增的，即使配置表中只删除多条配置中的一条，逻辑里面也会找到这个 来源系统+交易环节 对应的全部配置进行删除。所以变更的时候必须找到全部的配置进行新增，并且必须至少有一条删除记录，否则会有重复配置
#以防出现忘记删除，导致配置重复的情况，会添加一步去重的操作

"sql_05": """
set hive.stats.column.autogather=false;
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_03;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_03
as
select     data_source_em,trans_type,del_sign
          ,dmf_bc.getmd5(data_source_em,trans_type) as joinkey
from dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_02
group by   data_source_em,trans_type,del_sign
          ,dmf_bc.getmd5(data_source_em,trans_type)
;
""",

#Modified by renxiaowei7@20211102
#  对增量数据的新增数据来源系统做限定
#  1、如果上一天分区中存在该来源系统的数据，则可以进快照表
#  2、如果业务管理有配置该来源系统，并且按照来源系统&业务小类关联以后能获取到交易明细数据，则不能进快照表

"sql_06": """
set hive.stats.column.autogather=false;
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_04;
create table dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_04
as
--获取历史数据中非删除的数据
select b2.model_id,b2.biz_typ,b2.cap_typ,b2.field_01,b2.field_02,b2.field_03,b2.field_04,b2.field_05,b2.field_06,b2.field_07,b2.field_08,b2.data_source_em,b2.trans_type,b2.corp_role_typ,b2.mercht_01_role_typ,b2.mercht_02_role_typ,b2.impt_dt
-- Added by machunliang@20210603 增加系数参数字段
,b2.Coef_Para
from (select * from dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_03 where del_sign = '1') b1
full outer join (select dmf_bc.getmd5(data_source_em,trans_type) as joinkey,*
                 from dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d where dt = date_sub('{TX_DATE}',1)
				) b2
             on  b1.joinkey = b2.joinkey
	      where  b1.joinkey is null
union all
--获取新增数据中非删除的数据
select a1.model_id,a1.biz_typ,a1.cap_typ,a1.field_01,a1.field_02,a1.field_03,a1.field_04,a1.field_05,a1.field_06,a1.field_07,a1.field_08,a1.data_source_em,a1.trans_type,a1.corp_role_typ,a1.mercht_01_role_typ,a1.mercht_02_role_typ,a1.impt_dt,a1.Coef_Para
from dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_02 a1
left join (select data_source_em from dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_data_source_em_03 group by data_source_em) a2
       on  a1.data_source_em = a2.data_source_em
left join (select data_source_em from dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d where dt = date_sub('{TX_DATE}',1) group by data_source_em) a3
       on  a1.data_source_em = a3.data_source_em
    where  a1.del_sign = '0'
	  and (a3.data_source_em is not null or a2.data_source_em is null)
;
""",

#当天数据全表去重，以防历史数据和新增数据配置重复
#创建4712-12-31分区，方便使用

#Modified by renxiaowei7@20211015
#  修改去重逻辑，添加对 field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08 假值和顺序的处理

"sql_07": """
set hive.stats.column.autogather=false;
use dmf_tmp;

with with_a1 as (
    select *
    from (
        select  model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
               ,row_number() over(partition by model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ order by impt_dt desc) as rank
        from  dmf_tmp.dmftmp_tmp_dmfbc_bc_fi_fst_indx_detail_s_d_tmp_04
    ) a where rank = 1
),
with_a2 as (
    select  model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
           ,concat(if(nvl(split(field_01,':')[1],'')='','',split(field_01,':')[0])
                  ,if(nvl(split(field_02,':')[1],'')='','',concat(',',split(field_02,':')[0]))
                  ,if(nvl(split(field_03,':')[1],'')='','',concat(',',split(field_03,':')[0]))
                  ,if(nvl(split(field_04,':')[1],'')='','',concat(',',split(field_04,':')[0]))
                  ,if(nvl(split(field_05,':')[1],'')='','',concat(',',split(field_05,':')[0]))
                  ,if(nvl(split(field_06,':')[1],'')='','',concat(',',split(field_06,':')[0]))
                  ,if(nvl(split(field_07,':')[1],'')='','',concat(',',split(field_07,':')[0]))
                  ,if(nvl(split(field_08,':')[1],'')='','',concat(',',split(field_08,':')[0]))
                  ) as 	field_src
    from with_a1
),
with_a3 as (
    select a1.model_id,a1.biz_typ,a1.cap_typ,a1.field_01,a1.field_02,a1.field_03,a1.field_04,a1.field_05,a1.field_06,a1.field_07
          ,a1.field_08,a1.data_source_em,a1.trans_type,a1.corp_role_typ,a1.mercht_01_role_typ,a1.mercht_02_role_typ,a1.impt_dt
          ,a1.Coef_Para,a2.field_src
    from with_a2 a1
    lateral view explode(split(a1.field_src,',')) a2 as field_src
),
with_a4 as (
    select a1.model_id,a1.biz_typ,a1.cap_typ,a1.field_01,a1.field_02,a1.field_03,a1.field_04,a1.field_05,a1.field_06,a1.field_07
          ,a1.field_08,a1.data_source_em,a1.trans_type,a1.corp_role_typ,a1.mercht_01_role_typ,a1.mercht_02_role_typ,a1.impt_dt
          ,a1.Coef_Para,a1.field_src
          ,row_number() over(partition by a1.model_id,a1.biz_typ,a1.cap_typ,a1.field_01,a1.field_02,a1.field_03,a1.field_04
                                         ,a1.field_05,a1.field_06,a1.field_07,a1.field_08,a1.data_source_em,a1.trans_type
                                         ,a1.corp_role_typ,a1.mercht_01_role_typ,a1.mercht_02_role_typ,a1.impt_dt,a1.Coef_Para
                             order by a1.field_src) as rank
    from with_a3 a1
),
with_a5 as (
    select model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
        ,concat_ws(',',collect_list(field_src)) as field_src
    from with_a4
    group by model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
)
from (
 select  model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
     ,row_number() over(partition by model_id,biz_typ,cap_typ,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para,field_src order by impt_dt desc ) as rank
from  with_a5
) t
insert into table dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d partition(dt = '{TX_DATE}')
select model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
insert into table dmf_bc.dmfbc_bc_fi_fst_indx_detail_s_d partition(dt = '4712-12-31')
select model_id,biz_typ,cap_typ,field_01,field_02,field_03,field_04,field_05,field_06,field_07,field_08,data_source_em,trans_type,corp_role_typ,mercht_01_role_typ,mercht_02_role_typ,impt_dt,Coef_Para
;
""",

}
# 以下部分无需改动，除非作业有特殊要求
sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
return_code = sql_task.execute_sqls(sql_map)
exit(return_code)
