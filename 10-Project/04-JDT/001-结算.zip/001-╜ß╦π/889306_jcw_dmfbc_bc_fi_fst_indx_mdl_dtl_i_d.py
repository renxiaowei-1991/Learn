#!/usr/bin/env python
# -*- coding: utf-8 -*-

from template.base_sql_task import *
from datetime import datetime
import os

####################################### 变更历史 ######################################

# Modified by machunliang@20210602 增加yn_flag条件
#   结算明细增加3个条件（两个在表上，一个yn_flag）

# Modified by machunliang@20210609
#   加工biz_type=699的特殊业务逻辑
#       主体、客商、项目段、账户等

# Modified by machunliang@20210610
#   增加收付款方的账户性质字段，用于区别平台户和一般户
#       暂时没有在中间模型表中增加物理字段，只在条件字段中增加

# Modified by renxiaowei7@20210701
#   增加按月重跑的逻辑

# Modified by machunliang@20210715
#   增加扩展字段6和税率作为动态条件

# Modified by machunliang@20210719 
#   处理445业务的业务线
#   增加莎莎的规模指标
#   699业务的平台户（账户属性）增加为3个
#   增加客商类型条件、客商id条件

# Modified by machunliang@20210720 增加从原来单客商字段取值
#   肖宁提出的增加可取原来单客商字段值的要求，同时可解决消金不是每笔数据都在同一个ID上的需求。使用KEY: ORIG

# Modified by machunliang@20210728
#   处理455业务的项目段增加函数做兜底方案

# Modified by machunliang@20210816
#   处理206业务从扩展字段取SellChannelType，空值空串转为井号（#）

# Modified by renxiaowei7@20210820
#   修改核算业务线&产品生成方式，并且支持一条数据对应多个产品的逻辑

# Modified by machunliang@20210930
#   30240这个场景 在spv集成一部分 在赊销白条集成一部分，用下面条件参数区分

# Modified by machunliang@202101014
#   740业务支持根据产品名称加工核算产品

# Modified by renxiaowei7@20211026
#   下沉逻辑兜底，处理历史数据&未来期数据产品为空问题

# Modified by machunliang@20211124
#   增加 20121费项的客户账户id分类标识，莎莎的000009业务大类需求


####################################### 变更说明 ######################################

#
# 目前支持：RUNNER_SPARK_SQL和RUNNER_HIVE
#
sql_runner=RUNNER_STINGER
##sql_runner=RUNNER_HIVE
##sql_runner=RUNNER_SPARK_SQL

#获取月初日期
def get_month_start(in_date):
    in_year,in_month,in_day = str(in_date).split('-')
    
    out_year = in_year
    out_month = in_month
    out_day = "01"
    
    list_date = [out_year,out_month,out_day]
    #split_str = "-"
    out_date = "-".join(list_date)

    return out_date
    
#当前日期加减n月
def get_add_months(in_date,num):
    in_year,in_month,in_day = str(in_date).split('-')
    
    #print(in_year,in_month,in_day)
    
    if (int(in_month)+num) % 12 == 0 :
        out_year = str(int(in_year) + (int(in_month)+num) / 12 - 1)
        out_month = str("12")
    else :
        out_year = str(int(in_year) + (int(in_month)+num) / 12)
        out_month = str((int(in_month)+num) % 12).zfill(2) #月份补齐两位
        
    out_day = in_day
    
    #print(out_year,out_month,out_day)

    list_date = [out_year,out_month,out_day]
    #split_str = "-"
    out_date = "-".join(list_date)
    
    return out_date

get_run_date = SqlTask()
#获取脚本参数
run_date = get_run_date._tx_date
print("run_date:" + run_date)

#日期判断:获取分区删除开始日期
if int(run_date.split('-')[2])<10 :
    start_date = get_month_start(get_add_months(run_date,-1))
else :
    start_date = get_month_start(run_date)
    
print("start_date:" + start_date)

def get_customized_items():
    """
     if you need some special values in your sql, please define and calculate then here
     to refer it as {YOUR_VAR} in your sql
    """
    today = Time.today()
    TX_PRE_60_DATE = Time.date_sub(date=today, itv=60)
    TX_PRE_365_DATE = Time.date_sub(date=today, itv=365)
    
    #按月重跑开始日期，用于删除分区
    START_DATE = start_date
    return locals()
    
#执行sql的方法
def execute_hive_e_sql(sql):
    """
    使用hive -e来执行
    :param sql:
    :return:
    """
    exe_sql = 'hive -e "{}"'.format(sql)
    print("开始执行：" + exe_sql)
    result = os.popen(exe_sql).readlines()
    print("执行完成：" + exe_sql)
    #print(exe_sql)
    return result

#获取sql的结果
def get_sys_config_data(sql_str):
    """
    读取sql结果信息
    :param sys:
    :return:
    """
    #print("sql："+sql_str)
    result_line = execute_hive_e_sql(sql_str)
    
    config_data = [ele.split("\t") for ele in result_line]

    #print("---配置表的信息---")
    #print(config_data)
    return config_data    

sql_task = SqlTask()
sql_task.set_sql_runner(sql_runner)
sql_task.set_customized_items(get_customized_items())
    
sql_map_01={

# ATTENTION:   ！！！！ sql_01  因为系统按字典顺序进行排序，小于10 的一定要写成0加编号，否则会顺序混乱，数据出问题，切记，切记！！！！

"sql_01": """
set hive.execution.engine=mr;
set mapred.max.split.size=64000000;
use dmf_tmp;
drop table if exists dmf_tmp.tmp_dmfbc_bc_fi_fst_indx_mdl_dtl;
create table if not exists dmf_tmp.tmp_dmfbc_bc_fi_fst_indx_mdl_dtl as 
select dt, model_id, indx_id, src_sys, src_tab, src_tab1, change_flag, rev_data_orig_dt, data_unikey, accti_prod_cd, 
       tx_tm, tx_amt, biz_typ, cap_typ, currency, corp_ids, corp_mercht_ids, corp_nms, corp_role_typ, mercht_ids, mercht_nms, 
       mercht_typs, sett_customer_name_merchant_id_all_src, fee_customer_name_merchant_id_all_src, 
       concat('sett#',NVL(sett_principal_company_customer_id1, ''),'&fee#',NVL(fee_principal_company_customer_id1, '')) as principal_company_customer_ids, 
       concat('sett#',NVL(sett_principal_company_merchant_id1, ''),'&fee#',NVL(fee_principal_company_merchant_id1, '')) as principal_company_merchant_ids, 
       concat('sett#',NVL(sett_principal_company_customer_name1, ''),'&fee#',NVL(fee_principal_company_customer_name1, '')) as principal_company_customer_names, 
       merchant_id_all_src, merchant_typ_all_src, direction, sett_direction,  
       fee_dir_sign,sett_dir_sign, bal_dir_sign, acct_id, bank_acct_no, acct_brvt_cd, acct_mercht_id, acct_corp_nm, acct_dpst_charc, acct_nature, acct_nature_hs, sett_id, 
       fee_id, fst_biz_typ, fst_sett_scen, fst_fee_typ, pay_id, plat_id, biz_pay_id, biz_ids, tax_rate, contr_id, cret_tm, modi_tm, 
       prod_id, prod_nm, cust_id, cust_nm, sett_stat, fee_stat, origin_id, ordr_id, is_cntn_tax, cap_acct_chk_stat, biz_tm, pay_tm, 
       acct_chk_tm, fst_tm, stmt_no, source_id, yn_flag 
       -- ,biz_map.accti_biz_lvl3_cd as accti_biz_line_cd1
       -- ,biz_map.accti_biz_prod_cd as accti_prod_cd1
       ,proj_id1 as proj_id
       --Added by renxiaowei7@20211118
       ,ex_one
       ,ex_two
       ,ex_three
       ,ex_four
       ,ex_five
       ,ex_six
       --Added by renxiaowei7@20220106
       ,ex_seven
       ,ex_eight
       ,ex_nine
       ,ex_ten
       ,ex_eleven
       ,ex_twelve
       ,ex_thirteen
       ,ex_fourteen
       ,ex_fifteen
       -- Modified by machunliang@20210816 处理206业务扩展字段取值
       ,if(trim(coalesce(ex5_SellChannelType, ''))= '', '#', ex5_SellChannelType) as ex5_SellChannelType
       ,spv_cust_xt
       --结算特殊处理逻辑下沉
       ,dept_id       --部门         Added by renxiaowei7@20210819
       ,spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
from (select  t1.* 
             -- 主体加工： 如果主体是3个信托公司，改为SPV（ 10000297,2192337,Special Purpose Vehicle（SPV）-供应链）
             ,case when fst_biz_typ = '699' and fee_principal_company_merchant_id in ('1001127','1002123','1002287','1001508') then '10000297'
                   else fee_principal_company_customer_id
               end as fee_principal_company_customer_id1
             ,case when fst_biz_typ = '699' and fee_principal_company_merchant_id in ('1001127','1002123','1002287','1001508') then '2192337'
                   else fee_principal_company_merchant_id
               end as fee_principal_company_merchant_id1
             ,case when fst_biz_typ = '699' and fee_principal_company_merchant_id in ('1001127','1002123','1002287','1001508') then 'Special Purpose Vehicle（SPV）-供应链'
                   else fee_principal_company_customer_name
               end as fee_principal_company_customer_name1
             
             ,case when fst_biz_typ = '699' and sett_principal_company_merchant_id in ('1001127','1002123','1002287','1001508') then '10000297'
                   else sett_principal_company_customer_id
               end as sett_principal_company_customer_id1
             ,case when fst_biz_typ = '699' and sett_principal_company_merchant_id in ('1001127','1002123','1002287','1001508') then '2192337'
                   else sett_principal_company_merchant_id
               end as sett_principal_company_merchant_id1
             ,case when fst_biz_typ = '699' and sett_principal_company_merchant_id in ('1001127','1002123','1002287','1001508') then 'Special Purpose Vehicle（SPV）-供应链'
                   else sett_principal_company_customer_name
               end as sett_principal_company_customer_name1
             
             -- 项目段映射
             ,case when fst_biz_typ = '699'
                   then case -- 根据客商/客户名称确定项目
                             when cust_nm = '中航信托天蔚京宜1号单一资金信托' then '0008KD00063'
                             when cust_nm = '中航信托股份有限公司'            then '0008KD00063'
                             when cust_nm = '华能信托溢诚1号单一资金信托'     then '0008KD00064'
                             when cust_nm = '华能贵诚信托有限公司'            then '0008KD00064'
                             when cust_nm = '渤海国际信托股份有限公司'        then '0008KD00048'
                             when cust_nm = '中诚信托有限责任公司'            then '0008KD00081' --Added by renxiaowei7@20230227
                             -- 根据计费明细&结算单主体确认项目
                             when '1001127' in (fee_principal_company_merchant_id,sett_principal_company_merchant_id) then '0008KD00063'
                             when '1002287' in (fee_principal_company_merchant_id,sett_principal_company_merchant_id) then '0008KD00064'
                             when '1002123' in (fee_principal_company_merchant_id,sett_principal_company_merchant_id) then '0008KD00048'
                             when '1001508' in (fee_principal_company_merchant_id,sett_principal_company_merchant_id) then '0008KD00081' --Added by renxiaowei7@20230227
                             else proj_id
                        end
                    when fst_biz_typ = '455'
                         -- Added by machunliang@20210706 增加biz_type=455的项目代码逻辑
                    -- then case when fst_sett_scen in ('45511','45515') and nvl(proj_id, '') not in ('', '请查看填写说明')
                    then case when fst_sett_scen in ('45511','45515') and nvl(proj_id, '') in ('', '请查看填写说明')
                              -- modified by machunliang@20210728 按王爽咚咚要求，增加函数取值，以原来的有第一优先级
                              -- then dmf_bc.dmdictDesc('jt_abs_project_no',prod_id) 
                              -- then coalesce(dmf_bc.dmdictDesc('jt_abs_project_no',prod_id), dmf_bc.dmdictDesc('fst_spv_project_no',cust_id,'03'), proj_id)
                              then coalesce(dmf_bc.dmdictDesc('jt_abs_project_no',prod_id), dmf_bc.dmdictDesc('jt_abs_project_no',substr(prod_id,4)), proj_id)    --R2022070863154 modified by wangshuang108@20220919 调整455类型项目段映射规则，使用协议号进行映射                  
                              else proj_id
                         end
                    when fst_biz_typ = '664' 
                         -- Added by machunliang@202107013 增加664业务的特殊逻辑
                    then case when src_tab in ('dmfbc_bc_fi_fst_fee_detail_i_d', 'dmfbc_bc_fi_fin_sett_all_fee_detail_i_d') and 
                                   fst_fee_typ in ('66408490', '6640901') 
                              then '0008KZ99999'
                              else proj_id
                         end
                    else proj_id
               end as proj_id1
      from (
        select  dt 
               ,'' as model_id                  -- 财务核算中间表模型编号
               ,'' as indx_id                   -- 指标编号
               ,'fst'           as src_sys                   -- 数据来源系统
               ,'dmfbc_bc_fi_fst_sett_i_d'          as src_tab                   -- 数据来源表
               ,'sett'          as src_tab1                   -- 数据来源表
               ,change_flag     as change_flag               -- 数据标识
               ,last_dt         as rev_data_orig_dt          -- 冲销数据源数据分区
               ,origin_id       as data_unikey               -- 数据唯一键       TODO: 唯一化
               --,str_to_map(Accti_Biz_Line_Cd)['BIZ_L3']  as accti_biz_line_cd         -- 核算业务线
               --,str_to_map(Accti_Biz_Line_Cd)['PROD_ID'] as accti_prod_cd             -- 核算业务线产品
               --Modified by renxiaowei7@20210820 修改核算业务线&产品生成方式，并且支持一条数据对应多个产品的逻辑
               ,t2.accti_prod_cd  --核算业务线产品
               ,sett_final_time      as tx_tm                     -- 交易时间
               ,sett_amount          as tx_amt                    -- 交易金额
               ,'' as biz_typ                   -- 指标业务类型
               ,'' as cap_typ                   -- 指标资金类型
               ,currency                  -- 币种
               -- 主体 & 客体
               ,'' as Corp_IDs                  -- 主体（公司）id
               ,'' as Corp_mercht_ids           -- 主体（客商）id
               ,'' as Corp_Nms                  -- 主体名称
               ,'' as Corp_role_typ             -- 主体角色类型
               ,'' as mercht_ids                -- 客商ID
               ,'' as mercht_nms                -- 客商名称
               ,'' as mercht_typs               -- 客商类型MAP
               -- 下面取计费明细和结算单的主体客体原始字段
               ,sett_principal_company_customer_id
               ,sett_principal_company_merchant_id
               ,sett_principal_company_customer_name
               ,'' as fee_principal_company_customer_id
               ,'' as fee_principal_company_merchant_id
               ,'' as fee_principal_company_customer_name
               ,sett_customer_name_merchant_id_all_src
               ,'' fee_customer_name_merchant_id_all_src
               ,concat('sett#', nvl(sett_principal_company_customer_id,''), '&fee#', '') as principal_company_customer_ids
               ,concat('sett#', nvl(sett_principal_company_merchant_id,''), '&fee#', '') as principal_company_merchant_ids
               ,concat('sett#', nvl(sett_principal_company_customer_name,''), '&fee#', '') as principal_company_customer_names
               -- Modified by machunliang@20210720 增加从原来单客商字段取值
               -- ,concat('sett#', sett_customer_name_merchant_id_all_src, '&fee#', '') as merchant_id_all_src
               -- ,concat('sett#', sett_customer_name_merchant_typ_all_src, '&fee#', '') as merchant_typ_all_src
               ,concat('sett#', nvl(sett_customer_name_merchant_id_all_src,''),  NVL(concat(',ORIG:', sett_customer_name_merchant_id),   ''), '&fee#', '') as merchant_id_all_src
               ,concat('sett#', nvl(sett_customer_name_merchant_typ_all_src,''), NVL(concat(',ORIG:', sett_customer_name_merchant_id_type), ''), '&fee#', '') as merchant_typ_all_src
               -- 账户
               ,direction       -- 结算方向
               ,direction       as sett_direction            -- 结算单结算方向
               ,if (direction = '1', 1, 0)     as fee_dir_sign     -- 计费方向（计算参数）-fee
               ,if (direction = '1', 1, 0)     as sett_dir_sign    -- 结算方向（计算参数）-sett
               --,if (sign(sett_amount)<0, 1, 0) as bal_dir_sign     -- 余额方向（计算参数）
               ,1 as bal_dir_sign                                  -- 金额方向（计算参数）
               -- 0：主体账户和1：客体账户
               ,str_to_map(concat('0:',NVL(payinfo_company_account_id        ,''),',1:',NVL(payinfo_other_company_account_id       ,''))) as Acct_ID            -- 账户主数据ID
               ,str_to_map(concat('0:',NVL(payinfo_company_account           ,''),',1:',NVL(payinfo_other_company_account          ,''))) as Bank_Acct_No       -- 账户账号
               ,str_to_map(concat('0:',NVL(payinfo_bank_acct_brvt_cd         ,''),',1:',NVL(payinfo_other_bank_acct_brvt_cd        ,''))) as Acct_Brvt_Cd       -- 账户简码
               ,str_to_map(concat('0:',NVL(payinfo_company_name_merchant_id  ,''),',1:',NVL(payinfo_other_company_name_merchant_id ,''))) as Acct_Mercht_ID     -- 账户客商ID
               ,str_to_map(concat('0:',NVL(payinfo_company_name              ,''),',1:',NVL(payinfo_other_company_name             ,''))) as Acct_Corp_Nm       -- 账户公司名称
               ,str_to_map(concat('0:',NVL(payinfo_bank_acct_dpst_charc      ,''),',1:',NVL(payinfo_other_bank_acct_dpst_charc     ,''))) as Acct_Dpst_Charc    -- 账户存款性质
               -- Added by machunliang@20210610 增加账户性质
               ,str_to_map(concat('0:',NVL(payinfo_company_account_nature    ,''),',1:',NVL(payinfo_other_company_account_nature   ,''))) as Acct_Nature        -- 账户性质
               ,str_to_map(concat('0:',NVL(payinfo_company_account_nature_hs ,''),',1:',NVL(payinfo_other_company_account_nature_hs,''))) as Acct_Nature_hs     -- 账户性质（核算加工）
               -- 结算基本信息
               ,sett_id                   -- 结算单号
               ,''              as fee_id                    -- 费用单号
               ,biz_type        as fst_biz_typ               -- 结算业务类型
               ,sett_scenes     as fst_sett_scen             -- 结算场景
               ,''              as fst_fee_typ               -- 结算费用类型
               ,pay_id                    -- 支付单号
               ,finance_sys_id  as plat_id                   -- 收付款平台编号
               ,ref_apply_id    as biz_pay_id                -- 业务打款编号
               ,'' as biz_ids                   -- 业务单号集合
               ,tax_rate        as tax_rate                  -- 税率
               ,contract_code   as contr_id                  -- 合同编码
               ,project_code    as proj_id                   -- 项目编码
               ,create_dt       as cret_tm                   -- 创建时间
               ,update_dt       as modi_tm                   -- 修改时间
               ,product_id      as prod_id                   -- 产品id
               ,product_name    as prod_nm                   -- 产品名称
               ,customer_id     as cust_id                   -- 客户id
               ,customer_name   as cust_nm                   -- 客户名称
               ,status          as sett_stat                 -- 结算单状态(结算单status)
               ,''              as fee_stat                  -- 结算状态(计费明细表status)
               -- 以下是之前模型需要加的
               ,origin_id       as origin_id                 -- 原始id
               ,''              as ordr_id                   -- 订单编号
               ,''              as is_cntn_tax               -- 是否含税
               ,''              as cap_acct_chk_stat         -- 资金对账状态
               ,''              as biz_tm                    -- 业务时间
               ,''              as pay_tm                    -- 支付时间
               ,''              as acct_chk_tm               -- 对账时间
               ,''              as fst_tm                    -- 结算时间
               ,''              as stmt_no                   -- 对账单号
               ,cast(null as string)    as source_id         -- 计费来源
               ,yn_flag
               --Added by renxiaowei7@20211118
               ,'' as ex_one
               ,'' as ex_two
               ,'' as ex_three
               ,'' as ex_four
               ,'' as ex_five
               ,'' as ex_six
               --Added by renxiaowei7@20220106
               ,'' as ex_seven
               ,'' as ex_eight
               ,'' as ex_nine
               ,'' as ex_ten
               ,'' as ex_eleven
               ,'' as ex_twelve
               ,'' as ex_thirteen
               ,'' as ex_fourteen
               ,'' as ex_fifteen
               -- Modified by machunliang@20210816 处理206业务扩展字段取值
               ,'' as ex5_SellChannelType
               -- Added by machunliang@20210920 立新需求，30240这个场景 在spv集成一部分 在赊销白条集成一部分，用下面条件参数区分
               ,COALESCE(dmf_bc.dmDictVersion('fst_spv_customer_xt',regexp_replace(substr(sett_final_time,1,10),'-',''),payinfo_bank_acct), 'N') as spv_cust_xt
               --结算特殊处理逻辑下沉
               ,t1.dept_id       --部门         Added by renxiaowei7@20210819
               ,t1.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
        from (select *, 
                     -- 逻辑1：（李娜）【业务类型： 455 -金条ABS ；结算场景：  45515 本息分配(收款) 】 简码中含zq的为证券户（18），其他为对公户（01）
                     -- 逻辑2：（莎莎）【结算场景：69912，账户id：6795,6969的，是平台户03，其他是对公户01】
                     -- 【账户性质（核算加工）  ## 上下两部分：计费明细&结算计费明细同步修改】
                     case when sett_scenes = '45515' and payinfo_bank_acct_brvt_cd like '%zq%'         then '18'
                          when sett_scenes = '45515' and NVL(payinfo_bank_acct_brvt_cd, '') <> ''      then '01'
                          when biz_type = '699'      and payinfo_company_account_id in ('6795','6969','7355') then '03'   -- 三个是平台户('spsyqzrxtbfpt','zhxtbfsfpt','hngcxtbfsfpt')，其他是对公户
                          when biz_type = '699'      and NVL(payinfo_company_account_id, '') <> ''     then '01'       
                          else ''
                      end as payinfo_company_account_nature_hs,
                     case when sett_scenes = '45515' and payinfo_other_company_account_nature like '%zq%'      then '18'
                          when sett_scenes = '45515' and NVL(payinfo_bank_acct_brvt_cd, '') <> ''              then '01'
                          when biz_type = '699'      and payinfo_other_company_account_id in ('6795','6969','7355') then '03'   -- 三个是平台户('spsyqzrxtbfpt','zhxtbfsfpt','hngcxtbfsfpt')，其他是对公户
                          when biz_type = '699'      and NVL(payinfo_other_company_account_id, '') <> ''       then '01'       
                          else ''
                      end as payinfo_other_company_account_nature_hs
              from dmf_bc.dmfbc_bc_fi_fst_sett_i_d
             ) t1
        lateral view explode(split(if(Accti_Biz_Line_Cd like '%PROD_ID%',str_to_map(Accti_Biz_Line_Cd)['PROD_ID'],Accti_Biz_Line_Cd),'&')) t2 as accti_prod_cd
        union all 
        select  dt
               ,'' as model_id                  -- 财务核算中间表模型编号
               ,'' as indx_id                   -- 指标编号
               ,'fst'           as src_sys                   -- 数据来源系统
               ,'dmfbc_bc_fi_fst_fee_detail_i_d'           as src_tab                   -- 数据来源表
               ,'fee'           as src_tab1                  -- 数据来源表
               ,change_flag     as change_flag               -- 数据标识
               ,last_dt         as rev_data_orig_dt          -- 冲销数据源数据分区
               ,origin_id       as data_unikey               -- 数据唯一键
               --,str_to_map(Accti_Biz_Line_Cd)['BIZ_L3']  as accti_biz_line_cd         -- 核算业务线
               --,str_to_map(Accti_Biz_Line_Cd)['PROD_ID'] as accti_prod_cd             -- 核算业务线产品
               --Modified by renxiaowei7@20210820 修改核算业务线&产品生成方式，并且支持一条数据对应多个产品的逻辑
               ,t2.accti_prod_cd  -- 核算业务线产品
               ,trans_time      as tx_tm                     -- 交易时间
               ,amount          as tx_amt                    -- 交易金额
               ,'' as biz_typ                   -- 指标业务类型
               ,'' as cap_typ                   -- 指标资金类型
               ,currency                  -- 币种
               -- 主体 & 客体
               ,'' as Corp_IDs                  -- 主体（公司）id
               ,'' as Corp_mercht_ids           -- 主体（客商）id
               ,'' as Corp_Nms                  -- 主体名称
               ,'' as Corp_role_typ             -- 主体角色类型
               ,'' as mercht_ids                -- 客商ID
               ,'' as mercht_nms                -- 客商名称
               ,'' as mercht_typs               -- 客商类型MAP
               -- 下面取计费明细和结算单的主体客体原始字段
               ,'' as sett_principal_company_customer_id
               ,'' as sett_principal_company_merchant_id
               ,'' as sett_principal_company_customer_name
               ,fee_principal_company_customer_id
               ,fee_principal_company_merchant_id
               ,fee_principal_company_customer_name
               ,'' as sett_customer_name_merchant_id_all_src
               ,fee_customer_name_merchant_id_all_src
               ,concat('sett#', '', '&fee#', nvl(fee_principal_company_customer_id,'')) as principal_company_customer_ids
               ,concat('sett#', '', '&fee#', nvl(fee_principal_company_merchant_id,'')) as principal_company_merchant_ids
               ,concat('sett#', '', '&fee#', nvl(fee_principal_company_customer_name,'')) as principal_company_customer_names
               -- Modified by machunliang@20210720 增加从原来单客商字段取值
               -- ,concat('sett#', '', '&fee#', fee_customer_name_merchant_id_all_src) as merchant_id_all_src
               -- ,concat('sett#', '', '&fee#', fee_customer_name_merchant_typ_all_src) as merchant_typ_all_src
               ,concat('sett#', '', '&fee#', nvl(fee_customer_name_merchant_id_all_src,''),  NVL(concat(',ORIG:', fee_customer_name_merchant_id),   '')) as merchant_id_all_src
               ,concat('sett#', '', '&fee#', nvl(fee_customer_name_merchant_typ_all_src,''), NVL(concat(',ORIG:', fee_customer_name_merchant_id_type), '')) as merchant_typ_all_src
               -- 账户
               ,direction       -- 计提方向
               ,cast(null as string) as sett_direction            -- 结算单结算方向
               ,if (direction = '1', 1, 0)     as fee_dir_sign     -- 计费方向（计算参数）-fee
               ,if (direction = '1', 1, 0)     as sett_dir_sign    -- 结算方向（计算参数）-sett
               --,if (sign(amount)<0, 1, 0) as bal_dir_sign         -- 余额方向（计算参数）
               ,1 as bal_dir_sign                                  -- 金额方向（计算参数）
               -- 0：主体账户和1：客体账户
               ,str_to_map('')  as Acct_ID            -- 账户主数据ID
               ,str_to_map('')  as Bank_Acct_No       -- 账户账号
               ,str_to_map('')  as Acct_Brvt_Cd       -- 账户简码
               ,str_to_map('')  as Acct_Mercht_ID     -- 账户客商ID
               ,str_to_map('')  as Acct_Corp_Nm       -- 账户公司名称
               ,str_to_map('')  as Acct_Dpst_Charc    -- 账户存款性质
               -- Added by machunliang@20210610 增加账户性质
               ,str_to_map('')  as Acct_Nature        -- 账户性质
               ,str_to_map('')  as Acct_Nature_hs     -- 账户性质（核算加工）
               -- 结算基本信息
               ,''              as sett_id                   -- 结算单号
               ,fee_id                    -- 费用单号
               ,biz_type        as fst_biz_typ               -- 结算业务类型
               ,''              as fst_sett_scen             -- 结算场景
               ,fee_type        as fst_fee_typ               -- 结算费用类型
               ,''              as pay_id                    -- 支付单号
               ,''              as plat_id                   -- 收付款平台编号
               ,''              as biz_pay_id                -- 业务打款编号
               ,'' as biz_ids                   -- 业务单号集合
               ,tax_rate        as tax_rate                  -- 税率
               ,contract_code   as contr_id                  -- 合同编码
               ,project_code    as proj_id                   -- 项目编码
               ,create_dt       as cret_tm                   -- 创建时间
               ,update_dt       as modi_tm                   -- 修改时间
               ,product_id      as prod_id                   -- 产品id
               ,product_name    as prod_nm                   -- 产品名称
               ,customer_id     as cust_id                   -- 客户id
               ,customer_name   as cust_nm                   -- 客户名称
               ,''              as sett_stat                 -- 结算单状态(结算单status)
               ,status          as fee_stat                  -- 结算状态(计费明细表status)
               -- 以下是之前模型需要加的
               ,origin_id       as origin_id                 -- 原始id
               ,''              as ordr_id                   -- 订单编号
               ,''              as is_cntn_tax               -- 是否含税
               ,''              as cap_acct_chk_stat         -- 资金对账状态
               ,''              as biz_tm                    -- 业务时间
               ,''              as pay_tm                    -- 支付时间
               ,''              as acct_chk_tm               -- 对账时间
               ,''              as fst_tm                    -- 结算时间
               ,bill_code       as stmt_no                   -- 对账单号
               ,source_id       as source_id                 -- 计费来源
               ,yn_flag
               --Added by renxiaowei7@20211118
               ,ex_one
               ,ex_two
               ,ex_three
               ,ex_four
               ,ex_five
               ,ex_six
               --Added by renxiaowei7@20220106
               ,ex_seven
               ,ex_eight
               ,ex_nine
               ,ex_ten
               ,ex_eleven
               ,ex_twelve
               ,ex_thirteen
               ,ex_fourteen
               ,ex_fifteen
               -- Modified by machunliang@20210816 处理206业务扩展字段取值
               ,get_json_object(ex_five, '$.SellChannelType') as ex5_SellChannelType
               -- Added by machunliang@20210920 立新需求，30240这个场景 在spv集成一部分 在赊销白条集成一部分，用下面条件参数区分
               ,null as spv_cust_xt
               --结算特殊处理逻辑下沉
               ,t1.dept_id       --部门         Added by renxiaowei7@20210819
               ,t1.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
        from dmf_bc.dmfbc_bc_fi_fst_fee_detail_i_d t1
        lateral view explode(split(if(Accti_Biz_Line_Cd like '%PROD_ID%',str_to_map(Accti_Biz_Line_Cd)['PROD_ID'],Accti_Biz_Line_Cd),'&')) t2 as accti_prod_cd
        union all 
        select  dt
               ,'' as model_id                  -- 财务核算中间表模型编号
               ,'' as indx_id                   -- 指标编号
               ,'fst'           as src_sys                   -- 数据来源系统
               ,'dmfbc_bc_fi_fin_sett_all_fee_detail_i_d'      as src_tab                   -- 数据来源表
               ,'sett_fee'      as src_tab1                  -- 数据来源表
               ,change_flag     as change_flag               -- 数据标识
               ,last_dt         as rev_data_orig_dt          -- 冲销数据源数据分区
               ,origin_id       as data_unikey               -- 数据唯一键
               --,str_to_map(Accti_Biz_Line_Cd)['BIZ_L3']  as accti_biz_line_cd         -- 核算业务线
               --,str_to_map(Accti_Biz_Line_Cd)['PROD_ID'] as accti_prod_cd             -- 核算业务线产品
               --Modified by renxiaowei7@20210820 修改核算业务线&产品生成方式，并且支持一条数据对应多个产品的逻辑
               ,t2.accti_prod_cd  -- 核算业务线产品
               ,sett_final_time      as tx_tm                     -- 交易时间
               ,sett_amount          as tx_amt                    -- 交易金额
               ,'' as biz_typ                   -- 指标业务类型
               ,'' as cap_typ                   -- 指标资金类型
               ,currency                  -- 币种
               -- 主体 & 客体
               ,'' as Corp_IDs                  -- 主体（公司）id
               ,'' as Corp_mercht_ids           -- 主体（客商）id
               ,'' as Corp_Nms                  -- 主体名称
               ,'' as Corp_role_typ             -- 主体角色类型
               ,'' as mercht_ids                -- 客商ID
               ,'' as mercht_nms                -- 客商名称
               ,'' as mercht_typs               -- 客商类型MAP
               -- 下面取计费明细和结算单的主体客体原始字段
               ,sett_principal_company_customer_id
               ,sett_principal_company_merchant_id
               ,sett_principal_company_customer_name
               ,fee_principal_company_customer_id
               ,fee_principal_company_merchant_id
               ,fee_principal_company_customer_name
               ,sett_customer_name_merchant_id_all_src
               ,fee_customer_name_merchant_id_all_src
               ,concat('sett#', nvl(sett_principal_company_customer_id,''), '&fee#', nvl(fee_principal_company_customer_id,'')) as principal_company_customer_ids
               ,concat('sett#', nvl(sett_principal_company_merchant_id,''), '&fee#', nvl(fee_principal_company_merchant_id,'')) as principal_company_merchant_ids
               ,concat('sett#', nvl(sett_principal_company_customer_name,''), '&fee#', nvl(fee_principal_company_customer_name,'')) as principal_company_customer_names
               -- Modified by machunliang@20210720 肖宁提出的增加可取原来单客商字段值的要求，同时可解决消金不是每笔数据都在同一个ID上的需求。使用KEY: ORIG
               -- ,concat('sett#', sett_customer_name_merchant_id_all_src, '&fee#', fee_customer_name_merchant_id_all_src) as merchant_id_all_src
               -- ,concat('sett#', sett_customer_name_merchant_typ_all_src, '&fee#', fee_customer_name_merchant_typ_all_src) as merchant_typ_all_src
               ,concat('sett#', nvl(sett_customer_name_merchant_id_all_src,''),  NVL(concat(',ORIG:', sett_customer_name_merchant_id), ''), 
                       '&fee#',  nvl(fee_customer_name_merchant_id_all_src,''),  NVL(concat(',ORIG:',  fee_customer_name_merchant_id), '')) as merchant_id_all_src
               ,concat('sett#', nvl(sett_customer_name_merchant_typ_all_src,''), NVL(concat(',ORIG:', sett_customer_name_merchant_id_type), ''), 
                       '&fee#',  nvl(fee_customer_name_merchant_typ_all_src,''), NVL(concat(',ORIG:',  fee_customer_name_merchant_id_type), '')) as merchant_typ_all_src
               -- 账户
               ,direction       -- 结算方向
               ,sett_direction  as sett_direction            -- 结算单结算方向
               ,if (direction = '1', 1, 0)     as fee_dir_sign     -- 计费方向（计算参数）-fee
               ,if (sett_direction = '1', 1, 0) as sett_dir_sign   -- 结算方向（计算参数）-sett
               --,if (sign(sett_amount)<0, 1, 0) as bal_dir_sign     -- 余额方向（计算参数）
               ,if(sett_direction=direction,1,-1) as bal_dir_sign  -- 金额方向（计算参数）
               -- 0：主体账户和1：客体账户
               ,str_to_map(concat('0:',NVL(payinfo_company_account_id        ,''),',1:',NVL(payinfo_other_company_account_id       ,''))) as Acct_ID            -- 账户主数据ID
               ,str_to_map(concat('0:',NVL(payinfo_company_account           ,''),',1:',NVL(payinfo_other_company_account          ,''))) as Bank_Acct_No       -- 账户账号
               ,str_to_map(concat('0:',NVL(payinfo_bank_acct_brvt_cd         ,''),',1:',NVL(payinfo_other_bank_acct_brvt_cd        ,''))) as Acct_Brvt_Cd       -- 账户简码
               ,str_to_map(concat('0:',NVL(payinfo_company_name_merchant_id  ,''),',1:',NVL(payinfo_other_company_name_merchant_id ,''))) as Acct_Mercht_ID     -- 账户客商ID
               ,str_to_map(concat('0:',NVL(payinfo_company_name              ,''),',1:',NVL(payinfo_other_company_name             ,''))) as Acct_Corp_Nm       -- 账户公司名称
               ,str_to_map(concat('0:',NVL(payinfo_bank_acct_dpst_charc      ,''),',1:',NVL(payinfo_other_bank_acct_dpst_charc     ,''))) as Acct_Dpst_Charc    -- 账户存款性质
                -- Added by machunliang@20210610 增加账户性质
               ,str_to_map(concat('0:',NVL(payinfo_company_account_nature    ,''),',1:',NVL(payinfo_other_company_account_nature   ,''))) as Acct_Nature        -- 账户性质
               ,str_to_map(concat('0:',NVL(payinfo_company_account_nature_hs ,''),',1:',NVL(payinfo_other_company_account_nature_hs,''))) as Acct_Nature_hs     -- 账户性质（核算加工）
               -- 结算基本信息
               ,sett_id                   -- 结算单号
               ,fee_id                    -- 费用单号
               ,biz_type        as fst_biz_typ               -- 结算业务类型
               ,sett_scenes     as fst_sett_scen             -- 结算场景
               ,fee_type        as fst_fee_typ               -- 结算费用类型
               ,pay_id          as pay_id                    -- 支付单号
               ,''              as plat_id                   -- 收付款平台编号
               ,''              as biz_pay_id                -- 业务打款编号
               ,'' as biz_ids                   -- 业务单号集合
               ,tax_rate        as tax_rate                  -- 税率
               ,contract_code   as contr_id                  -- 合同编码
               ,project_code    as proj_id                   -- 项目编码
               ,create_dt       as cret_tm                   -- 创建时间
               ,update_dt       as modi_tm                   -- 修改时间
               ,product_id      as prod_id                   -- 产品id
               ,product_name    as prod_nm                   -- 产品名称
               ,customer_id     as cust_id                   -- 客户id
               ,customer_name   as cust_nm                   -- 客户名称
               ,sett_status     as sett_stat                 -- 结算单状态(结算单status)
               ,status          as fee_stat                  -- 结算状态(计费明细表status)
               -- 以下是之前模型需要加的
               ,origin_id       as origin_id                 -- 原始id
               ,''              as ordr_id                   -- 订单编号
               ,''              as is_cntn_tax               -- 是否含税
               ,''              as cap_acct_chk_stat         -- 资金对账状态
               ,''              as biz_tm                    -- 业务时间
               ,''              as pay_tm                    -- 支付时间
               ,''              as acct_chk_tm               -- 对账时间
               ,''              as fst_tm                    -- 结算时间
               ,bill_code       as stmt_no                   -- 对账单号
               ,source_id       as source_id                 -- 计费来源
               ,yn_flag
               --Added by renxiaowei7@20211118
               ,ex_one
               ,ex_two
               ,ex_three
               ,ex_four
               ,ex_five
               ,ex_six
               --Added by renxiaowei7@20220106
               ,ex_seven
               ,ex_eight
               ,ex_nine
               ,ex_ten
               ,ex_eleven
               ,ex_twelve
               ,ex_thirteen
               ,ex_fourteen
               ,ex_fifteen
               -- Modified by machunliang@20210816 处理206业务扩展字段取值
               ,get_json_object(ex_five, '$.SellChannelType') as ex5_SellChannelType
               -- Added by machunliang@20210920 立新需求，30240这个场景 在spv集成一部分 在赊销白条集成一部分，用下面条件参数区分
               ,COALESCE(dmf_bc.dmDictVersion('fst_spv_customer_xt',regexp_replace(substr(sett_final_time,1,10),'-',''),payinfo_bank_acct), 'N') as spv_cust_xt
               --结算特殊处理逻辑下沉
               ,t1.dept_id       --部门         Added by renxiaowei7@20210819
               ,t1.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
        -- from dmf_bc.dmfbc_bc_fi_fin_sett_all_fee_detail_i_d 
        from (select *, 
                     -- 逻辑1：（李娜）【业务类型： 455 -金条ABS ；结算场景：  45515 本息分配(收款) 】 简码中含zq的为证券户（18），其他为对公户（01）
                     -- 逻辑2：（莎莎）【结算场景：69912，账户id：6795,6969的，是平台户03，其他是对公户01】
                     -- 【账户性质（核算加工）  ## 上下两部分：计费明细&结算计费明细同步修改】
                     case when sett_scenes = '45515' and payinfo_bank_acct_brvt_cd like '%zq%'         then '18'
                          when sett_scenes = '45515' and NVL(payinfo_bank_acct_brvt_cd, '') <> ''      then '01'
                          when biz_type = '699'      and payinfo_company_account_id in ('6795','6969','7355') then '03'   -- 三个是平台户('spsyqzrxtbfpt','zhxtbfsfpt','hngcxtbfsfpt')，其他是对公户
                          when biz_type = '699'      and NVL(payinfo_company_account_id, '') <> ''     then '01'       
                          else ''
                      end as payinfo_company_account_nature_hs,
                     case when sett_scenes = '45515' and payinfo_other_company_account_nature like '%zq%'      then '18'
                          when sett_scenes = '45515' and NVL(payinfo_bank_acct_brvt_cd, '') <> ''              then '01'
                          when biz_type = '699'      and payinfo_other_company_account_id in ('6795','6969','7355') then '03'   -- 三个是平台户('spsyqzrxtbfpt','zhxtbfsfpt','hngcxtbfsfpt')，其他是对公户
                          when biz_type = '699'      and NVL(payinfo_other_company_account_id, '') <> ''       then '01'       
                          else ''
                      end as payinfo_other_company_account_nature_hs
              from dmf_bc.dmfbc_bc_fi_fin_sett_all_fee_detail_i_d
             ) t1
        lateral view explode(split(if(Accti_Biz_Line_Cd like '%PROD_ID%',str_to_map(Accti_Biz_Line_Cd)['PROD_ID'],Accti_Biz_Line_Cd),'&')) t2 as accti_prod_cd
        where sett_yn_flag = '1' and sett_final_time is not null 
        union all 
        select  dt
               ,'' as model_id                  -- 财务核算中间表模型编号
               ,'' as indx_id                   -- 指标编号
               ,'fst'           as src_sys                   -- 数据来源系统
               ,'dmfbc_bc_fi_fst_bal_s_d'      as src_tab    -- 数据来源表
               ,'bal'      as src_tab1                       -- 数据来源表
               ,''         as change_flag                    -- 数据标识
               ,''         as rev_data_orig_dt          -- 冲销数据源数据分区
               ,origin_id       as data_unikey               -- 数据唯一键
               --,str_to_map(Accti_Biz_Line_Cd)['BIZ_L3']  as accti_biz_line_cd         -- 核算业务线
               --,str_to_map(Accti_Biz_Line_Cd)['PROD_ID'] as accti_prod_cd             -- 核算业务线产品
               --Modified by renxiaowei7@20210820 修改核算业务线&产品生成方式，并且支持一条数据对应多个产品的逻辑
               ,t2.accti_prod_cd  -- 核算业务线产品
               ,trans_dt        as tx_tm                     -- 交易时间
               ,amount          as tx_amt                    -- 交易金额
               ,'' as biz_typ                   -- 指标业务类型
               ,'' as cap_typ                   -- 指标资金类型
               ,'' as currency                  -- 币种
               -- 主体 & 客体
               ,'' as Corp_IDs                  -- 主体（公司）id
               ,'' as Corp_mercht_ids           -- 主体（客商）id
               ,'' as Corp_Nms                  -- 主体名称
               ,'' as Corp_role_typ             -- 主体角色类型
               ,'' as mercht_ids                -- 客商ID
               ,'' as mercht_nms                -- 客商名称
               ,'' as mercht_typs               -- 客商类型MAP
               -- 下面取计费明细和结算单的主体客体原始字段
               ,principal_company_customer_id   as sett_principal_company_customer_id
               ,principal_company_merchant_id   as sett_principal_company_merchant_id
               ,principal_company_customer_name as sett_principal_company_customer_name
               ,principal_company_customer_id   as fee_principal_company_customer_id
               ,principal_company_merchant_id   as fee_principal_company_merchant_id
               ,principal_company_customer_name as fee_principal_company_customer_name
               ,customer_name_merchant_id_all_src as sett_customer_name_merchant_id_all_src
               ,customer_name_merchant_id_all_src as fee_customer_name_merchant_id_all_src
               ,concat('sett#', nvl(principal_company_customer_id,''), '&fee#', nvl(principal_company_customer_id,'')) as principal_company_customer_ids
               ,concat('sett#', nvl(principal_company_merchant_id,''), '&fee#', nvl(principal_company_merchant_id,'')) as principal_company_merchant_ids
               ,concat('sett#', nvl(principal_company_customer_name,''), '&fee#', nvl(principal_company_customer_name,'')) as principal_company_customer_names
               ,concat('sett#', nvl(customer_name_merchant_id_all_src,''), '&fee#', nvl(customer_name_merchant_id_all_src,'')) as merchant_id_all_src
               ,concat('sett#', nvl(customer_name_merchant_typ_all_src,''), '&fee#', nvl(customer_name_merchant_typ_all_src,'')) as merchant_typ_all_src
               -- 账户
               ,'' as direction       -- 结算方向
               ,'' as sett_direction            -- 结算单结算方向
               ,0  as fee_dir_sign     -- 计费方向（计算参数）-fee
               ,0  as sett_dir_sign    -- 结算方向（计算参数）-sett
               --,0  as bal_dir_sign     -- 金额正负方向（计算参数）
               ,1 as bal_dir_sign      -- 金额方向（计算参数）
               -- 0：主体账户和1：客体账户
               ,str_to_map('') as Acct_ID            -- 账户主数据ID
               ,str_to_map('') as Bank_Acct_No       -- 账户账号
               ,str_to_map('') as Acct_Brvt_Cd       -- 账户简码
               ,str_to_map('') as Acct_Mercht_ID     -- 账户客商ID
               ,str_to_map('') as Acct_Corp_Nm       -- 账户公司名称
               ,str_to_map('') as Acct_Dpst_Charc    -- 账户存款性质
               ,str_to_map('') as Acct_Nature        -- 账户性质
               ,str_to_map('') as Acct_Nature_hs     -- 账户性质（核算加工）
               -- 结算基本信息
               ,'' as sett_id                   -- 结算单号
               ,'' as fee_id                    -- 费用单号
               ,biz_type        as fst_biz_typ               -- 结算业务类型
               ,cap_type        as fst_sett_scen             -- 结算场景
               ,cap_type        as fst_fee_typ               -- 结算费用类型
               ,''              as pay_id                    -- 支付单号
               ,''              as plat_id                   -- 收付款平台编号
               ,''              as biz_pay_id                -- 业务打款编号
               ,''              as biz_ids                   -- 业务单号集合
               ,''              as tax_rate                  -- 税率
               ,contract_code   as contr_id                  -- 合同编码
               ,project_code    as proj_id                   -- 项目编码
               ,''              as cret_tm                   -- 创建时间
               ,''              as modi_tm                   -- 修改时间
               ,''              as prod_id                   -- 产品id
               ,''              as prod_nm                   -- 产品名称
               ,''              as cust_id                   -- 客户id
               ,''              as cust_nm                   -- 客户名称
               ,''              as sett_stat                 -- 结算单状态(结算单status)
               ,''              as fee_stat                  -- 结算状态(计费明细表status)
               ,origin_id       as origin_id                 -- 原始id
               ,''              as ordr_id                   -- 订单编号
               ,''              as is_cntn_tax               -- 是否含税
               ,''              as cap_acct_chk_stat         -- 资金对账状态
               ,''              as biz_tm                    -- 业务时间
               ,''              as pay_tm                    -- 支付时间
               ,''              as acct_chk_tm               -- 对账时间
               ,''              as fst_tm                    -- 结算时间
               ,''              as stmt_no                   -- 对账单号
               ,''              as source_id                 -- 计费来源
               ,'1'             as yn_flag
               --Added by renxiaowei7@20211118
               ,''              as ex_one
               ,''              as ex_two
               ,''              as ex_three
               ,''              as ex_four
               ,''              as ex_five
               ,''              as ex_six
               --Added by renxiaowei7@20220106
               ,''              as ex_seven
               ,''              as ex_eight
               ,''              as ex_nine
               ,''              as ex_ten
               ,''              as ex_eleven
               ,''              as ex_twelve
               ,''              as ex_thirteen
               ,''              as ex_fourteen
               ,''              as ex_fifteen
               -- Modified by machunliang@20210816 处理206业务扩展字段取值
               ,'' as ex5_SellChannelType
               -- Added by machunliang@20210920 立新需求，30240这个场景 在spv集成一部分 在赊销白条集成一部分，用下面条件参数区分
               ,null as spv_cust_xt
               --结算特殊处理逻辑下沉
               ,'' as dept_id       --部门         Added by renxiaowei7@20210819
               ,'' as spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
          from dmf_bc.dmfbc_bc_fi_fst_bal_s_d t1
          lateral view explode(split(if(Accti_Biz_Line_Cd like '%PROD_ID%',str_to_map(Accti_Biz_Line_Cd)['PROD_ID'],Accti_Biz_Line_Cd),'&')) t2 as accti_prod_cd
      ) t1
      where  dt >= '{START_DATE}' and dt <= '{TX_DATE}'  --Modified by renxiaowei7@20210701 按月跑数逻辑修改
        and  yn_flag = '1'
) t2
;

""",

"sql_02": """
set hive.auto.convert.join=true;
set mapred.max.split.size=8000000;
set mapred.min.split.size.per.node=8000000;
set mapred.min.split.size.per.rack=8000000;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.merge.mapfiles = true;
set hive.merge.size.per.task = 8000000;
set mapreduce.input.fileinputformat.split.maxsize = 8000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=8000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=8000000;
set hive.execution.engine=mr;
use dmf_tmp;

drop table if exists dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_01;
create table if not exists dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_01 
as 
select     a1.*
          ,a2.typecd       --处理类型
          ,a2.result_flag  --结果类型
          ,a2.result_sql   --映射结果
          ,case when a2.result_flag = 'S' then a2.result_val_sql    --固定值
                --映射函数
                when a2.result_flag = 'F' then nvl(dmf_bc.dmdictDesc(a2.result_val_func_nm,if(substr(a2.result_val_func_coll_01,1,2)='S$',substr(a2.result_val_func_coll_01,3),a1.conn_cols[a2.result_val_func_coll_01]),if(substr(a2.result_val_func_coll_02,1,2)='S$',substr(a2.result_val_func_coll_02,3),a1.conn_cols[a2.result_val_func_coll_02]),if(substr(a2.result_val_func_coll_03,1,2)='S$',substr(a2.result_val_func_coll_03,3),a1.conn_cols[a2.result_val_func_coll_03]),if(substr(a2.result_val_func_coll_04,1,2)='S$',substr(a2.result_val_func_coll_04,3),a1.conn_cols[a2.result_val_func_coll_04]),if(substr(a2.result_val_func_coll_05,1,2)='S$',substr(a2.result_val_func_coll_05,3),a1.conn_cols[a2.result_val_func_coll_05]),if(substr(a2.result_val_func_coll_06,1,2)='S$',substr(a2.result_val_func_coll_06,3),a1.conn_cols[a2.result_val_func_coll_06]),if(substr(a2.result_val_func_coll_07,1,2)='S$',substr(a2.result_val_func_coll_07,3),a1.conn_cols[a2.result_val_func_coll_07]),if(substr(a2.result_val_func_coll_08,1,2)='S$',substr(a2.result_val_func_coll_08,3),a1.conn_cols[a2.result_val_func_coll_08])),'')
                when a2.result_flag = 'C' then a2.result_val_sql
                else ''
           end as result_val
from (select     *
                ,str_to_map(concat_ws('#'
                               ,concat('biz_type&'      ,nvl(fst_biz_typ   ,''))
                               ,concat('sett_scenes&'   ,nvl(fst_sett_scen ,''))
                               ,concat('fee_type&'      ,nvl(fst_fee_typ   ,''))
                               ,concat('sett_status&'   ,nvl(sett_stat     ,''))
                               ,concat('status&'        ,nvl(fee_stat      ,''))
                               ,concat('product_id&'    ,nvl(prod_id       ,''))
                               ,concat('customer_id&'   ,nvl(cust_id       ,''))
                               ,concat('source_id&'     ,nvl(source_id     ,''))
                               --Added by renxiaowei7@20211118
                               ,concat('ex_one&'        ,nvl(ex_one        ,''))
                               ,concat('ex_two&'        ,nvl(ex_two        ,''))
                               ,concat('ex_three&'      ,nvl(ex_three      ,''))
                               ,concat('ex_four&'       ,nvl(ex_four       ,''))
                               ,concat('ex_five&'       ,nvl(ex_five       ,''))
                               ,concat('ex_six&'        ,nvl(ex_six        ,''))
                               ,concat('ex_seven&'      ,nvl(ex_seven      ,''))
                               ,concat('ex_eight&'      ,nvl(ex_eight      ,''))
                               ,concat('ex_nine&'       ,nvl(ex_nine       ,''))
                               ,concat('ex_ten&'        ,nvl(ex_ten        ,''))
                               ,concat('ex_eleven&'     ,nvl(ex_eleven     ,''))
                               ,concat('ex_twelve&'     ,nvl(ex_twelve     ,''))
                               ,concat('ex_thirteen&'   ,nvl(ex_thirteen   ,''))
                               ,concat('ex_fourteen&'   ,nvl(ex_fourteen   ,''))
                               ,concat('ex_fifteen&'    ,nvl(ex_fifteen    ,''))
                               ,concat('product_name&'  ,nvl(prod_nm       ,''))
                               ,concat('customer_name&' ,nvl(cust_nm       ,''))
                               ,concat('direction&'     ,nvl(direction     ,''))
                               ,concat('sett_direction&',nvl(sett_direction,''))
                               ,concat('fee_principal_company_merchant_id&',nvl(str_to_map(principal_company_merchant_ids,'&','#')['fee'],''))
                               ,concat('sett_principal_company_merchant_id&',nvl(str_to_map(principal_company_merchant_ids,'&','#')['sett'],''))
                               ,concat('fee_customer_name_merchant_id&',nvl(str_to_map(str_to_map(merchant_id_all_src,'&','#')['fee'])['ORIG'],''))
                               ,concat('fee_customer_name_merchant_id_type&',nvl(str_to_map(str_to_map(merchant_typ_all_src,'&','#')['fee'])['ORIG'],''))
                               ,concat('sett_customer_name_merchant_id&',nvl(str_to_map(str_to_map(merchant_id_all_src,'&','#')['sett'])['ORIG'],''))
                               ,concat('sett_customer_name_merchant_id_type&',nvl(str_to_map(str_to_map(merchant_typ_all_src,'&','#')['sett'])['ORIG'],''))
                          ),'#','&') as conn_cols
      from dmf_tmp.tmp_dmfbc_bc_fi_fst_indx_mdl_dtl
      where nvl(accti_prod_cd,'')='' or nvl(tax_rate,'')=''
     ) a1
left join (select * from dmf_bc.dmfbc_bc_sett_spec_conf_detail_a_d
           where modleCd = 'sett_gdm' --配置层级 结算中间层
             --and tabCd   = 'fee'      --处理表   计费明细
             and typecd in ('dmf_product','dmf_tax')  --核算交易明细兜底，只兜产品/税率
          ) a2
       on  case when a1.src_tab='dmfbc_bc_fi_fst_fee_detail_i_d' then 'fee' 
                when a1.src_tab='dmfbc_bc_fi_fst_sett_i_d' then 'sett' 
                when a1.src_tab='dmfbc_bc_fi_fin_sett_all_fee_detail_i_d' then 'sett_fee' 
                else '' 
           end = a2.tabCd
      and  a1.fst_biz_typ = a2.bizType
      and  case when a2.settScenes     like '!%' and concat(',',substr(a2.settScenes,2),',') not like concat('%,',a1.fst_sett_scen,',%') then '1'
                when a2.settScenes not like '!%' and concat(',',a2.settScenes,',')               like concat('%,',a1.fst_sett_scen,',%') then '1'
                when a2.settScenes='' then '1'
                else '0'
           end = '1'
      and  case when a2.feeType     like '!%' and concat(',',substr(a2.feeType,2),',') not like concat('%,',a1.fst_fee_typ,',%') then '1'
                when a2.feeType not like '!%' and concat(',',a2.feeType,',')               like concat('%,',a1.fst_fee_typ,',%') then '1'
                when a2.feeType='' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_01_flag,'') = 'S&='     and a1.conn_cols[a2.field_01_coll] =  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&!='    and a1.conn_cols[a2.field_01_coll] != a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&>'     and a1.conn_cols[a2.field_01_coll] >  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&<'     and a1.conn_cols[a2.field_01_coll] <  a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&>='    and a1.conn_cols[a2.field_01_coll] >= a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&<='    and a1.conn_cols[a2.field_01_coll] <= a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&IN'    and concat(',',a2.field_01_val,',') like     concat('%,',a1.conn_cols[a2.field_01_coll],',%') then '1'
                when nvl(a2.field_01_flag,'') = 'S&!IN'   and concat(',',a2.field_01_val,',') not like concat('%,',a1.conn_cols[a2.field_01_coll],',%') then '1'
                when nvl(a2.field_01_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_01_coll]  like     a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_01_coll]  not like a2.field_01_val then '1'
                when nvl(a2.field_01_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_02_flag,'') = 'S&='     and a1.conn_cols[a2.field_02_coll] =  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&!='    and a1.conn_cols[a2.field_02_coll] != a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&>'     and a1.conn_cols[a2.field_02_coll] >  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&<'     and a1.conn_cols[a2.field_02_coll] <  a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&>='    and a1.conn_cols[a2.field_02_coll] >= a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&<='    and a1.conn_cols[a2.field_02_coll] <= a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&IN'    and concat(',',a2.field_02_val,',') like     concat('%,',a1.conn_cols[a2.field_02_coll],',%') then '1'
                when nvl(a2.field_02_flag,'') = 'S&!IN'   and concat(',',a2.field_02_val,',') not like concat('%,',a1.conn_cols[a2.field_02_coll],',%') then '1'
                when nvl(a2.field_02_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_02_coll]  like     a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_02_coll]  not like a2.field_02_val then '1'
                when nvl(a2.field_02_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_03_flag,'') = 'S&='     and a1.conn_cols[a2.field_03_coll] =  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&!='    and a1.conn_cols[a2.field_03_coll] != a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&>'     and a1.conn_cols[a2.field_03_coll] >  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&<'     and a1.conn_cols[a2.field_03_coll] <  a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&>='    and a1.conn_cols[a2.field_03_coll] >= a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&<='    and a1.conn_cols[a2.field_03_coll] <= a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&IN'    and concat(',',a2.field_03_val,',') like     concat('%,',a1.conn_cols[a2.field_03_coll],',%') then '1'
                when nvl(a2.field_03_flag,'') = 'S&!IN'   and concat(',',a2.field_03_val,',') not like concat('%,',a1.conn_cols[a2.field_03_coll],',%') then '1'
                when nvl(a2.field_03_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_03_coll]  like     a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_03_coll]  not like a2.field_03_val then '1'
                when nvl(a2.field_03_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_04_flag,'') = 'S&='     and a1.conn_cols[a2.field_04_coll] =  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&!='    and a1.conn_cols[a2.field_04_coll] != a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&>'     and a1.conn_cols[a2.field_04_coll] >  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&<'     and a1.conn_cols[a2.field_04_coll] <  a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&>='    and a1.conn_cols[a2.field_04_coll] >= a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&<='    and a1.conn_cols[a2.field_04_coll] <= a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&IN'    and concat(',',a2.field_04_val,',') like     concat('%,',a1.conn_cols[a2.field_04_coll],',%') then '1'
                when nvl(a2.field_04_flag,'') = 'S&!IN'   and concat(',',a2.field_04_val,',') not like concat('%,',a1.conn_cols[a2.field_04_coll],',%') then '1'
                when nvl(a2.field_04_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_04_coll]  like     a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_04_coll]  not like a2.field_04_val then '1'
                when nvl(a2.field_04_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_05_flag,'') = 'S&='     and a1.conn_cols[a2.field_05_coll] =  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&!='    and a1.conn_cols[a2.field_05_coll] != a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&>'     and a1.conn_cols[a2.field_05_coll] >  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&<'     and a1.conn_cols[a2.field_05_coll] <  a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&>='    and a1.conn_cols[a2.field_05_coll] >= a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&<='    and a1.conn_cols[a2.field_05_coll] <= a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&IN'    and concat(',',a2.field_05_val,',') like     concat('%,',a1.conn_cols[a2.field_05_coll],',%') then '1'
                when nvl(a2.field_05_flag,'') = 'S&!IN'   and concat(',',a2.field_05_val,',') not like concat('%,',a1.conn_cols[a2.field_05_coll],',%') then '1'
                when nvl(a2.field_05_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_05_coll]  like     a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_05_coll]  not like a2.field_05_val then '1'
                when nvl(a2.field_05_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_06_flag,'') = 'S&='     and a1.conn_cols[a2.field_06_coll] =  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&!='    and a1.conn_cols[a2.field_06_coll] != a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&>'     and a1.conn_cols[a2.field_06_coll] >  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&<'     and a1.conn_cols[a2.field_06_coll] <  a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&>='    and a1.conn_cols[a2.field_06_coll] >= a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&<='    and a1.conn_cols[a2.field_06_coll] <= a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&IN'    and concat(',',a2.field_06_val,',') like     concat('%,',a1.conn_cols[a2.field_06_coll],',%') then '1'
                when nvl(a2.field_06_flag,'') = 'S&!IN'   and concat(',',a2.field_06_val,',') not like concat('%,',a1.conn_cols[a2.field_06_coll],',%') then '1'
                when nvl(a2.field_06_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_06_coll]  like     a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_06_coll]  not like a2.field_06_val then '1'
                when nvl(a2.field_06_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_07_flag,'') = 'S&='     and a1.conn_cols[a2.field_07_coll] =  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&!='    and a1.conn_cols[a2.field_07_coll] != a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&>'     and a1.conn_cols[a2.field_07_coll] >  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&<'     and a1.conn_cols[a2.field_07_coll] <  a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&>='    and a1.conn_cols[a2.field_07_coll] >= a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&<='    and a1.conn_cols[a2.field_07_coll] <= a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&IN'    and concat(',',a2.field_07_val,',') like     concat('%,',a1.conn_cols[a2.field_07_coll],',%') then '1'
                when nvl(a2.field_07_flag,'') = 'S&!IN'   and concat(',',a2.field_07_val,',') not like concat('%,',a1.conn_cols[a2.field_07_coll],',%') then '1'
                when nvl(a2.field_07_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_07_coll]  like     a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_07_coll]  not like a2.field_07_val then '1'
                when nvl(a2.field_07_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.field_08_flag,'') = 'S&='     and a1.conn_cols[a2.field_08_coll] =  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&!='    and a1.conn_cols[a2.field_08_coll] != a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&>'     and a1.conn_cols[a2.field_08_coll] >  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&<'     and a1.conn_cols[a2.field_08_coll] <  a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&>='    and a1.conn_cols[a2.field_08_coll] >= a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&<='    and a1.conn_cols[a2.field_08_coll] <= a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&IN'    and concat(',',a2.field_08_val,',') like     concat('%,',a1.conn_cols[a2.field_08_coll],',%') then '1'
                when nvl(a2.field_08_flag,'') = 'S&!IN'   and concat(',',a2.field_08_val,',') not like concat('%,',a1.conn_cols[a2.field_08_coll],',%') then '1'
                when nvl(a2.field_08_flag,'') = 'S&LIKE'  and a1.conn_cols[a2.field_08_coll]  like     a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = 'S&!LIKE' and a1.conn_cols[a2.field_08_coll]  not like a2.field_08_val then '1'
                when nvl(a2.field_08_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_01_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') =  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') != a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') >  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') <  a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') >= a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'') <= a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&IN'    and concat(',',a2.func_01_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),''),',%') then '1'
                when nvl(a2.func_01_flag,'') = 'S&!IN'   and concat(',',a2.func_01_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),''),',%') then '1'
                when nvl(a2.func_01_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'')  like     a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_01_nm,if(substr(a2.func_01_coll_01,1,2)='S$',substr(a2.func_01_coll_01,3),a1.conn_cols[a2.func_01_coll_01]),if(substr(a2.func_01_coll_02,1,2)='S$',substr(a2.func_01_coll_02,3),a1.conn_cols[a2.func_01_coll_02]),if(substr(a2.func_01_coll_03,1,2)='S$',substr(a2.func_01_coll_03,3),a1.conn_cols[a2.func_01_coll_03]),if(substr(a2.func_01_coll_04,1,2)='S$',substr(a2.func_01_coll_04,3),a1.conn_cols[a2.func_01_coll_04]),if(substr(a2.func_01_coll_05,1,2)='S$',substr(a2.func_01_coll_05,3),a1.conn_cols[a2.func_01_coll_05]),if(substr(a2.func_01_coll_06,1,2)='S$',substr(a2.func_01_coll_06,3),a1.conn_cols[a2.func_01_coll_06]),if(substr(a2.func_01_coll_07,1,2)='S$',substr(a2.func_01_coll_07,3),a1.conn_cols[a2.func_01_coll_07]),if(substr(a2.func_01_coll_08,1,2)='S$',substr(a2.func_01_coll_08,3),a1.conn_cols[a2.func_01_coll_08])),'')  not like a2.func_01_val then '1'
                when nvl(a2.func_01_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_02_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') =  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') != a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') >  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') <  a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') >= a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'') <= a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&IN'    and concat(',',a2.func_02_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),''),',%') then '1'
                when nvl(a2.func_02_flag,'') = 'S&!IN'   and concat(',',a2.func_02_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),''),',%') then '1'
                when nvl(a2.func_02_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'')  like     a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_02_nm,if(substr(a2.func_02_coll_01,1,2)='S$',substr(a2.func_02_coll_01,3),a1.conn_cols[a2.func_02_coll_01]),if(substr(a2.func_02_coll_02,1,2)='S$',substr(a2.func_02_coll_02,3),a1.conn_cols[a2.func_02_coll_02]),if(substr(a2.func_02_coll_03,1,2)='S$',substr(a2.func_02_coll_03,3),a1.conn_cols[a2.func_02_coll_03]),if(substr(a2.func_02_coll_04,1,2)='S$',substr(a2.func_02_coll_04,3),a1.conn_cols[a2.func_02_coll_04]),if(substr(a2.func_02_coll_05,1,2)='S$',substr(a2.func_02_coll_05,3),a1.conn_cols[a2.func_02_coll_05]),if(substr(a2.func_02_coll_06,1,2)='S$',substr(a2.func_02_coll_06,3),a1.conn_cols[a2.func_02_coll_06]),if(substr(a2.func_02_coll_07,1,2)='S$',substr(a2.func_02_coll_07,3),a1.conn_cols[a2.func_02_coll_07]),if(substr(a2.func_02_coll_08,1,2)='S$',substr(a2.func_02_coll_08,3),a1.conn_cols[a2.func_02_coll_08])),'')  not like a2.func_02_val then '1'
                when nvl(a2.func_02_flag,'') = '' then '1'
                else '0'
           end = '1'
      and  case when nvl(a2.func_03_flag,'') = 'S&='     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') =  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&!='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') != a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&>'     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') >  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&<'     and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') <  a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&>='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') >= a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&<='    and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'') <= a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&IN'    and concat(',',a2.func_03_val,',') like     concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),''),',%') then '1'
                when nvl(a2.func_03_flag,'') = 'S&!IN'   and concat(',',a2.func_03_val,',') not like concat('%,',nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),''),',%') then '1'
                when nvl(a2.func_03_flag,'') = 'S&LIKE'  and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'')  like     a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = 'S&!LIKE' and nvl(dmf_bc.dmdictDesc(a2.func_03_nm,if(substr(a2.func_03_coll_01,1,2)='S$',substr(a2.func_03_coll_01,3),a1.conn_cols[a2.func_03_coll_01]),if(substr(a2.func_03_coll_02,1,2)='S$',substr(a2.func_03_coll_02,3),a1.conn_cols[a2.func_03_coll_02]),if(substr(a2.func_03_coll_03,1,2)='S$',substr(a2.func_03_coll_03,3),a1.conn_cols[a2.func_03_coll_03]),if(substr(a2.func_03_coll_04,1,2)='S$',substr(a2.func_03_coll_04,3),a1.conn_cols[a2.func_03_coll_04]),if(substr(a2.func_03_coll_05,1,2)='S$',substr(a2.func_03_coll_05,3),a1.conn_cols[a2.func_03_coll_05]),if(substr(a2.func_03_coll_06,1,2)='S$',substr(a2.func_03_coll_06,3),a1.conn_cols[a2.func_03_coll_06]),if(substr(a2.func_03_coll_07,1,2)='S$',substr(a2.func_03_coll_07,3),a1.conn_cols[a2.func_03_coll_07]),if(substr(a2.func_03_coll_08,1,2)='S$',substr(a2.func_03_coll_08,3),a1.conn_cols[a2.func_03_coll_08])),'')  not like a2.func_03_val then '1'
                when nvl(a2.func_03_flag,'') = '' then '1'
                else '0'
           end = '1'
;
""",

}

return_code = sql_task.execute_sqls(sql_map_01)

###################Added by renxiaowei7@20210819 结算特殊处理逻辑下沉 特殊逻辑处理 start########
#临时表-库表-定义
database_name_01 = 'dmf_tmp'
table_name_01 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_01'
table_name_02 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_02'
table_name_03 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_03'
table_name_04 = 'dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_04'

#sql模板01-获取结果表想要的字段
#提取公共字段，用于sql替换，否则脚本长度太长，可读性不好
sql_model_01= """
    desc {table_name_01}
"""
    
#sql模板02-获取拼sql-需要拼sql的sql主键及需要拼接的sql
sql_model_02= """
    set hive.auto.convert.join=true;
    set mapred.max.split.size=8000000;
    set mapred.min.split.size.per.node=8000000;
    set mapred.min.split.size.per.rack=8000000;
    set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
    set hive.merge.mapfiles = true;
    set hive.merge.size.per.task = 8000000;
    set mapreduce.input.fileinputformat.split.maxsize = 8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.node=8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.rack=8000000;
    
    select dmf_bc.getmd5(typecd,result_flag,result_val) as result_val_md5,result_val
    from {table_name_01}
    where result_flag not in ('S','F')
    group by dmf_bc.getmd5(typecd,result_flag,result_val),result_val
"""

#sql模板03-获取拼sql-固定部分逻辑
sql_model_03= """
    set hive.auto.convert.join=true;
    set mapred.max.split.size=8000000;
    set mapred.min.split.size.per.node=8000000;
    set mapred.min.split.size.per.rack=8000000;
    set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
    set hive.merge.mapfiles = true;
    set hive.merge.size.per.task = 8000000;
    set mapreduce.input.fileinputformat.split.maxsize = 8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.node=8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.rack=8000000;
    use {database_name_01};
    
    drop table if exists {table_name_02};
    create table {table_name_02}
    as
    select     {result_cols_sql}
              ,conn_cols,typecd,result_flag,result_sql
              ,result_val
    from {table_name_01}
    where nvl(result_flag,'') in ('S','F','')
"""

#sql模板04-获取拼sql-可变部分逻辑
sql_model_04= """
    select     {result_cols_sql}
              ,conn_cols,typecd,result_flag,result_sql
              ,nvl({spec_sql},'') as result_val
    from {table_name_01}
    where nvl(result_flag,'') not in ('S','F','')
      and dmf_bc.getmd5(typecd,result_flag,result_val) = '{unikey}'
"""

#sql模板05-获取拼sql-如果union all超过30则拆sql
sql_model_05="""
    ;
    insert into table {table_name_02}
    select     {result_cols_sql}
              ,conn_cols,typecd,result_flag,result_sql
              ,'' as result_val
    from {table_name_01}
    where 1 = 2
"""

#sql模板06-获取客商类型临时表sql-优化mapjoin-客商逻辑提前
sql_model_06="""
    set hive.auto.convert.join=true;
    set mapred.max.split.size=8000000;
    set mapred.min.split.size.per.node=8000000;
    set mapred.min.split.size.per.rack=8000000;
    set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
    set hive.merge.mapfiles = true;
    set hive.merge.size.per.task = 8000000;
    set mapreduce.input.fileinputformat.split.maxsize = 8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.node=8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.rack=8000000;
    use {database_name_01};
    
    drop table if exists {table_name_03};
    create table {table_name_03}
    as
    select a2.mercht_id,a2.mercht_typ
    from (select result_val
          from {table_name_02}
          where nvl(typeCd,'') in ('dmf_cust_ID7','dmf_cust_ID8')
            and nvl(result_val,'')!=''
          group by result_val
         ) a1
    left join (select mercht_id,mercht_typ
               from dmf_bc.dmfbc_bc_view_odm_fi_fin_subject_merchant_s_d  --客商类型映射表
               where dt = '{TX_DATE}'
              ) a2
           on  a1.result_val = a2.mercht_id
    ;
"""

#sql模板07-获取聚合数据的sql-下沉逻辑处理完成后
#Modified by renxiaowei7@20220617 添加sort_array排序逻辑
sql_model_07= """
    set hive.auto.convert.join=true;
    set mapred.max.split.size=8000000;
    set mapred.min.split.size.per.node=8000000;
    set mapred.min.split.size.per.rack=8000000;
    set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
    set hive.merge.mapfiles = true;
    set hive.merge.size.per.task = 8000000;
    set mapreduce.input.fileinputformat.split.maxsize = 8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.node=8000000;
    set mapreduce.input.fileinputformat.split.minsize.per.rack=8000000;
    set hive.execution.engine=mr;
    use {database_name_01};
    
    drop table if exists {table_name_04};
    create table {table_name_04}
    as
    select     {result_cols_sql}
              ,concat_ws(',',sort_array(collect_set(a1.typecd))) as spec_type_cd_new --下沉类型编码
              ,concat_ws(',',collect_list(concat(
                    a1.typecd
                   ,if(nvl(a1.typecd,'')!='',':','')
                   ,a1.result_val
                   ,case when nvl(a1.typecd,'') in ('dmf_cust_ID7','dmf_cust_ID8') then concat('&',a2.mercht_typ)
                         else ''
                    end
                ))) as conn_spe_cols
    from (select     {result_cols_sql}
                    ,'' as typecd
                    ,'' as result_val
          from {table_name_02}
          where nvl(result_val,'')=''
          union all
          select     {result_cols_sql}
                    ,typecd
                    ,case when typecd not in ('dmf_product') then max(result_val)  --除核算业务线外，如果映射配置表出现一条数据对应多个映射的，直接max取值
                          when typecd in ('dmf_product') then concat_ws('&',sort_array(collect_set(result_val)))
                          else ''
                     end as result_val
          from {table_name_02}
          where nvl(result_val,'') !=''
          group by   {result_cols_sql}
                    ,typecd
         ) a1
    left join  {table_name_03} a2
           on  a1.typeCd in ('dmf_cust_ID7','dmf_cust_ID8')
          and  a1.result_val = a2.mercht_id
    group by   {result_cols_sql}
"""

#sql模板08-获取拼sql-结算中间层&核算交易明细&字段映射关系获取
sql_model_08= """
    select from_col_str,to_col_str from dmf_add.dmfadd_finsetts_mdl_col_trans_a_d
"""


#下沉函数定义01-获取未进行下沉逻辑处理之前临时表的字段
def get_result_cols_sql():
    select_result_map = get_sys_config_data(sql_model_01.format(table_name_01=table_name_01))
    select_result_map_col = [cols[0].replace(' ','') for cols in select_result_map]
    result_cols_sql = '\n              ,'.join(select_result_map_col[0:-5])
    return result_cols_sql

#下沉函数定义02-获取使用python处理的下沉逻辑sql_map
def get_union_all_sql():
    #获取固定字段
    result_cols_sql = get_result_cols_sql()
    #获取拼sql
    union_all_sql_list = []
    #获取拼sql-固定部分逻辑
    sql_model_03_list = {}
    sql_model_03_list['database_name_01'] = database_name_01
    sql_model_03_list['table_name_01'] = table_name_01
    sql_model_03_list['table_name_02'] = table_name_02
    sql_model_03_list['result_cols_sql'] = result_cols_sql
    union_all_sql_list.append(sql_model_03.format(**sql_model_03_list))
    #获取拼sql-可变部分逻辑
    num = 0
    select_result_map = get_sys_config_data(sql_model_02.format(table_name_01=table_name_01))
    #结算中间层&核算交易明细&字段映射关系获取
    select_col_map = get_sys_config_data(sql_model_08)
    for cols in select_result_map:
        num += 1
        sql_model_04_list = {}
        sql_model_04_list['result_cols_sql'] = result_cols_sql
        sql_model_04_list['table_name_01'] = table_name_01
        sql_model_04_list['unikey'] = cols[0]
        spec_sql = cols[1]
        #结算中间层&核算交易明细&字段映射&循环替换
        for col_maps in select_col_map:
            col_01 = col_maps[0].replace('\n','')
            col_02 = col_maps[1].replace('\n','')
            spec_sql=spec_sql.replace('&'+col_01,'&'+col_02).replace(','+col_01,','+col_02).replace('('+col_01,'('+col_02).replace(' '+col_01,' '+col_02)
        sql_model_04_list['spec_sql'] = spec_sql
        if(num%30 == 0):
            union_all_sql_list.append(sql_model_04.format(**sql_model_04_list)+sql_model_05.format(table_name_01=table_name_01,table_name_02=table_name_02,result_cols_sql=result_cols_sql))
        else:
            union_all_sql_list.append(sql_model_04.format(**sql_model_04_list))
    
    #获取拼sql结果
    sql_31 = union_all_sql_list[0] if(len(union_all_sql_list)<=1) else 'union all'.join(union_all_sql_list)
    #获取客商类型临时表sql
    sql_model_06_list = {}
    sql_model_06_list['database_name_01'] = database_name_01
    sql_model_06_list['table_name_02'] = table_name_02
    sql_model_06_list['table_name_03'] = table_name_03
    sql_model_06_list['TX_DATE'] = sql_task._tx_date
    sql_32 = sql_model_06.format(**sql_model_06_list)
    #获取聚合数据的sql
    sql_model_07_list = {}
    sql_model_07_list['database_name_01'] = database_name_01
    sql_model_07_list['table_name_02'] = table_name_02
    sql_model_07_list['table_name_03'] = table_name_03
    sql_model_07_list['table_name_04'] = table_name_04
    sql_model_07_list['result_cols_sql'] = result_cols_sql
    sql_33 = sql_model_07.format(**sql_model_07_list)
    #下沉特殊处理sql放入sql_map
    sql_map = {}
    sql_map['sql_31']=sql_31
    sql_map['sql_32']=sql_32
    sql_map['sql_33']=sql_33
    return sql_map
    
#执行下沉函数定义02，获取下沉逻辑需要执行的sql_map
sql_map_02 = get_union_all_sql()
return_code = sql_task.execute_sqls(sql_map_02)

###################Added by renxiaowei7@20210819 结算特殊处理逻辑下沉 特殊逻辑处理 end  ########


sql_map_03={

#20210701 renxiaowei7 按月跑数逻辑修改
"sql_41": """
set hive.auto.convert.join=true;
set mapred.max.split.size=8000000;
set mapred.min.split.size.per.node=8000000;
set mapred.min.split.size.per.rack=8000000;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.merge.mapfiles = true;
set hive.merge.size.per.task = 8000000;
set mapreduce.input.fileinputformat.split.maxsize = 8000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=8000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=8000000;
use dmf_bc;

alter table dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d drop partition(dt >= '{START_DATE}',dt <= '{TX_DATE}');
insert overwrite table dmf_bc.dmfbc_bc_fi_fst_indx_mdl_dtl_i_d partition(dt)
select     model_id              -- 财务核算中间表模型编号
          ,indx_id               -- 指标编号
          ,src_sys               -- 数据来源系统
          ,src_tab               -- 数据来源表
          ,change_flag           -- 数据标识
          ,rev_data_orig_dt      -- 冲销数据源数据分区
          -- Modified by machunliang@20211022 解决部分配置表中没有填写indx_id的问题
          -- ,concat(indx_id, '-', data_unikey) as data_unikey           -- 数据唯一键
          ,concat(biz_typ, '-', cap_typ, '-', data_unikey) as data_unikey           -- 数据唯一键
          ,accti_biz_line_cd     -- 核算业务线
          ,accti_prod_cd         -- 核算业务线产品
          ,tx_tm                 -- 交易时间
          ,tx_amt                -- 交易金额
          ,biz_typ               -- 指标业务类型
          ,cap_typ               -- 指标资金类型
          ,currency              -- 币种
          ,corp_ids              -- 主体（主体）id
          ,corp_mercht_ids       -- 主体（客商）id
          ,corp_nms              -- 主体名称
          ,corp_role_typ         -- 主体角色类型
          ,mercht_ids            -- 客商ID
          ,mercht_nms            -- 客商名称
          ,mercht_typs           -- 客商类型MAP
          
          ,acct_id        [acct_dir_sign0]    as recv_acct_id          -- 收款账户主数据ID
          ,bank_acct_no   [acct_dir_sign0]    as recv_bank_acct_no     -- 收款账户账号
          ,acct_brvt_cd   [acct_dir_sign0]    as recv_acct_brvt_cd     -- 收款账户简码
          ,acct_mercht_id [acct_dir_sign0]    as recv_acct_mercht_id   -- 收款账户客商ID
          ,acct_corp_nm   [acct_dir_sign0]    as recv_acct_corp_nm     -- 收款账户公司名称
          ,acct_dpst_charc[acct_dir_sign0]    as recv_acct_dpst_charc  -- 收款账户存款性质
          
          ,acct_id        [acct_dir_sign1]    as pay_acct_id           -- 付款账户主数据ID
          ,bank_acct_no   [acct_dir_sign1]    as pay_bank_acct_no      -- 付款账户账号
          ,acct_brvt_cd   [acct_dir_sign1]    as pay_acct_brvt_cd      -- 付款账户简码
          ,acct_mercht_id [acct_dir_sign1]    as pay_acct_mercht_id    -- 付款账户客商ID
          ,acct_corp_nm   [acct_dir_sign1]    as pay_acct_corp_nm      -- 付款账户公司名称
          ,acct_dpst_charc[acct_dir_sign1]    as pay_acct_dpst_charc   -- 付款账户存款性质
          
          ,linkg_acct_vals[0]   as linkg_acct_id            -- 联动账户主数据ID
          ,linkg_acct_vals[1]   as linkg_bank_acct_no       -- 联动账户账号
          ,linkg_acct_vals[2]   as linkg_acct_brvt_cd       -- 联动账户简码
          ,linkg_acct_vals[3]   as linkg_acct_mercht_id     -- 联动账户客商ID
          ,linkg_acct_vals[4]   as linkg_acct_corp_nm       -- 联动账户公司名称
          ,linkg_acct_vals[5]   as linkg_acct_dpst_charc    -- 联动账户存款性质
          ,linkg_acct_vals[6]   as Linkg_Acct_Recv_Pay_Drct -- 联动账户收支方向
          ,sett_id               -- 结算单号
          ,fee_id                -- 费用单号
          ,fst_biz_typ           -- 结算业务类型
          ,Fst_sett_Scen         -- 结算场景
          ,fst_fee_typ           -- 结算费用类型
          ,pay_id                -- 支付单号
          ,plat_id               -- 收付款平台编号
          ,biz_pay_id            -- 业务打款编号
          ,biz_ids               -- 业务单号集合
          ,tax_rate              -- 税率
          ,contr_id              -- 合同编码
          ,proj_id               -- 项目编码
          ,cret_tm               -- 创建时间
          ,modi_tm               -- 修改时间
          ,prod_id               -- 产品id
          ,prod_nm               -- 产品名称
          ,cust_id               -- 客户id
          ,cust_nm               -- 客户名称
          ,origin_id             -- 原始id
          ,ordr_id               -- 订单编号
          ,is_cntn_tax           -- 是否含税
          ,cap_acct_chk_stat     -- 资金对账状态
          ,biz_tm                -- 业务时间
          ,pay_tm                -- 支付时间
          ,acct_chk_tm           -- 对账时间
          ,fst_tm                -- 结算时间
          ,stmt_no               -- 对账单号
          ,str_to_map(concat_ws(',' 
                          --,concat('src_tab:', src_tab) 
                          --,concat('fst_biz_typ:', fst_biz_typ) 
                          --,concat('fst_sett_scen:', fst_sett_scen) 
                          --,concat('fst_fee_typ:', fst_fee_typ) 
                          --,concat('sett_stat:', sett_stat) 
                          --,concat('fee_stat:', fee_stat) 
                          -- Added by machunliang@20210610 增加账户性质
                          ,concat('recv_acct_nature:', Acct_Nature[acct_dir_sign0]) 
                          ,concat('pay_acct_nature:', Acct_Nature[acct_dir_sign1]) 
                          ,concat('recv_acct_nature_hs:', Acct_Nature_hs[acct_dir_sign0]) 
                          ,concat('pay_acct_nature_hs:', Acct_Nature_hs[acct_dir_sign1]) 
                          ,concat('source_id:', source_id) 
                          -- 增加计费和结算方向
                          ,concat('direction:', direction) 
                          ,concat('sett_direction:', sett_direction) 
                          ,concat('tax_rate:', tax_rate) 
                          -- Modified by machunliang@20211019 增加客商角色取客商ID动态变量
                          -- ,concat('cust_mercht_id:', bal_mercht_id) 
                          ,concat('cust_mercht_id:', NVL(bal_mercht_id, str_to_map(mercht_ids)['Merchant'])) 
                          -- 增加王雪的需求处理：客商类型做条件
                          -- ,concat('cust_mercht_typ:', if(src_tab = 'dmfbc_bc_fi_fst_fee_detail_i_d' and fst_fee_typ in ('51411', '51412'), str_to_map(mercht_typs)['Merchant'] , null)) 
                          ,concat('cust_mercht_typ:', str_to_map(mercht_typs)['Merchant']) 
                          -- Modified by machunliang@20210816 处理206业务扩展字段取值
                          ,concat('SellChannelType:', ex5_SellChannelType) 
                          ,concat('accti_prod_cd:', accti_prod_cd) 
                          -- Added by machunliang@20210924 增加455业务的票据主体取SPV的标识
                          ,concat('spv_455_pj:', case when fst_biz_typ = '455' and prod_id like '%PJ%' then '1'
                                                      when fst_biz_typ = '455' and prod_id not like '%PJ%' then '0'
                                                      else null 
                                                  end
                                 )
                          -- Added by machunliang@20210930 30240这个场景 在spv集成一部分 在赊销白条集成一部分，用下面条件参数区分
                          ,concat('spv_cust_xt:', IF(fst_sett_scen = '30240', spv_cust_xt, null))
                          -- Added by machunliang@20211009 立新需求，针对 biz_type='302' and sett_scenes in ('30241') 指定主体来集成
                          ,concat('comp_mercht_id:', case when fst_biz_typ = '302' and fst_sett_scen in ('30241') then str_to_map(corp_mercht_ids)['OprMain']
                                                          else null 
                                                     end
                                 )
                          ,concat('dept_id:', dept_id)
                          -- Added by machunliang@20211124 增加 20121费项的客户账户id分类标识
                          ,concat('cust_id_20121_sign:', 
                                    case when fst_fee_typ = '20121' and cust_id in ('1001578') then '1'
                                         when fst_fee_typ = '20121' and cust_id not in ('1001578') then '0'
                                     end
                                 )
                          ,concat('ex_one:'  , ex_one  )
                          ,concat('ex_two:'  , ex_two  )
                          ,concat('ex_three:', ex_three)
                          ,concat('ex_four:' , ex_four )
                          ,concat('ex_five:' , ex_five )
                          ,concat('ex_six:'  , ex_six  )
                          ,concat('ex_seven:', ex_seven)
                          ,concat('ex_eight:', ex_eight)
                          ,concat('ex_nine:' , ex_nine )
                          ,concat('ex_ten:'  , if(coalesce(ex_ten,'')='','noDim',ex_ten) ) --Modified by renxiaowei7@20220623 为了让锦钰能单独获取为空的部分，这里先这么处理 
           )) as conn_cols
          ,writeoff_status
          ,sett_stat
          ,fee_stat
          -- Added by machunliang@20210610 增加账户性质，暂时先不加物理字段
          -- ,Acct_Nature[acct_dir_sign0]    as recv_acct_nature  -- 收款账户性质
          -- ,Acct_Nature[acct_dir_sign1]    as pay_acct_nature   -- 付款账户性质
          -- ,source_id             -- 计费来源
          --结算特殊处理逻辑下沉
          ,dept_id       --部门         Added by renxiaowei7@20210819
          ,spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
          ,dt  -- Added by renxiaowei7@20210701
from (select     t2.model_id                  -- 财务核算中间表模型编号
                ,t2.indx_id                   -- 指标编号
                ,t1.src_sys                   -- 数据来源系统
                ,t1.src_tab                   -- 数据来源表
                ,t1.change_flag               -- 数据标识
                ,t1.rev_data_orig_dt          -- 冲销数据源数据分区
                ,t1.data_unikey               -- 数据唯一键
                -- Modified by machunliang@20210708 增加支持函数取业务线
                -- ,NVL(t1.accti_biz_line_cd, biz_map.accti_biz_lvl3_cd) as accti_biz_line_cd   -- 核算业务线
                -- ,NVL(t1.accti_prod_cd,     biz_map.accti_biz_prod_cd) as accti_prod_cd       -- 核算业务线产品
                -- Modified by renxiaowei7@20210914 核算业务线通过核算产品取，并且全部从结算底层取，这里不兜底
                -- ,dmf_bc.dmdictdesc('BUSI_TYPE_3_2',if(nvl(t1.accti_prod_cd,'')='',nvl(t3.product_no,''),t1.accti_prod_cd),'{TXDATE}') as accti_biz_line_cd -- 核算业务线
                -- ,if(nvl(t1.accti_prod_cd,'')='',nvl(t3.product_no,''),t1.accti_prod_cd) as accti_prod_cd  -- 核算业务线产品
                --Modified by renxiaowei7@20221227 添加 基金代销-按【sku信息字段】动态映射业务线，关联金蝶业务线编码 逻辑
                ,dmf_bc.dmdictdesc('BUSI_TYPE_3_2'
                                  ,case when nvl(t4.product_no,'')!='' then t4.product_no
                                        when nvl(t1.accti_prod_cd,'')='' then nvl(t3.product_no,'')
                                        else t1.accti_prod_cd  --核算业务线产品
                                   end
                                  ,'{TXDATE}'
                                  ) as accti_biz_line_cd -- 核算业务线
                ,case when nvl(t4.product_no,'')!='' then t4.product_no
                      when nvl(t1.accti_prod_cd,'')='' then nvl(t3.product_no,'')
                      else t1.accti_prod_cd
                 end as accti_prod_cd  --核算业务线产品
                ,t1.tx_tm                     -- 交易时间
                -- 如果配置表中指定账户反向取值，则金额交换正负
                -- ,t1.tx_amt                    -- 交易金额
                -- ,if (Recv_Pay_Acct_Get_Val_Ind in ('1'), -1, 1) * t1.tx_amt as tx_amt     -- 交易金额
                --Modified by renxiaowei7@20220113 添加金额判断，结算计费明细中，如果配置表中配置的要取sett的金额，则按下述逻辑处理，其余全部取默认金额
                --  处理逻辑 case when(sett_direction=direction) then amount else -1*amount end as trans_amt
                ,if(t2.amt_dir_type='sett',t1.bal_dir_sign,1) * RecvPay_Amt_Parm * t1.tx_amt as tx_amt     -- 交易金额
                ,t2.biz_typ                   -- 指标业务类型
                ,t2.cap_typ                   -- 指标资金类型
                ,t1.currency                  -- 币种
                -- 主客体
                 -- ---------------------------- 主体ID -------------------------
                ,concat(
                   NVL(if (NVL(t2.Corp_01_Role_Typ, '') = '', '',
                       concat(t2.Corp_01_Role_Typ, ':', 
                             if (t2.Corp_01_Src like '#FIX:%', 
                                     split(substr(t2.Corp_01_Src, 6, 100), ',')[0], 
                                     str_to_map(t1.principal_company_customer_ids, '&', '#')[t2.Corp_01_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_02_Role_Typ, '') = '', '',
                       concat(t2.Corp_02_Role_Typ, ':', 
                             if (t2.Corp_02_Src like '#FIX:%', 
                                     split(substr(t2.Corp_02_Src, 6, 100), ',')[0], 
                                     str_to_map(t1.principal_company_customer_ids, '&', '#')[t2.Corp_02_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_03_Role_Typ, '') = '', '',
                       concat(t2.Corp_03_Role_Typ, ':', 
                             if (t2.Corp_03_Src like '#FIX:%', 
                                     split(substr(t2.Corp_03_Src, 6, 100), ',')[0], 
                                     str_to_map(t1.principal_company_customer_ids, '&', '#')[t2.Corp_03_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_04_Role_Typ, '') = '', '',
                       concat(t2.Corp_04_Role_Typ, ':', 
                             if (t2.Corp_04_Src like '#FIX:%', 
                                     split(substr(t2.Corp_04_Src, 6, 100), ',')[0], 
                                     str_to_map(t1.principal_company_customer_ids, '&', '#')[t2.Corp_04_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_05_Role_Typ, '') = '', '',
                       concat(t2.Corp_05_Role_Typ, ':', 
                             if (t2.Corp_05_Src like '#FIX:%', 
                                     split(substr(t2.Corp_05_Src, 6, 100), ',')[0], 
                                     str_to_map(t1.principal_company_customer_ids, '&', '#')[t2.Corp_05_Src]
                                 ),
                             ','
                            )
                      ), '')
                 ) as Corp_IDs
                
                 -- ---------------------------- 主体客商ID -------------------------
                ,concat(
                   NVL(if (NVL(t2.Corp_01_Role_Typ, '') = '', '',
                       concat(t2.Corp_01_Role_Typ, ':', 
                             if (t2.Corp_01_Src like '#FIX:%', 
                                     split(substr(t2.Corp_01_Src, 6, 100), ',')[1], 
                                     str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_01_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_02_Role_Typ, '') = '', '',
                       concat(t2.Corp_02_Role_Typ, ':', 
                             if (t2.Corp_02_Src like '#FIX:%', 
                                     split(substr(t2.Corp_02_Src, 6, 100), ',')[1], 
                                     str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_02_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_03_Role_Typ, '') = '', '',
                     concat(t2.Corp_03_Role_Typ, ':', 
                             if (t2.Corp_03_Src like '#FIX:%', 
                                     split(substr(t2.Corp_03_Src, 6, 100), ',')[1], 
                                     str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_03_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_04_Role_Typ, '') = '', '',
                       concat(t2.Corp_04_Role_Typ, ':', 
                             if (t2.Corp_04_Src like '#FIX:%', 
                                     split(substr(t2.Corp_04_Src, 6, 100), ',')[1], 
                                     str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_04_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_05_Role_Typ, '') = '', '',
                       concat(t2.Corp_05_Role_Typ, ':', 
                             if (t2.Corp_05_Src like '#FIX:%', 
                                     split(substr(t2.Corp_05_Src, 6, 100), ',')[1], 
                                     str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_05_Src]
                                 ),
                             ','
                            )
                      ), '')
                 ) as Corp_mercht_ids
                
                 -- ---------------------------- 主体名称 -------------------------
                ,concat(
                   NVL(if (NVL(t2.Corp_01_Role_Typ, '') = '', '',
                       concat(t2.Corp_01_Role_Typ, ':', 
                             if (t2.Corp_01_Src like '#FIX:%', 
                                     split(substr(t2.Corp_01_Src, 6, 100), ',')[2], 
                                     str_to_map(t1.principal_company_customer_names, '&', '#')[t2.Corp_01_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_02_Role_Typ, '') = '', '',
                       concat(t2.Corp_02_Role_Typ, ':', 
                             if (t2.Corp_02_Src like '#FIX:%', 
                                     split(substr(t2.Corp_02_Src, 6, 100), ',')[2], 
                                     str_to_map(t1.principal_company_customer_names, '&', '#')[t2.Corp_02_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_03_Role_Typ, '') = '', '',
                       concat(t2.Corp_03_Role_Typ, ':', 
                             if (t2.Corp_03_Src like '#FIX:%', 
                                     split(substr(t2.Corp_03_Src, 6, 100), ',')[2], 
                                     str_to_map(t1.principal_company_customer_names, '&', '#')[t2.Corp_03_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_04_Role_Typ, '') = '', '',
                       concat(t2.Corp_04_Role_Typ, ':', 
                             if (t2.Corp_04_Src like '#FIX:%', 
                                     split(substr(t2.Corp_04_Src, 6, 100), ',')[2], 
                                     str_to_map(t1.principal_company_customer_names, '&', '#')[t2.Corp_04_Src]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Corp_05_Role_Typ, '') = '', '',
                       concat(t2.Corp_05_Role_Typ, ':', 
                             if (t2.Corp_05_Src like '#FIX:%', 
                                     split(substr(t2.Corp_05_Src, 6, 100), ',')[2], 
                                     str_to_map(t1.principal_company_customer_names, '&', '#')[t2.Corp_05_Src]
                                 ),
                             ','
                            )
                      ), '')
                 ) as Corp_Nms
                
                ,'' as Corp_role_typ       -- 主体角色类型
                
                 -- ---------------------------- 客体ID -------------------------
                ,concat(
                   NVL(if (NVL(t2.Mercht_01_Role_Typ, '') = '', '',
                       concat(t2.Mercht_01_Role_Typ, ':', 
                             if (t2.Mercht_01_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_01_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_01_Src], ',',':')[t2.Mercht_01_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_02_Role_Typ, '') = '', '',
                       concat(t2.Mercht_02_Role_Typ, ':', 
                             if (t2.Mercht_02_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_02_Src, 6, 100), ',')[0], 
                                     -- ------------------------------客商特殊处理--------------------
                                     case 
                                          --1、猫酷业务客商特殊逻辑 renxiaowei7 20210324 start-------------------------------
                                          when t2.fst_biz_typ = '704'
                                          then case 
                                                   --1.1、财付通支付科技有限公司 部分摘要，主体客商ID=客体客商ID，则客体客商ID取 1006432|财付通支付科技有限公司
                                                   when str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_01_Src] 
                                                         = str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID]
                                                    then '1006432'
                                                   --1.2、摘要"计提运营业务-无票服务收入"：
                                                   --  客商名称=[支付宝（中国）网络技术有限公司]，按照实际客商名称
                                                   --  客商名称≠[支付宝（中国）网络技术有限公司]，写死为[财付通支付科技有限公司]
                                                   when t1.src_tab = 'dmfbc_bc_fi_fst_fee_detail_i_d' and t1.fst_fee_typ = '70451'
                                                   then case when str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID] = '1059467' 
                                                             then '1059467'
                                                             else '1006432'
                                                        end
                                                   --默认值和客商整体默认值一致
                                                    else str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID]
                                              end
                                         --1、猫酷业务客商特殊逻辑 renxiaowei7 20210324 end---------------------------------
                                         else str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID]
                                     end
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_03_Role_Typ, '') = '', '',
                       concat(t2.Mercht_03_Role_Typ, ':', 
                             if (t2.Mercht_03_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_03_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_03_Src], ',',':')[t2.Mercht_03_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_04_Role_Typ, '') = '', '',
                       concat(t2.Mercht_04_Role_Typ, ':', 
                             if (t2.Mercht_04_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_04_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_04_Src], ',',':')[t2.Mercht_04_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_05_Role_Typ, '') = '', '',
                       concat(t2.Mercht_05_Role_Typ, ':', 
                             if (t2.Mercht_05_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_05_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_05_Src], ',',':')[t2.Mercht_05_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_06_Role_Typ, '') = '', '',
                       concat(t2.Mercht_06_Role_Typ, ':', 
                             if (t2.Mercht_06_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_06_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_06_Src], ',',':')[t2.Mercht_06_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_07_Role_Typ, '') = '', '',
                       concat(t2.Mercht_07_Role_Typ, ':', 
                             if (t2.Mercht_07_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_07_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_07_Src], ',',':')[t2.Mercht_07_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_08_Role_Typ, '') = '', '',
                       concat(t2.Mercht_08_Role_Typ, ':', 
                             if (t2.Mercht_08_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_08_Src, 6, 100), ',')[0],  
                                     str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_08_Src], ',',':')[t2.Mercht_08_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_09_Role_Typ, '') = '', '',
                       concat(t2.Mercht_09_Role_Typ, ':', 
                             if (t2.Mercht_09_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_09_Src, 6, 100), ',')[0],  
                                     -- Modified by machunliang@20210616 解决从多个ID-X取值的问题
                                     -- str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID]
                                     coalesce(str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_1],
                                              str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_2],
                                              str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_3],
                                              str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_4]
                                             )
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_10_Role_Typ, '') = '', '',
                       concat(t2.Mercht_10_Role_Typ, ':', 
                             if (t2.Mercht_10_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_10_Src, 6, 100), ',')[0],  
                                     -- Modified by machunliang@20210616 解决从多个ID-X取值的问题
                                     -- str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID]
                                     coalesce(str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_1],
                                              str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_2],
                                              str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_3],
                                              str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_4]
                                             )
                                 ),
                             ','
                            )
                      ), '')
                
                 ) as mercht_ids              -- 客商ID
                ,mercht_nms                   -- 客商名称
                -- ,mercht_typs               -- 客商类型MAP     取值 ：merchant_typ_all_src
                 -- ---------------------------- 客体类型 -------------------------
                ,concat(
                   NVL(if (NVL(t2.Mercht_01_Role_Typ, '') = '', '',
                       concat(t2.Mercht_01_Role_Typ, ':', 
                             if (t2.Mercht_01_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_01_Src, 6, 100), ',')[2],
                                     -- str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_01_Src], ',',':')[t2.Mercht_01_ID]
                                     NVL(str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_01_Src], ',',':')[t2.Mercht_01_ID],
                                         str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_01_Src], ',',':')['ORIG'])
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_02_Role_Typ, '') = '', '',
                       concat(t2.Mercht_02_Role_Typ, ':', 
                             if (t2.Mercht_02_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_02_Src, 6, 100), ',')[2], 
                                     -- ------------------------------客商特殊处理--------------------
                                     case 
                                          --renxiaowei7 20210324 财付通支付科技有限公司 部分摘要，主体客商ID=客体客商ID，则客体客商ID取 1006432|财付通支付科技有限公司
                                          when t2.fst_biz_typ = '704'
                                               and str_to_map(t1.principal_company_merchant_ids, '&', '#')[t2.Corp_01_Src] 
                                                   = str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID]
                                          then '1006432'
                                          else -- str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID]
                                               NVL(str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')[t2.Mercht_02_ID],
                                                   str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_02_Src], ',',':')['ORIG'])
                                     end
                                     
                                     
                                 ),
                             ','
                            )
                       ), ''),
                
                   NVL(if (NVL(t2.Mercht_03_Role_Typ, '') = '', '',
                       concat(t2.Mercht_03_Role_Typ, ':', 
                             if (t2.Mercht_03_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_03_Src, 6, 100), ',')[2],  
                                     -- str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_03_Src], ',',':')[t2.Mercht_03_ID]
                                     NVL(str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_03_Src], ',',':')[t2.Mercht_03_ID],
                                         str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_03_Src], ',',':')['ORIG'])
                                 ),
                             ','
                            )
                       ), ''),
                
                   NVL(if (NVL(t2.Mercht_04_Role_Typ, '') = '', '',
                       concat(t2.Mercht_04_Role_Typ, ':', 
                             if (t2.Mercht_04_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_04_Src, 6, 100), ',')[2],  
                                     -- str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_04_Src], ',',':')[t2.Mercht_04_ID]
                                     NVL(str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_04_Src], ',',':')[t2.Mercht_04_ID],
                                         str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_04_Src], ',',':')['ORIG'])
                                 ),
                             ','
                            )
                       ), ''),
                
                   NVL(if (NVL(t2.Mercht_05_Role_Typ, '') = '', '',
                       concat(t2.Mercht_05_Role_Typ, ':', 
                             if (t2.Mercht_05_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_05_Src, 6, 100), ',')[2],  
                                     str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_05_Src], ',',':')[t2.Mercht_05_ID]
                                 ),
                             ','
                            )
                       ), ''),
                
                   NVL(if (NVL(t2.Mercht_06_Role_Typ, '') = '', '',
                       concat(t2.Mercht_06_Role_Typ, ':', 
                             if (t2.Mercht_06_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_06_Src, 6, 100), ',')[2],  
                                     str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_06_Src], ',',':')[t2.Mercht_06_ID]
                                 ),
                             ','
                            )
                       ), ''),
                
                   NVL(if (NVL(t2.Mercht_07_Role_Typ, '') = '', '',
                       concat(t2.Mercht_07_Role_Typ, ':', 
                             if (t2.Mercht_07_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_07_Src, 6, 100), ',')[2],  
                                     str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_07_Src], ',',':')[t2.Mercht_07_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_08_Role_Typ, '') = '', '',
                       concat(t2.Mercht_08_Role_Typ, ':', 
                             if (t2.Mercht_08_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_08_Src, 6, 100), ',')[2],  
                                     str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_08_Src], ',',':')[t2.Mercht_08_ID]
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_09_Role_Typ, '') = '', '',
                       concat(t2.Mercht_09_Role_Typ, ':', 
                             if (t2.Mercht_09_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_09_Src, 6, 100), ',')[2],  
                                     -- Modified by machunliang@20210616 解决从多个ID-X取值的问题
                                     -- str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID]
                                     coalesce(str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_1],
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_2],
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_3],
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_09_Src], ',',':')[t2.Mercht_09_ID_4]
                                             )
                                 ),
                             ','
                            )
                      ), ''),
                
                   NVL(if (NVL(t2.Mercht_10_Role_Typ, '') = '', '',
                       concat(t2.Mercht_10_Role_Typ, ':', 
                             if (t2.Mercht_10_Src like '#FIX:%', 
                                     split(substr(t2.Mercht_10_Src, 6, 100), ',')[2],  
                                     -- Modified by machunliang@20210616 解决从多个ID-X取值的问题
                                     -- str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID]
                                     coalesce(str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_1], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_2], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_3], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_4], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_5], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_6], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_7], 
                                              str_to_map(str_to_map(t1.merchant_typ_all_src, '&', '#')[t2.Mercht_10_Src], ',',':')[t2.Mercht_10_ID_8] 
                                              )
                                 ),
                             ','
                            )
                       ), '')
                
                 ) as mercht_typs               -- 客商ID
                
                ,merchant_id_all_src
                -- 账户：正常情况（Recv_Pay_Acct_Get_Val_Ind=0）， direction=0：主体账户->收款账户（借方）， 客体账户->付款账户（贷方）
                -- ,cast(abs(    cast(Recv_Pay_Acct_Get_Val_Ind as int) - sett_dir_sign) as string) as acct_dir_sign0
                -- ,cast(abs(1 - cast(Recv_Pay_Acct_Get_Val_Ind as int) - sett_dir_sign) as string) as acct_dir_sign1
                -- Modified by renxiaowei7@20220113 生成配置表添加字段sett_fee_dir_type用来控制结算计费明细表使用哪个方向字段来加工银行账户
                ,cast(abs(    t2.RecvPay_Dir_Sign - if(t2.sett_fee_dir_type='sett',t1.sett_dir_sign,t1.fee_dir_sign)) as string) as acct_dir_sign0
                ,cast(abs(1 - t2.RecvPay_Dir_Sign - if(t2.sett_fee_dir_type='sett',t1.sett_dir_sign,t1.fee_dir_sign)) as string) as acct_dir_sign1
                ,split(t2.linkg_Acct_Get_Val_Ind, ',')   as linkg_acct_vals    -- 联动账户取值标识
                ,Acct_ID                      -- 账户主数据ID
                ,Bank_Acct_No                 -- 账户账号
                ,Acct_Brvt_Cd                 -- 账户简码
                ,Acct_Mercht_ID               -- 账户客商ID
                ,Acct_Corp_Nm                 -- 账户公司名称
                ,Acct_Dpst_Charc              -- 账户存款性质
                ,Acct_Nature                  -- 账户性质
                ,Acct_Nature_hs               -- 账户性质
                -- 结算其他字段
                ,t1.sett_id                   -- 结算单号
                ,t1.fee_id                    -- 费用单号
                ,t1.fst_biz_typ               -- 结算业务类型
                ,t1.fst_sett_scen             -- 结算场景
                ,t1.fst_fee_typ               -- 结算费用类型
                ,t1.pay_id                    -- 支付单号
                ,t1.plat_id                   -- 收付款平台编号
                ,t1.biz_pay_id                -- 业务打款编号
                ,t1.biz_ids                   -- 业务单号集合
                ,t1.tax_rate                  -- 税率
                ,t1.contr_id                  -- 合同编码
                ,t1.proj_id                   -- 项目编码
                ,t1.cret_tm                   -- 创建时间
                ,t1.modi_tm                   -- 修改时间
                ,t1.prod_id                   -- 产品id
                ,t1.prod_nm                   -- 产品名称
                ,t1.cust_id                   -- 客户id
                ,t1.cust_nm                   -- 客户名称
                ,t1.origin_id                 -- 原始id
                ,t1.ordr_id                   -- 订单编号
                ,t1.is_cntn_tax               -- 是否含税
                ,t1.cap_acct_chk_stat         -- 资金对账状态
                ,t1.biz_tm                    -- 业务时间
                ,t1.pay_tm                    -- 支付时间
                ,t1.acct_chk_tm               -- 对账时间
                ,t1.fst_tm                    -- 结算时间
                ,t1.stmt_no                   -- 对账单号
                ,t1.source_id                 -- 计费来源
                -- 其他加工字段
                ,case when change_flag = '6' then 'WRITEOFF'
                      else 'NORMAL'
                 end as writeoff_status       --'冲销标识 NORMAL-正常,WRITEOFF-被冲销'
                ,t1.sett_stat                 -- 结算单状态
                ,t1.fee_stat                  -- 计费明细状态
                ,t1.direction
                ,t1.sett_direction
                ,t1.dt
                ,t1.ex_one
                ,t1.ex_two
                ,t1.ex_three
                ,t1.ex_four
                ,t1.ex_five
                ,t1.ex_six
                ,t1.ex_seven
                ,t1.ex_eight
                ,t1.ex_nine
                ,t1.ex_ten
                -- 针对 莎莎的计算信托客商的投资规模的的需求，要按客商做条件，此处加工
                ,if(t1.src_tab = 'dmfbc_bc_fi_fst_bal_s_d', str_to_map(str_to_map(t1.merchant_id_all_src, '&', '#')['fee'], ',',':')['ID-8'], null) as bal_mercht_id
                -- Modified by machunliang@20210816 处理206业务扩展字段取值
                ,t1.ex5_SellChannelType
                -- Added by machunliang@20210930
                ,t1.spv_cust_xt
                --结算特殊处理逻辑下沉
                ,t1.dept_id       --部门         Added by renxiaowei7@20210819
                ,t1.spec_type_cd  --下沉类型编码 Added by renxiaowei7@20210913
      from (--产品已处理
            select     dt,model_id,indx_id,src_sys,src_tab,src_tab1,change_flag,rev_data_orig_dt,data_unikey
                      ,accti_prod_cd
                      ,tx_tm,tx_amt,biz_typ,cap_typ,currency,corp_ids,corp_mercht_ids,corp_nms,corp_role_typ,mercht_ids,mercht_nms,mercht_typs,sett_customer_name_merchant_id_all_src,fee_customer_name_merchant_id_all_src,principal_company_customer_ids,principal_company_merchant_ids,principal_company_customer_names,merchant_id_all_src,merchant_typ_all_src,direction,sett_direction,fee_dir_sign,sett_dir_sign,bal_dir_sign,acct_id,bank_acct_no,acct_brvt_cd,acct_mercht_id,acct_corp_nm,acct_dpst_charc,acct_nature,acct_nature_hs,sett_id,fee_id,fst_biz_typ,fst_sett_scen,fst_fee_typ,pay_id,plat_id,biz_pay_id,biz_ids
                      ,tax_rate
                      ,contr_id,cret_tm,modi_tm,prod_id,prod_nm,cust_id,cust_nm,sett_stat,fee_stat,origin_id,ordr_id,is_cntn_tax,cap_acct_chk_stat,biz_tm,pay_tm,acct_chk_tm,fst_tm,stmt_no,source_id,yn_flag,proj_id,ex5_sellchanneltype,spv_cust_xt,dept_id,spec_type_cd
                      ,ex_one,ex_two,ex_three,ex_four,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_fifteen
            from dmf_tmp.tmp_dmfbc_bc_fi_fst_indx_mdl_dtl
            where not (nvl(accti_prod_cd,'')='' or nvl(tax_rate,'')='')
            union all
            --产品兜底
            select     dt,model_id,indx_id,src_sys,src_tab,src_tab1,change_flag,rev_data_orig_dt,data_unikey
                      ,if(nvl(t1.accti_prod_cd,'')!='',t1.accti_prod_cd,t2.accti_prod_cd_sub) as accti_prod_cd
                      ,tx_tm,tx_amt,biz_typ,cap_typ,currency,corp_ids,corp_mercht_ids,corp_nms,corp_role_typ,mercht_ids,mercht_nms,mercht_typs,sett_customer_name_merchant_id_all_src,fee_customer_name_merchant_id_all_src,principal_company_customer_ids,principal_company_merchant_ids,principal_company_customer_names,merchant_id_all_src,merchant_typ_all_src,direction,sett_direction,fee_dir_sign,sett_dir_sign,bal_dir_sign,acct_id,bank_acct_no,acct_brvt_cd,acct_mercht_id,acct_corp_nm,acct_dpst_charc,acct_nature,acct_nature_hs,sett_id,fee_id,fst_biz_typ,fst_sett_scen,fst_fee_typ,pay_id,plat_id,biz_pay_id,biz_ids
                      ,if(conn_spe_cols like '%dmf_tax%',str_to_map(conn_spe_cols)['dmf_tax'],tax_rate) as tax_rate
                      ,contr_id,cret_tm,modi_tm,prod_id,prod_nm,cust_id,cust_nm,sett_stat,fee_stat,origin_id,ordr_id,is_cntn_tax,cap_acct_chk_stat,biz_tm,pay_tm,acct_chk_tm,fst_tm,stmt_no,source_id,yn_flag,proj_id,ex5_sellchanneltype,spv_cust_xt,dept_id
                      ,concat(spec_type_cd,spec_type_cd_new) as spec_type_cd
                      ,ex_one,ex_two,ex_three,ex_four,ex_five,ex_six,ex_seven,ex_eight,ex_nine,ex_ten,ex_fifteen
            from dmf_tmp.dmftmp_sett_spec_manage_tmp_mdl_04 t1
            lateral view explode(split(if(conn_spe_cols like '%dmf_product%',str_to_map(conn_spe_cols)['dmf_product'],''),'&')) t2 as accti_prod_cd_sub
            ) t1
      INNER JOIN (select  *
                        -- Modified by machunliang@20210616 解决从多个ID-X取值的问题
                        ,split(Mercht_09_ID, ',')[0] as Mercht_09_ID_1
                        ,split(Mercht_09_ID, ',')[1] as Mercht_09_ID_2
                        ,split(Mercht_09_ID, ',')[2] as Mercht_09_ID_3
                        ,split(Mercht_09_ID, ',')[3] as Mercht_09_ID_4

                        ,split(Mercht_10_ID, ',')[0] as Mercht_10_ID_1
                        ,split(Mercht_10_ID, ',')[1] as Mercht_10_ID_2
                        ,split(Mercht_10_ID, ',')[2] as Mercht_10_ID_3
                        ,split(Mercht_10_ID, ',')[3] as Mercht_10_ID_4
                        ,split(Mercht_10_ID, ',')[4] as Mercht_10_ID_5
                        ,split(Mercht_10_ID, ',')[5] as Mercht_10_ID_6
                        ,split(Mercht_10_ID, ',')[6] as Mercht_10_ID_7
                        ,split(Mercht_10_ID, ',')[7] as Mercht_10_ID_8
                        ,if(fst_biz_typ   = '', null, fst_biz_typ)   as fst_biz_typ1
                        ,if(Fst_Fee_Typ   = '', null, Fst_Fee_Typ)   as Fst_Fee_Typ1
                        ,if(Fst_sett_Scen = '', null, Fst_sett_Scen) as Fst_sett_Scen1
                        ,mod(cast(Recv_Pay_Acct_Get_Val_Ind as int),2) as RecvPay_Dir_Sign
                        ,if (Recv_Pay_Acct_Get_Val_Ind in ('2', '3'), -1, 1) as RecvPay_Amt_Parm
                    from dmf_bc.dmfbc_bc_fi_fst_indx_make_cnfg_s_d 
                   where dt = '4712-12-31'      -- 每次取最新配置表
                ) t2
             on  t2.Src_Sys                     = t1.Src_Sys
            and  t2.Src_Tab                     = t1.Src_Tab
            and  t2.Fst_Biz_Typ                 = t1.Fst_Biz_Typ
            -- Modified by machunliang@20210615 解决配置表中结算场景和费用类型是空串而非空值的异常问题
            -- and  NVL(t2.Fst_sett_Scen, t1.Fst_sett_Scen) = t1.Fst_sett_Scen
            -- and  NVL(t2.Fst_Fee_Typ,   t1.Fst_Fee_Typ)   = t1.Fst_Fee_Typ 
            and  NVL(t2.Fst_sett_Scen1, t1.Fst_sett_Scen) = t1.Fst_sett_Scen
            and  NVL(t2.Fst_Fee_Typ1,   t1.Fst_Fee_Typ)   = t1.Fst_Fee_Typ 
      --Added by renxiaowei7@20220106
      --核算产品获取-特殊逻辑处理-保险业务线拆分
      --计费明细扩展字段json串，ebs业务名称关联核算业务线配置中ebs业务线名称，获取核算产品
      left join (select     b1.parent_node_id as big_biz_type
                           ,b1.node_id as small_biz_type
                           ,b1.node_name as small_biz_type_name
                           ,b2.node_id as biz_line
                           ,b2.node_name as biz_line_name
                           ,b2.jdfin_code
                           ,b2.jdfin_name
                           ,b3.node_id as product_no
                           ,b3.node_name as product_name
                           --,row_number() over(partition by b2.jdfin_name order by b1.node_id,b2.node_id,b3.node_id) as rank
                           --Modified by renxiaowei7@20220216 从关联ebs业务线名称修改为关联核算业务线名称，锦钰和核算确认过
                           ,row_number() over(partition by b2.node_name order by b1.node_id,b2.node_id,b3.node_id) as rank
                 from (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online
                       from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
                       where  dt='{TX_DATE}'
                         and  status='1'  --业务线生效状态 0失效/1有效
                         and (if(expire_date is null,'',expire_date) = '' or expire_date > '{TX_DATE}')
                      ) b1  -- 一个节点处于有效状态的只会有一条数据
                 left join (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online,jdfin_code,jdfin_name
                            from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
                            where  dt='{TX_DATE}'
                              and  status='1'  --业务线生效状态 0失效/1有效
                              and (if(expire_date is null,'',expire_date) = '' or expire_date > '{TX_DATE}')
                           ) b2  -- 业务线配置表中业务线的上线状态不可用，只能使用业务小类的状态
                        on  b2.parent_node_id = b1.node_id
                 left join (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online
                            from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
                            where  dt='{TX_DATE}'
                              and  status='1'  --业务线生效状态 0失效/1有效
                              and (if(expire_date is null,'',expire_date) = '' or expire_date > '{TX_DATE}')
                           ) b3  -- 业务线配置表中业务线的上线状态不可用，只能使用业务小类的状态
                        on  b3.parent_node_id = b2.node_id
                     where  b1.parent_node_id='000009'
                       and  b1.node_id in ('100188','100189','100206','100226','100259')
                       and  if(b2.jdfin_code is null,'',b2.jdfin_code) not in ('800146','')  --ebs业务线为空不处理,800146使用下沉配置处理为固定值(800146 需要按照业务小类加区分逻辑)
                       and  if(b3.node_id is null,'',b3.node_id) != ''        --核算产品为空不处理
                 union all 
                 --兜底逻辑 保险业务-保代线下
                 select     '000009' as big_biz_type
                           ,'100206' as small_biz_type
                           ,'鼎鼎保代-线下业务' as small_biz_type_name
                           ,'201607' as biz_line
                           ,'保险业务-保代线下' as biz_line_name
                           ,'800625' as jdfin_code
                           ,'京东科技-保险业务-保代线下' as jdfin_name
                           ,'304981' as product_no
                           ,'保险业务-保代线下' as product_name
                           ,1 as rank
                 from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d
                 union all 
                 --兜底逻辑 保险业务-保险业务
                 select     '000009' as big_biz_type
                           ,'100206' as small_biz_type
                           ,'鼎鼎保代-线下业务' as small_biz_type_name
                           ,'201089' as biz_line
                           ,'保险业务-保险业务' as biz_line_name
                           ,'800146' as jdfin_code
                           ,'京东科技-保险业务-保险业务' as jdfin_name
                           ,'303505' as product_no
                           ,'保险业务-保险业务' as product_name
                           ,1 as rank
                 from dmf_dim.dmfdim_gj_hs_fi_hs_dual_a_d
                ) t3  
                 --这三个类型直接全部关联，如果其中有部分有单独的下沉，覆盖关联结果
                 --Modified by renxiaowei7@20220713 新增765业务
             on  t1.fst_biz_typ in ('820','828','833','765')
            and  t3.rank = 1
            --and  t1.ex_one = t3.jdfin_name
            --Modified by renxiaowei7@20220216 从关联ebs业务线名称修改为关联核算业务线名称，锦钰和核算确认过
            --and  t1.ex_one = t3.biz_line_name
            and (case when nvl(t1.ex_one,'')='' and nvl(t1.ex_fifteen,'')=''
                      then case when t1.fst_sett_scen in ('82016','82017') then '保险业务-保代线下'
                                when t1.fst_sett_scen in ('82018','82013','6204','6205') 
                                     or t1.fst_fee_typ in ('8208','8209','82010','82011','82012','82014') 
                                     or t1.fst_fee_typ in ('83308','83309','83310','83311','83312')
                                then '保险业务-保险业务'
                                else ''
                           end
                      else if(nvl(t1.ex_one,'')='',t1.ex_fifteen,t1.ex_one)
                 end) = t3.biz_line_name
      --Added by renxiaowei7@20221227
      --基金代销-按【sku信息字段】动态映射业务线，关联金蝶业务线编码
      left join (select     b1.parent_node_id as small_biz_type
                           ,b1.node_id as biz_line
                           ,b1.node_name as biz_line_name
                           ,b1.jdfin_code
                           ,b1.jdfin_name
                           ,b2.node_id as product_no
                           ,b2.node_name as product_name
                           ,row_number() over(partition by b1.jdfin_code order by b1.node_id,b2.node_id) as rank
                 from (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online,jdfin_code,jdfin_name
                       from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
                       where  dt='{TX_DATE}'
                         and  status='1'  --业务线生效状态 0失效/1有效
                         and (if(expire_date is null,'',expire_date) = '' or expire_date > '{TX_DATE}')
                      ) b1  -- 一个节点处于有效状态的只会有一条数据
                 left join (select id,node_id,node_name,parent_node_id,type,effective_date,expire_date,status,is_online
                            from odm.odm_fi_tz_dm_busi_type_s_d  --业务线配置
                            where  dt='{TX_DATE}'
                              and  status='1'  --业务线生效状态 0失效/1有效
                              and (if(expire_date is null,'',expire_date) = '' or expire_date > '{TX_DATE}')
                           ) b2  -- 业务线配置表中业务线的上线状态不可用，只能使用业务小类的状态
                        on  b2.parent_node_id = b1.node_id
                     where  b1.parent_node_id='100037'
                       and  coalesce(b1.jdfin_code,'') != ''  --ebs业务线为空不处理
                       and  coalesce(b2.node_id,'') != ''     --核算产品为空不处理
                ) t4
             on  t1.fst_biz_typ in ('149','758')
            and (   (t1.src_tab1='fee' and t1.fst_fee_typ in ('149120','14920') and substr(t1.cret_tm,1,10)>='2023-01-01' and substr(t1.tx_tm,1,10)>='2023-01-01')
                 or (t1.src_tab1='sett_fee' and t1.fst_sett_scen in ('149120','14920') and t1.sett_stat='1' and substr(coalesce(t1.tx_tm,''),1,10)>='2023-01-01')
                )
            and  t4.rank = 1
            and  coalesce(get_json_object(t1.ex_eight,'$.ebsProductNo'),'') = t4.jdfin_code
            
          where  t2.indx_id is not null

) t 
;
""",

}


# 以下部分无需改动，除非作业有特殊要求
return_code = sql_task.execute_sqls(sql_map_03)
exit(return_code)